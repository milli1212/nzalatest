/**
 * NzalaFamilly - Plateforme Numérique Familiale
 * Core Application Entrypoint
 */

import React, { useState } from 'react';
import { FamilyProvider, useFamily } from './context/FamilyContext';
import { Navbar } from './components/navigation/Navbar';
import { Sidebar } from './components/navigation/Sidebar';
import { LandingView } from './components/landing/LandingView';
import { DashboardView } from './components/dashboard/DashboardView';
import { UserProfileView } from './components/profile/UserProfileView';
import { AffiliationWizard } from './components/affiliation/AffiliationWizard';
import { MembersView } from './components/members/MembersView';
import { AlliancesView } from './components/alliances/AlliancesView';
import { VerificationCenterView } from './components/verification/VerificationCenterView';
import { GenealogyPreview } from './components/genealogy/GenealogyPreview';
import { EventsView } from './components/events/EventsView';
import { AnnouncementsView } from './components/announcements/AnnouncementsView';
import { MessagesView } from './components/messages/MessagesView';
import { AdminAuditView } from './components/admin/AdminAuditView';
import { MemoireNzalaView } from './components/memory/MemoireNzalaView';
import { DiscoveryView } from './components/discovery/DiscoveryView';
import { AdminPublicationModal } from './components/admin/AdminPublicationModal';
import { BirthdayCelebrationModal } from './components/events/BirthdayCelebrationModal';
import { AuthModal } from './components/auth/AuthModal';
import { ToastContainer } from './components/common/ToastContainer';
import { NzalaCallModal } from './components/calls/NzalaCallModal';
import { IncomingCallModal } from './components/calls/IncomingCallModal';
import { NotificationDrawer } from './components/notifications/NotificationDrawer';
import { NotificationSettingsModal } from './components/notifications/NotificationSettingsModal';
import { ReportModal } from './components/moderation/ReportModal';
import { CallsView } from './components/calls/CallsView';
import { SearchModalMobile } from './components/search/SearchModalMobile';
import { AdvancedSearchModal } from './components/search/AdvancedSearchModal';
import { SearchResult } from './types/search';
import { Search, Radio, Newspaper, PhoneCall, Bell } from 'lucide-react';

const MainLayout: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    activeCallSession,
    incomingCallSession,
    endActiveCall,
    toggleMuteCall,
    toggleVideoCall,
    switchCameraCall,
    toggleSpeakerCall,
    answerIncomingCall,
    rejectIncomingCall,
    notifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    isNotificationDrawerOpen,
    setIsNotificationDrawerOpen,
    isNotificationSettingsOpen,
    setIsNotificationSettingsOpen,
    notificationPreferences,
    updateNotificationPreferences,
    reportingTarget,
    setReportingTarget,
    submitSocialReport,
    adminPublicationModalOpen,
    setAdminPublicationModalOpen,
    birthdayCelebrationModalOpen,
    setBirthdayCelebrationModalOpen,
    activeBirthdayDraft,
    setActiveBirthdayDraft,
    setActiveConversationId,
    setSelectedPost,
    setSelectedMember,
    setSelectedEvent,
    setSelectedFamily,
    posts,
    members,
    events,
    families,
    liveStreams,
  } = useFamily();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false);
  const [isAdvancedSearchOpen, setIsAdvancedSearchOpen] = useState(false);

  // Auth modal state
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'LOGIN' | 'REGISTER' | 'RESET'>('LOGIN');

  const handleOpenAuth = (mode: 'LOGIN' | 'REGISTER' | 'RESET') => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  const handleSelectSearchResult = (res: SearchResult) => {
    setIsMobileSearchOpen(false);
    setIsAdvancedSearchOpen(false);

    if (res.type === 'MEMBER') {
      const targetMember = members.find((m) => m.id === res.targetId);
      if (targetMember) {
        setSelectedMember(targetMember);
        setActiveTab('members');
      }
    } else if (res.type === 'GENEALOGY_NODE' || res.type === 'BRANCH') {
      const targetMember = members.find((m) => m.id === res.targetId);
      if (targetMember) {
        setSelectedMember(targetMember);
      }
      setActiveTab('genealogy');
    } else if (res.type === 'FAMILY') {
      const targetFam = families.find((f) => f.id === res.targetId);
      if (targetFam) {
        setSelectedFamily(targetFam);
      }
      setActiveTab('alliances');
    } else if (res.type === 'POST') {
      const targetPost = posts.find((p) => p.id === res.targetId);
      if (targetPost) {
        setSelectedPost(targetPost);
      }
      setActiveTab('announcements');
    } else if (res.type === 'EVENT') {
      const targetEvent = events.find((e) => e.id === res.targetId);
      if (targetEvent) {
        setSelectedEvent(targetEvent);
      }
      setActiveTab('events');
    } else if (res.type === 'LIVE' || res.type === 'STORY') {
      setActiveTab('announcements');
    } else if (res.type === 'MEMORY_ALBUM' || res.type === 'HISTORICAL_FIGURE') {
      setActiveTab('memoire');
    } else if (res.linkTab) {
      setActiveTab(res.linkTab);
    }
  };

  const unreadNotificationsCount = notifications.filter((n) => !n.isRead).length;
  const activeLiveCount = liveStreams?.filter((l) => l.status === 'LIVE').length || 0;

  const renderActiveView = () => {
    switch (activeTab) {
      case 'landing':
        return <LandingView onOpenAuth={handleOpenAuth} />;
      case 'discovery':
        return <DiscoveryView />;
      case 'dashboard':
        return <DashboardView />;
      case 'profile':
        return <UserProfileView />;
      case 'affiliation':
        return <AffiliationWizard onCompleted={() => setActiveTab('profile')} />;
      case 'members':
        return <MembersView />;
      case 'alliances':
        return <AlliancesView />;
      case 'verifications':
        return <VerificationCenterView />;
      case 'genealogy':
        return <GenealogyPreview />;
      case 'memoire':
      case 'memory':
        return <MemoireNzalaView />;
      case 'events':
        return <EventsView />;
      case 'announcements':
        return <AnnouncementsView />;
      case 'messages':
        return <MessagesView />;
      case 'calls':
        return <CallsView />;
      case 'admin':
        return <AdminAuditView />;
      default:
        return <LandingView onOpenAuth={handleOpenAuth} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-900 selection:bg-blue-100 selection:text-blue-900">
      {/* Top Navbar (Strict 3 buttons on mobile: Messages, Profile/Login, Menu) */}
      <Navbar
        onMobileMenuToggle={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        isMobileMenuOpen={isMobileMenuOpen}
        onOpenAuth={handleOpenAuth}
      />

      {/* Main Body with Sidebar + Content */}
      <div className="flex-1 flex max-w-7xl w-full mx-auto pb-20 md:pb-0">
        <Sidebar
          isMobileOpen={isMobileMenuOpen}
          onCloseMobile={() => setIsMobileMenuOpen(false)}
        />

        <main className="flex-1 min-w-0 p-3 sm:p-5 lg:p-7 overflow-y-auto">
          {renderActiveView()}
        </main>
      </div>

      {/* MOBILE FLOATING BOTTOM BAR - STRICTLY 5 BUTTONS: Recherche, Live, Fil, Appel, Notifications */}
      <nav
        id="mobile-bottom-nav"
        className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-1.5 flex items-center justify-around shadow-lg pb-[max(0.375rem,env(safe-area-inset-bottom))]"
      >
        {/* 1. Recherche */}
        <button
          id="bottom-nav-search"
          onClick={() => setIsMobileSearchOpen(true)}
          className="flex flex-col items-center justify-center py-1 px-2 rounded-xl text-[10px] font-semibold text-slate-500 hover:text-blue-600 transition cursor-pointer min-h-[44px] min-w-[54px]"
          aria-label="Recherche"
        >
          <Search className="w-5 h-5 mb-0.5 text-slate-600" />
          <span className="leading-tight">Recherche</span>
        </button>

        {/* 2. Live */}
        <button
          id="bottom-nav-live"
          onClick={() => {
            setActiveTab('announcements');
          }}
          className={`relative flex flex-col items-center justify-center py-1 px-2 rounded-xl text-[10px] font-semibold transition cursor-pointer min-h-[44px] min-w-[54px] ${
            activeTab === 'announcements' && activeLiveCount > 0
              ? 'text-rose-600 font-bold'
              : 'text-slate-500 hover:text-rose-600'
          }`}
          aria-label="Live"
        >
          <div className="relative">
            <Radio className={`w-5 h-5 mb-0.5 ${activeLiveCount > 0 ? 'text-rose-600 animate-pulse' : 'text-slate-600'}`} />
            {activeLiveCount > 0 && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white"></span>
            )}
          </div>
          <span className="leading-tight">Live</span>
        </button>

        {/* 3. Fil */}
        <button
          id="bottom-nav-feed"
          onClick={() => setActiveTab('announcements')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl text-[10px] font-semibold transition cursor-pointer min-h-[44px] min-w-[54px] ${
            activeTab === 'announcements'
              ? 'text-blue-600 font-bold bg-blue-50/70'
              : 'text-slate-500 hover:text-slate-900'
          }`}
          aria-label="Fil Familial"
        >
          <Newspaper className="w-5 h-5 mb-0.5" />
          <span className="leading-tight">Fil</span>
        </button>

        {/* 4. Appel */}
        <button
          id="bottom-nav-call"
          onClick={() => setActiveTab('calls')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl text-[10px] font-semibold transition cursor-pointer min-h-[44px] min-w-[54px] ${
            activeTab === 'calls'
              ? 'text-blue-600 font-bold bg-blue-50/70'
              : 'text-slate-500 hover:text-blue-600'
          }`}
          aria-label="Appels Audio & Vidéo"
        >
          <PhoneCall className="w-5 h-5 mb-0.5" />
          <span className="leading-tight">Appel</span>
        </button>

        {/* 5. Notifications */}
        <button
          id="bottom-nav-notifications"
          onClick={() => setIsNotificationDrawerOpen(true)}
          className="relative flex flex-col items-center justify-center py-1 px-2 rounded-xl text-[10px] font-semibold text-slate-500 hover:text-blue-600 transition cursor-pointer min-h-[44px] min-w-[54px]"
          aria-label="Notifications"
        >
          <div className="relative">
            <Bell className="w-5 h-5 mb-0.5 text-slate-600" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute -top-1 -right-1.5 px-1 min-w-[14px] h-[14px] rounded-full bg-rose-500 text-white text-[9px] font-black flex items-center justify-center shadow-xs">
                {unreadNotificationsCount > 9 ? '9+' : unreadNotificationsCount}
              </span>
            )}
          </div>
          <span className="leading-tight">Notifs</span>
        </button>
      </nav>

      {/* Dedicated Fullscreen Mobile Search Modal (Preserves Background State) */}
      <SearchModalMobile
        isOpen={isMobileSearchOpen}
        onClose={() => setIsMobileSearchOpen(false)}
        onSelectResult={handleSelectSearchResult}
        onOpenAdvancedSearch={() => {
          setIsMobileSearchOpen(false);
          setIsAdvancedSearchOpen(true);
        }}
      />

      {/* Advanced Search Modal */}
      <AdvancedSearchModal
        isOpen={isAdvancedSearchOpen}
        onClose={() => setIsAdvancedSearchOpen(false)}
        onSelectResult={handleSelectSearchResult}
      />

      {/* Auth Modal (Login / Register / Reset) */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        initialMode={authModalMode}
      />

      {/* Active Audio/Video Call Screen */}
      <NzalaCallModal
        session={activeCallSession}
        onEndCall={endActiveCall}
        onToggleMute={toggleMuteCall}
        onToggleVideo={toggleVideoCall}
        onSwitchCamera={switchCameraCall}
        onToggleSpeaker={toggleSpeakerCall}
      />

      {/* Incoming Call Ringing Overlay */}
      <IncomingCallModal
        session={incomingCallSession}
        onAccept={answerIncomingCall}
        onReject={rejectIncomingCall}
      />

      {/* Notifications Drawer */}
      <NotificationDrawer
        isOpen={isNotificationDrawerOpen}
        onClose={() => setIsNotificationDrawerOpen(false)}
        notifications={notifications}
        onMarkAsRead={markNotificationAsRead}
        onMarkAllAsRead={markAllNotificationsAsRead}
        onNavigateToTarget={(linkTab, targetId) => {
          if (linkTab) {
            setActiveTab(linkTab);
            if (linkTab === 'messages' && targetId) {
              setActiveConversationId(targetId);
            } else if (linkTab === 'announcements' && targetId) {
              const p = posts.find((item) => item.id === targetId);
              if (p) setSelectedPost(p);
            }
          }
        }}
        onOpenSettings={() => setIsNotificationSettingsOpen(true)}
      />

      {/* Notification Preferences Modal */}
      <NotificationSettingsModal
        isOpen={isNotificationSettingsOpen}
        onClose={() => setIsNotificationSettingsOpen(false)}
        preferences={notificationPreferences}
        onUpdatePreferences={updateNotificationPreferences}
      />

      {/* Social & Content Report Modal */}
      {reportingTarget && (
        <ReportModal
          isOpen={!!reportingTarget}
          onClose={() => setReportingTarget(null)}
          targetType={reportingTarget.targetType}
          targetId={reportingTarget.targetId}
          targetTitle={reportingTarget.targetTitle}
          reportedUserId={reportingTarget.reportedUserId}
          reportedUserName={reportingTarget.reportedUserName}
          onSubmit={(data) => {
            submitSocialReport(data);
            setReportingTarget(null);
          }}
        />
      )}

      {/* Admin Official Publication Modal */}
      <AdminPublicationModal
        isOpen={adminPublicationModalOpen}
        onClose={() => setAdminPublicationModalOpen(false)}
        onSuccess={() => setActiveTab('announcements')}
      />

      {/* Birthday & Hommage Celebration Modal */}
      <BirthdayCelebrationModal
        isOpen={birthdayCelebrationModalOpen}
        onClose={() => {
          setBirthdayCelebrationModalOpen(false);
          setActiveBirthdayDraft(null);
        }}
        initialDraft={activeBirthdayDraft}
        onSuccess={() => setActiveTab('announcements')}
      />

      {/* Toast Notifications */}
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <FamilyProvider>
      <MainLayout />
    </FamilyProvider>
  );
}

