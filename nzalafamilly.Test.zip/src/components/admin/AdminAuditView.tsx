/**
 * NzalaFamilly - Console d'Administration, Gouvernance & Registre Souverain
 */

import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { VerificationStatus, UserRole, RelationshipStatus } from '../../types';
import {
  RoleBadge,
  StatusBadge,
  RelationshipStatusBadge,
  BelongingBadge,
  LivingStatusBadge,
  GenerationBadge,
} from '../common/Badges';
import { LinkAccountModal } from './LinkAccountModal';
import { AddRelationshipModal } from '../relationships/AddRelationshipModal';
import { AdminUsersTab } from './AdminUsersTab';
import { AdminRolesTab } from './AdminRolesTab';
import { AdminCertificationsTab } from './AdminCertificationsTab';
import { AdminTechnicalConfigTab } from './AdminTechnicalConfigTab';
import { AdminGeneralSettingsTab } from './AdminGeneralSettingsTab';
import {
  ShieldCheck,
  RotateCcw,
  CheckCircle2,
  Lock,
  History,
  FileCheck2,
  Users,
  Building2,
  KeyRound,
  AlertTriangle,
  Link2,
  Unlink,
  UserCheck,
  Clock,
  XCircle,
  HelpCircle,
  ChevronRight,
  Eye,
  Award,
  Server,
  Sliders,
  Sparkles,
} from 'lucide-react';

type AdminTab =
  | 'requests'
  | 'users'
  | 'roles'
  | 'certifications'
  | 'relationships'
  | 'technical'
  | 'settings'
  | 'audit';

export const AdminAuditView: React.FC = () => {
  const {
    auditLogs,
    verificationRequests,
    userAccounts,
    members,
    relationships,
    currentUser,
    processVerificationRequest,
    linkUserToMember,
    unlinkUserFromMember,
    validateRelationshipAction,
    deleteRelationship,
    resetToDefaults,
    certifications,
    showToast,
  } = useFamily();

  const [activeTab, setActiveTab] = useState<AdminTab>('requests');
  const [selectedReqId, setSelectedReqId] = useState<string | null>(null);
  const [reviewRole, setReviewRole] = useState<UserRole>('MEMBRE_NZALA');
  const [reviewMemberId, setReviewMemberId] = useState<string>('');
  const [reviewNotes, setReviewNotes] = useState<string>('');
  const [isLinkModalOpen, setIsLinkModalOpen] = useState(false);
  const [targetUserIdForLink, setTargetUserIdForLink] = useState<string>('');
  const [isAddRelModalOpen, setIsAddRelModalOpen] = useState(false);

  const pendingRequests = verificationRequests.filter(
    (r) => r.status === 'EN_ATTENTE' || r.status === 'EN_VERIFICATION'
  );
  const pendingRelationships = relationships.filter((r) => r.status === 'PROPOSEE');

  const selectedRequest = verificationRequests.find((r) => r.id === selectedReqId);

  const handleProcessRequest = (status: VerificationStatus) => {
    if (!selectedReqId) return;

    processVerificationRequest(
      selectedReqId,
      status,
      reviewNotes.trim() || `Décision administrative : ${status}`,
      reviewNotes.trim() || undefined
    );

    const targetReq = verificationRequests.find((r) => r.id === selectedReqId);
    if (status === 'APPROUVEE' && reviewMemberId && targetReq?.userId) {
      linkUserToMember(targetReq.userId, reviewMemberId);
    }

    setSelectedReqId(null);
    setReviewNotes('');
    setReviewMemberId('');
  };

  const navTabs: { id: AdminTab; label: string; icon: any; count?: number; color: string }[] = [
    {
      id: 'requests',
      label: "Demandes d'Affiliation",
      icon: FileCheck2,
      count: pendingRequests.length > 0 ? pendingRequests.length : undefined,
      color: 'text-purple-600',
    },
    {
      id: 'users',
      label: 'Utilisateurs & Fiches',
      icon: Users,
      count: userAccounts.length,
      color: 'text-blue-600',
    },
    {
      id: 'roles',
      label: 'Matrice RBAC',
      icon: KeyRound,
      color: 'text-emerald-600',
    },
    {
      id: 'certifications',
      label: 'Certifications & Badges',
      icon: Award,
      count: certifications.length,
      color: 'text-amber-500',
    },
    {
      id: 'relationships',
      label: 'Relations & Alliances',
      icon: Link2,
      count: pendingRelationships.length > 0 ? pendingRelationships.length : undefined,
      color: 'text-rose-500',
    },
    {
      id: 'technical',
      label: 'Production & Services',
      icon: Server,
      color: 'text-indigo-600',
    },
    {
      id: 'settings',
      label: 'Paramètres Généraux',
      icon: Sliders,
      color: 'text-slate-600',
    },
    {
      id: 'audit',
      label: "Journal d'Audit",
      icon: History,
      count: auditLogs.length,
      color: 'text-stone-600',
    },
  ];

  return (
    <div id="admin-audit-view" className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
              Gouvernance, Administration &amp; Registre
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-50 text-purple-900 border border-purple-200">
              Contrôle Souverain
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Gestion des utilisateurs, habilitations RBAC, certifications officielles, production et audit immuable.
          </p>
        </div>

        <button
          onClick={resetToDefaults}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold border border-slate-200 transition shrink-0 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Réinitialiser les données de démo</span>
        </button>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-1.5 p-1.5 rounded-2xl bg-slate-100 border border-slate-200 overflow-x-auto no-scrollbar">
        {navTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer shrink-0 ${
                isActive
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <Icon className={`w-4 h-4 ${tab.color}`} />
              <span>{tab.label}</span>
              {tab.count !== undefined && (
                <span
                  className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                    isActive ? 'bg-slate-900 text-white' : 'bg-slate-200 text-slate-800'
                  }`}
                >
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB 1: Verification Requests Queue */}
      {activeTab === 'requests' && (
        <div className="space-y-6">
          <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <FileCheck2 className="w-5 h-5 text-purple-700" />
                <h2 className="font-bold text-base text-slate-900">
                  File d'Instruction des Demandes d'Affiliation
                </h2>
              </div>
              <span className="text-xs text-slate-500 font-medium">
                {verificationRequests.length} demandes répertoriées
              </span>
            </div>

            {verificationRequests.length > 0 ? (
              <div className="space-y-3">
                {verificationRequests.map((req) => (
                  <div
                    key={req.id}
                    className={`p-4 rounded-2xl border transition ${
                      selectedReqId === req.id
                        ? 'bg-purple-50/70 border-purple-300 shadow-xs'
                        : 'bg-slate-50 border-slate-200 hover:border-purple-200'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-bold text-sm text-slate-900">
                            {req.applicantName}
                          </span>
                          <span className="text-slate-400 font-mono">({req.applicantEmail})</span>
                          <StatusBadge status={req.status} size="sm" />
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-200 text-slate-800">
                            {req.claimedFamilyType === 'NZALA_DIRECT'
                              ? 'Lignée Nzala'
                              : `Famille Alliée (${req.originFamilyName})`}
                          </span>
                        </div>

                        <div className="text-slate-600 space-y-0.5">
                          <p>
                            <strong>Filiation / Lien :</strong> {req.relationshipNature}{' '}
                            {req.targetNzalaMemberName ? `avec ${req.targetNzalaMemberName}` : ''}
                          </p>
                          {req.references && (
                            <p>
                              <strong>Témoins / Références :</strong> {req.references}
                            </p>
                          )}
                          {req.explanation && (
                            <p className="text-slate-500 italic">« {req.explanation} »</p>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {req.status === 'EN_ATTENTE' || req.status === 'EN_VERIFICATION' ? (
                          <button
                            onClick={() => {
                              setSelectedReqId(req.id);
                              setReviewRole(
                                req.claimedFamilyType === 'NZALA_DIRECT'
                                  ? 'MEMBRE_NZALA'
                                  : 'MEMBRE_ALLIE'
                              );
                            }}
                            className="px-4 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs shadow-xs transition cursor-pointer"
                          >
                            Instruire le dossier
                          </button>
                        ) : (
                          <span className="text-xs text-slate-500 font-medium">
                            Traité ({req.status})
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Instruction Box when selected */}
                    {selectedReqId === req.id && (
                      <div className="mt-4 pt-4 border-t border-purple-200/60 space-y-4 animate-in fade-in duration-150">
                        <h3 className="font-bold text-xs text-purple-950 uppercase tracking-wider">
                          Décision du Conseil d'Administration
                        </h3>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block font-bold text-slate-800 mb-1">
                              Rôle à attribuer après validation
                            </label>
                            <select
                              value={reviewRole}
                              onChange={(e) => setReviewRole(e.target.value as UserRole)}
                              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900 text-xs font-semibold"
                            >
                              <option value="MEMBRE_NZALA">👑 Membre Famille Nzala (Lignée Directe)</option>
                              <option value="MEMBRE_ALLIE">💍 Membre Famille Alliée</option>
                              <option value="VALIDATEUR">🛡️ Validateur du Conseil</option>
                              <option value="ADMIN_FAMILIAL">🏛️ Administrateur Familial</option>
                              <option value="VISITEUR">Visiteur (Accès Restreint)</option>
                            </select>
                          </div>

                          <div>
                            <label className="block font-bold text-slate-800 mb-1">
                              Lier à une fiche membre existante (optionnel)
                            </label>
                            <select
                              value={reviewMemberId}
                              onChange={(e) => setReviewMemberId(e.target.value)}
                              className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900 text-xs"
                            >
                              <option value="">-- Créer une nouvelle fiche membre automatiquement --</option>
                              {members.map((m) => (
                                <option key={m.id} value={m.id}>
                                  {m.firstName} {m.lastName} — G{m.generationLevel} ({m.primaryFamilyName})
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>

                        <div>
                          <label className="block font-bold text-slate-800 mb-1">
                            Motif ou remarques d'instruction (consigné dans l'audit)
                          </label>
                          <input
                            type="text"
                            value={reviewNotes}
                            onChange={(e) => setReviewNotes(e.target.value)}
                            placeholder="Ex: Filiation vérifiée auprès des aînés..."
                            className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900 text-xs"
                          />
                        </div>

                        <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
                          <button
                            type="button"
                            onClick={() => setSelectedReqId(null)}
                            className="px-3 py-1.5 rounded-lg text-slate-600 hover:bg-slate-200 text-xs font-semibold cursor-pointer"
                          >
                            Fermer
                          </button>

                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => handleProcessRequest('COMPLEMENT_REQUIS')}
                              className="px-3.5 py-2 rounded-xl bg-purple-100 hover:bg-purple-200 text-purple-900 font-bold text-xs transition cursor-pointer"
                            >
                              Demander un complément
                            </button>
                            <button
                              type="button"
                              onClick={() => handleProcessRequest('REFUSEE')}
                              className="px-3.5 py-2 rounded-xl bg-rose-100 hover:bg-rose-200 text-rose-900 font-bold text-xs transition cursor-pointer"
                            >
                              Refuser
                            </button>
                            <button
                              type="button"
                              onClick={() => handleProcessRequest('APPROUVEE')}
                              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition cursor-pointer"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                              <span>Valider &amp; Activer le compte</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 italic">Aucune demande d'adhésion pour le moment.</p>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: Users Management Full CRUD */}
      {activeTab === 'users' && <AdminUsersTab />}

      {/* TAB 3: RBAC Roles & Capabilities Matrix */}
      {activeTab === 'roles' && <AdminRolesTab />}

      {/* TAB 4: Official Certifications & Blue Badges */}
      {activeTab === 'certifications' && <AdminCertificationsTab />}

      {/* TAB 5: Relationships & Family Alliances */}
      {activeTab === 'relationships' && (
        <div className="space-y-6">
          <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h2 className="font-bold text-base text-slate-900">
                  Registre des Liens de Parenté &amp; Propositions d'Alliances
                </h2>
                <p className="text-xs text-slate-500">
                  Vérification de la cohérence généalogique et validation des liens proposés.
                </p>
              </div>

              <button
                onClick={() => setIsAddRelModalOpen(true)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs shadow-xs transition cursor-pointer"
              >
                <Link2 className="w-4 h-4" />
                <span>Ajouter / Proposer un lien</span>
              </button>
            </div>

            <div className="space-y-3">
              {relationships.map((rel) => {
                const memberA = members.find((m) => m.id === rel.memberAId);
                const memberB = members.find((m) => m.id === rel.memberBId);

                return (
                  <div
                    key={rel.id}
                    className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-bold text-slate-900">
                          {memberA ? `${memberA.firstName} ${memberA.lastName}` : rel.memberAName || rel.memberAId}
                        </span>
                        <span className="text-slate-400">↔</span>
                        <span className="font-bold text-slate-900">
                          {memberB ? `${memberB.firstName} ${memberB.lastName}` : rel.memberBName || rel.memberBId}
                        </span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-200 text-slate-800">
                          {rel.relationshipType.replace(/_/g, ' ')}
                        </span>
                        <RelationshipStatusBadge status={rel.status} size="sm" />
                      </div>

                      {rel.notes && (
                        <p className="text-slate-600 italic">Note : « {rel.notes} »</p>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {rel.status === 'PROPOSEE' && (
                        <>
                          <button
                            onClick={() => validateRelationshipAction(rel.id, 'VALIDEE')}
                            className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition cursor-pointer"
                          >
                            Valider le lien
                          </button>
                          <button
                            onClick={() => validateRelationshipAction(rel.id, 'REFUSEE')}
                            className="px-3 py-1.5 rounded-lg bg-rose-100 hover:bg-rose-200 text-rose-800 font-semibold text-xs transition cursor-pointer"
                          >
                            Rejeter
                          </button>
                        </>
                      )}
                      <button
                        onClick={() => deleteRelationship(rel.id)}
                        className="px-2.5 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold text-xs transition cursor-pointer"
                      >
                        Supprimer
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: Technical Configuration & Production Status */}
      {activeTab === 'technical' && <AdminTechnicalConfigTab />}

      {/* TAB 7: General Platform Settings */}
      {activeTab === 'settings' && <AdminGeneralSettingsTab />}

      {/* TAB 8: Sovereign Audit Log */}
      {activeTab === 'audit' && (
        <div className="p-5 sm:p-6 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <History className="w-5 h-5 text-amber-600" />
              <h2 className="font-bold text-base text-slate-900">
                Journal d'Audit Souverain &amp; Traçabilité Immuable
              </h2>
            </div>
            <span className="text-xs text-slate-500 font-medium">
              {auditLogs.length} opérations consignées
            </span>
          </div>

          <div className="space-y-3">
            {auditLogs.map((log) => (
              <div
                key={log.id}
                className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs hover:border-slate-300 transition"
              >
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-bold text-slate-900">{log.action.replace(/_/g, ' ')}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-200 text-slate-700">
                      {log.targetType}
                    </span>
                    <span className="text-slate-400">•</span>
                    <span className="text-slate-600 font-medium">Cible : {log.targetName}</span>
                  </div>

                  <p className="text-slate-600">{log.details}</p>
                </div>

                <div className="text-left sm:text-right shrink-0 space-y-0.5">
                  <div className="font-semibold text-slate-800">
                    Par {log.actorName} ({log.actorRole.replace('_', ' ')})
                  </div>
                  <div className="text-[11px] text-slate-400">
                    {new Date(log.timestamp).toLocaleString('fr-FR')}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Link Account Modal */}
      {isLinkModalOpen && (
        <LinkAccountModal
          isOpen={isLinkModalOpen}
          onClose={() => setIsLinkModalOpen(false)}
          targetUserId={targetUserIdForLink}
        />
      )}

      {/* Add Relationship Modal */}
      {isAddRelModalOpen && (
        <AddRelationshipModal
          isOpen={isAddRelModalOpen}
          onClose={() => setIsAddRelModalOpen(false)}
        />
      )}
    </div>
  );
};
