/**
 * NzalaFamilly - Gestionnaire des Certifications Officielles & Sceaux Personnalisés
 */

import React, { useState } from 'react';
import { AccountCertification, CertificationType, UserRole } from '../../types';
import { useFamily } from '../../context/FamilyContext';
import { VerifiedBadge } from '../common/VerifiedBadge';
import {
  Award,
  ShieldCheck,
  Plus,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Calendar,
  Sparkles,
  User,
  X,
  Mail,
  FileText,
  Palette,
  Check,
  Clock,
  ThumbsUp,
  ThumbsDown,
} from 'lucide-react';

const CERTIFICATION_TYPES: { type: CertificationType; label: string; icon: string; description: string }[] = [
  {
    type: 'SUPER_ADMIN',
    label: 'Super Administrateur de la Plateforme',
    icon: '👑',
    description: 'Contrôle souverain et gouvernance technique',
  },
  {
    type: 'ADMIN_FAMILIAL',
    label: 'Administrateur de Famille / Branche',
    icon: '🛡️',
    description: 'Gestionnaire d’une lignée ou d’une branche territoriale',
  },
  {
    type: 'SAGE_CONSEIL',
    label: 'Membre du Conseil des Sages',
    icon: '📜',
    description: 'Gardien de la tradition, garant des filiations et arbitre familial',
  },
  {
    type: 'MODERATEUR',
    label: 'Modérateur de Contenus Officiel',
    icon: '⚖️',
    description: 'Responsable du respect des règles et de la bienveillance',
  },
  {
    type: 'RESPONSABLE_OFFICIEL',
    label: 'Personnalité d’Honneur / Événements',
    icon: '🌟',
    description: 'Doyen, artiste, notable ou représentant officiel',
  },
];

const PRESET_COLORS = [
  { hex: '#EC4899', name: 'Rose Super Admin', desc: 'Réservé gouvernance suprême' },
  { hex: '#2563EB', name: 'Bleu Nzala', desc: 'Standard officiel certifié' },
  { hex: '#D97706', name: 'Or Sagesse', desc: 'Conseil des Sages & Doyens' },
  { hex: '#059669', name: 'Émeraude', desc: 'Modérateurs & Médiateurs' },
  { hex: '#7C3AED', name: 'Violet Royal', desc: 'Personnalités & Artistes' },
  { hex: '#0891B2', name: 'Cyan Lignée', desc: 'Responsables Alliances' },
];

export const AdminCertificationsTab: React.FC = () => {
  const {
    currentUser,
    userAccounts,
    certifications,
    certificationColorRequests,
    certifyAccount,
    revokeCertification,
    updateCertificationBadgeColor,
    approveCertificationColorRequest,
    rejectCertificationColorRequest,
    showToast,
  } = useFamily();

  const [activeTab, setActiveTab] = useState<'CERTIFICATIONS' | 'REQUESTS'>('CERTIFICATIONS');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState('');
  const [selectedType, setSelectedType] = useState<CertificationType>('SAGE_CONSEIL');
  const [badgeLabel, setBadgeLabel] = useState('Membre du Conseil des Sages');
  const [selectedColor, setSelectedColor] = useState('#2563EB');
  const [reason, setReason] = useState('');

  // Editing existing cert color modal
  const [editingCert, setEditingCert] = useState<AccountCertification | null>(null);
  const [editColorVal, setEditColorVal] = useState('#2563EB');

  const isSuperAdmin = currentUser.role === 'SUPER_ADMIN';
  const pendingRequests = certificationColorRequests.filter((r) => r.status === 'EN_ATTENTE');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserId) {
      showToast('error', 'Veuillez sélectionner un compte utilisateur.');
      return;
    }

    const targetUser = userAccounts.find((u) => u.id === selectedUserId);
    if (!targetUser) return;

    // Rule: if Super Admin type, default to pink if not overridden
    const finalColor =
      selectedType === 'SUPER_ADMIN' && selectedColor === '#2563EB' ? '#EC4899' : selectedColor;

    certifyAccount({
      userId: targetUser.id,
      userName: `${targetUser.firstName} ${targetUser.lastName}`,
      userEmail: targetUser.email,
      userRole: targetUser.role,
      familyName: targetUser.primaryFamilyName,
      certificationType: selectedType,
      badgeLabel: badgeLabel.trim() || 'Compte Officiel Certifié',
      icon: CERTIFICATION_TYPES.find((c) => c.type === selectedType)?.icon || '✓',
      badgeColor: finalColor,
      reason: reason.trim() || 'Attribution de responsabilité officielle par le Conseil.',
    });

    setIsModalOpen(false);
    setSelectedUserId('');
    setReason('');
    setSelectedColor('#2563EB');
  };

  const handleRevoke = (certId: string, userName: string) => {
    if (window.confirm(`Confirmez-vous le retrait de la certification officielle pour ${userName} ?`)) {
      revokeCertification(certId, 'Retrait par décision administrative');
    }
  };

  const handleSaveColorEdit = () => {
    if (!editingCert) return;
    updateCertificationBadgeColor(editingCert.id, editColorVal);
    setEditingCert(null);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-base text-slate-900 flex items-center gap-2 flex-wrap">
              <span>Sceaux de Certification &amp; Gouvernance</span>
              <span className="text-[11px] bg-blue-100 text-blue-900 px-2.5 py-0.5 rounded-full font-bold">
                {certifications.length} certifiés
              </span>
              {pendingRequests.length > 0 && (
                <span className="text-[11px] bg-rose-100 text-rose-800 px-2.5 py-0.5 rounded-full font-bold animate-pulse">
                  {pendingRequests.length} demande{pendingRequests.length > 1 ? 's' : ''} en attente
                </span>
              )}
            </h3>
            <p className="text-xs text-slate-500">
              Garantie d'authenticité, sceaux zigzagués personnalisés et gestion stricte par l'administration
            </p>
          </div>
        </div>

        {isSuperAdmin && (
          <button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition flex items-center gap-1.5 shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Attribuer un sceau de certification</span>
          </button>
        )}
      </div>

      {/* Sub tabs: Certifications vs Demandes */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          type="button"
          onClick={() => setActiveTab('CERTIFICATIONS')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'CERTIFICATIONS'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Comptes Certifiés Actifs ({certifications.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('REQUESTS')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'REQUESTS'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Palette className="w-4 h-4" />
          <span>Demandes de Couleurs &amp; Sceaux ({certificationColorRequests.length})</span>
          {pendingRequests.length > 0 && (
            <span className="w-2 h-2 rounded-full bg-rose-500" />
          )}
        </button>
      </div>

      {/* Tab 1: Certifications List */}
      {activeTab === 'CERTIFICATIONS' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {certifications.map((cert) => {
            const isSuper = cert.certificationType === 'SUPER_ADMIN' || cert.userRole === 'SUPER_ADMIN';
            const badgeColor = cert.badgeColor || (isSuper ? '#EC4899' : '#2563EB');

            return (
              <div
                key={cert.id}
                className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-3 hover:border-blue-200 transition"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className="w-12 h-12 rounded-2xl flex items-center justify-center text-xl shrink-0 border"
                      style={{
                        backgroundColor: `${badgeColor}12`,
                        borderColor: `${badgeColor}35`,
                      }}
                    >
                      {cert.icon || '🎖️'}
                    </div>

                    <div className="space-y-0.5 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h4 className="font-bold text-sm text-slate-900 truncate">
                          {cert.userName}
                        </h4>
                        <VerifiedBadge
                          role={cert.userRole}
                          isVerified={true}
                          customColor={badgeColor}
                          badgeLabel={cert.badgeLabel}
                          size="md"
                        />
                      </div>
                      <p className="text-xs font-semibold" style={{ color: badgeColor }}>
                        {cert.badgeLabel}
                      </p>
                      <p className="text-[11px] text-slate-400 font-mono truncate">
                        {cert.userEmail}
                      </p>
                    </div>
                  </div>

                  {isSuperAdmin && (
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => {
                          setEditingCert(cert);
                          setEditColorVal(badgeColor);
                        }}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition cursor-pointer"
                        title="Modifier la couleur du sceau"
                      >
                        <Palette className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleRevoke(cert.id, cert.userName)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
                        title="Révoquer cette certification"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs text-slate-600 space-y-1.5">
                  <p>
                    <strong>Motif &amp; Décision :</strong> {cert.reason}
                  </p>
                  <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-200/60">
                    <span>Délivré le : {cert.certifiedAt?.split('T')[0] || 'Actif'}</span>
                    <span className="flex items-center gap-1 font-semibold">
                      <span>Couleur :</span>
                      <span
                        className="inline-block w-3 h-3 rounded-full border border-slate-300"
                        style={{ backgroundColor: badgeColor }}
                      />
                      <span>{badgeColor}</span>
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Tab 2: Requests List */}
      {activeTab === 'REQUESTS' && (
        <div className="space-y-4">
          {certificationColorRequests.length === 0 ? (
            <div className="bg-white p-8 rounded-3xl border border-slate-200 text-center text-slate-500 text-xs">
              Aucune demande de couleur ou de badge en cours.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {certificationColorRequests.map((req) => (
                <div
                  key={req.id}
                  className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-bold text-sm text-slate-900">{req.userName}</h4>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            req.status === 'EN_ATTENTE'
                              ? 'bg-amber-100 text-amber-800'
                              : req.status === 'APPROUVEE'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {req.status === 'EN_ATTENTE'
                            ? 'En attente'
                            : req.status === 'APPROUVEE'
                            ? 'Approuvée'
                            : 'Refusée'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 font-mono">{req.userEmail}</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <div
                        className="w-6 h-6 rounded-full border border-slate-300 shadow-2xs"
                        style={{ backgroundColor: req.requestedColor }}
                        title={`Couleur demandée : ${req.requestedColor}`}
                      />
                      <VerifiedBadge
                        role={req.userRole}
                        isVerified={true}
                        customColor={req.requestedColor}
                        badgeLabel={req.requestedLabel || 'Aperçu'}
                        size="sm"
                      />
                    </div>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs text-slate-600 space-y-1">
                    <p>
                      <strong>Libellé souhaité :</strong> {req.requestedLabel || 'Non spécifié'}
                    </p>
                    <p>
                      <strong>Motivation :</strong> {req.reason}
                    </p>
                    {req.adminDecisionNotes && (
                      <p className="text-slate-500 italic pt-1 border-t border-slate-200/60">
                        <strong>Note administrative :</strong> {req.adminDecisionNotes}
                      </p>
                    )}
                  </div>

                  {isSuperAdmin && req.status === 'EN_ATTENTE' && (
                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={() => {
                          const note = prompt('Motif du refus (optionnel) :');
                          rejectCertificationColorRequest(req.id, note || 'Refusé');
                        }}
                        className="px-3 py-1.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-rose-50 hover:text-rose-700 font-bold text-xs transition cursor-pointer"
                      >
                        Refuser
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          approveCertificationColorRequest(req.id, req.requestedColor);
                        }}
                        className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition cursor-pointer flex items-center gap-1 shadow-2xs"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Valider &amp; Attribuer</span>
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Grant Certification Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-base text-slate-900">
                  Attribuer un Sceau de Certification
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="space-y-4 text-xs">
              {/* Select User */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Compte Utilisateur à certifier
                </label>
                <select
                  required
                  value={selectedUserId}
                  onChange={(e) => setSelectedUserId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900 font-semibold"
                >
                  <option value="">-- Choisir un utilisateur --</option>
                  {userAccounts.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.firstName} {u.lastName} ({u.email}) — {u.role}
                    </option>
                  ))}
                </select>
              </div>

              {/* Select Certification Type */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Type de Titre / Responsabilité
                </label>
                <select
                  value={selectedType}
                  onChange={(e) => {
                    const nextType = e.target.value as CertificationType;
                    setSelectedType(nextType);
                    const def = CERTIFICATION_TYPES.find((c) => c.type === nextType);
                    if (def) setBadgeLabel(def.label);
                    if (nextType === 'SUPER_ADMIN') {
                      setSelectedColor('#EC4899');
                    } else if (nextType === 'SAGE_CONSEIL') {
                      setSelectedColor('#2563EB');
                    }
                  }}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900 font-semibold"
                >
                  {CERTIFICATION_TYPES.map((ct) => (
                    <option key={ct.type} value={ct.type}>
                      {ct.icon} {ct.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Choose Badge Color */}
              <div>
                <label className="block font-bold text-slate-700 mb-1.5 flex items-center justify-between">
                  <span>Couleur du Sceau Zigzagué</span>
                  <span className="text-[11px] text-slate-400 font-mono">{selectedColor}</span>
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {PRESET_COLORS.map((c) => (
                    <button
                      key={c.hex}
                      type="button"
                      onClick={() => setSelectedColor(c.hex)}
                      className={`p-2 rounded-xl border text-left flex items-center gap-2 transition cursor-pointer ${
                        selectedColor === c.hex
                          ? 'border-blue-600 bg-blue-50/50 ring-2 ring-blue-500/20'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <span
                        className="w-4 h-4 rounded-full shrink-0 border border-slate-300"
                        style={{ backgroundColor: c.hex }}
                      />
                      <span className="font-semibold text-[11px] text-slate-800 truncate">{c.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Live Preview */}
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <span className="font-semibold text-slate-600">Aperçu en direct du sceau :</span>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900">Utilisateur</span>
                  <VerifiedBadge
                    role={selectedType === 'SUPER_ADMIN' ? 'SUPER_ADMIN' : 'ADMIN_FAMILIAL'}
                    isVerified={true}
                    customColor={selectedColor}
                    badgeLabel={badgeLabel}
                    size="lg"
                  />
                </div>
              </div>

              {/* Custom Label */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Libellé du Badge Public
                </label>
                <input
                  type="text"
                  required
                  value={badgeLabel}
                  onChange={(e) => setBadgeLabel(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900"
                />
              </div>

              {/* Reason */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Justification Administrative &amp; Références
                </label>
                <textarea
                  required
                  rows={3}
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Décision du Conseil des Sages lors de l'assemblée..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-xs cursor-pointer"
                >
                  Valider la Certification
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Color Modal */}
      {editingCert && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Palette className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-base text-slate-900">
                  Modifier la Couleur du Sceau
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingCert(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-sm text-slate-900">{editingCert.userName}</h4>
                  <p className="text-slate-500">{editingCert.badgeLabel}</p>
                </div>
                <VerifiedBadge
                  role={editingCert.userRole}
                  isVerified={true}
                  customColor={editColorVal}
                  size="lg"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-2">
                  Sélectionnez la nouvelle couleur :
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {PRESET_COLORS.map((c) => (
                    <button
                      key={c.hex}
                      type="button"
                      onClick={() => setEditColorVal(c.hex)}
                      className={`p-2.5 rounded-xl border text-left flex items-center gap-2 transition cursor-pointer ${
                        editColorVal === c.hex
                          ? 'border-blue-600 bg-blue-50/50 ring-2 ring-blue-500/20'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <span
                        className="w-4 h-4 rounded-full shrink-0 border border-slate-300"
                        style={{ backgroundColor: c.hex }}
                      />
                      <div>
                        <p className="font-bold text-slate-800">{c.name}</p>
                        <p className="text-[10px] text-slate-400">{c.hex}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingCert(null)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="button"
                  onClick={handleSaveColorEdit}
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-xs cursor-pointer"
                >
                  Enregistrer
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
