/**
 * NzalaFamilly - Paramètres Généraux de la Plateforme (Super Admin)
 */

import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import {
  Settings,
  Sliders,
  Shield,
  Eye,
  Clock,
  Sparkles,
  MessageSquare,
  Globe,
  Save,
  CheckCircle2,
} from 'lucide-react';

export const AdminGeneralSettingsTab: React.FC = () => {
  const { showToast } = useFamily();

  const [platformName, setPlatformName] = useState('NzalaFamilly');
  const [platformMotto, setPlatformMotto] = useState('Union, Tradition, Souveraineté & Préservation');
  const [foundationYear, setFoundationYear] = useState('1910');
  const [defaultTreeVisibility, setDefaultTreeVisibility] = useState<'MEMBERS_ONLY' | 'ALLIED' | 'PUBLIC'>('MEMBERS_ONLY');
  const [defaultProfilePrivacy, setDefaultProfilePrivacy] = useState<'PRIVATE' | 'MEMBERS' | 'PUBLIC'>('MEMBERS');
  const [storyExpirationHours, setStoryExpirationHours] = useState('24');
  const [allowViewOnce, setAllowViewOnce] = useState(true);
  const [autoModeratePosts, setAutoModeratePosts] = useState(true);
  const [allowPublicVisitorRegistration, setAllowPublicVisitorRegistration] = useState(true);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    showToast('success', 'Paramètres généraux de la plateforme enregistrés avec succès.');
  };

  return (
    <form onSubmit={handleSave} className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-base text-slate-900">
              Paramètres Généraux de NzalaFamilly
            </h3>
            <p className="text-xs text-slate-500">
              Configuration globale de la plateforme, des règles d'accès et des paramètres sociaux
            </p>
          </div>
        </div>

        <button
          type="submit"
          className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition flex items-center gap-1.5 shrink-0 cursor-pointer"
        >
          <Save className="w-4 h-4" />
          <span>Enregistrer les paramètres</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Section 1: Identité */}
        <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <Globe className="w-4 h-4 text-blue-600" />
            <h4 className="font-bold text-sm text-slate-900">Identité &amp; Héritage</h4>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Nom de la Plateforme</label>
              <input
                type="text"
                value={platformName}
                onChange={(e) => setPlatformName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Devise Familiale Ancestrale</label>
              <input
                type="text"
                value={platformMotto}
                onChange={(e) => setPlatformMotto(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Année Historique de Référence</label>
              <input
                type="text"
                value={foundationYear}
                onChange={(e) => setFoundationYear(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Confidentialité & Accès */}
        <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <Shield className="w-4 h-4 text-purple-600" />
            <h4 className="font-bold text-sm text-slate-900">Confidentialité &amp; Protection des Données</h4>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Visibilité par défaut de l'Arbre</label>
              <select
                value={defaultTreeVisibility}
                onChange={(e: any) => setDefaultTreeVisibility(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900 font-semibold"
              >
                <option value="MEMBERS_ONLY">🔒 Membres Nzala &amp; Familles Alliées Uniquement</option>
                <option value="ALLIED">💍 Familles Alliées Confirmées</option>
                <option value="PUBLIC">🌍 Public avec Masquage des Vivants</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Niveau de Confidentialité des Nouveaux Profils</label>
              <select
                value={defaultProfilePrivacy}
                onChange={(e: any) => setDefaultProfilePrivacy(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900 font-semibold"
              >
                <option value="MEMBERS">👥 Visible par les membres de la famille</option>
                <option value="PRIVATE">🔒 Profil Privé Strict</option>
                <option value="PUBLIC">🌍 Profil Public</option>
              </select>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <div>
                <p className="font-bold text-slate-800">Inscriptions Visiteurs Ouvertes</p>
                <p className="text-[11px] text-slate-500">Permettre aux visiteurs de déposer une demande d’affiliation</p>
              </div>
              <input
                type="checkbox"
                checked={allowPublicVisitorRegistration}
                onChange={(e) => setAllowPublicVisitorRegistration(e.target.checked)}
                className="w-4 h-4 text-blue-600 rounded"
              />
            </div>
          </div>
        </div>

        {/* Section 3: Stories & Fil Familial */}
        <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <h4 className="font-bold text-sm text-slate-900">Stories &amp; Fil Familial</h4>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Durée d'expiration des Stories</label>
              <select
                value={storyExpirationHours}
                onChange={(e) => setStoryExpirationHours(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900 font-semibold"
              >
                <option value="12">12 Heures</option>
                <option value="24">24 Heures (Standard)</option>
                <option value="48">48 Heures (Week-end familial)</option>
              </select>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <div>
                <p className="font-bold text-slate-800">Modération Automatique des Contenus</p>
                <p className="text-[11px] text-slate-500">Filtre anti-injures et mise en attente si signalements multiples</p>
              </div>
              <input
                type="checkbox"
                checked={autoModeratePosts}
                onChange={(e) => setAutoModeratePosts(e.target.checked)}
                className="w-4 h-4 text-blue-600 rounded"
              />
            </div>
          </div>
        </div>

        {/* Section 4: Messagerie & View-Once */}
        <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <MessageSquare className="w-4 h-4 text-indigo-600" />
            <h4 className="font-bold text-sm text-slate-900">Messagerie &amp; Sécurité View-Once</h4>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-bold text-slate-800">Activer le Mode Vue Unique (View-Once)</p>
                <p className="text-[11px] text-slate-500">Permettre l’envoi de photos/vidéos éphémères détruites à la lecture</p>
              </div>
              <input
                type="checkbox"
                checked={allowViewOnce}
                onChange={(e) => setAllowViewOnce(e.target.checked)}
                className="w-4 h-4 text-blue-600 rounded"
              />
            </div>
          </div>
        </div>
      </div>
    </form>
  );
};
