import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { PostType, PostScope, MediaItem, Member } from '../../types';
import { NzalaLogo } from '../common/NzalaLogo';
import { NzalaAvatar } from '../common/NzalaAvatar';
import {
  X,
  Sparkles,
  Send,
  Eye,
  Edit3,
  Image as ImageIcon,
  Plus,
  Trash2,
  Lock,
  Globe,
  Users,
  ShieldCheck,
  Award,
  Heart,
  Baby,
  GraduationCap,
  Briefcase,
  AlertTriangle,
  Megaphone,
  BookOpen,
} from 'lucide-react';

interface AdminPublicationModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialType?: PostType;
  initialMemberId?: string;
  onSuccess?: () => void;
}

export const AdminPublicationModal: React.FC<AdminPublicationModalProps> = ({
  isOpen,
  onClose,
  initialType = 'COMMUNIQUE_OFFICIEL',
  initialMemberId,
  onSuccess,
}) => {
  const {
    currentUser,
    members,
    branches,
    createAdminOfficialPost,
    showToast,
  } = useFamily();

  // Form State
  const [postType, setPostType] = useState<PostType>(initialType);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [selectedMemberId, setSelectedMemberId] = useState<string>(initialMemberId || '');
  const [scope, setScope] = useState<PostScope>('PUBLIC');
  const [targetBranchId, setTargetBranchId] = useState<string>('');
  const [isOfficial, setIsOfficial] = useState(true);
  const [isImportant, setIsImportant] = useState(false);

  // Photos State
  const [mediaList, setMediaList] = useState<Array<{ url: string; caption: string }>>([]);
  const [newPhotoUrl, setNewPhotoUrl] = useState('');
  const [newPhotoCaption, setNewPhotoCaption] = useState('');

  // Preview Mode
  const [previewMode, setPreviewMode] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  if (!isOpen) return null;

  const targetMember = members.find((m) => m.id === selectedMemberId);

  // Category Configuration
  const categoryConfigs: Record<
    string,
    { label: string; icon: any; color: string; placeholder: string; defaultTitle: string }
  > = {
    COMMUNIQUE: {
      label: 'Communiqué Officiel',
      icon: Megaphone,
      color: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      placeholder: 'Rédigez le communiqué officiel à l\'attention de la communauté...',
      defaultTitle: 'COMMUNIQUÉ OFFICIEL DE LA FAMILLE NZALA',
    },
    ANNIVERSAIRE: {
      label: 'Anniversaire & Célébration',
      icon: Sparkles,
      color: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
      placeholder: 'Rédigez le message solennel d\'anniversaire et de bénédiction...',
      defaultTitle: `Joyeux Anniversaire à notre cher(e) ${targetMember ? targetMember.firstName : 'membre'} ! 🎂`,
    },
    NAISSANCE: {
      label: 'Heureuse Naissance',
      icon: Baby,
      color: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
      placeholder: 'Annoncez la naissance d\'un nouveau-né au sein de notre grande famille...',
      defaultTitle: 'Carnet Rose : Bienvenue à un nouvel enfant dans la famille ! 👶',
    },
    MARIAGE: {
      label: 'Mariage & Alliance',
      icon: Heart,
      color: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
      placeholder: 'Célébrez l\'union sacrée et le renforcement des liens d\'alliance...',
      defaultTitle: 'Félicitations pour cette belle alliance matrimoniale ! 💍',
    },
    REUSSITE: {
      label: 'Réussite & Diplôme',
      icon: GraduationCap,
      color: 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30',
      placeholder: 'Félicitez un lauréat ou diplômé de notre jeunesse...',
      defaultTitle: 'Honneur & Félicitations pour cette brillante réussite académique ! 🎓',
    },
    PROMOTION: {
      label: 'Promotion & Distinction',
      icon: Award,
      color: 'bg-amber-600/20 text-amber-300 border-amber-500/30',
      placeholder: 'Soulignez une nomination ou une distinction d\'honneur...',
      defaultTitle: 'Distinction d\'Honneur & Évolution Professionnelle 🌟',
    },
    DECES: {
      label: 'Nécrologie & Deuil',
      icon: AlertTriangle,
      color: 'bg-stone-500/20 text-stone-300 border-stone-500/30',
      placeholder: 'Faites part du rappel à Dieu d\'un être cher avec recueillement...',
      defaultTitle: 'Avis de Décès & Programme des Obsèques 🕊️',
    },
    HOMMAGE: {
      label: 'Hommage & Mémoire',
      icon: BookOpen,
      color: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
      placeholder: 'Rendez hommage à une figure disparue ou commémorez un anniversaire de rappel à Dieu...',
      defaultTitle: 'Pensée Pieuse & Hommage Solennel à la Mémoire de notre Ancien 🕊️',
    },
    HISTOIRE: {
      label: 'Histoire Familiale & Souvenir',
      icon: BookOpen,
      color: 'bg-amber-700/20 text-amber-300 border-amber-700/30',
      placeholder: 'Partagez une anecdote, un proverbe coutumier ou un récit d\'époque...',
      defaultTitle: 'Récit du Patrimoine : Les Enseignements de nos Aînés 📜',
    },
    AUTRE: {
      label: 'Publication Libre',
      icon: Edit3,
      color: 'bg-teal-500/20 text-teal-400 border-teal-500/30',
      placeholder: 'Rédigez librement votre publication administrative...',
      defaultTitle: 'Information Familiale',
    },
  };

  const currentConfig = categoryConfigs[postType] || categoryConfigs.COMMUNIQUE;

  const handleAddPhoto = () => {
    if (!newPhotoUrl.trim()) return;
    setMediaList((prev) => [
      ...prev,
      {
        url: newPhotoUrl.trim(),
        caption: newPhotoCaption.trim(),
      },
    ]);
    setNewPhotoUrl('');
    setNewPhotoCaption('');
  };

  const handleRemovePhoto = (idx: number) => {
    setMediaList((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) {
      showToast('error', 'Veuillez saisir le texte de la publication.');
      return;
    }

    setSubmitting(true);

    const formattedMedia: MediaItem[] = mediaList.map((m, idx) => ({
      id: `med-${Date.now()}-${idx}`,
      type: 'IMAGE',
      url: m.url,
      caption: m.caption,
    }));

    const result = createAdminOfficialPost({
      title: title.trim() || currentConfig.defaultTitle,
      content: content.trim(),
      postType: postType,
      relatedMemberId: targetMember?.id,
      relatedMemberName: targetMember ? `${targetMember.firstName} ${targetMember.lastName}` : undefined,
      media: formattedMedia,
      scope: scope,
      isOfficial: isOfficial,
      isImportant: isImportant,
    });

    setSubmitting(false);

    if (result.success) {
      showToast('success', 'Publication administrative officielle publiée avec succès !');
      onSuccess?.();
      onClose();
    } else {
      showToast('error', result.error || 'Erreur lors de la publication.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-3xl my-8 bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-stone-900 via-stone-850 to-stone-900 text-stone-100 border-b border-amber-500/20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <NzalaLogo variant="icon" size="sm" />
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-serif font-bold text-stone-100">
                  Publication Administrative &amp; Événementielle
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500 text-stone-950">
                  Administration
                </span>
              </div>
              <p className="text-xs text-stone-400">
                Créez une annonce officielle, célébrez un anniversaire ou honorez la mémoire d'un membre.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-white hover:bg-stone-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toggle Mode (Édition vs Aperçu) */}
        <div className="px-6 py-2 bg-stone-100 dark:bg-stone-850 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setPreviewMode(false)}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg font-bold transition cursor-pointer ${
                !previewMode
                  ? 'bg-amber-500 text-stone-950'
                  : 'text-stone-600 dark:text-stone-300 hover:text-white'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Formulaire d'édition</span>
            </button>
            <button
              type="button"
              onClick={() => setPreviewMode(true)}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg font-bold transition cursor-pointer ${
                previewMode
                  ? 'bg-amber-500 text-stone-950'
                  : 'text-stone-600 dark:text-stone-300 hover:text-white'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Aperçu en direct</span>
            </button>
          </div>

          <span className="text-[11px] text-stone-500">
            Auteur : <strong>{currentUser.name}</strong> ({currentUser.role})
          </span>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {!previewMode ? (
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Type Selector */}
              <div className="space-y-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300">
                  Type d'annonce administrative
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {Object.entries(categoryConfigs).map(([key, cfg]) => {
                    const Icon = cfg.icon;
                    const isSelected = postType === key;
                    return (
                      <button
                        key={key}
                        type="button"
                        onClick={() => {
                          setPostType(key as PostType);
                          if (!title) setTitle(cfg.defaultTitle);
                        }}
                        className={`p-3 rounded-2xl border text-left flex flex-col justify-between gap-2 transition cursor-pointer ${
                          isSelected
                            ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-500 text-amber-900 dark:text-amber-300 ring-2 ring-amber-500/20'
                            : 'bg-stone-50 dark:bg-stone-850 border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:border-stone-400'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <Icon className={`w-4 h-4 ${isSelected ? 'text-amber-600' : 'text-stone-400'}`} />
                          {isSelected && <span className="text-xs">✓</span>}
                        </div>
                        <span className="text-xs font-bold leading-tight">{cfg.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Target Member (Optionnel, ex: Personne fêtée ou honorée) */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300">
                  Personne concernée (Fiche généalogique / Membre avec ou sans compte)
                </label>
                <select
                  value={selectedMemberId}
                  onChange={(e) => setSelectedMemberId(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-700 text-xs sm:text-sm text-stone-900 dark:text-stone-100 focus:ring-2 focus:ring-amber-500"
                >
                  <option value="">-- Aucune personne spécifique (Communiqué général) --</option>
                  {members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.firstName} {m.lastName} ({m.primaryFamilyName} • G{m.generationLevel}
                      {m.livingStatus === 'DECEDE' ? ' • Défunt🕊️' : ''})
                    </option>
                  ))}
                </select>
                {targetMember && (
                  <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center gap-3 text-xs">
                    <NzalaAvatar
                      name={`${targetMember.firstName} ${targetMember.lastName}`}
                      src={targetMember.avatarUrl}
                      size="sm"
                      livingStatus={targetMember.livingStatus}
                    />
                    <div>
                      <div className="font-bold text-stone-900 dark:text-stone-100">
                        {targetMember.firstName} {targetMember.lastName}
                      </div>
                      <div className="text-stone-500 dark:text-stone-400">
                        {targetMember.branchName || targetMember.primaryFamilyName} •{' '}
                        {targetMember.livingStatus === 'DECEDE' ? 'Statut : Défunt(e)' : 'Statut : Vivant(e)'}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Title Input */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300">
                  Titre de la publication
                </label>
                <input
                  type="text"
                  placeholder={currentConfig.defaultTitle}
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-700 text-sm font-semibold text-stone-900 dark:text-stone-100 focus:ring-2 focus:ring-amber-500"
                />
              </div>

              {/* Content Textarea */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300">
                  Contenu détaillé &amp; Message officiel <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={5}
                  required
                  placeholder={currentConfig.placeholder}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="w-full p-4 rounded-xl bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-700 text-sm text-stone-900 dark:text-stone-100 focus:ring-2 focus:ring-amber-500 leading-relaxed font-sans"
                />
              </div>

              {/* Photos & Documents d'Illustration */}
              <div className="space-y-3 p-4 rounded-2xl bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-700">
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300">
                  Photographies &amp; Documents joints ({mediaList.length})
                </label>

                {/* List of already added photos */}
                {mediaList.length > 0 && (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {mediaList.map((m, i) => (
                      <div
                        key={i}
                        className="relative rounded-xl overflow-hidden border border-stone-300 dark:border-stone-700 group bg-stone-950"
                      >
                        <img
                          src={m.url}
                          alt={m.caption || `Photo ${i + 1}`}
                          className="w-full h-24 object-cover"
                          referrerPolicy="no-referrer"
                        />
                        <button
                          type="button"
                          onClick={() => handleRemovePhoto(i)}
                          className="absolute top-1 right-1 p-1 rounded-full bg-rose-600 text-white opacity-90 hover:opacity-100 transition cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                        {m.caption && (
                          <div className="p-1.5 text-[10px] text-stone-300 truncate bg-stone-900/90">
                            {m.caption}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {/* Add Photo Input */}
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="url"
                    placeholder="URL de l'image (ex: https://images.unsplash.com/...)"
                    value={newPhotoUrl}
                    onChange={(e) => setNewPhotoUrl(e.target.value)}
                    className="flex-1 px-3 py-2 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 text-xs text-stone-900 dark:text-stone-100"
                  />
                  <input
                    type="text"
                    placeholder="Légende d'époque / description"
                    value={newPhotoCaption}
                    onChange={(e) => setNewPhotoCaption(e.target.value)}
                    className="flex-1 px-3 py-2 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 text-xs text-stone-900 dark:text-stone-100"
                  />
                  <button
                    type="button"
                    onClick={handleAddPhoto}
                    disabled={!newPhotoUrl.trim()}
                    className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-stone-950 font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Ajouter</span>
                  </button>
                </div>
              </div>

              {/* Diffusion & Scope Settings */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300">
                    Périmètre de visibilité
                  </label>
                  <select
                    value={scope}
                    onChange={(e) => setScope(e.target.value as PostScope)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-700 text-xs text-stone-900 dark:text-stone-100"
                  >
                    <option value="PUBLIC">🌐 Public (Toute la famille &amp; Alliances)</option>
                    <option value="FAMILLE_DIRECTE">🛡️ Famille Nzala Directe Uniquement</option>
                    <option value="INTER_FAMILLES">🤝 Inter-Familles &amp; Alliés Spécifiques</option>
                    <option value="RESTREINT">🔒 Conseil de Famille / Administration</option>
                  </select>
                </div>

                <div className="flex flex-col justify-center space-y-2 pt-2">
                  <label className="flex items-center gap-2 text-xs font-semibold text-stone-700 dark:text-stone-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isOfficial}
                      onChange={(e) => setIsOfficial(e.target.checked)}
                      className="rounded border-stone-400 text-amber-600 focus:ring-amber-500 w-4 h-4"
                    />
                    <span>Marquer comme Sceau Officiel de l'Administration</span>
                  </label>

                  <label className="flex items-center gap-2 text-xs font-semibold text-stone-700 dark:text-stone-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isImportant}
                      onChange={(e) => setIsImportant(e.target.checked)}
                      className="rounded border-stone-400 text-amber-600 focus:ring-amber-500 w-4 h-4"
                    />
                    <span>Épingler en tête du fil familial (Priorité Haute)</span>
                  </label>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-4 border-t border-stone-200 dark:border-stone-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-xl text-xs font-bold text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800 transition cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={submitting || !content.trim()}
                  className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs shadow-lg shadow-amber-500/20 flex items-center gap-2 transition cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>{submitting ? 'Publication en cours...' : 'Publier Officiellement'}</span>
                </button>
              </div>
            </form>
          ) : (
            /* Live Preview Layout */
            <div className="space-y-6">
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-800 dark:text-amber-300 text-xs flex items-center gap-2">
                <Eye className="w-4 h-4 shrink-0" />
                <span>Voici l'aperçu exact tel qu'il apparaîtra dans le fil familial des membres :</span>
              </div>

              <div className="bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 p-6 shadow-xl space-y-4">
                {/* Header preview */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <NzalaAvatar
                      name={currentUser.name}
                      src={currentUser.avatarUrl}
                      size="md"
                      isOnline={true}
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-stone-900 dark:text-stone-100">
                          {currentUser.name}
                        </span>
                        {isOfficial && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500 text-stone-950">
                            COMMUNIQUÉ OFFICIEL
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-stone-500">
                        {currentUser.role} • À l'instant • {scope}
                      </div>
                    </div>
                  </div>

                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${currentConfig.color}`}>
                    {currentConfig.label}
                  </span>
                </div>

                {/* Target person banner if specified */}
                {targetMember && (
                  <div className="p-3 rounded-2xl bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-700 flex items-center gap-3">
                    <NzalaAvatar
                      name={`${targetMember.firstName} ${targetMember.lastName}`}
                      src={targetMember.avatarUrl}
                      size="md"
                      livingStatus={targetMember.livingStatus}
                    />
                    <div>
                      <div className="text-xs font-bold text-stone-900 dark:text-stone-100">
                        Personne à l'honneur : {targetMember.firstName} {targetMember.lastName}
                      </div>
                      <div className="text-[11px] text-stone-500">
                        {targetMember.primaryFamilyName} • {targetMember.branchName || 'Lignée Directe'}
                      </div>
                    </div>
                  </div>
                )}

                {/* Title */}
                <h3 className="text-lg sm:text-xl font-serif font-bold text-stone-900 dark:text-stone-100">
                  {title || currentConfig.defaultTitle}
                </h3>

                {/* Content text */}
                <p className="text-sm text-stone-800 dark:text-stone-200 whitespace-pre-line leading-relaxed">
                  {content || currentConfig.placeholder}
                </p>

                {/* Media Preview */}
                {mediaList.length > 0 && (
                  <div
                    className={`grid gap-2 ${
                      mediaList.length === 1 ? 'grid-cols-1' : 'grid-cols-2'
                    }`}
                  >
                    {mediaList.map((m, i) => (
                      <div key={i} className="rounded-2xl overflow-hidden border border-stone-800 bg-stone-950">
                        <img src={m.url} alt="" className="w-full h-48 object-cover" referrerPolicy="no-referrer" />
                        {m.caption && (
                          <div className="p-2 text-xs text-stone-300 bg-stone-900/90">{m.caption}</div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setPreviewMode(false)}
                  className="px-5 py-2.5 rounded-xl bg-stone-200 dark:bg-stone-800 text-xs font-bold text-stone-800 dark:text-stone-200"
                >
                  Revenir aux modifications
                </button>
                <button
                  type="button"
                  onClick={handleSubmit}
                  className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs flex items-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Confirmer &amp; Publier</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
