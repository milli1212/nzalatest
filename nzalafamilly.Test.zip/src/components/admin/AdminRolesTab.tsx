/**
 * NzalaFamilly - Matrice des Rôles & Habilitations (RBAC)
 */

import React from 'react';
import { UserRole } from '../../types';
import {
  ShieldCheck,
  Shield,
  Key,
  Users,
  GitFork,
  HeartHandshake,
  MessageSquare,
  Newspaper,
  Calendar,
  Lock,
  Check,
  X,
  AlertCircle,
} from 'lucide-react';

interface RoleCapability {
  capability: string;
  description: string;
  superAdmin: boolean;
  adminFamilial: boolean;
  validateur: boolean;
  membreNzala: boolean;
  membreAllie: boolean;
  visiteur: boolean;
}

const CAPABILITIES_MATRIX: RoleCapability[] = [
  {
    capability: 'Accès Arbre & Généalogie Complète',
    description: 'Consulter toutes les branches, ascendances et descendances',
    superAdmin: true,
    adminFamilial: true,
    validateur: true,
    membreNzala: true,
    membreAllie: true,
    visiteur: false,
  },
  {
    capability: 'Gestion des Membres & Fiches',
    description: 'Créer, modifier et enrichir les fiches généalogiques de la famille',
    superAdmin: true,
    adminFamilial: true,
    validateur: true,
    membreNzala: true,
    membreAllie: false,
    visiteur: false,
  },
  {
    capability: 'Pactes & Alliances Familiales',
    description: 'Proposer ou officialiser des alliances entre familles',
    superAdmin: true,
    adminFamilial: true,
    validateur: true,
    membreNzala: true,
    membreAllie: true,
    visiteur: false,
  },
  {
    capability: 'Publications & Fil Familial',
    description: 'Publier des annonces, photos, hommages et stories familiales',
    superAdmin: true,
    adminFamilial: true,
    validateur: true,
    membreNzala: true,
    membreAllie: true,
    visiteur: false,
  },
  {
    capability: 'Modération des Contenus',
    description: 'Approuver, masquer ou rejeter les publications signalées',
    superAdmin: true,
    adminFamilial: true,
    validateur: true,
    membreNzala: false,
    membreAllie: false,
    visiteur: false,
  },
  {
    capability: 'Messagerie & Appels Sécurisés',
    description: 'Échanger en direct avec les membres et créer des groupes',
    superAdmin: true,
    adminFamilial: true,
    validateur: true,
    membreNzala: true,
    membreAllie: true,
    visiteur: false,
  },
  {
    capability: 'Validation des Affiliations (Conseil des Sages)',
    description: 'Instruire et valider les demandes d’adhésion et de filiation',
    superAdmin: true,
    adminFamilial: true,
    validateur: true,
    membreNzala: false,
    membreAllie: false,
    visiteur: false,
  },
  {
    capability: 'Attribution des Certifications & Badges Bleus',
    description: 'Accorder ou révoquer les badges officiels aux comptes vérifiés',
    superAdmin: true,
    adminFamilial: false,
    validateur: false,
    membreNzala: false,
    membreAllie: false,
    visiteur: false,
  },
  {
    capability: 'Administration Système & Audit Global',
    description: 'Configuration technique, gestion des rôles et traçabilité',
    superAdmin: true,
    adminFamilial: false,
    validateur: false,
    membreNzala: false,
    membreAllie: false,
    visiteur: false,
  },
];

export const AdminRolesTab: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Intro Banner */}
      <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-purple-50 text-purple-700 flex items-center justify-center font-bold">
            <Key className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-base text-slate-900">
              Architecture des Habilitations RBAC (Role-Based Access Control)
            </h3>
            <p className="text-xs text-slate-500">
              Garantie de la souveraineté familiale et du respect des règles de confidentialité
            </p>
          </div>
        </div>
      </div>

      {/* Capabilities Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-700 font-bold">
                <th className="py-3.5 px-4 sm:px-6 w-1/3">Fonctionnalité / Droit</th>
                <th className="py-3.5 px-3 text-center">Super Admin</th>
                <th className="py-3.5 px-3 text-center">Admin Familial</th>
                <th className="py-3.5 px-3 text-center">Validateur</th>
                <th className="py-3.5 px-3 text-center">Membre Nzala</th>
                <th className="py-3.5 px-3 text-center">Membre Allié</th>
                <th className="py-3.5 px-3 text-center">Visiteur</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {CAPABILITIES_MATRIX.map((cap, idx) => (
                <tr key={idx} className="hover:bg-slate-50/70 transition">
                  <td className="py-3.5 px-4 sm:px-6">
                    <p className="font-bold text-slate-900">{cap.capability}</p>
                    <p className="text-[11px] text-slate-500 mt-0.5">{cap.description}</p>
                  </td>

                  {/* Super Admin */}
                  <td className="py-3.5 px-3 text-center">
                    {cap.superAdmin ? (
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 font-bold">
                        <Check className="w-3.5 h-3.5" />
                      </span>
                    ) : (
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-slate-100 text-slate-400">
                        <X className="w-3.5 h-3.5" />
                      </span>
                    )}
                  </td>

                  {/* Admin Familial */}
                  <td className="py-3.5 px-3 text-center">
                    {cap.adminFamilial ? (
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 font-bold">
                        <Check className="w-3.5 h-3.5" />
                      </span>
                    ) : (
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-slate-100 text-slate-400">
                        <X className="w-3.5 h-3.5" />
                      </span>
                    )}
                  </td>

                  {/* Validateur */}
                  <td className="py-3.5 px-3 text-center">
                    {cap.validateur ? (
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 font-bold">
                        <Check className="w-3.5 h-3.5" />
                      </span>
                    ) : (
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-slate-100 text-slate-400">
                        <X className="w-3.5 h-3.5" />
                      </span>
                    )}
                  </td>

                  {/* Membre Nzala */}
                  <td className="py-3.5 px-3 text-center">
                    {cap.membreNzala ? (
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 font-bold">
                        <Check className="w-3.5 h-3.5" />
                      </span>
                    ) : (
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-slate-100 text-slate-400">
                        <X className="w-3.5 h-3.5" />
                      </span>
                    )}
                  </td>

                  {/* Membre Allié */}
                  <td className="py-3.5 px-3 text-center">
                    {cap.membreAllie ? (
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 font-bold">
                        <Check className="w-3.5 h-3.5" />
                      </span>
                    ) : (
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-slate-100 text-slate-400">
                        <X className="w-3.5 h-3.5" />
                      </span>
                    )}
                  </td>

                  {/* Visiteur */}
                  <td className="py-3.5 px-3 text-center">
                    {cap.visiteur ? (
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 font-bold">
                        <Check className="w-3.5 h-3.5" />
                      </span>
                    ) : (
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-slate-100 text-slate-400">
                        <X className="w-3.5 h-3.5" />
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
