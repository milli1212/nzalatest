/**
 * NzalaFamilly - Gestion Complète des Utilisateurs & Comptes (Super Admin)
 */

import React, { useState } from 'react';
import { UserAccount, UserRole, AccountStatus, Member } from '../../types';
import { useFamily } from '../../context/FamilyContext';
import { VerifiedBadge } from '../common/VerifiedBadge';
import {
  Users,
  Search,
  Filter,
  Shield,
  ShieldCheck,
  Award,
  Link2,
  Unlink,
  Lock,
  Unlock,
  CheckCircle2,
  AlertTriangle,
  Mail,
  Calendar,
  ChevronRight,
  Edit3,
  UserCheck,
  UserX,
  RefreshCw,
  MoreVertical,
  X,
} from 'lucide-react';

export const AdminUsersTab: React.FC = () => {
  const {
    userAccounts,
    members,
    currentUser,
    updateUserProfile,
    linkUserToMember,
    unlinkUserFromMember,
    certifications,
    showToast,
  } = useFamily();

  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [selectedUser, setSelectedUser] = useState<UserAccount | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editRole, setEditRole] = useState<UserRole>('MEMBRE_NZALA');
  const [editMemberId, setEditMemberId] = useState<string>('');
  const [editReason, setEditReason] = useState<string>('');
  const [editStatus, setEditStatus] = useState<AccountStatus>('ACTIF');

  const isSuperAdmin = currentUser.role === 'SUPER_ADMIN';

  // Filtered users
  const filteredUsers = userAccounts.filter((u) => {
    const matchesSearch =
      `${u.firstName} ${u.lastName} ${u.email} ${u.primaryFamilyName || ''}`
        .toLowerCase()
        .includes(searchQuery.toLowerCase());
    const matchesRole = roleFilter === 'ALL' || u.role === roleFilter;
    const matchesStatus =
      statusFilter === 'ALL' ||
      (statusFilter === 'ACTIVE' && u.accountStatus === 'ACTIF') ||
      (statusFilter === 'BLOCKED' && u.accountStatus === 'SUSPENDU');
    return matchesSearch && matchesRole && matchesStatus;
  });

  const handleOpenEdit = (user: UserAccount) => {
    setSelectedUser(user);
    setEditRole(user.role);
    setEditMemberId(user.memberId || '');
    setEditStatus(user.accountStatus || 'ACTIF');
    setEditReason('');
    setIsEditModalOpen(true);
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser) return;

    // Update profile data in context
    updateUserProfile(selectedUser.id, {
      role: editRole,
      accountStatus: editStatus,
      memberId: editMemberId || undefined,
    });

    // Update member link if needed
    if (editMemberId !== (selectedUser.memberId || '')) {
      if (editMemberId) {
        linkUserToMember(selectedUser.id, editMemberId);
      } else if (selectedUser.memberId) {
        unlinkUserFromMember(selectedUser.id, selectedUser.memberId);
      }
    }

    showToast('success', `Profil utilisateur mis à jour avec succès.`);
    setIsEditModalOpen(false);
    setSelectedUser(null);
  };

  const handleToggleStatus = (user: UserAccount) => {
    const nextStatus: AccountStatus = user.accountStatus === 'SUSPENDU' ? 'ACTIF' : 'SUSPENDU';
    updateUserProfile(user.id, { accountStatus: nextStatus });
    showToast(
      nextStatus === 'ACTIF' ? 'success' : 'warning',
      `Compte ${user.firstName} ${user.lastName} ${nextStatus === 'ACTIF' ? 'réactivé' : 'suspendu'}.`
    );
  };

  const getRoleLabel = (role: UserRole) => {
    switch (role) {
      case 'SUPER_ADMIN':
        return 'Super Administrateur';
      case 'ADMIN_FAMILIAL':
        return 'Admin Familial';
      case 'VALIDATEUR':
        return 'Validateur du Conseil';
      case 'MEMBRE_NZALA':
        return 'Membre Nzala (Direct)';
      case 'MEMBRE_ALLIE':
        return 'Membre Famille Alliée';
      case 'VISITEUR':
      default:
        return 'Visiteur';
    }
  };

  const getRoleBadgeColor = (role: UserRole) => {
    switch (role) {
      case 'SUPER_ADMIN':
        return 'bg-amber-100 text-amber-900 border-amber-300';
      case 'ADMIN_FAMILIAL':
        return 'bg-blue-100 text-blue-900 border-blue-300';
      case 'VALIDATEUR':
        return 'bg-emerald-100 text-emerald-900 border-emerald-300';
      case 'MEMBRE_NZALA':
        return 'bg-purple-100 text-purple-900 border-purple-300';
      case 'MEMBRE_ALLIE':
        return 'bg-cyan-100 text-cyan-900 border-cyan-300';
      case 'VISITEUR':
      default:
        return 'bg-slate-100 text-slate-700 border-slate-300';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Search Bar */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher par nom, prénom, email ou famille..."
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 text-xs sm:text-sm text-slate-900 transition"
          />
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-700 focus:bg-white"
          >
            <option value="ALL">Tous les rôles ({userAccounts.length})</option>
            <option value="SUPER_ADMIN">Super Administrateur</option>
            <option value="ADMIN_FAMILIAL">Admin Familial</option>
            <option value="VALIDATEUR">Validateur</option>
            <option value="MEMBRE_NZALA">Membre Nzala</option>
            <option value="MEMBRE_ALLIE">Membre Allié</option>
            <option value="VISITEUR">Visiteur</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-700 focus:bg-white"
          >
            <option value="ALL">Tous les statuts</option>
            <option value="ACTIVE">Actifs uniquement</option>
            <option value="BLOCKED">Suspendus / Bloqués</option>
          </select>
        </div>
      </div>

      {/* Users Table / Cards */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            <h3 className="font-bold text-sm sm:text-base text-slate-900">
              Répertoire des Utilisateurs Enregistrés
            </h3>
            <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 text-xs font-bold">
              {filteredUsers.length} comptes
            </span>
          </div>
        </div>

        <div className="divide-y divide-slate-100">
          {filteredUsers.length > 0 ? (
            filteredUsers.map((user) => {
              const linkedMember = members.find((m) => m.id === user.memberId);
              const userCert = certifications.find((c) => c.userId === user.id);

              return (
                <div
                  key={user.id}
                  className="p-4 sm:p-5 hover:bg-slate-50/80 transition flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  {/* User info */}
                  <div className="flex items-start sm:items-center gap-3.5 min-w-0">
                    <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white font-bold flex items-center justify-center text-sm shadow-xs shrink-0">
                      {user.avatarUrl ? (
                        <img
                          src={user.avatarUrl}
                          alt=""
                          className="w-full h-full object-cover rounded-2xl"
                        />
                      ) : (
                        <span>
                          {user.firstName.charAt(0)}
                          {user.lastName.charAt(0)}
                        </span>
                      )}
                    </div>

                    <div className="space-y-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-sm text-slate-900 truncate">
                          {user.firstName} {user.lastName}
                        </span>
                        <VerifiedBadge
                          role={user.role}
                          isVerified={!!userCert || user.role === 'SUPER_ADMIN'}
                          size="sm"
                        />
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase border ${getRoleBadgeColor(
                            user.role
                          )}`}
                        >
                          {getRoleLabel(user.role)}
                        </span>
                        {user.accountStatus === 'SUSPENDU' ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-rose-100 text-rose-800 border border-rose-200">
                            Suspendu
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-emerald-50 text-emerald-700 border border-emerald-200">
                            Actif
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-3 text-xs text-slate-500 flex-wrap">
                        <span className="flex items-center gap-1 font-mono">
                          <Mail className="w-3.5 h-3.5 text-slate-400" />
                          <span>{user.email}</span>
                        </span>
                        {user.primaryFamilyName && (
                          <span>• Famille : {user.primaryFamilyName}</span>
                        )}
                        {linkedMember ? (
                          <span className="flex items-center gap-1 text-purple-700 font-semibold">
                            <Link2 className="w-3.5 h-3.5" />
                            <span>Lié à : {linkedMember.firstName} {linkedMember.lastName} (G{linkedMember.generationLevel})</span>
                          </span>
                        ) : (
                          <span className="text-amber-600 italic">
                            Non rattaché à l'arbre
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 self-end md:self-center shrink-0">
                    <button
                      type="button"
                      onClick={() => handleOpenEdit(user)}
                      className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 font-bold text-xs border border-slate-200 hover:border-blue-200 transition cursor-pointer flex items-center gap-1.5"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Gérer le compte</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleToggleStatus(user)}
                      className={`px-3 py-2 rounded-xl font-bold text-xs border transition cursor-pointer flex items-center gap-1 ${
                        user.accountStatus === 'SUSPENDU'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                          : 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100'
                      }`}
                    >
                      {user.accountStatus === 'SUSPENDU' ? (
                        <>
                          <Unlock className="w-3.5 h-3.5" />
                          <span>Réactiver</span>
                        </>
                      ) : (
                        <>
                          <Lock className="w-3.5 h-3.5" />
                          <span>Suspendre</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="p-8 text-center text-slate-500 text-xs sm:text-sm">
              Aucun compte utilisateur ne correspond à vos filtres.
            </div>
          )}
        </div>
      </div>

      {/* Edit User Modal */}
      {isEditModalOpen && selectedUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-base text-slate-900">
                  Administration du Compte : {selectedUser.firstName} {selectedUser.lastName}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsEditModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveUser} className="space-y-4 text-xs">
              {/* Role Selection */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Rôle &amp; Habilitations RBAC
                </label>
                <select
                  value={editRole}
                  onChange={(e) => setEditRole(e.target.value as UserRole)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900 font-semibold"
                >
                  <option value="SUPER_ADMIN">👑 Super Administrateur (Contrôle total)</option>
                  <option value="ADMIN_FAMILIAL">🏛️ Administrateur de Famille / Branche</option>
                  <option value="VALIDATEUR">🛡️ Validateur du Conseil des Sages</option>
                  <option value="MEMBRE_NZALA">👑 Membre Nzala (Lignée directe)</option>
                  <option value="MEMBRE_ALLIE">💍 Membre Famille Alliée</option>
                  <option value="VISITEUR">Visiteur (Accès Restreint)</option>
                </select>
              </div>

              {/* Status */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Statut du Compte
                </label>
                <select
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value as AccountStatus)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900 font-semibold"
                >
                  <option value="ACTIF">🟢 Compte Actif &amp; Opérationnel</option>
                  <option value="SUSPENDU">🔴 Compte Suspendu / Bloqué</option>
                  <option value="COMPTE_CREE">🟡 En attente d'activation</option>
                </select>
              </div>

              {/* Genealogy Link */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Liaison à la fiche de l'Arbre Généalogique
                </label>
                <select
                  value={editMemberId}
                  onChange={(e) => setEditMemberId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900"
                >
                  <option value="">-- Aucune liaison (Compte autonome) --</option>
                  {members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.firstName} {m.lastName} (G{m.generationLevel}, {m.primaryFamilyName})
                    </option>
                  ))}
                </select>
              </div>

              {/* Audit Reason */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Motif de la modification (obligatoire pour traçabilité)
                </label>
                <input
                  type="text"
                  required
                  value={editReason}
                  onChange={(e) => setEditReason(e.target.value)}
                  placeholder="Ex : Validation de l'affiliation par les Sages..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-900"
                />
              </div>

              {/* Footer Buttons */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-xs"
                >
                  Enregistrer les modifications
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
