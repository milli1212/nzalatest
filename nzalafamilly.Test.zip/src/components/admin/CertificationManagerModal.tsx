/**
 * NzalaFamilly - Gestionnaire de Certification des Comptes Officiels (Réservé Super Admin)
 */

import React, { useState } from 'react';
import {
  ShieldCheck,
  Award,
  UserCheck,
  UserX,
  Plus,
  X,
  Trash2,
  CheckCircle,
  AlertCircle,
  Clock,
  Sparkles,
} from 'lucide-react';
import { AccountCertification, CertificationType, UserRole } from '../../types';
import { useFamily } from '../../context/FamilyContext';
import { VerifiedBadge } from '../common/VerifiedBadge';

interface CertificationManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const CERTIFICATION_TYPES: { type: CertificationType; label: string; icon: string }[] = [
  { type: 'SUPER_ADMIN', label: 'Super Administrateur de la Plateforme', icon: '👑' },
  { type: 'ADMIN_FAMILIAL', label: 'Administrateur de Famille / Branche', icon: '🛡️' },
  { type: 'SAGE_CONSEIL', label: 'Membre du Conseil des Sages Nzala', icon: '📜' },
  { type: 'MODERATEUR', label: 'Modérateur de Contenus & Publications', icon: '⚖️' },
  { type: 'RESPONSABLE_OFFICIEL', label: 'Responsable des Événements & Traditions', icon: '🌟' },
];

export const CertificationManagerModal: React.FC<CertificationManagerModalProps> = ({
  isOpen,
  onClose,
}) => {
  const {
    currentUser,
    userAccounts,
    certifications,
    certifyAccount,
    revokeCertification,
    showToast,
  } = useFamily();

  const [isAdding, setIsAdding] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState('');
  const [selectedCertType, setSelectedCertType] = useState<CertificationType>('ADMIN_FAMILIAL');
  const [badgeLabel, setBadgeLabel] = useState('Administrateur Familial Certifié');
  const [reason, setReason] = useState('');

  if (!isOpen) return null;

  const isSuperAdmin = currentUser.role === 'SUPER_ADMIN';

  const handleCreateCertification = (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedUserId) {
      showToast('error', 'Veuillez sélectionner un compte utilisateur.');
      return;
    }

    const user = userAccounts.find((u) => u.id === selectedUserId);
    if (!user) return;

    certifyAccount({
      userId: user.id,
      userName: `${user.firstName} ${user.lastName}`,
      userEmail: user.email,
      userRole: user.role,
      familyName: user.primaryFamilyName,
      certificationType: selectedCertType,
      badgeLabel: badgeLabel.trim() || 'Compte Officiel Certifié',
      icon: CERTIFICATION_TYPES.find((c) => c.type === selectedCertType)?.icon || '✓',
      reason: reason.trim() || 'Attribution de responsabilité officielle par le Super Administrateur.',
    });

    showToast('success', `Certification accordée à ${user.firstName} ${user.lastName} !`);
    setIsAdding(false);
    setSelectedUserId('');
    setReason('');
  };

  const handleRevoke = (certId: string, userName: string) => {
    if (window.confirm(`Confirmez-vous le retrait de la certification pour ${userName} ?`)) {
      revokeCertification(certId, 'Retrait par décision administrative');
      showToast('info', `Certification révoquée pour ${userName}.`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-3xl w-full p-5 sm:p-7 shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-slate-900 flex items-center gap-2">
                <span>Certification des Comptes Officiels</span>
                <span className="text-[11px] bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full font-bold">
                  Super Admin
                </span>
              </h3>
              <p className="text-xs text-slate-500">
                Garantissez l'authenticité des badges officiels sur l'ensemble de la plateforme
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto py-4 space-y-4">
          {!isSuperAdmin && (
            <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>Seul le Super Administrateur peut accorder ou révoquer les certifications officielles.</span>
            </div>
          )}

          {/* New Certification Form */}
          {isAdding ? (
            <form onSubmit={handleCreateCertification} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-900 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>Accorder une Nouvelle Certification</span>
                </h4>
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="text-xs text-slate-500 hover:text-slate-800 cursor-pointer"
                >
                  Fermer
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Sélectionner l'utilisateur *
                  </label>
                  <select
                    value={selectedUserId}
                    onChange={(e) => setSelectedUserId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-800 outline-none focus:ring-2 focus:ring-amber-500"
                    required
                  >
                    <option value="">Sélectionnez un membre...</option>
                    {userAccounts.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.firstName} {u.lastName} ({u.email}) - {u.role}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Type de Certification
                  </label>
                  <select
                    value={selectedCertType}
                    onChange={(e) => {
                      const val = e.target.value as CertificationType;
                      setSelectedCertType(val);
                      const found = CERTIFICATION_TYPES.find((c) => c.type === val);
                      if (found) setBadgeLabel(found.label);
                    }}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-800 outline-none focus:ring-2 focus:ring-amber-500"
                  >
                    {CERTIFICATION_TYPES.map((c) => (
                      <option key={c.type} value={c.type}>
                        {c.icon} {c.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Intitulé du Badge (Libellé public) *
                </label>
                <input
                  type="text"
                  value={badgeLabel}
                  onChange={(e) => setBadgeLabel(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-900 outline-none focus:ring-2 focus:ring-amber-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Motif d'attribution & Traçabilité *
                </label>
                <textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Ex: Élection au Conseil des Sages lors de l'assemblée du 15 août..."
                  rows={2}
                  className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-900 outline-none focus:ring-2 focus:ring-amber-500 resize-none"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs text-slate-600 cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-sm"
                >
                  <Award className="w-3.5 h-3.5" />
                  <span>Confirmer la Certification</span>
                </button>
              </div>
            </form>
          ) : (
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700">
                Comptes Actuellement Certifiés ({certifications.length})
              </span>
              {isSuperAdmin && (
                <button
                  type="button"
                  onClick={() => setIsAdding(true)}
                  className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-sm"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Certifier un Compte</span>
                </button>
              )}
            </div>
          )}

          {/* List of certified accounts */}
          <div className="space-y-2">
            {certifications.map((cert) => (
              <div
                key={cert.id}
                className="p-3.5 rounded-2xl border border-slate-200 bg-white hover:bg-slate-50/80 transition flex items-start justify-between gap-3 shadow-xs"
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold text-lg shrink-0">
                    {cert.icon || '✓'}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h5 className="font-bold text-xs sm:text-sm text-slate-900 truncate">
                        {cert.userName}
                      </h5>
                      <VerifiedBadge
                        role={cert.userRole}
                        isVerified={cert.isActive}
                        badgeLabel={cert.badgeLabel}
                        size="sm"
                      />
                    </div>

                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {cert.userEmail} • Rôle : {cert.userRole} {cert.familyName && `• ${cert.familyName}`}
                    </p>

                    <p className="text-xs text-slate-700 mt-1 bg-slate-100 px-2 py-1 rounded-lg">
                      <strong className="text-slate-900">Motif :</strong> {cert.reason}
                    </p>

                    <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1">
                      <Clock className="w-3 h-3" />
                      <span>Certifié par {cert.certifiedByUserName} le {new Date(cert.certifiedAt).toLocaleDateString('fr-FR')}</span>
                    </div>
                  </div>
                </div>

                {isSuperAdmin && (
                  <button
                    type="button"
                    onClick={() => handleRevoke(cert.id, cert.userName)}
                    className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition cursor-pointer shrink-0"
                    title="Révoquer la certification"
                  >
                    <UserX className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-100 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800 transition cursor-pointer"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
