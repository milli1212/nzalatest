import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { UserAccount, Member } from '../../types';
import { validateUserMemberLink } from '../../services/relationshipEngine';
import {
  X,
  Link,
  Unlink,
  UserCheck,
  AlertTriangle,
  CheckCircle2,
  Users,
  Building2,
  Mail,
} from 'lucide-react';

interface LinkAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetUserId?: string;
  targetMemberId?: string;
}

export const LinkAccountModal: React.FC<LinkAccountModalProps> = ({
  isOpen,
  onClose,
  targetUserId,
  targetMemberId,
}) => {
  const { userAccounts, members, linkUserToMember, unlinkUserFromMember, showToast } = useFamily();

  const [selectedUserId, setSelectedUserId] = useState(targetUserId || '');
  const [selectedMemberId, setSelectedMemberId] = useState(targetMemberId || '');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const selectedUser = userAccounts.find((u) => u.id === selectedUserId);
  const selectedMember = members.find((m) => m.id === selectedMemberId);

  const handleLink = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!selectedUserId || !selectedMemberId) {
      setError('Veuillez sélectionner un compte utilisateur et une fiche membre.');
      return;
    }

    const res = linkUserToMember(selectedUserId, selectedMemberId);
    if (!res.success) {
      setError(res.error || 'Erreur lors de la liaison.');
    } else {
      onClose();
    }
  };

  const handleUnlink = (userId: string, memberId: string) => {
    unlinkUserFromMember(userId, memberId);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl max-w-xl w-full border border-stone-200 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col">
        {/* Header */}
        <div className="p-6 bg-stone-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30 flex items-center justify-center">
              <Link className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif font-bold text-lg text-purple-100">
                Liaison Compte Utilisateur ↔ Fiche Membre
              </h2>
              <p className="text-xs text-stone-300">
                Associez l'identité technique (login) à la fiche généalogique familiale.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-white hover:bg-stone-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleLink} className="p-6 space-y-5">
          {/* User Account Selection */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-stone-800 flex items-center justify-between">
              <span>Compte Utilisateur (Compte de connexion)</span>
              {selectedUser?.memberId && (
                <span className="text-[10px] text-amber-700 font-semibold">
                  Déjà lié à une fiche
                </span>
              )}
            </label>
            <select
              value={selectedUserId}
              onChange={(e) => setSelectedUserId(e.target.value)}
              required
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 text-stone-900 text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-500 transition"
            >
              <option value="">-- Choisir un compte utilisateur --</option>
              {userAccounts.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.firstName} {u.lastName} ({u.email}) — Rôle: {u.role} {u.memberId ? '✓ Lié' : '⚠️ Sans fiche'}
                </option>
              ))}
            </select>
          </div>

          {/* Member Card Selection */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-stone-800 flex items-center justify-between">
              <span>Fiche Membre (Registre Généalogique)</span>
              {selectedMember?.userId && (
                <span className="text-[10px] text-amber-700 font-semibold">
                  Déjà associée à un compte
                </span>
              )}
            </label>
            <select
              value={selectedMemberId}
              onChange={(e) => setSelectedMemberId(e.target.value)}
              required
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 text-stone-900 text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-500 transition"
            >
              <option value="">-- Choisir la fiche membre correspondante --</option>
              {members.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.firstName} {m.lastName} {m.livingStatus === 'DECEDE' ? '(🕊️ Décédé)' : ''} — G{m.generationLevel} ({m.primaryFamilyName}) {m.userId ? '✓ Associé' : '○ Fiche libre'}
                </option>
              ))}
            </select>
          </div>

          {/* Details / Preview */}
          {selectedUser && selectedMember && (
            <div className="p-4 rounded-2xl bg-purple-50 border border-purple-200 text-xs space-y-2 text-purple-950">
              <div className="font-bold flex items-center gap-1.5">
                <UserCheck className="w-4 h-4 text-purple-700" />
                <span>Conséquences de la liaison :</span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-stone-700 text-[11px]">
                <li>
                  L'utilisateur <strong className="text-stone-900">{selectedUser.email}</strong> aura accès direct à sa fiche membre.
                </li>
                <li>
                  Son rôle passera automatiquement à <strong className="text-stone-900">{selectedMember.familyType === 'NZALA_DIRECT' ? 'MEMBRE_NZALA' : 'MEMBRE_ALLIE'}</strong>.
                </li>
                <li>
                  Rattachement officiel à la <strong className="text-stone-900">{selectedMember.primaryFamilyName}</strong>.
                </li>
              </ul>
            </div>
          )}

          {error && (
            <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Action buttons */}
          <div className="flex items-center justify-between pt-4 border-t border-stone-100">
            {selectedUser?.memberId && (
              <button
                type="button"
                onClick={() => handleUnlink(selectedUser.id, selectedUser.memberId!)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-800 text-xs font-semibold border border-rose-200 transition cursor-pointer"
              >
                <Unlink className="w-3.5 h-3.5" />
                <span>Dissocier la fiche actuelle</span>
              </button>
            )}

            <div className="flex items-center gap-2 ml-auto">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold transition cursor-pointer"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="flex items-center gap-2 px-5 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs shadow-md shadow-purple-950/20 transition cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Établir la liaison</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
