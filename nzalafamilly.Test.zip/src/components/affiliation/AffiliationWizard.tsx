import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { AffiliationOption, VerificationRelationNature } from '../../types';
import { StatusBadge, AffiliationStatusBadge } from '../common/Badges';
import {
  Building2,
  Crown,
  Heart,
  GitFork,
  Users,
  ShieldCheck,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FileText,
  Send,
  HelpCircle,
  ChevronRight,
  ArrowLeft,
  Sparkles,
  Info,
  MessageSquare
} from 'lucide-react';

interface AffiliationWizardProps {
  onCompleted?: () => void;
}

export const AffiliationWizard: React.FC<AffiliationWizardProps> = ({ onCompleted }) => {
  const {
    currentUser,
    families,
    members,
    verificationRequests,
    submitVerificationRequest,
    setActiveTab,
    showToast,
  } = useFamily();

  // Look for existing request for current user
  const userRequest = verificationRequests.find(
    (r) =>
      (r.userId && r.userId === currentUser.id) ||
      (currentUser.email && r.applicantEmail.toLowerCase() === currentUser.email.toLowerCase())
  );

  const [step, setStep] = useState<number>(1);

  // Form State
  const [selectedOption, setSelectedOption] = useState<AffiliationOption>('NZALA_DIRECT');
  const [originFamilyName, setOriginFamilyName] = useState('Famille Nzala');
  const [targetNzalaMemberId, setTargetNzalaMemberId] = useState('');
  const [targetNzalaMemberName, setTargetNzalaMemberName] = useState('');
  const [branchOrTown, setBranchOrTown] = useState('');
  const [relationshipNature, setRelationshipNature] = useState<VerificationRelationNature>('MEMBRE_DIRECT');
  const [explanation, setExplanation] = useState('');
  const [references, setReferences] = useState('');
  const [phone, setPhone] = useState(currentUser.phone || '');

  // Options configuration
  const affiliationOptions = [
    {
      id: 'NZALA_DIRECT' as AffiliationOption,
      title: 'Membre direct de la Famille Nzala',
      subtitle: 'Descendance directe, lignée sanguine Nzala',
      badge: 'Lignée Souche',
      badgeColor: 'bg-amber-100 text-amber-900 border-amber-300',
      icon: Crown,
      defaultFamily: 'Famille Nzala',
      defaultRelation: 'MEMBRE_DIRECT' as VerificationRelationNature,
      description:
        'Vous êtes né(e) Nzala, enfant, petit-enfant ou descendant direct de l’aïeul Nzala.',
    },
    {
      id: 'NZALA_CONJOINT' as AffiliationOption,
      title: 'Conjoint(e) d’un membre Nzala',
      subtitle: 'Mariage ou union officielle avec un(e) Nzala',
      badge: 'Alliance Mariage',
      badgeColor: 'bg-rose-100 text-rose-900 border-rose-300',
      icon: Heart,
      defaultFamily: '',
      defaultRelation: 'CONJOINT' as VerificationRelationNature,
      description:
        'Vous êtes marié(e) ou fiancé(e) officiellement à un membre de la lignée Nzala.',
    },
    {
      id: 'ALLIANCE_DESCENDANT' as AffiliationOption,
      title: 'Descendant issu d’une alliance Nzala',
      subtitle: 'Enfant ou petit-enfant issu d’une union mixte',
      badge: 'Descendant d’Alliance',
      badgeColor: 'bg-emerald-100 text-emerald-900 border-emerald-300',
      icon: GitFork,
      defaultFamily: '',
      defaultRelation: 'DESCENDANT_ALLIANCE' as VerificationRelationNature,
      description:
        'L’un de vos parents ou grands-parents est un membre direct de la famille Nzala.',
    },
    {
      id: 'FAMILLE_ALLIEE' as AffiliationOption,
      title: 'Représentant d’une Famille Alliée',
      subtitle: 'Membre officiel des familles Mavungu, Kanza, Lukoki, Ndombe...',
      badge: 'Famille Alliée',
      badgeColor: 'bg-sky-100 text-sky-900 border-sky-300',
      icon: Building2,
      defaultFamily: 'Famille Mavungu',
      defaultRelation: 'FAMILLE_ALLIEE' as VerificationRelationNature,
      description:
        'Vous appartenez à une famille historiquement liée ou alliée à la communauté Nzala.',
    },
    {
      id: 'AUTRE_LIEN' as AffiliationOption,
      title: 'Autre lien familial ou historique',
      subtitle: 'Parenté élargie, parrainage ou attache coutumière',
      badge: 'Lien Particulier',
      badgeColor: 'bg-purple-100 text-purple-900 border-purple-300',
      icon: Users,
      defaultFamily: '',
      defaultRelation: 'AUTRE' as VerificationRelationNature,
      description:
        'Votre lien avec la communauté relève d’une relation coutumière ou d’un historique spécifique.',
    },
  ];

  const handleSelectOption = (opt: AffiliationOption) => {
    setSelectedOption(opt);
    const cfg = affiliationOptions.find((o) => o.id === opt);
    if (cfg) {
      if (opt === 'NZALA_DIRECT') {
        setOriginFamilyName('Famille Nzala');
        setRelationshipNature('MEMBRE_DIRECT');
      } else if (opt === 'NZALA_CONJOINT') {
        setRelationshipNature('CONJOINT');
        if (originFamilyName === 'Famille Nzala') setOriginFamilyName('');
      } else if (opt === 'ALLIANCE_DESCENDANT') {
        setRelationshipNature('DESCENDANT_ALLIANCE');
        if (originFamilyName === 'Famille Nzala') setOriginFamilyName('');
      } else if (opt === 'FAMILLE_ALLIEE') {
        setRelationshipNature('FAMILLE_ALLIEE');
        if (originFamilyName === 'Famille Nzala') setOriginFamilyName('Famille Mavungu');
      } else {
        setRelationshipNature('AUTRE');
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!explanation.trim()) {
      showToast('error', 'Veuillez préciser votre lien et vos informations de rattachement.');
      return;
    }

    const isDirect = selectedOption === 'NZALA_DIRECT';

    submitVerificationRequest({
      applicantFirstName: currentUser.firstName,
      applicantLastName: currentUser.lastName,
      applicantName: currentUser.name,
      applicantEmail: currentUser.email,
      applicantPhone: phone || currentUser.phone || '+243 000 000 000',
      originFamilyName: originFamilyName.trim() || (isDirect ? 'Famille Nzala' : 'Famille Déclarée'),
      claimedFamilyType: isDirect ? 'NZALA_DIRECT' : 'FAMILLE_ALLIEE',
      affiliationOption: selectedOption,
      targetNzalaMemberId: targetNzalaMemberId || undefined,
      targetNzalaMemberName: targetNzalaMemberName || undefined,
      relationshipNature,
      branchOrTown,
      explanation,
      references,
    });

    if (onCompleted) {
      onCompleted();
    }
  };

  // nzala members list for referral selection
  const directNzalaMembers = members.filter((m) => m.familyType === 'NZALA_DIRECT');

  return (
    <div id="affiliation-wizard-container" className="space-y-6 max-w-4xl mx-auto pb-12">
      {/* Header Banner */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-serif font-bold text-stone-900">
                Déclaration d'Affiliation Familiale
              </h1>
              <AffiliationStatusBadge status={userRequest ? userRequest.status : currentUser.affiliationStatus} />
            </div>
            <p className="text-xs sm:text-sm text-stone-500">
              Définissez précisément votre lien avec la <strong>Famille Nzala</strong> ou votre rattachement à l'une de nos <strong>familles alliées</strong>.
            </p>
          </div>

          <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 text-xs text-amber-950 max-w-xs shrink-0">
            <div className="font-bold flex items-center gap-1 text-amber-900 mb-0.5">
              <ShieldCheck className="w-4 h-4 text-amber-700" />
              <span>Gouvernance &amp; Confidentialité</span>
            </div>
            <p className="text-[11px] text-amber-800 leading-snug">
              Vos déclarations sont examinées avec discrétion par les aînés et validateurs du Conseil de Famille.
            </p>
          </div>
        </div>
      </div>

      {/* If a request already exists, display tracking card */}
      {userRequest && (
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-100 pb-4">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-stone-400">
                État d'avancement de votre dossier
              </span>
              <h2 className="text-lg font-serif font-bold text-stone-900 mt-0.5">
                Dossier Réf : {userRequest.id}
              </h2>
            </div>
            <StatusBadge status={userRequest.status} />
          </div>

          {/* Stepper Progress */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            {/* Step 1 */}
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1">
              <div className="flex items-center gap-2 text-emerald-800 font-bold text-xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>1. Compte Créé</span>
              </div>
              <p className="text-[11px] text-emerald-700">Identité enregistrée</p>
            </div>

            {/* Step 2 */}
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1">
              <div className="flex items-center gap-2 text-emerald-800 font-bold text-xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>2. Dossier Déposé</span>
              </div>
              <p className="text-[11px] text-emerald-700">
                Transmis le {new Date(userRequest.createdAt).toLocaleDateString('fr-FR')}
              </p>
            </div>

            {/* Step 3 */}
            <div
              className={`p-3.5 rounded-2xl border space-y-1 ${
                userRequest.status === 'EN_VERIFICATION' || userRequest.status === 'COMPLEMENT_REQUIS'
                  ? 'bg-blue-50 border-blue-300 text-blue-900'
                  : userRequest.status === 'APPROUVEE'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-stone-50 border-stone-200 text-stone-600'
              }`}
            >
              <div className="flex items-center gap-2 font-bold text-xs">
                <Clock className="w-4 h-4" />
                <span>3. Examen Conseil</span>
              </div>
              <p className="text-[11px]">
                {userRequest.status === 'EN_ATTENTE' && 'En file d\'attente'}
                {userRequest.status === 'EN_VERIFICATION' && 'Instruction en cours'}
                {userRequest.status === 'COMPLEMENT_REQUIS' && 'Informations demandées'}
                {userRequest.status === 'APPROUVEE' && 'Vérification validée'}
                {userRequest.status === 'REFUSEE' && 'Examen terminé'}
              </p>
            </div>

            {/* Step 4 */}
            <div
              className={`p-3.5 rounded-2xl border space-y-1 ${
                userRequest.status === 'APPROUVEE'
                  ? 'bg-emerald-100 border-emerald-300 text-emerald-950 font-bold'
                  : userRequest.status === 'REFUSEE'
                  ? 'bg-rose-50 border-rose-200 text-rose-900'
                  : 'bg-stone-50 border-stone-200 text-stone-500'
              }`}
            >
              <div className="flex items-center gap-2 text-xs font-bold">
                {userRequest.status === 'APPROUVEE' ? (
                  <Sparkles className="w-4 h-4 text-emerald-700" />
                ) : (
                  <ShieldCheck className="w-4 h-4" />
                )}
                <span>4. Décision &amp; Intégration</span>
              </div>
              <p className="text-[11px]">
                {userRequest.status === 'APPROUVEE'
                  ? 'Intégré(e) à l\'annuaire'
                  : userRequest.status === 'REFUSEE'
                  ? 'Demande non retenue'
                  : 'En attente de délibération'}
              </p>
            </div>
          </div>

          {/* Feedback from reviewer if complement is needed */}
          {userRequest.publicFeedback && (
            <div className="p-4 rounded-2xl bg-purple-50 border border-purple-200 space-y-1.5">
              <div className="flex items-center gap-2 text-xs font-bold text-purple-900">
                <MessageSquare className="w-4 h-4 text-purple-700" />
                <span>Message du Conseil des Validateurs :</span>
              </div>
              <p className="text-xs text-purple-950 leading-relaxed font-medium">
                "{userRequest.publicFeedback}"
              </p>
            </div>
          )}

          {/* Submitted Data Summary */}
          <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 text-xs grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <span className="text-stone-400 block mb-0.5">Famille déclarée :</span>
              <strong className="text-stone-900">{userRequest.originFamilyName}</strong>
            </div>
            <div>
              <span className="text-stone-400 block mb-0.5">Statut revendiqué :</span>
              <strong className="text-stone-900">
                {userRequest.claimedFamilyType === 'NZALA_DIRECT' ? '👑 Membre Direct Nzala' : '🤝 Famille Alliée'}
              </strong>
            </div>
            <div>
              <span className="text-stone-400 block mb-0.5">Nature de la relation :</span>
              <span className="font-semibold text-stone-800">
                {userRequest.relationshipNature.replace('_', ' ')}
              </span>
            </div>
          </div>

          {userRequest.status === 'APPROUVEE' && (
            <div className="p-4 rounded-2xl bg-emerald-50/80 border border-emerald-200 flex items-center justify-between gap-4">
              <div className="text-xs text-emerald-900">
                <strong>Félicitations !</strong> Votre affiliation a été validée. Votre compte a été élevé au rang de <strong>{currentUser.role === 'MEMBRE_NZALA' ? 'Membre Nzala' : 'Membre Allié'}</strong>.
              </div>
              <button
                onClick={() => setActiveTab('members')}
                className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs transition shrink-0 cursor-pointer shadow-xs"
              >
                Consulter l'annuaire
              </button>
            </div>
          )}
        </div>
      )}

      {/* Form Submission View (if not submitted or submitting new/additional request) */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200 shadow-xs space-y-6">
        <div className="border-b border-stone-100 pb-4">
          <h2 className="text-lg font-serif font-bold text-stone-900">
            {userRequest ? 'Mettre à jour ou déposer une nouvelle déclaration' : 'Formulaire d\'affiliation'}
          </h2>
          <p className="text-xs text-stone-500 mt-1">
            Sélectionnez votre cas de figure pour adapter automatiquement les informations demandées.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Question 1: 5 Interactive Option Cards */}
          <div className="space-y-3">
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-700">
              1. Quel est votre lien avec la famille Nzala ?
            </label>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {affiliationOptions.map((opt) => {
                const isSelected = selectedOption === opt.id;
                const IconComponent = opt.icon;

                return (
                  <div
                    key={opt.id}
                    onClick={() => handleSelectOption(opt.id)}
                    className={`p-4 rounded-2xl border-2 transition cursor-pointer flex flex-col justify-between space-y-2 ${
                      isSelected
                        ? 'border-amber-600 bg-amber-50/50 shadow-sm'
                        : 'border-stone-200 bg-white hover:border-stone-300 hover:bg-stone-50'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                            isSelected ? 'bg-amber-600 text-stone-950 shadow-xs' : 'bg-stone-100 text-stone-600'
                          }`}
                        >
                          <IconComponent className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="font-bold text-xs sm:text-sm text-stone-900 leading-tight">
                            {opt.title}
                          </h3>
                          <span className="text-[11px] text-stone-500 block mt-0.5">
                            {opt.subtitle}
                          </span>
                        </div>
                      </div>

                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold border shrink-0 ${opt.badgeColor}`}>
                        {opt.badge}
                      </span>
                    </div>

                    <p className="text-[11px] text-stone-600 leading-relaxed pt-1">
                      {opt.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Question 2: Specific Inputs Based on Chosen Option */}
          <div className="space-y-4 pt-4 border-t border-stone-200">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-700">
                2. Renseignements spécifiques à votre déclaration
              </label>
              <span className="text-[11px] text-stone-400 italic">Principe de minimisation des données</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Origin Family Name */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Nom de votre famille d'origine
                </label>
                <input
                  type="text"
                  required
                  value={originFamilyName}
                  onChange={(e) => setOriginFamilyName(e.target.value)}
                  placeholder="ex: Famille Nzala ou Famille Mavungu"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:outline-hidden focus:border-amber-500"
                />
              </div>

              {/* Branch or location */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Branche familiale / Ville de rattachement
                </label>
                <input
                  type="text"
                  value={branchOrTown}
                  onChange={(e) => setBranchOrTown(e.target.value)}
                  placeholder="ex: Branche de Kinshasa, Matadi, Boma, Diaspora..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:outline-hidden focus:border-amber-500"
                />
              </div>

              {/* Reference Nzala member (if applicable) */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Membre ou Aïeul Nzala référent (optionnel mais recommandé)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <select
                    value={targetNzalaMemberId}
                    onChange={(e) => {
                      const id = e.target.value;
                      setTargetNzalaMemberId(id);
                      const m = members.find((x) => x.id === id);
                      if (m) {
                        setTargetNzalaMemberName(`${m.firstName} ${m.lastName}`);
                      }
                    }}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:outline-hidden focus:border-amber-500"
                  >
                    <option value="">Sélectionner parmi les membres Nzala répertoriés...</option>
                    {directNzalaMembers.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.firstName} {m.lastName} ({m.generationLevel === 1 ? 'Patriarche' : 'Lignée Nzala'})
                      </option>
                    ))}
                  </select>

                  <input
                    type="text"
                    value={targetNzalaMemberName}
                    onChange={(e) => setTargetNzalaMemberName(e.target.value)}
                    placeholder="Ou saisir manuellement le nom du parent / conjoint Nzala"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:outline-hidden focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Phone number */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Numéro de contact pour confirmation par les aînés
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+243 81 234 5678"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:outline-hidden focus:border-amber-500"
                />
              </div>
            </div>
          </div>

          {/* Question 3: Explanation & References */}
          <div className="space-y-4 pt-4 border-t border-stone-200">
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-700">
              3. Précisions sur votre filiation &amp; Témoins référents
            </label>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Explication de votre lien familial <span className="text-amber-800">*</span>
              </label>
              <textarea
                rows={3}
                required
                value={explanation}
                onChange={(e) => setExplanation(e.target.value)}
                placeholder="Exemple : Je suis le fils cadet de Papa André Nzala et Maman Georgette. Mon grand-père est l'aïeul Jean Nzala..."
                className="w-full p-3 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:outline-hidden focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Témoins, aînés ou membres pouvant attester de votre affiliation
              </label>
              <input
                type="text"
                value={references}
                onChange={(e) => setReferences(e.target.value)}
                placeholder="Ex : Maman Véronique Nzala (Tante), Pasteur Paul Mavungu..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:outline-hidden focus:border-amber-500"
              />
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-4 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="text-[11px] text-stone-500 leading-snug">
              En soumettant cette déclaration, vos informations seront transmises aux administrateurs pour examen.
            </p>

            <button
              type="submit"
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs shadow-md shadow-amber-950/20 transition flex items-center justify-center gap-2 cursor-pointer shrink-0"
            >
              <Send className="w-4 h-4" />
              <span>Transmettre ma déclaration d'affiliation</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
