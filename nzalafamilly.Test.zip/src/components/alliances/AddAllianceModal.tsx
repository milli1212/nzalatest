import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { AllianceType, AllianceStatus } from '../../types';
import { X, HeartHandshake } from 'lucide-react';

interface AddAllianceModalProps {
  onClose: () => void;
}

export const AddAllianceModal: React.FC<AddAllianceModalProps> = ({ onClose }) => {
  const { families, members, addAlliance, currentUser, showToast } = useFamily();

  const alliedFamilies = families.filter((f) => f.type === 'ALLIEE');
  const nzalaMembers = members.filter((m) => m.familyType === 'NZALA_DIRECT');

  const [alliedFamilyId, setAlliedFamilyId] = useState(alliedFamilies[0]?.id || '');
  const [allianceType, setAllianceType] = useState<AllianceType>('MARIAGE');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [primaryMemberSourceId, setPrimaryMemberSourceId] = useState(nzalaMembers[0]?.id || '');
  const [primaryMemberAlliedName, setPrimaryMemberAlliedName] = useState('');
  const [allianceDate, setAllianceDate] = useState('');
  const [notes, setNotes] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!alliedFamilyId || !title.trim()) {
      showToast('error', 'Le titre et la famille alliée sont obligatoires.');
      return;
    }

    const selectedAlliedFam = families.find((f) => f.id === alliedFamilyId);
    const selectedNzalaMember = members.find((m) => m.id === primaryMemberSourceId);

    addAlliance({
      sourceFamilyId: 'fam-nzala',
      sourceFamilyName: 'Famille Nzala',
      alliedFamilyId,
      alliedFamilyName: selectedAlliedFam ? selectedAlliedFam.name : 'Famille Alliée',
      allianceType,
      title: title.trim(),
      description: description.trim() || `Alliance officielle établie avec la ${selectedAlliedFam?.name}.`,
      primaryMemberSourceId: selectedNzalaMember?.id,
      primaryMemberSourceName: selectedNzalaMember ? `${selectedNzalaMember.firstName} ${selectedNzalaMember.lastName}` : undefined,
      primaryMemberAlliedName: primaryMemberAlliedName.trim() || undefined,
      startDate: allianceDate || undefined,
      status: currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL' ? 'APPROUVEE' : 'EN_VERIFICATION',
      validatedBy: currentUser.id,
      validatedByName: currentUser.name,
      validatedAt: new Date().toISOString(),
      notes: notes.trim() || undefined,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        <div className="bg-stone-900 text-stone-100 p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <HeartHandshake className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-serif font-bold text-stone-100">
                Formaliser une Nouvelle Alliance
              </h2>
              <p className="text-xs text-stone-400">
                Enregistrer un lien matrimonial ou pacte avec une famille alliée
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full text-stone-400 hover:text-stone-100 hover:bg-stone-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto text-xs">
          <div>
            <label className="block font-semibold text-stone-700 mb-1">
              Famille Alliée Partenaire <span className="text-rose-500">*</span>
            </label>
            <select
              value={alliedFamilyId}
              onChange={(e) => setAlliedFamilyId(e.target.value)}
              required
              className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
            >
              {alliedFamilies.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name} ({f.originLocation || 'Origine non spécifiée'})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-stone-700 mb-1">
              Intitulé de l'Alliance <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ex: Alliance Nzala - Mavungu (Union Jean-Pierre & Claudine)"
              className="w-full px-3 py-2 rounded-xl border border-stone-300"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Type d'Alliance</label>
              <select
                value={allianceType}
                onChange={(e) => setAllianceType(e.target.value as AllianceType)}
                className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
              >
                <option value="MARIAGE">Alliance par Mariage</option>
                <option value="DESCENDANCE">Alliance par Descendance</option>
                <option value="PACT_FAMILIAL">Pacte Familial Historique</option>
                <option value="AUTRE">Autre lien reconnu</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">Date de l'Alliance</label>
              <input
                type="date"
                value={allianceDate}
                onChange={(e) => setAllianceDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">
                Membre Nzala Référent
              </label>
              <select
                value={primaryMemberSourceId}
                onChange={(e) => setPrimaryMemberSourceId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
              >
                {nzalaMembers.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.firstName} {m.lastName}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">
                Membre Famille Alliée Référent
              </label>
              <input
                type="text"
                value={primaryMemberAlliedName}
                onChange={(e) => setPrimaryMemberAlliedName(e.target.value)}
                placeholder="Ex: Claudine Mavungu..."
                className="w-full px-3 py-2 rounded-xl border border-stone-300"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-stone-700 mb-1">
              Description &amp; Portée de l'Alliance
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Préciser l'historique du mariage, les branches concernées, les accords familiaux..."
              className="w-full px-3 py-2 rounded-xl border border-stone-300"
            />
          </div>

          <div className="pt-4 border-t border-stone-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-stone-300 text-stone-700 font-semibold hover:bg-stone-50 transition"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold transition shadow-md"
            >
              Enregistrer l'alliance
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
