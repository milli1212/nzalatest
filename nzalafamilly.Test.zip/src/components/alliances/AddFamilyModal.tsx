import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { FamilyType } from '../../types';
import { X, Building2 } from 'lucide-react';

interface AddFamilyModalProps {
  onClose: () => void;
}

export const AddFamilyModal: React.FC<AddFamilyModalProps> = ({ onClose }) => {
  const { addFamily, showToast } = useFamily();

  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [originLocation, setOriginLocation] = useState('');
  const [description, setDescription] = useState('');
  const [patriarchName, setPatriarchName] = useState('');
  const [foundingYear, setFoundingYear] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      showToast('error', 'Le nom de la famille est obligatoire.');
      return;
    }

    addFamily({
      name: name.trim().startsWith('Famille ') ? name.trim() : `Famille ${name.trim()}`,
      code: code.trim().toUpperCase() || name.slice(0, 6).toUpperCase(),
      type: 'ALLIEE',
      status: 'ACTIVE',
      originLocation: originLocation.trim() || undefined,
      description: description.trim() || `Famille alliée partenaire de la Famille Nzala.`,
      patriarchName: patriarchName.trim() || undefined,
      foundingYear: foundingYear ? parseInt(foundingYear) : undefined,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        <div className="bg-stone-900 text-stone-100 p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center border border-sky-500/30">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-serif font-bold text-stone-100">
                Enregistrer une Famille Alliée
              </h2>
              <p className="text-xs text-stone-400">
                Ajouter une famille partenaire dans le registre de NzalaFamilly
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full text-stone-400 hover:text-stone-100 hover:bg-stone-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-stone-700 mb-1">
              Nom de la Famille <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Famille Mavungu, Famille Kanza, Famille Nlandu..."
              className="w-full px-3 py-2 rounded-xl border border-stone-300"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">
                Lieu d'origine / Territoire
              </label>
              <input
                type="text"
                value={originLocation}
                onChange={(e) => setOriginLocation(e.target.value)}
                placeholder="Ex: Boma, Muanda, Tshela, Kinshasa..."
                className="w-full px-3 py-2 rounded-xl border border-stone-300"
              />
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">
                Doyen / Patriarche Référent
              </label>
              <input
                type="text"
                value={patriarchName}
                onChange={(e) => setPatriarchName(e.target.value)}
                placeholder="Ex: Doyen Joseph Mavungu..."
                className="w-full px-3 py-2 rounded-xl border border-stone-300"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-stone-700 mb-1">
              Description &amp; Historique de la Famille
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Origines, traditions et liens d'alliance avec la famille Nzala..."
              className="w-full px-3 py-2 rounded-xl border border-stone-300"
            />
          </div>

          <div className="pt-4 border-t border-stone-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl border border-stone-300 text-stone-700 font-semibold hover:bg-stone-50 transition"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-sky-700 hover:bg-sky-600 text-white font-bold transition shadow-md"
            >
              Enregistrer la famille
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
