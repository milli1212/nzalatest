import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { Family, Alliance } from '../../types';
import { FamilyTypeBadge, AllianceStatusBadge } from '../common/Badges';
import { AddAllianceModal } from './AddAllianceModal';
import { AddFamilyModal } from './AddFamilyModal';
import {
  Building2,
  HeartHandshake,
  Plus,
  Users,
  MapPin,
  Calendar,
  ShieldCheck,
  Award,
  ChevronRight,
  Info
} from 'lucide-react';

export const AlliancesView: React.FC = () => {
  const {
    families,
    alliances,
    members,
    currentUser,
    can,
    setActiveTab,
  } = useFamily();

  const [activeTabSub, setActiveTabSub] = useState<'FAMILLES' | 'ALLIANCES'>('FAMILLES');
  const [isAddAllianceOpen, setIsAddAllianceOpen] = useState(false);
  const [isAddFamilyOpen, setIsAddFamilyOpen] = useState(false);
  const [selectedFamilyDetail, setSelectedFamilyDetail] = useState<Family | null>(null);

  const nzalaFamily = families.find((f) => f.type === 'PRINCIPALE');
  const alliedFamilies = families.filter((f) => f.type === 'ALLIEE');

  const canManageAlliances =
    currentUser.role === 'SUPER_ADMIN' ||
    currentUser.role === 'ADMIN_FAMILIAL' ||
    can('CREATE_ALLIANCE');

  return (
    <div id="alliances-view" className="space-y-6 pb-12">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-stone-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-serif font-bold text-stone-900">
              Familles Alliées &amp; Alliances
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-sky-50 text-sky-800 border border-sky-200">
              {alliedFamilies.length} familles alliées • {alliances.length} alliances
            </span>
          </div>
          <p className="text-xs sm:text-sm text-stone-500 mt-1">
            Gestion du réseau familial, des pactes coutumiers et des mariages liant la <strong>Famille Nzala</strong> aux familles alliées.
          </p>
        </div>

        {canManageAlliances && (
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setIsAddFamilyOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold border border-stone-300 transition cursor-pointer"
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>Ajouter une famille</span>
            </button>

            <button
              onClick={() => setIsAddAllianceOpen(true)}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold transition shadow-md shadow-emerald-950/20 cursor-pointer"
            >
              <HeartHandshake className="w-4 h-4" />
              <span>Nouvelle Alliance</span>
            </button>
          </div>
        )}
      </div>

      {/* Switcher Tab */}
      <div className="flex gap-2 border-b border-stone-200 pb-2">
        <button
          onClick={() => setActiveTabSub('FAMILLES')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
            activeTabSub === 'FAMILLES'
              ? 'bg-stone-900 text-stone-100 shadow-xs'
              : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
          }`}
        >
          Répertoire des Familles ({families.length})
        </button>

        <button
          onClick={() => setActiveTabSub('ALLIANCES')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
            activeTabSub === 'ALLIANCES'
              ? 'bg-emerald-800 text-emerald-50 shadow-xs'
              : 'bg-white text-emerald-900 hover:bg-emerald-50 border border-emerald-300'
          }`}
        >
          Registre des Alliances &amp; Mariages ({alliances.length})
        </button>
      </div>

      {/* Sub-view: Familles (Nzala + Alliées) */}
      {activeTabSub === 'FAMILLES' && (
        <div className="space-y-6">
          {/* Main Source Family Card: Nzala */}
          {nzalaFamily && (
            <div className="p-6 rounded-3xl bg-gradient-to-br from-amber-900 via-stone-900 to-stone-950 text-stone-100 border border-amber-800/40 shadow-xl relative overflow-hidden">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
                <div className="space-y-2 max-w-2xl">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-amber-500 text-stone-950">
                      Famille Souche &amp; Fondatrice
                    </span>
                    <span className="text-xs text-amber-200/80">Code: {nzalaFamily.code}</span>
                  </div>

                  <h2 className="text-2xl font-serif font-bold text-amber-100">{nzalaFamily.name}</h2>
                  <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
                    {nzalaFamily.description}
                  </p>

                  <div className="pt-2 flex flex-wrap gap-4 text-xs text-amber-200/90">
                    <span>📍 Origine : <strong>{nzalaFamily.originLocation}</strong></span>
                    <span>👑 Patriarche fondateur : <strong>{nzalaFamily.patriarchName}</strong></span>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-stone-900/80 border border-stone-700/80 shrink-0 text-center space-y-1">
                  <div className="text-2xl font-bold font-serif text-amber-400">
                    {members.filter((m) => m.familyType === 'NZALA_DIRECT').length}
                  </div>
                  <div className="text-xs text-stone-400">Membres Directs Enregistrés</div>
                  <button
                    onClick={() => setActiveTab('members')}
                    className="mt-2 w-full py-1.5 px-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold transition"
                  >
                    Voir les membres
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Section: Allied Families Grid */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-serif font-bold text-stone-900">
                Familles Alliées Reconnues
              </h2>
              <p className="text-xs text-stone-500">
                Familles partenaires disposant d'un statut d'alliance validé
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {alliedFamilies.map((family) => {
                const familyMembersCount = members.filter((m) => m.primaryFamilyId === family.id).length;
                const familyAlliances = alliances.filter(
                  (a) => a.alliedFamilyId === family.id || a.sourceFamilyId === family.id
                );

                return (
                  <div
                    key={family.id}
                    className="p-6 rounded-3xl bg-white border border-stone-200 hover:border-sky-400 hover:shadow-md transition space-y-4 flex flex-col justify-between"
                  >
                    <div className="space-y-3">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="w-2.5 h-2.5 rounded-full bg-sky-500"></span>
                            <h3 className="font-serif font-bold text-lg text-stone-900">
                              {family.name}
                            </h3>
                          </div>
                          {family.originLocation && (
                            <p className="text-xs text-stone-500 flex items-center gap-1 mt-0.5">
                              <MapPin className="w-3.5 h-3.5 text-stone-400" />
                              <span>{family.originLocation}</span>
                              {family.foundingYear && <span>• Fondée vers {family.foundingYear}</span>}
                            </p>
                          )}
                        </div>

                        <FamilyTypeBadge type={family.type} />
                      </div>

                      <p className="text-xs text-stone-600 leading-relaxed">
                        {family.description}
                      </p>

                      {family.patriarchName && (
                        <div className="text-xs text-stone-700 bg-stone-50 p-2.5 rounded-xl border border-stone-150">
                          <span className="text-stone-400 font-medium">Doyen référent : </span>
                          <strong className="text-stone-900">{family.patriarchName}</strong>
                        </div>
                      )}
                    </div>

                    <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-3 text-stone-500 font-medium">
                        <span>{familyMembersCount} membres alliés</span>
                        <span>•</span>
                        <span>{familyAlliances.length} alliances formelles</span>
                      </div>

                      <button
                        onClick={() => setActiveTab('members')}
                        className="font-bold text-sky-800 hover:text-sky-900 flex items-center gap-1"
                      >
                        <span>Membres</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Sub-view: Alliances & Pacts */}
      {activeTabSub === 'ALLIANCES' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-start gap-3">
            <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <p>
              Les alliances représentent les unions matrimoniales et liens séculaires scellant le rapprochement entre la <strong>Famille Nzala</strong> et ses familles alliées. Chaque alliance donne lieu à des droits de participation familiale spécifiques.
            </p>
          </div>

          <div className="space-y-4">
            {alliances.map((alliance) => {
              return (
                <div
                  key={alliance.id}
                  className="p-6 rounded-3xl bg-white border border-stone-200 hover:border-emerald-400 hover:shadow-md transition space-y-4"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-100 pb-3">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <h3 className="font-serif font-bold text-base sm:text-lg text-stone-900">
                          {alliance.title}
                        </h3>
                        <AllianceStatusBadge status={alliance.status} />
                      </div>
                      <p className="text-xs text-stone-500 font-medium">
                        Union entre <strong className="text-amber-900">{alliance.sourceFamilyName}</strong> et{' '}
                        <strong className="text-sky-900">{alliance.alliedFamilyName}</strong>
                      </p>
                    </div>

                    {alliance.startDate && (
                      <span className="px-3 py-1 rounded-xl text-xs font-semibold bg-stone-100 text-stone-700 shrink-0">
                        Date : {alliance.startDate}
                      </span>
                    )}
                  </div>

                  <p className="text-xs sm:text-sm text-stone-700 leading-relaxed">
                    {alliance.description}
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-stone-50 p-3.5 rounded-2xl border border-stone-150">
                    <div>
                      <span className="text-stone-400 block mb-0.5">Membres Fondateurs de l'Union</span>
                      <span className="font-semibold text-stone-900">
                        {alliance.primaryMemberSourceName || 'Non spécifié'} &amp;{' '}
                        {alliance.primaryMemberAlliedName || 'Non spécifié'}
                      </span>
                    </div>

                    <div>
                      <span className="text-stone-400 block mb-0.5">Autorité de Validation</span>
                      <span className="font-semibold text-stone-900">
                        {alliance.validatedByName || 'Conseil des Sages Nzala'}
                      </span>
                    </div>
                  </div>

                  {alliance.notes && (
                    <p className="text-xs text-stone-500 italic">
                      Note administrative : {alliance.notes}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Modals */}
      {isAddAllianceOpen && <AddAllianceModal onClose={() => setIsAddAllianceOpen(false)} />}
      {isAddFamilyOpen && <AddFamilyModal onClose={() => setIsAddFamilyOpen(false)} />}
    </div>
  );
};
