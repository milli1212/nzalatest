import React from 'react';
import { FeedView } from '../feed/FeedView';

export const AnnouncementsView: React.FC = () => {
  return <FeedView />;
};
