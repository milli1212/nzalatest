import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { checkPasswordStrength } from '../../services/authService';
import {
  X,
  Lock,
  Mail,
  User,
  Phone,
  Eye,
  EyeOff,
  ShieldCheck,
  Check,
  AlertCircle,
  Sparkles,
  ArrowRight,
  KeyRound
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'LOGIN' | 'REGISTER' | 'RESET';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'LOGIN',
}) => {
  const { login, register, requestPasswordReset, switchProfile, availableProfiles } = useFamily();

  const [mode, setMode] = useState<'LOGIN' | 'REGISTER' | 'RESET'>(initialMode);
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Register form state
  const [regFirstName, setRegFirstName] = useState('');
  const [regLastName, setRegLastName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regPasswordConfirm, setRegPasswordConfirm] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);

  // Reset form state
  const [resetEmail, setResetEmail] = useState('');

  if (!isOpen) return null;

  const passwordStrength = checkPasswordStrength(regPassword);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!loginEmail.trim() || !loginPassword) {
      setErrorMessage('Veuillez renseigner votre adresse e-mail et votre mot de passe.');
      return;
    }

    const res = login(loginEmail, loginPassword);
    if (!res.success) {
      setErrorMessage(res.error || 'Erreur lors de la connexion.');
    } else {
      onClose();
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!regFirstName.trim() || !regLastName.trim() || !regEmail.trim() || !regPhone.trim()) {
      setErrorMessage('Tous les champs sont requis.');
      return;
    }

    if (passwordStrength.score < 2) {
      setErrorMessage('Le mot de passe est trop faible. Veuillez respecter au moins 8 caractères et plusieurs types de caractères.');
      return;
    }

    if (regPassword !== regPasswordConfirm) {
      setErrorMessage('Les mots de passe ne correspondent pas.');
      return;
    }

    if (!termsAccepted) {
      setErrorMessage('Veuillez accepter la charte de confidentialité et les règles de gouvernance familiale.');
      return;
    }

    const res = register({
      firstName: regFirstName,
      lastName: regLastName,
      email: regEmail,
      phone: regPhone,
      password: regPassword,
    });

    if (!res.success) {
      setErrorMessage(res.error || "Erreur lors de la création du compte.");
    } else {
      onClose();
    }
  };

  const handleResetSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!resetEmail.trim()) {
      setErrorMessage('Veuillez saisir votre adresse e-mail.');
      return;
    }

    const res = requestPasswordReset(resetEmail);
    setSuccessMessage(res.message);
  };

  const handleQuickDemoLogin = (index: number) => {
    switchProfile(index);
    onClose();
  };

  return (
    <div
      id="auth-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-xs overflow-y-auto"
    >
      <div
        id="auth-modal-container"
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Modal Top Header */}
        <div className="bg-stone-900 text-stone-100 p-6 flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-serif font-bold text-lg text-stone-100">NzalaFamilly</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Portail Sécurisé
                </span>
              </div>
              <p className="text-xs text-stone-400 mt-0.5">
                {mode === 'LOGIN' && 'Connectez-vous à votre espace familial'}
                {mode === 'REGISTER' && 'Création de compte personnel'}
                {mode === 'RESET' && 'Récupération de mot de passe'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full text-stone-400 hover:text-stone-100 hover:bg-stone-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Toggle (Login / Register) */}
        {mode !== 'RESET' && (
          <div className="grid grid-cols-2 p-1.5 bg-stone-100 border-b border-stone-200 text-xs font-bold">
            <button
              onClick={() => {
                setMode('LOGIN');
                setErrorMessage(null);
              }}
              className={`py-2.5 rounded-xl transition cursor-pointer ${
                mode === 'LOGIN'
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-500 hover:text-stone-900'
              }`}
            >
              Se connecter
            </button>
            <button
              onClick={() => {
                setMode('REGISTER');
                setErrorMessage(null);
              }}
              className={`py-2.5 rounded-xl transition cursor-pointer ${
                mode === 'REGISTER'
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-500 hover:text-stone-900'
              }`}
            >
              Créer un compte
            </button>
          </div>
        )}

        {/* Body content */}
        <div className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Error Message */}
          {errorMessage && (
            <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
              <div>{errorMessage}</div>
            </div>
          )}

          {/* Success Message (for reset) */}
          {successMessage && (
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-start gap-2.5">
              <Check className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
              <div>{successMessage}</div>
            </div>
          )}

          {/* MODE: LOGIN */}
          {mode === 'LOGIN' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5">
                  Adresse e-mail
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                  <input
                    type="email"
                    required
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="ex: jean.nzala@email.com"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:outline-hidden focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-stone-700">Mot de passe</label>
                  <button
                    type="button"
                    onClick={() => {
                      setMode('RESET');
                      setErrorMessage(null);
                    }}
                    className="text-[11px] text-amber-800 hover:underline font-semibold cursor-pointer"
                  >
                    Mot de passe oublié ?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="Votre mot de passe"
                    className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:outline-hidden focus:border-amber-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 p-1"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs shadow-md shadow-amber-950/20 transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Accéder à mon espace familial</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* MODE: REGISTER */}
          {mode === 'REGISTER' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              {/* Important Rule Notice */}
              <div className="p-3.5 rounded-2xl bg-amber-50/80 border border-amber-200/80 text-[11px] text-amber-950 space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-amber-900">
                  <Sparkles className="w-3.5 h-3.5 text-amber-700" />
                  <span>Principe de gouvernance NzalaFamilly</span>
                </div>
                <p className="leading-relaxed">
                  L'inscription crée votre <strong>compte personnel d'accès</strong>. L'appartenance à la Famille Nzala ou l'affiliation d'une famille alliée est ensuite soumise à déclaration et examen par le Conseil de Famille.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Prénom</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                    <input
                      type="text"
                      required
                      value={regFirstName}
                      onChange={(e) => setRegFirstName(e.target.value)}
                      placeholder="ex: Alain"
                      className="w-full pl-9 pr-3 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:outline-hidden focus:border-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Nom de famille</label>
                  <input
                    type="text"
                    required
                    value={regLastName}
                    onChange={(e) => setRegLastName(e.target.value)}
                    placeholder="ex: Nzala"
                    className="w-full px-3 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:outline-hidden focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Adresse e-mail</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                    <input
                      type="email"
                      required
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="ex: alain@email.com"
                      className="w-full pl-9 pr-3 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:outline-hidden focus:border-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">Téléphone</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                    <input
                      type="tel"
                      required
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      placeholder="+243 ..."
                      className="w-full pl-9 pr-3 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:outline-hidden focus:border-amber-500"
                    />
                  </div>
                </div>
              </div>

              {/* Password & Security checks */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-stone-700">
                  Mot de passe sécurisé
                </label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Minimum 8 caractères"
                    className="w-full pl-10 pr-10 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:outline-hidden focus:border-amber-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 p-1"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                {/* Password strength meter */}
                {regPassword && (
                  <div className="space-y-1 pt-1">
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-stone-500">Robustesse du mot de passe :</span>
                      <span className="font-bold text-stone-800">{passwordStrength.label}</span>
                    </div>
                    <div className="grid grid-cols-4 gap-1 h-1.5">
                      {[1, 2, 3, 4].map((step) => (
                        <div
                          key={step}
                          className={`rounded-full transition-all ${
                            step <= passwordStrength.score ? passwordStrength.color : 'bg-stone-200'
                          }`}
                        />
                      ))}
                    </div>

                    <div className="grid grid-cols-2 gap-1 text-[10px] text-stone-500 pt-1">
                      <span className={passwordStrength.hasMinLength ? 'text-emerald-700 font-medium' : ''}>
                        ✓ 8 caractères min.
                      </span>
                      <span className={passwordStrength.hasUpperCase && passwordStrength.hasLowerCase ? 'text-emerald-700 font-medium' : ''}>
                        ✓ Majuscules &amp; minuscules
                      </span>
                      <span className={passwordStrength.hasNumber ? 'text-emerald-700 font-medium' : ''}>
                        ✓ Au moins 1 chiffre
                      </span>
                      <span className={passwordStrength.hasSpecialChar ? 'text-emerald-700 font-medium' : ''}>
                        ✓ Caractère spécial
                      </span>
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Confirmer le mot de passe
                </label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={regPasswordConfirm}
                    onChange={(e) => setRegPasswordConfirm(e.target.value)}
                    placeholder="Retapez votre mot de passe"
                    className="w-full pl-10 pr-3.5 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:outline-hidden focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="flex items-start gap-2 pt-1">
                <input
                  type="checkbox"
                  id="reg-terms"
                  checked={termsAccepted}
                  onChange={(e) => setTermsAccepted(e.target.checked)}
                  className="mt-1 rounded text-amber-600 focus:ring-amber-500 cursor-pointer"
                />
                <label htmlFor="reg-terms" className="text-[11px] text-stone-600 leading-snug cursor-pointer">
                  J'accepte la charte d'utilisation de NzalaFamilly et je comprends que l'accès complet à la généalogie nécessite une validation préalable.
                </label>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs shadow-md shadow-amber-950/20 transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Créer mon compte &amp; Définir mon affiliation</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* MODE: RESET */}
          {mode === 'RESET' && (
            <form onSubmit={handleResetSubmit} className="space-y-4">
              <p className="text-xs text-stone-600 leading-relaxed">
                Saisissez l'adresse e-mail associée à votre compte familial. Nous vous transmettrons les consignes sécurisées pour définir un nouveau mot de passe.
              </p>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5">Adresse e-mail</label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                  <input
                    type="email"
                    required
                    value={resetEmail}
                    onChange={(e) => setResetEmail(e.target.value)}
                    placeholder="votre.email@domaine.com"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:bg-white focus:outline-hidden focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setMode('LOGIN');
                    setErrorMessage(null);
                    setSuccessMessage(null);
                  }}
                  className="flex-1 py-2.5 rounded-xl border border-stone-300 text-stone-700 font-semibold text-xs hover:bg-stone-50 transition cursor-pointer"
                >
                  Retour
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs transition cursor-pointer"
                >
                  Envoyer le lien
                </button>
              </div>
            </form>
          )}

          {/* Fast Demo Switcher for convenience and review */}
          <div className="pt-4 border-t border-stone-200 space-y-2">
            <div className="flex items-center justify-between text-[11px] text-stone-500 font-bold uppercase tracking-wider">
              <span className="flex items-center gap-1">
                <KeyRound className="w-3 h-3 text-amber-700" />
                <span>Test Rapide : Profils de Démonstration</span>
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {availableProfiles.slice(0, 6).map((p, idx) => (
                <button
                  key={p.user.id}
                  type="button"
                  onClick={() => handleQuickDemoLogin(idx)}
                  className="p-2.5 rounded-xl bg-stone-50 hover:bg-amber-50 hover:border-amber-300 border border-stone-200 text-left transition flex flex-col justify-between cursor-pointer"
                >
                  <span className="font-bold text-[11px] text-stone-900 truncate">{p.user.name}</span>
                  <span className="text-[10px] text-stone-500">{p.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
