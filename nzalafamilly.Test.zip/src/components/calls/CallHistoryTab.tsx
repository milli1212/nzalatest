/**
 * NzalaFamilly - Onglet Historique des Appels (NZALA CALL HISTORY)
 * Visualisation des appels entrants, sortants, manqués et rappel direct en un clic
 */

import React, { useState } from 'react';
import {
  Phone,
  PhoneIncoming,
  PhoneOutgoing,
  PhoneMissed,
  Video,
  Clock,
  Calendar,
  Sparkles,
  Trash2,
  Filter,
  User,
  Shield,
  Radio,
  CheckCircle,
} from 'lucide-react';
import { CallHistoryItem, CallType } from '../../types/calls';
import { CallService } from '../../services/calls/CallService';
import { MessagingService } from '../../services/messagingService';

interface CallHistoryTabProps {
  callHistory: CallHistoryItem[];
  currentUserId: string;
  onInitiateCall: (target: { id: string; name: string; avatarUrl?: string }, type: CallType) => void;
  onSimulateIncomingCall: () => void;
  onClearHistory: () => void;
}

export const CallHistoryTab: React.FC<CallHistoryTabProps> = ({
  callHistory,
  currentUserId,
  onInitiateCall,
  onSimulateIncomingCall,
  onClearHistory,
}) => {
  const [filterType, setFilterType] = useState<'ALL' | 'MISSED' | 'AUDIO' | 'VIDEO'>('ALL');

  const filteredHistory = callHistory.filter((item) => {
    if (filterType === 'MISSED') return item.status === 'MISSED';
    if (filterType === 'AUDIO') return item.type === 'AUDIO';
    if (filterType === 'VIDEO') return item.type === 'VIDEO';
    return true;
  });

  const renderCallIcon = (item: CallHistoryItem) => {
    if (item.status === 'MISSED') {
      return <PhoneMissed className="w-4 h-4 text-rose-500" />;
    }
    if (item.direction === 'INCOMING') {
      return <PhoneIncoming className="w-4 h-4 text-emerald-500" />;
    }
    return <PhoneOutgoing className="w-4 h-4 text-blue-500" />;
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-white overflow-hidden">
      {/* Header bar */}
      <div className="p-4 border-b border-stone-200 bg-stone-50/50 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-stone-900">Historique des Appels</h2>
            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-200">
              {callHistory.length} appels
            </span>
          </div>
          <p className="text-xs text-stone-500">
            Journal sécurisé des communications audio et vidéo privées
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Simulate button for testing */}
          <button
            id="btn-simulate-incoming-call"
            onClick={onSimulateIncomingCall}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs shadow-xs transition cursor-pointer"
            title="Tester la réception d'un appel entrant"
          >
            <Radio className="w-3.5 h-3.5" />
            <span>Tester Appel Entrant</span>
          </button>

          {callHistory.length > 0 && (
            <button
              id="btn-clear-call-history"
              onClick={onClearHistory}
              className="p-2 rounded-xl text-stone-400 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
              title="Effacer l’historique"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="px-4 py-2 border-b border-stone-200 bg-white flex gap-1.5 overflow-x-auto text-xs">
        {[
          { id: 'ALL', label: 'Tous les appels' },
          { id: 'MISSED', label: 'Appels manqués' },
          { id: 'AUDIO', label: 'Audio' },
          { id: 'VIDEO', label: 'Vidéo HD' },
        ].map((tab) => (
          <button
            key={tab.id}
            id={`filter-calls-${tab.id.toLowerCase()}`}
            onClick={() => setFilterType(tab.id as any)}
            className={`px-3 py-1.5 rounded-lg font-medium transition whitespace-nowrap cursor-pointer ${
              filterType === tab.id
                ? 'bg-stone-900 text-white font-bold shadow-xs'
                : 'text-stone-600 hover:bg-stone-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* History List */}
      <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-2">
        {filteredHistory.length > 0 ? (
          filteredHistory.map((item) => {
            const isOutgoing = item.callerId === currentUserId;
            const contactName = isOutgoing ? item.receiverName : item.callerName;
            const contactAvatar = isOutgoing ? item.receiverAvatar : item.callerAvatar;
            const contactId = isOutgoing ? item.receiverId : item.callerId;

            return (
              <div
                key={item.id}
                id={`call-item-${item.id}`}
                className="p-3 sm:p-4 rounded-2xl bg-white border border-stone-200/80 hover:border-amber-300 hover:shadow-xs transition flex items-center justify-between gap-3 group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  {/* Contact Avatar */}
                  <div className="relative shrink-0">
                    {contactAvatar ? (
                      <img
                        src={contactAvatar}
                        alt={contactName}
                        className="w-11 h-11 rounded-2xl object-cover border border-stone-200"
                      />
                    ) : (
                      <div className="w-11 h-11 rounded-2xl bg-stone-100 border border-stone-200 flex items-center justify-center text-stone-700 font-bold text-base">
                        {contactName.charAt(0)}
                      </div>
                    )}
                    <div className="absolute -bottom-1 -right-1 p-0.5 bg-white rounded-full shadow-xs">
                      {renderCallIcon(item)}
                    </div>
                  </div>

                  {/* Call details */}
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h4
                        className={`text-sm font-bold truncate ${
                          item.status === 'MISSED' ? 'text-rose-600' : 'text-stone-900'
                        }`}
                      >
                        {contactName}
                      </h4>
                      <span className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-stone-100 text-stone-600 border border-stone-200">
                        {item.type === 'VIDEO' ? 'Vidéo' : 'Audio'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-xs text-stone-500 mt-0.5">
                      <span>{MessagingService.formatRelativeTime(item.timestamp)}</span>
                      {item.durationSeconds > 0 && (
                        <>
                          <span>•</span>
                          <span className="font-mono text-[11px]">
                            {CallService.formatDuration(item.durationSeconds)}
                          </span>
                        </>
                      )}
                      {item.status === 'MISSED' && (
                        <>
                          <span>•</span>
                          <span className="text-rose-500 font-medium">Non décroché</span>
                        </>
                      )}
                    </div>

                    {item.recordedNote && (
                      <p className="text-[11px] text-stone-500 italic mt-1 truncate max-w-sm">
                        « {item.recordedNote} »
                      </p>
                    )}
                  </div>
                </div>

                {/* Direct Action Buttons (Redial) */}
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    id={`btn-redial-audio-${item.id}`}
                    onClick={() =>
                      onInitiateCall(
                        { id: contactId, name: contactName, avatarUrl: contactAvatar },
                        'AUDIO'
                      )
                    }
                    className="p-2.5 rounded-xl bg-stone-100 hover:bg-emerald-50 text-stone-700 hover:text-emerald-700 border border-stone-200 transition cursor-pointer"
                    title="Rappeler en audio"
                  >
                    <Phone className="w-4 h-4" />
                  </button>

                  <button
                    id={`btn-redial-video-${item.id}`}
                    onClick={() =>
                      onInitiateCall(
                        { id: contactId, name: contactName, avatarUrl: contactAvatar },
                        'VIDEO'
                      )
                    }
                    className="p-2.5 rounded-xl bg-stone-100 hover:bg-blue-50 text-stone-700 hover:text-blue-700 border border-stone-200 transition cursor-pointer"
                    title="Rappeler en vidéo HD"
                  >
                    <Video className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="py-16 text-center text-stone-400">
            <Phone className="w-12 h-12 mx-auto mb-3 opacity-30 text-stone-500" />
            <h3 className="text-base font-bold text-stone-700">Aucun appel dans cette catégorie</h3>
            <p className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
              Vos appels audio et vidéo passés ou reçus apparaîtront ici avec leur durée et statut.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
