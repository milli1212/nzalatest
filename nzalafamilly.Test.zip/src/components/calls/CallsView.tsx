import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { CallHistoryTab } from './CallHistoryTab';
import { NzalaCallModal } from './NzalaCallModal';
import { IncomingCallModal } from './IncomingCallModal';
import { Phone, Video, Users, Search, Sparkles, ShieldCheck, PhoneCall, Plus } from 'lucide-react';
import { VerifiedBadge } from '../common/VerifiedBadge';

export const CallsView: React.FC = () => {
  const {
    members,
    currentUser,
    startCall,
    callHistory,
    clearCallHistory,
    activeCallSession,
    incomingCallSession,
    answerIncomingCall,
    rejectIncomingCall,
    endActiveCall,
    toggleMuteCall,
    toggleVideoCall,
    switchCameraCall,
    toggleSpeakerCall,
    simulateIncomingCall,
  } = useFamily();

  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'CONTACTS' | 'HISTORY'>('CONTACTS');

  // Filter contacts to call
  const callableMembers = members.filter((m) => {
    // Exclude current user
    if (currentUser.memberId && m.id === currentUser.memberId) return false;
    if (currentUser.email && m.email && m.email.toLowerCase() === currentUser.email.toLowerCase()) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const fullName = `${m.firstName} ${m.lastName}`.toLowerCase();
      const branch = (m.branchName || '').toLowerCase();
      const family = (m.primaryFamilyName || '').toLowerCase();
      return fullName.includes(q) || branch.includes(q) || family.includes(q);
    }
    return true;
  });

  return (
    <div id="calls-view-container" className="space-y-6 max-w-5xl mx-auto pb-12 animate-fadeIn">
      {/* Hero Header */}
      <div className="rounded-3xl bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white p-5 sm:p-7 shadow-xl border border-blue-800/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5 mb-1.5">
            <div className="w-10 h-10 rounded-2xl bg-blue-500/20 text-blue-300 flex items-center justify-center border border-blue-400/30 shadow-xs">
              <PhoneCall className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
                Nzala Calls
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-blue-500/30 text-blue-200 border border-blue-400/30">
                  Audio & Vidéo HD
                </span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-300">
                Appels familiaux chiffrés de bout en bout avec caméra HD et son clair
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => simulateIncomingCall()}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold border border-white/20 transition cursor-pointer backdrop-blur-xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Tester un appel</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          type="button"
          onClick={() => setActiveTab('CONTACTS')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition cursor-pointer ${
            activeTab === 'CONTACTS'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Annuaire & Contacts ({callableMembers.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('HISTORY')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition cursor-pointer ${
            activeTab === 'HISTORY'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Phone className="w-4 h-4" />
          <span>Journal d'appels</span>
        </button>
      </div>

      {/* Tab: Contacts */}
      {activeTab === 'CONTACTS' ? (
        <div className="space-y-4">
          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher un membre de la famille pour l'appeler..."
              className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white border border-slate-200 text-xs sm:text-sm text-slate-900 focus:outline-hidden focus:border-blue-500 shadow-2xs"
            />
          </div>

          {/* Members List */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {callableMembers.map((member) => (
              <div
                key={member.id}
                className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-11 h-11 rounded-full overflow-hidden bg-gradient-to-tr from-blue-600 to-indigo-600 text-white shrink-0 flex items-center justify-center font-bold text-sm shadow-xs">
                    {member.avatarUrl ? (
                      <img src={member.avatarUrl} alt="" className="w-full h-full object-cover" />
                    ) : (
                      member.firstName.charAt(0)
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1">
                      <p className="text-xs sm:text-sm font-bold text-slate-900 truncate">
                        {member.firstName} {member.lastName}
                      </p>
                      <VerifiedBadge
                        role="MEMBRE_NZALA"
                        isVerified={true}
                        size="sm"
                      />
                    </div>
                    <p className="text-[10px] text-slate-500 truncate">
                      {member.branchName || member.primaryFamilyName}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() =>
                      startCall({
                        id: member.userId || member.id,
                        name: `${member.firstName} ${member.lastName}`,
                        avatarUrl: member.avatarUrl,
                        role: 'MEMBRE_NZALA',
                        familyName: member.primaryFamilyName,
                      }, 'AUDIO')
                    }
                    className="w-8 h-8 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 flex items-center justify-center border border-emerald-200 transition cursor-pointer"
                    title="Appel Audio"
                  >
                    <Phone className="w-3.5 h-3.5" />
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      startCall({
                        id: member.userId || member.id,
                        name: `${member.firstName} ${member.lastName}`,
                        avatarUrl: member.avatarUrl,
                        role: 'MEMBRE_NZALA',
                        familyName: member.primaryFamilyName,
                      }, 'VIDEO')
                    }
                    className="w-8 h-8 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 flex items-center justify-center border border-blue-200 transition cursor-pointer"
                    title="Appel Vidéo"
                  >
                    <Video className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <CallHistoryTab
          callHistory={callHistory}
          currentUserId={currentUser.id}
          onInitiateCall={(target, type) => startCall(target, type)}
          onSimulateIncomingCall={() => simulateIncomingCall()}
          onClearHistory={() => clearCallHistory()}
        />
      )}

      {/* Call Modals */}
      {activeCallSession && (
        <NzalaCallModal
          session={activeCallSession}
          onEndCall={(dur) => endActiveCall(dur)}
          onToggleMute={toggleMuteCall}
          onToggleVideo={toggleVideoCall}
          onSwitchCamera={switchCameraCall}
          onToggleSpeaker={toggleSpeakerCall}
        />
      )}

      {incomingCallSession && (
        <IncomingCallModal
          session={incomingCallSession}
          onAccept={(withVideo) => answerIncomingCall(withVideo)}
          onReject={() => rejectIncomingCall()}
        />
      )}
    </div>
  );
};
