/**
 * NzalaFamilly - Modale d'Appel Entrant (INCOMING CALL)
 * Affiche l'identité de l'appelant, le type d'appel (audio/vidéo) et les options de réponse
 */

import React, { useEffect } from 'react';
import { Phone, PhoneOff, Video, Mic, Shield, Sparkles } from 'lucide-react';
import { CallSession } from '../../types/calls';
import { CallService } from '../../services/calls/CallService';
import { VerifiedBadge } from '../common/VerifiedBadge';

interface IncomingCallModalProps {
  session: CallSession | null;
  onAccept: (withVideo: boolean) => void;
  onReject: () => void;
}

export const IncomingCallModal: React.FC<IncomingCallModalProps> = ({
  session,
  onAccept,
  onReject,
}) => {
  useEffect(() => {
    if (session && session.direction === 'INCOMING') {
      CallService.startRingtone('INCOMING');
    } else {
      CallService.stopRingtone();
    }
    return () => {
      CallService.stopRingtone();
    };
  }, [session]);

  if (!session || session.direction !== 'INCOMING') return null;

  return (
    <div
      id="incoming-call-overlay"
      className="fixed inset-0 z-50 bg-stone-950/90 backdrop-blur-md flex items-center justify-center p-4 select-none animate-fadeIn"
    >
      <div className="w-full max-w-md bg-stone-900 rounded-3xl border border-amber-500/40 shadow-2xl p-6 text-center text-white relative overflow-hidden">
        {/* Glow effect */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-amber-500/20 rounded-full blur-3xl" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-blue-500/20 rounded-full blur-3xl" />

        {/* Header Tag */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-bold uppercase tracking-wider mb-6">
          <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
          Appel Entrant...
        </div>

        {/* Caller Avatar & Ringing pulse */}
        <div className="relative w-28 h-28 mx-auto mb-5">
          <span className="absolute -inset-3 rounded-full border-2 border-amber-400/50 animate-ping" />
          <span className="absolute -inset-6 rounded-full border border-amber-400/20 animate-pulse" />
          {session.initiatorAvatar ? (
            <img
              src={session.initiatorAvatar}
              alt={session.initiatorName}
              className="w-full h-full rounded-full object-cover border-4 border-amber-400 shadow-xl relative z-10"
            />
          ) : (
            <div className="w-full h-full rounded-full bg-stone-800 border-4 border-amber-400 flex items-center justify-center text-amber-400 font-bold text-3xl shadow-xl relative z-10">
              {session.initiatorName.charAt(0)}
            </div>
          )}
        </div>

        {/* Caller Information */}
        <div className="flex items-center justify-center gap-1.5 mb-1">
          <h3 className="text-xl sm:text-2xl font-bold text-white">
            {session.initiatorName}
          </h3>
          <VerifiedBadge isVerified={true} size="md" />
        </div>
        <p className="text-xs text-stone-300 mb-2">
          {session.groupTitle ? `Dans : ${session.groupTitle}` : 'Membre vérifié de la communauté'}
        </p>

        {/* Call Type Indicator */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-xl bg-stone-800 border border-stone-700 text-xs text-stone-200 mb-8">
          {session.type === 'VIDEO' ? (
            <>
              <Video className="w-4 h-4 text-blue-400" />
              <span>Invitation à un appel vidéo HD</span>
            </>
          ) : (
            <>
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>Invitation à un appel audio</span>
            </>
          )}
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            {/* Refuse */}
            <button
              id="incoming-btn-reject"
              onClick={onReject}
              className="w-full py-3.5 px-4 rounded-2xl bg-rose-600/90 hover:bg-rose-600 text-white font-bold flex items-center justify-center gap-2 shadow-lg shadow-rose-900/40 transition cursor-pointer"
            >
              <PhoneOff className="w-5 h-5" />
              <span>Refuser</span>
            </button>

            {/* Accept (Standard) */}
            <button
              id="incoming-btn-accept"
              onClick={() => onAccept(session.type === 'VIDEO')}
              className="w-full py-3.5 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/40 transition cursor-pointer"
            >
              {session.type === 'VIDEO' ? <Video className="w-5 h-5" /> : <Phone className="w-5 h-5" />}
              <span>Accepter</span>
            </button>
          </div>

          {/* Option: Answer without video (for video calls) */}
          {session.type === 'VIDEO' && (
            <button
              id="incoming-btn-accept-audio-only"
              onClick={() => onAccept(false)}
              className="w-full py-2.5 px-4 rounded-xl bg-stone-800 hover:bg-stone-750 text-stone-300 hover:text-white text-xs font-semibold border border-stone-700 transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <Mic className="w-4 h-4 text-amber-400" />
              <span>Répondre en audio uniquement (sans caméra)</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
