/**
 * NzalaFamilly - Interface Complète d'Appels Audio & Vidéo (NZALA CALLS)
 * Prise en charge WebRTC locale, caméra réelle, bascule micro/vidéo, haut-parleur et historique
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  PhoneOff,
  Mic,
  MicOff,
  Video,
  VideoOff,
  Maximize2,
  Minimize2,
  Volume2,
  VolumeX,
  RotateCcw,
  Sparkles,
  Shield,
  Radio,
  Users,
  AlertTriangle,
  Info,
} from 'lucide-react';
import { CallSession, CallType } from '../../types/calls';
import { CallService } from '../../services/calls/CallService';
import { WebRTCService } from '../../services/calls/WebRTCService';
import { VerifiedBadge } from '../common/VerifiedBadge';

interface NzalaCallModalProps {
  session: CallSession | null;
  onEndCall: (durationSeconds: number) => void;
  onToggleMute: () => void;
  onToggleVideo: () => void;
  onSwitchCamera: () => Promise<boolean>;
  onToggleSpeaker: () => void;
}

export const NzalaCallModal: React.FC<NzalaCallModalProps> = ({
  session,
  onEndCall,
  onToggleMute,
  onToggleVideo,
  onSwitchCamera,
  onToggleSpeaker,
}) => {
  const [duration, setDuration] = useState(0);
  const [callState, setCallState] = useState<'RINGING' | 'CONNECTING' | 'CONNECTED'>('RINGING');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [switchingCamera, setSwitchingCamera] = useState(false);

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const webrtcServiceRef = useRef<WebRTCService | null>(null);
  const modalContainerRef = useRef<HTMLDivElement | null>(null);

  // Initialize call & timer
  useEffect(() => {
    if (!session) {
      setDuration(0);
      setCallState('RINGING');
      setCameraError(null);
      return;
    }

    // Play outgoing ringtone if in ringing state
    CallService.startRingtone('OUTGOING');

    // Simulate peer pickup after 2.2 seconds if outgoing
    const pickupTimer = setTimeout(() => {
      CallService.stopRingtone();
      setCallState('CONNECTING');
      setTimeout(() => {
        setCallState('CONNECTED');
      }, 800);
    }, 2200);

    // Call duration timer once connected
    const durationInterval = setInterval(() => {
      if (callState === 'CONNECTED') {
        setDuration((prev) => prev + 1);
      }
    }, 1000);

    // WebRTC initialization
    const rtc = new WebRTCService({
      onLocalStream: (stream) => {
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }
      },
      onError: (errMsg) => {
        console.warn('WebRTC Error:', errMsg);
        setCameraError(errMsg);
      },
    });
    webrtcServiceRef.current = rtc;

    if (session.type === 'VIDEO') {
      rtc.startLocalMedia({ audio: true, video: true, facingMode: 'user' });
    } else {
      rtc.startLocalMedia({ audio: true, video: false });
    }

    return () => {
      clearTimeout(pickupTimer);
      clearInterval(durationInterval);
      CallService.stopRingtone();
      if (webrtcServiceRef.current) {
        webrtcServiceRef.current.stopAll();
      }
    };
  }, [session?.id, session?.type]);

  // Sync mute/video toggles with local WebRTC stream
  useEffect(() => {
    if (webrtcServiceRef.current && session) {
      webrtcServiceRef.current.setAudioEnabled(!session.isMuted);
      webrtcServiceRef.current.setVideoEnabled(session.isVideoEnabled);
    }
  }, [session?.isMuted, session?.isVideoEnabled]);

  if (!session) return null;

  const otherPersonName =
    session.direction === 'OUTGOING' ? session.recipientName : session.initiatorName;
  const otherPersonAvatar =
    session.direction === 'OUTGOING' ? session.recipientAvatar : session.initiatorAvatar;

  const handleHangup = () => {
    CallService.stopRingtone();
    if (webrtcServiceRef.current) {
      webrtcServiceRef.current.stopAll();
    }
    onEndCall(duration);
  };

  const handleSwitchCameraClick = async () => {
    if (switchingCamera || !webrtcServiceRef.current) return;
    setSwitchingCamera(true);
    try {
      await webrtcServiceRef.current.switchCamera();
      await onSwitchCamera();
    } finally {
      setSwitchingCamera(false);
    }
  };

  const toggleFullscreen = () => {
    if (!modalContainerRef.current) return;
    if (!document.fullscreenElement) {
      modalContainerRef.current.requestFullscreen?.().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.().catch(() => {});
      setIsFullscreen(false);
    }
  };

  return (
    <div
      id="nzala-call-overlay"
      className="fixed inset-0 z-50 bg-stone-950/95 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 select-none animate-fadeIn"
    >
      <div
        ref={modalContainerRef}
        className="w-full max-w-3xl h-[85vh] max-h-[700px] bg-stone-900 rounded-3xl border border-stone-800 shadow-2xl flex flex-col justify-between overflow-hidden relative text-white"
      >
        {/* Top bar header */}
        <div className="p-4 sm:p-6 z-20 flex items-center justify-between bg-gradient-to-b from-black/80 via-black/40 to-transparent">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold">
              {session.type === 'VIDEO' ? <Video className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-white leading-tight">
                  {otherPersonName}
                </h3>
                <VerifiedBadge isVerified={true} size="sm" />
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  {session.type === 'VIDEO' ? 'Appel Vidéo HD' : 'Appel Audio'}
                </span>
              </div>
              <p className="text-xs text-stone-400">
                {session.isGroup ? 'Groupe Familial' : 'Appel Privé Sécurisé'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Simulation/WebRTC Badge */}
            <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-stone-800/80 border border-stone-700 text-[11px] text-stone-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Chiffrement bout en bout</span>
            </div>

            <button
              id="call-btn-fullscreen"
              onClick={toggleFullscreen}
              className="p-2.5 rounded-xl bg-stone-800/80 hover:bg-stone-700 text-stone-300 transition"
              title="Plein écran"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Center Canvas / Video / Avatar Area */}
        <div className="flex-1 relative flex items-center justify-center p-4 overflow-hidden bg-radial from-stone-850 to-stone-950">
          {session.type === 'VIDEO' && session.isVideoEnabled ? (
            <div className="w-full h-full relative rounded-2xl overflow-hidden bg-black flex items-center justify-center border border-stone-800">
              {/* Simulated Remote Video Feed (or real remote if connected) */}
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-b from-stone-900 to-stone-950 text-center p-6">
                <div className="relative mb-4">
                  {otherPersonAvatar ? (
                    <img
                      src={otherPersonAvatar}
                      alt={otherPersonName}
                      className="w-28 h-28 sm:w-36 sm:h-36 rounded-full object-cover border-4 border-amber-500/50 shadow-2xl"
                    />
                  ) : (
                    <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-full bg-stone-800 border-4 border-amber-500/50 flex items-center justify-center text-amber-400 font-bold text-3xl">
                      {otherPersonName.charAt(0)}
                    </div>
                  )}
                  {callState === 'RINGING' && (
                    <span className="absolute -inset-2 rounded-full border-2 border-amber-400/40 animate-ping" />
                  )}
                </div>

                <h4 className="text-xl sm:text-2xl font-bold text-white mb-1">{otherPersonName}</h4>
                <div className="flex items-center gap-2 text-stone-400 text-xs sm:text-sm">
                  {callState === 'RINGING' && (
                    <span className="flex items-center gap-2 text-amber-400 font-medium">
                      <Radio className="w-4 h-4 animate-pulse" />
                      Sonnerie en cours chez le destinataire...
                    </span>
                  )}
                  {callState === 'CONNECTING' && (
                    <span className="text-blue-400 font-medium animate-pulse">
                      Établissement du canal sécurisé WebRTC...
                    </span>
                  )}
                  {callState === 'CONNECTED' && (
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                      <span className="text-emerald-400 font-bold">
                        En communication • {CallService.formatDuration(duration)}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Local Camera Picture-in-Picture (PiP) */}
              <div className="absolute bottom-4 right-4 w-32 sm:w-44 aspect-3/4 rounded-2xl overflow-hidden bg-stone-900 border-2 border-white/20 shadow-2xl z-20 group">
                <video
                  ref={localVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover mirror scale-x-[-1]"
                />
                <div className="absolute top-2 left-2 px-1.5 py-0.5 rounded bg-black/60 text-[9px] font-bold text-white">
                  Vous (Caméra locale)
                </div>
                {cameraError && (
                  <div className="absolute inset-0 bg-stone-900/90 flex flex-col items-center justify-center p-2 text-center text-[10px] text-amber-300">
                    <AlertTriangle className="w-4 h-4 mb-1 text-amber-400" />
                    <span>Caméra non accessible</span>
                  </div>
                )}
              </div>
            </div>
          ) : (
            // Audio Call View
            <div className="flex flex-col items-center justify-center text-center z-10 space-y-6">
              <div className="relative">
                {otherPersonAvatar ? (
                  <img
                    src={otherPersonAvatar}
                    alt={otherPersonName}
                    className="w-32 h-32 sm:w-40 sm:h-40 rounded-full object-cover border-4 border-amber-500/50 shadow-2xl"
                  />
                ) : (
                  <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-full bg-stone-800 border-4 border-amber-500/50 flex items-center justify-center text-amber-400 font-bold text-4xl shadow-2xl">
                    {otherPersonName.charAt(0)}
                  </div>
                )}

                {callState === 'RINGING' && (
                  <>
                    <span className="absolute -inset-2 rounded-full border-2 border-amber-400/40 animate-ping" />
                    <span className="absolute -inset-5 rounded-full border border-amber-500/20 animate-pulse" />
                  </>
                )}

                {callState === 'CONNECTED' && (
                  <div className="absolute -bottom-2 -right-2 p-2 rounded-full bg-emerald-500 text-white shadow-lg">
                    <Volume2 className="w-5 h-5 animate-pulse" />
                  </div>
                )}
              </div>

              <div>
                <h4 className="text-2xl sm:text-3xl font-bold text-white mb-2">{otherPersonName}</h4>
                <div className="text-sm font-medium">
                  {callState === 'RINGING' && (
                    <p className="text-amber-400 flex items-center justify-center gap-2">
                      <Radio className="w-4 h-4 animate-pulse" />
                      Sonnerie en cours...
                    </p>
                  )}
                  {callState === 'CONNECTING' && (
                    <p className="text-blue-400 animate-pulse">Connexion audio HD...</p>
                  )}
                  {callState === 'CONNECTED' && (
                    <p className="text-emerald-400 font-bold text-lg font-mono">
                      {CallService.formatDuration(duration)}
                    </p>
                  )}
                </div>
              </div>

              {/* Status Note & Technical Note */}
              <div className="px-4 py-2 rounded-2xl bg-stone-800/60 border border-stone-750 text-xs text-stone-400 max-w-md flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  Flux audio voix haute fidélité avec annulation d'écho et suppression de bruit.
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Control Bar */}
        <div className="p-4 sm:p-6 z-20 bg-gradient-to-t from-black/90 via-black/50 to-transparent">
          <div className="flex items-center justify-center gap-3 sm:gap-6 max-w-md mx-auto">
            {/* Microphone Toggle */}
            <button
              id="call-btn-mute"
              onClick={onToggleMute}
              className={`p-3.5 sm:p-4 rounded-2xl border transition flex flex-col items-center gap-1 cursor-pointer ${
                session.isMuted
                  ? 'bg-rose-500/20 border-rose-500 text-rose-400 hover:bg-rose-500/30'
                  : 'bg-stone-800 border-stone-700 text-stone-200 hover:bg-stone-700'
              }`}
              title={session.isMuted ? 'Activer le micro' : 'Couper le micro'}
            >
              {session.isMuted ? <MicOff className="w-5 h-5 sm:w-6 sm:h-6" /> : <Mic className="w-5 h-5 sm:w-6 sm:h-6" />}
              <span className="text-[10px] font-semibold">{session.isMuted ? 'Muet' : 'Micro'}</span>
            </button>

            {/* Video Camera Toggle */}
            <button
              id="call-btn-video"
              onClick={onToggleVideo}
              className={`p-3.5 sm:p-4 rounded-2xl border transition flex flex-col items-center gap-1 cursor-pointer ${
                !session.isVideoEnabled
                  ? 'bg-rose-500/20 border-rose-500 text-rose-400 hover:bg-rose-500/30'
                  : 'bg-stone-800 border-stone-700 text-stone-200 hover:bg-stone-700'
              }`}
              title={session.isVideoEnabled ? 'Couper la caméra' : 'Activer la caméra'}
            >
              {session.isVideoEnabled ? (
                <Video className="w-5 h-5 sm:w-6 sm:h-6" />
              ) : (
                <VideoOff className="w-5 h-5 sm:w-6 sm:h-6" />
              )}
              <span className="text-[10px] font-semibold">{session.isVideoEnabled ? 'Caméra' : 'Sans vidéo'}</span>
            </button>

            {/* Flip Camera (if video active) */}
            {session.isVideoEnabled && (
              <button
                id="call-btn-flip-cam"
                onClick={handleSwitchCameraClick}
                disabled={switchingCamera}
                className="p-3.5 sm:p-4 rounded-2xl bg-stone-800 border border-stone-700 text-stone-200 hover:bg-stone-700 transition flex flex-col items-center gap-1 cursor-pointer"
                title="Changer de caméra (avant/arrière)"
              >
                <RotateCcw className={`w-5 h-5 sm:w-6 sm:h-6 ${switchingCamera ? 'animate-spin' : ''}`} />
                <span className="text-[10px] font-semibold">Basculer</span>
              </button>
            )}

            {/* Speaker Toggle */}
            <button
              id="call-btn-speaker"
              onClick={onToggleSpeaker}
              className={`p-3.5 sm:p-4 rounded-2xl border transition flex flex-col items-center gap-1 cursor-pointer ${
                !session.isSpeakerOn
                  ? 'bg-rose-500/20 border-rose-500 text-rose-400'
                  : 'bg-stone-800 border-stone-700 text-stone-200 hover:bg-stone-700'
              }`}
              title={session.isSpeakerOn ? 'Haut-parleur actif' : 'Écouteur discret'}
            >
              {session.isSpeakerOn ? (
                <Volume2 className="w-5 h-5 sm:w-6 sm:h-6 text-amber-400" />
              ) : (
                <VolumeX className="w-5 h-5 sm:w-6 sm:h-6" />
              )}
              <span className="text-[10px] font-semibold">Haut-parleur</span>
            </button>

            {/* Hangup / End Call Button */}
            <button
              id="call-btn-hangup"
              onClick={handleHangup}
              className="p-3.5 sm:p-4 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-bold shadow-lg shadow-rose-900/50 transition flex flex-col items-center gap-1 cursor-pointer hover:scale-105"
              title="Raccrocher"
            >
              <PhoneOff className="w-5 h-5 sm:w-6 sm:h-6" />
              <span className="text-[10px] font-bold">Raccrocher</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
