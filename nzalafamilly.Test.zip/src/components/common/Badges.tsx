import React from 'react';
import {
  VerificationStatus,
  MemberBelonging,
  UserRole,
  FamilyType,
  AllianceStatus,
  LivingStatus,
  RelationshipStatus,
  RelationshipType,
  VisibilityLevel
} from '../../types';
import { getRoleBadgeInfo } from '../../services/permissions';
import { VerifiedBadge } from './VerifiedBadge';

export const StatusBadge: React.FC<{ status: VerificationStatus; size?: 'sm' | 'md' }> = ({
  status,
  size = 'md',
}) => {
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs font-medium';

  switch (status) {
    case 'APPROUVEE':
      return (
        <span
          id={`status-badge-${status.toLowerCase()}`}
          className={`inline-flex items-center gap-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 ${sizeClasses}`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
          Approuvée
        </span>
      );
    case 'EN_ATTENTE':
      return (
        <span
          id={`status-badge-${status.toLowerCase()}`}
          className={`inline-flex items-center gap-1 rounded-full bg-amber-50 text-amber-800 border border-amber-200 ${sizeClasses}`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
          En attente
        </span>
      );
    case 'EN_VERIFICATION':
      return (
        <span
          id={`status-badge-${status.toLowerCase()}`}
          className={`inline-flex items-center gap-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200 ${sizeClasses}`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
          En vérification
        </span>
      );
    case 'COMPLEMENT_REQUIS':
      return (
        <span
          id={`status-badge-${status.toLowerCase()}`}
          className={`inline-flex items-center gap-1 rounded-full bg-purple-50 text-purple-700 border border-purple-200 ${sizeClasses}`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-purple-500"></span>
          Complément Requis
        </span>
      );
    case 'REFUSEE':
      return (
        <span
          id={`status-badge-${status.toLowerCase()}`}
          className={`inline-flex items-center gap-1 rounded-full bg-rose-50 text-rose-700 border border-rose-200 ${sizeClasses}`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
          Refusée
        </span>
      );
    case 'SUSPENDUE':
      return (
        <span
          id={`status-badge-${status.toLowerCase()}`}
          className={`inline-flex items-center gap-1 rounded-full bg-slate-100 text-slate-700 border border-slate-300 ${sizeClasses}`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
          Suspendue
        </span>
      );
    default:
      return null;
  }
};

export const AllianceStatusBadge: React.FC<{ status: AllianceStatus }> = ({ status }) => {
  switch (status) {
    case 'APPROUVEE':
    case 'VALIDEE':
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
          Alliance Validée
        </span>
      );
    case 'EN_VERIFICATION':
    case 'PROPOSEE':
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-200">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
          En cours de validation
        </span>
      );
    case 'REFUSEE':
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
          Non retenue
        </span>
      );
    case 'ARCHIVEE':
    case 'SUSPENDUE':
    default:
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-200">
          Archivée
        </span>
      );
  }
};

export const RelationshipStatusBadge: React.FC<{ status: RelationshipStatus; size?: 'sm' | 'md' }> = ({
  status,
  size = 'md',
}) => {
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-0.5 text-xs font-medium';

  switch (status) {
    case 'VALIDEE':
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 ${sizeClasses}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
          Validée par le Conseil
        </span>
      );
    case 'PROPOSEE':
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-amber-50 text-amber-800 border border-amber-200 ${sizeClasses}`}>
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
          Proposition en attente
        </span>
      );
    case 'REFUSEE':
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-rose-50 text-rose-800 border border-rose-200 ${sizeClasses}`}>
          Refusée
        </span>
      );
    case 'SUSPENDUE':
      return (
        <span className={`inline-flex items-center gap-1 rounded-full bg-slate-100 text-slate-600 border border-slate-300 ${sizeClasses}`}>
          Suspendue
        </span>
      );
    default:
      return null;
  }
};

export const LivingStatusBadge: React.FC<{
  status: LivingStatus;
  deathDate?: string;
  burialPlace?: string;
  size?: 'sm' | 'md';
}> = ({ status, deathDate, burialPlace, size = 'md' }) => {
  const sizeClasses = size === 'sm' ? 'px-1.5 py-0.5 text-[10px]' : 'px-2 py-0.5 text-xs';

  if (status === 'DECEDE') {
    const year = deathDate ? new Date(deathDate).getFullYear() : null;
    return (
      <span
        title={burialPlace ? `Sépulture : ${burialPlace}` : undefined}
        className={`inline-flex items-center gap-1 rounded-md bg-slate-100 text-slate-700 border border-slate-300 font-medium ${sizeClasses}`}
      >
        🕊️ Décédé(e){year ? ` (${year})` : ''}
      </span>
    );
  }

  return (
    <span className={`inline-flex items-center gap-1 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 font-medium ${sizeClasses}`}>
      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
      Vivant(e)
    </span>
  );
};

export const GenerationBadge: React.FC<{ level: number; status?: string }> = ({ level, status }) => {
  const titles: Record<number, string> = {
    1: 'G1 — Patriarcat Fondateur',
    2: 'G2 — Aînés & Branches',
    3: 'G3 — Descendance & Forces vives',
    4: 'G4 — Jeunesse & Avenir',
  };

  const title = titles[level] || `Génération G${level}`;

  return (
    <span
      title={status ? `Statut de génération : ${status}` : undefined}
      className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-xs font-semibold bg-slate-100 text-slate-800 border border-slate-200"
    >
      <span className="font-mono font-bold text-blue-700">G{level}</span>
      <span className="text-slate-400">•</span>
      <span>{title.split(' — ')[1] || `G${level}`}</span>
    </span>
  );
};

export const BelongingBadge: React.FC<{
  belonging: MemberBelonging;
  familyType: 'NZALA_DIRECT' | 'ALLIE';
  size?: 'sm' | 'md';
}> = ({ belonging, familyType, size = 'md' }) => {
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs font-semibold';

  if (familyType === 'NZALA_DIRECT' && belonging === 'APPARTENANCE_DIRECTE') {
    return (
      <span className={`inline-flex items-center gap-1 rounded-md bg-blue-50 text-blue-800 border border-blue-200 ${sizeClasses}`}>
        👑 Membre Direct Nzala
      </span>
    );
  }

  switch (belonging) {
    case 'APPARTENANCE_DIRECTE':
      return (
        <span className={`inline-flex items-center gap-1 rounded-md bg-blue-50 text-blue-800 border border-blue-200 ${sizeClasses}`}>
          👑 Lignée Directe
        </span>
      );
    case 'ALLIANCE_MARIAGE':
      return (
        <span className={`inline-flex items-center gap-1 rounded-md bg-sky-50 text-sky-800 border border-sky-200 ${sizeClasses}`}>
          💍 Allié par Mariage
        </span>
      );
    case 'ALLIANCE_DESCENDANCE':
      return (
        <span className={`inline-flex items-center gap-1 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 ${sizeClasses}`}>
          🌿 Descendant d'Alliance
        </span>
      );
    case 'ALLIANCE_AUTRE':
      return (
        <span className={`inline-flex items-center gap-1 rounded-md bg-indigo-50 text-indigo-800 border border-indigo-200 ${sizeClasses}`}>
          🤝 Allié Reconnu
        </span>
      );
    default:
      return null;
  }
};

export const VisibilityBadge: React.FC<{ level: VisibilityLevel }> = ({ level }) => {
  switch (level) {
    case 'PUBLIC':
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
          🌐 Public
        </span>
      );
    case 'FAMILY':
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-blue-50 text-blue-700 border border-blue-200">
          🔒 Famille
        </span>
      );
    case 'PRIVATE':
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700 border border-slate-300">
          🛡️ Privé
        </span>
      );
  }
};

export const RelationshipTypeBadge: React.FC<{ type: RelationshipType }> = ({ type }) => {
  const typeLabels: Record<RelationshipType, { label: string; color: string }> = {
    PARENT_ENFANT: { label: 'Parent ↔ Enfant', color: 'bg-blue-50 text-blue-900 border-blue-200' },
    CONJOINT: { label: 'Conjoint(e) / Époux', color: 'bg-rose-50 text-rose-900 border-rose-200' },
    FRERE_SOEUR: { label: 'Frère ↔ Sœur', color: 'bg-sky-50 text-sky-900 border-sky-200' },
    GRAND_PARENT_PETIT_ENFANT: { label: 'Grand-parent ↔ Petit-enfant', color: 'bg-purple-50 text-purple-900 border-purple-200' },
    ONCLE_TANTE_NEVEU_NIECE: { label: 'Oncle/Tante ↔ Neveu/Nièce', color: 'bg-teal-50 text-teal-900 border-teal-200' },
    COUSIN: { label: 'Cousin(e) germain(e)', color: 'bg-emerald-50 text-emerald-900 border-emerald-200' },
    BEAU_PARENT_BEAU_FILS_FILLE: { label: 'Beau-parent ↔ Beau-fils/fille', color: 'bg-amber-50 text-amber-900 border-amber-200' },
    PARRAIN_MARRAINE: { label: 'Parrain / Marraine', color: 'bg-indigo-50 text-indigo-900 border-indigo-200' },
    AUTRE: { label: 'Autre lien familial', color: 'bg-slate-50 text-slate-800 border-slate-200' },
  };

  const item = typeLabels[type] || { label: type, color: 'bg-slate-50 text-slate-800 border-slate-200' };

  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold border ${item.color}`}>
      {item.label}
    </span>
  );
};

export const FamilyTypeBadge: React.FC<{ type: FamilyType }> = ({ type }) => {
  if (type === 'PRINCIPALE') {
    return (
      <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-bold tracking-wide uppercase bg-blue-900 text-white shadow-xs">
        Famille Souche Nzala
      </span>
    );
  }
  return (
    <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-semibold tracking-wide uppercase bg-sky-100 text-sky-900 border border-sky-200">
      Famille Alliée
    </span>
  );
};

export const RoleBadge: React.FC<{ role: UserRole; isVerified?: boolean }> = ({ role, isVerified }) => {
  const info = getRoleBadgeInfo(role);
  const showCheck = isVerified ?? (role === 'SUPER_ADMIN' || role === 'ADMIN_FAMILIAL');
  return (
    <span
      className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold ${info.bgColor} ${info.color} border ${info.borderColor}`}
    >
      <span>{info.label}</span>
      {showCheck && <VerifiedBadge role={role} isVerified={true} size="sm" />}
    </span>
  );
};

export const AffiliationStatusBadge: React.FC<{ status?: string }> = ({ status }) => {
  switch (status) {
    case 'APPROUVEE':
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
          Affiliation Validée
        </span>
      );
    case 'EN_ATTENTE':
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-900 border border-amber-200">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-600 animate-pulse"></span>
          En attente d'examen
        </span>
      );
    case 'EN_VERIFICATION':
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-900 border border-blue-200">
          <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
          En cours d'instruction
        </span>
      );
    case 'COMPLEMENT_REQUIS':
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-50 text-purple-900 border border-purple-200">
          <span className="w-1.5 h-1.5 rounded-full bg-purple-600"></span>
          Complément requis
        </span>
      );
    case 'REFUSEE':
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-50 text-rose-900 border border-rose-200">
          <span className="w-1.5 h-1.5 rounded-full bg-rose-600"></span>
          Non affilié / Refusé
        </span>
      );
    case 'NON_DEPOSEE':
    default:
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700 border border-slate-300">
          Affiliation non déposée
        </span>
      );
  }
};

export const AccountStatusBadge: React.FC<{ status?: string }> = ({ status }) => {
  switch (status) {
    case 'ACTIF':
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
          Compte Actif
        </span>
      );
    case 'COMPTE_CREE':
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
          Compte Créé
        </span>
      );
    case 'SUSPENDU':
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-rose-50 text-rose-700 border border-rose-200">
          Compte Suspendu
        </span>
      );
    default:
      return null;
  }
};
