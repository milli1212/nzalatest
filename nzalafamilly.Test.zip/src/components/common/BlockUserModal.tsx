/**
 * NzalaFamilly - Modale de Blocage d'Utilisateur
 * Permet de bloquer un utilisateur avec motif argumenté et prise d'effet immédiate.
 */

import React, { useState } from 'react';
import {
  Ban,
  Shield,
  AlertTriangle,
  X,
  UserX,
  CheckCircle2,
} from 'lucide-react';
import { useFamily } from '../../context/FamilyContext';

interface BlockUserModalProps {
  isOpen: boolean;
  targetUserId: string;
  targetUserName: string;
  onClose: () => void;
  onSuccess?: () => void;
}

const BLOCK_REASONS = [
  { id: 'HARCELEMENT', label: 'Harcèlement ou propos blessants' },
  { id: 'MESSAGES_INDESIRABLES', label: 'Messages indésirables répétitifs (Spam)' },
  { id: 'CONTENU_INAPPROPRIE', label: 'Contenu inapproprié ou non respectueux' },
  { id: 'OFFENSE_VALEURS', label: 'Non-respect des règles et valeurs de la famille' },
  { id: 'SOUHAIT_PERSONNEL', label: 'Choix personnel de ne plus interagir' },
  { id: 'AUTRE', label: 'Autre motif' },
];

export const BlockUserModal: React.FC<BlockUserModalProps> = ({
  isOpen,
  targetUserId,
  targetUserName,
  onClose,
  onSuccess,
}) => {
  const { blockUser, showToast } = useFamily();
  const [selectedReason, setSelectedReason] = useState(BLOCK_REASONS[0].id);
  const [customDetails, setCustomDetails] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const handleConfirmBlock = () => {
    setIsProcessing(true);
    const reasonLabel = BLOCK_REASONS.find((r) => r.id === selectedReason)?.label || selectedReason;
    const fullReason = customDetails.trim() ? `${reasonLabel} (${customDetails.trim()})` : reasonLabel;

    blockUser(targetUserId, targetUserName, fullReason);
    showToast('info', `${targetUserName} a été bloqué(e).`);
    setIsProcessing(false);
    if (onSuccess) onSuccess();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-slate-200 overflow-hidden">
        <div className="flex items-start justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold">
              <UserX className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900">
                Bloquer {targetUserName} ?
              </h3>
              <p className="text-xs text-slate-500">Protection des interactions</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Explication des conséquences */}
        <div className="my-4 p-3 rounded-2xl bg-rose-50/70 border border-rose-100 space-y-1.5 text-xs text-rose-900">
          <p className="font-bold flex items-center gap-1.5">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            Conséquences immédiates du blocage :
          </p>
          <ul className="list-disc list-inside space-y-1 pl-1 text-[11px] text-rose-800">
            <li>Ce membre ne pourra plus vous envoyer de messages privés.</li>
            <li>Les appels audio et vidéo directs seront désactivés.</li>
            <li>Vous ne recevrez plus de notifications de sa part.</li>
            <li>Vous pourrez le débloquer à tout moment dans vos paramètres.</li>
          </ul>
        </div>

        {/* Sélection du motif */}
        <div className="space-y-3">
          <label className="block text-xs font-bold text-slate-700">
            Sélectionnez un motif de blocage :
          </label>
          <div className="space-y-1.5">
            {BLOCK_REASONS.map((r) => (
              <label
                key={r.id}
                className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-xs cursor-pointer transition ${
                  selectedReason === r.id
                    ? 'bg-blue-50 border-blue-500 text-blue-900 font-semibold'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <input
                  type="radio"
                  name="blockReason"
                  value={r.id}
                  checked={selectedReason === r.id}
                  onChange={(e) => setSelectedReason(e.target.value)}
                  className="text-blue-600 focus:ring-blue-500"
                />
                <span>{r.label}</span>
              </label>
            ))}
          </div>

          {selectedReason === 'AUTRE' && (
            <div>
              <textarea
                value={customDetails}
                onChange={(e) => setCustomDetails(e.target.value)}
                placeholder="Précisez la raison..."
                rows={2}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          )}
        </div>

        {/* Buttons */}
        <div className="flex items-center justify-end gap-2.5 pt-5 border-t border-slate-100 mt-4">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold cursor-pointer"
          >
            Annuler
          </button>
          <button
            type="button"
            onClick={handleConfirmBlock}
            disabled={isProcessing}
            className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-2 transition active:scale-95 shadow-md cursor-pointer"
          >
            <Ban className="w-4 h-4" />
            <span>Confirmer le blocage</span>
          </button>
        </div>
      </div>
    </div>
  );
};
