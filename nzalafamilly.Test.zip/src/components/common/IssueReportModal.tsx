/**
 * NzalaFamilly - Modale de Signalement de Problème Technique & Assistance
 * Permet aux membres de signaler un dysfonctionnement, un souci de compte ou une faille de sécurité à l'administration.
 */

import React, { useState, useRef } from 'react';
import {
  AlertCircle,
  Bug,
  ShieldAlert,
  Send,
  X,
  Paperclip,
  Image as ImageIcon,
  CheckCircle2,
  HelpCircle,
  MessageSquare,
} from 'lucide-react';
import { IssueCategory, IssuePriority, MediaItem } from '../../types';
import { useFamily } from '../../context/FamilyContext';
import { MediaStorage } from '../../services/mediaStorage';

interface IssueReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultCategory?: IssueCategory;
}

export const IssueReportModal: React.FC<IssueReportModalProps> = ({
  isOpen,
  onClose,
  defaultCategory = 'BUG_TECHNIQUE',
}) => {
  const { currentUser, submitIssueReport, showToast } = useFamily();
  const [category, setCategory] = useState<IssueCategory>(defaultCategory);
  const [priority, setPriority] = useState<IssuePriority>('NORMALE');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [attachments, setAttachments] = useState<MediaItem[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const validation = MediaStorage.validateFile(file);
        if (validation.isValid) {
          const uploaded = await MediaStorage.uploadFile(file);
          setAttachments((prev) => [...prev, uploaded]);
        } else {
          showToast('error', validation.error || 'Fichier non supporté');
        }
      }
    } catch {
      showToast('error', 'Erreur lors de l\'ajout de la capture.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim() || !description.trim()) {
      showToast('error', 'Veuillez renseigner un titre et une description.');
      return;
    }

    submitIssueReport({
      category,
      priority,
      title: title.trim(),
      description: description.trim(),
      attachments: attachments.length > 0 ? attachments : undefined,
      deviceInfo: `${navigator.userAgent} • ${window.innerWidth}x${window.innerHeight}`,
    });

    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      setTitle('');
      setDescription('');
      setAttachments([]);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-xl w-full p-5 sm:p-7 shadow-2xl border border-slate-200 overflow-hidden relative">
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold">
              <Bug className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-slate-900">
                Signaler un Problème ou une Assistance
              </h3>
              <p className="text-xs text-slate-500">
                Transmis directement à l'équipe d'administration NzalaFamilly
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSubmitted ? (
          <div className="py-12 flex flex-col items-center text-center space-y-3">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-2xl animate-bounce">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="font-bold text-lg text-slate-900">Signalement bien enregistré !</h4>
            <p className="text-xs text-slate-600 max-w-sm">
              Votre demande a été transmise aux administrateurs. Vous pouvez suivre son statut dans votre profil.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-4 space-y-4">
            {/* Category & Priority */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Catégorie du problème
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as IssueCategory)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="BUG_TECHNIQUE">🐛 Bug / Dysfonctionnement</option>
                  <option value="COMPTE">👤 Compte & Affiliation</option>
                  <option value="MESSAGERIE">💬 Messagerie & Appels</option>
                  <option value="PUBLICATION">📰 Fil & Publications</option>
                  <option value="LIVE_VIDEO">🎥 Live & Vidéos</option>
                  <option value="SECURITE">🛡️ Sécurité & Confidentialité</option>
                  <option value="AUTRE">💡 Autre demande</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Niveau d'urgence
                </label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as IssuePriority)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="BASSE">Basse (Gêne mineure)</option>
                  <option value="NORMALE">Normale</option>
                  <option value="HAUTE">Haute (Bloquant)</option>
                  <option value="URGENTE">Urgente (Sécurité / Critique)</option>
                </select>
              </div>
            </div>

            {/* Title */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Titre du problème *
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ex: Erreur lors de l'envoi d'un message vocal..."
                className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm text-slate-900 outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Description détaillée *
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={4}
                placeholder="Expliquez ce qui s'est produit, les étapes pour reproduire le souci ou les détails utiles..."
                className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm text-slate-900 outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                required
              />
            </div>

            {/* Capture d'écran / Pièces jointes */}
            <div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={handleFileUpload}
              />
              <div className="flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                  className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-2 transition cursor-pointer"
                >
                  <Paperclip className="w-4 h-4 text-blue-600" />
                  <span>Joindre une capture d'écran</span>
                </button>
                {attachments.length > 0 && (
                  <span className="text-xs text-slate-500">{attachments.length} fichier(s) joint(s)</span>
                )}
              </div>

              {attachments.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {attachments.map((att, idx) => (
                    <div key={idx} className="relative w-14 h-14 rounded-xl overflow-hidden border border-slate-200">
                      <img src={att.url} alt="Preuve" className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => setAttachments((prev) => prev.filter((_, i) => i !== idx))}
                        className="absolute top-0.5 right-0.5 w-4 h-4 bg-rose-600 text-white rounded-full flex items-center justify-center text-[10px]"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Action buttons */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 font-bold text-xs cursor-pointer"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-2 transition shadow-md cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Envoyer le signalement</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
