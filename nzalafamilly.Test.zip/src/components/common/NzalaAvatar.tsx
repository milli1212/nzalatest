import React, { useState } from 'react';
import { LivingStatus, Gender } from '../../types';

export interface NzalaAvatarProps {
  src?: string | null;
  name: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  isOnline?: boolean;
  livingStatus?: LivingStatus;
  familyType?: 'NZALA_DIRECT' | 'ALLIE';
  gender?: Gender;
  className?: string;
  bordered?: boolean;
  showBadge?: boolean;
  roleBadge?: string;
  onClick?: () => void;
}

export const NzalaAvatar: React.FC<NzalaAvatarProps> = ({
  src,
  name,
  size = 'md',
  isOnline,
  livingStatus = 'VIVANT',
  familyType = 'NZALA_DIRECT',
  gender,
  className = '',
  bordered = true,
  showBadge = false,
  roleBadge,
  onClick,
}) => {
  const [imageError, setImageError] = useState(false);

  // Size mapping
  const sizeClasses = {
    xs: 'w-6 h-6 text-[10px]',
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm font-semibold',
    lg: 'w-14 h-14 text-base font-bold',
    xl: 'w-20 h-20 text-xl font-bold',
    '2xl': 'w-28 h-28 text-2xl font-bold',
  };

  const badgeSizeClasses = {
    xs: 'w-1.5 h-1.5 ring-1',
    sm: 'w-2.5 h-2.5 ring-1.5',
    md: 'w-3 h-3 ring-2',
    lg: 'w-3.5 h-3.5 ring-2',
    xl: 'w-4 h-4 ring-2',
    '2xl': 'w-5 h-5 ring-3',
  };

  // Get Initials
  const getInitials = (fullName: string): string => {
    if (!fullName) return 'NF';
    const parts = fullName.trim().split(/\s+/);
    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  };

  const isDeceased = livingStatus === 'DECEDE';

  // Border and Background colors
  const borderClasses = bordered
    ? isDeceased
      ? 'border-2 border-slate-400 shadow-xs'
      : familyType === 'NZALA_DIRECT'
      ? 'border-2 border-blue-500 shadow-xs'
      : 'border-2 border-sky-400 shadow-xs'
    : 'border border-slate-200';

  const defaultBg = isDeceased
    ? 'bg-gradient-to-br from-slate-600 to-slate-800 text-slate-200'
    : familyType === 'NZALA_DIRECT'
    ? 'bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white'
    : 'bg-gradient-to-br from-sky-600 via-indigo-600 to-slate-800 text-white';

  return (
    <div
      className={`relative inline-block shrink-0 select-none ${onClick ? 'cursor-pointer' : ''} ${className}`}
      onClick={onClick}
    >
      <div
        className={`${sizeClasses[size]} rounded-full overflow-hidden flex items-center justify-center font-sans font-bold ${borderClasses} ${defaultBg} transition-all duration-200`}
      >
        {src && !imageError ? (
          <img
            src={src}
            alt={name}
            onError={() => setImageError(true)}
            className={`w-full h-full object-cover transition-opacity duration-300 ${
              isDeceased ? 'grayscale contrast-105 opacity-90' : ''
            }`}
            referrerPolicy="no-referrer"
          />
        ) : (
          <span className="tracking-wider uppercase drop-shadow-xs">{getInitials(name)}</span>
        )}
      </div>

      {/* Deceased Symbol */}
      {isDeceased && (
        <span
          className="absolute -bottom-1 -right-1 px-1 py-0.2 bg-slate-900 text-slate-300 text-[9px] font-sans font-semibold rounded-full border border-slate-600 shadow-xs"
          title="Mémoire familiale - Défunt(e)"
        >
          🕊️
        </span>
      )}

      {/* Online Presence Dot */}
      {!isDeceased && isOnline !== undefined && (
        <span
          className={`absolute bottom-0 right-0 rounded-full ring-white ${
            badgeSizeClasses[size]
          } ${isOnline ? 'bg-emerald-500' : 'bg-slate-400'}`}
          title={isOnline ? 'En ligne' : 'Hors ligne'}
        />
      )}

      {/* Custom Role Badge */}
      {showBadge && roleBadge && (
        <span className="absolute -top-1 -right-1 px-1.5 py-0.2 bg-blue-600 text-white text-[9px] font-bold rounded-full border border-white shadow-xs">
          {roleBadge}
        </span>
      )}
    </div>
  );
};
