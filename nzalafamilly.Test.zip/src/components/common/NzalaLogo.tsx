import React from 'react';

export interface NzalaLogoProps {
  variant?: 'full' | 'icon' | 'badge' | 'compact' | 'horizontal';
  theme?: 'dark' | 'light' | 'auto';
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showSubtitle?: boolean;
}

/**
 * Nouveau Logo Officiel NzalaFamilly
 * Monogramme "NZ" épuré, dynamique et technologique.
 * Le 'N' et le 'Z' s'entrelacent avec fluidité sur un dégradé Bleu Moderne (#1877F2 -> #0D5AC4)
 * avec une touche d'indigo et de cyan lumineux.
 */
export const NzalaLogo: React.FC<NzalaLogoProps> = ({
  variant = 'full',
  theme = 'auto',
  size = 'md',
  className = '',
  showSubtitle = true,
}) => {
  // Dimensions map
  const iconDimensions: Record<string, { w: number; h: number; text: string; sub: string; symbolSize: number }> = {
    xs: { w: 24, h: 24, text: 'text-sm', sub: 'text-[9px]', symbolSize: 24 },
    sm: { w: 32, h: 32, text: 'text-base font-semibold', sub: 'text-[10px]', symbolSize: 32 },
    md: { w: 40, h: 40, text: 'text-lg sm:text-xl font-bold', sub: 'text-[11px]', symbolSize: 40 },
    lg: { w: 52, h: 52, text: 'text-2xl font-bold', sub: 'text-xs', symbolSize: 52 },
    xl: { w: 64, h: 64, text: 'text-3xl font-extrabold', sub: 'text-sm', symbolSize: 64 },
  };

  const dim = iconDimensions[size] || iconDimensions.md;

  // Render Modern NZ Monogram SVG
  const renderSymbol = () => (
    <svg
      width={dim.symbolSize}
      height={dim.symbolSize}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="shrink-0 transition-transform duration-300 hover:scale-105"
      role="img"
      aria-label="Logo NzalaFamilly - Monogramme NZ"
    >
      <defs>
        {/* Dégradé Bleu Moderne de Référence */}
        <linearGradient id="nzalaPrimaryGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#38BDF8" />
          <stop offset="30%" stopColor="#1877F2" />
          <stop offset="100%" stopColor="#0B48A8" />
        </linearGradient>

        {/* Accent Cyan & Indigo */}
        <linearGradient id="nzalaAccentGrad" x1="100%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#60A5FA" />
          <stop offset="60%" stopColor="#2563EB" />
          <stop offset="100%" stopColor="#1D4ED8" />
        </linearGradient>

        {/* Ombre portée douce */}
        <filter id="symbolShadow" x="-15%" y="-15%" width="130%" height="130%">
          <feDropShadow dx="0" dy="4" stdDeviation="4" floodColor="#0F172A" floodOpacity="0.18" />
        </filter>
      </defs>

      {/* Fond Arrondi Modern Squircle */}
      <rect
        x="4"
        y="4"
        width="92"
        height="92"
        rx="26"
        fill="url(#nzalaPrimaryGrad)"
        filter="url(#symbolShadow)"
      />

      {/* Trait de lumière discret sur la bordure supérieure */}
      <rect
        x="5"
        y="5"
        width="90"
        height="90"
        rx="25"
        stroke="#93C5FD"
        strokeWidth="1.5"
        strokeOpacity="0.4"
        fill="none"
      />

      {/* Monogramme 'N' & 'Z' stylisé et continu */}
      {/* Lettre N - Branche gauche */}
      <path
        d="M24 72V28C24 25.7909 25.7909 24 28 24H33C35.2091 24 37 25.7909 37 28V52L54 26C55.5 24.5 58 24.5 60 25.8C61.3 26.7 62 28.2 62 30V40"
        stroke="#FFFFFF"
        strokeWidth="7"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Lettre Z - Barre supérieure, diagonale et barre inférieure connectées */}
      <path
        d="M44 45H72C74.5 45 76 47 75 49.5L52 70.5H76"
        stroke="#BAE6FD"
        strokeWidth="7"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Point de convergence / Alliance Familiale */}
      <circle cx="76" cy="27" r="4.5" fill="#38BDF8" />
    </svg>
  );

  if (variant === 'icon') {
    return <div className={`inline-flex items-center justify-center ${className}`}>{renderSymbol()}</div>;
  }

  if (variant === 'badge') {
    return (
      <div
        className={`inline-flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-slate-900 text-white border border-slate-700/60 shadow-sm ${className}`}
      >
        {renderSymbol()}
        <div className="flex flex-col text-left">
          <span className="font-sans font-bold text-sm tracking-tight text-white">
            Nzala<span className="text-blue-400 font-semibold">Familly</span>
          </span>
          <span className="text-[10px] text-slate-400 font-medium">
            Plateforme Familiale
          </span>
        </div>
      </div>
    );
  }

  // Full & Horizontal Variants
  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {renderSymbol()}

      <div className="flex flex-col text-left min-w-0">
        <div className="flex items-center gap-2">
          <span className={`font-sans tracking-tight text-slate-900 dark:text-white ${dim.text}`}>
            Nzala<span className="text-blue-600 dark:text-blue-400 font-semibold">Familly</span>
          </span>
          <span className="hidden sm:inline-flex items-center px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800/60 rounded-md">
            Portail
          </span>
        </div>
        {showSubtitle && (
          <p className={`${dim.sub} text-slate-500 dark:text-slate-400 font-normal truncate mt-0.5 hidden xs:block sm:block`}>
            Famille Nzala &amp; Familles Alliées
          </p>
        )}
      </div>
    </div>
  );
};
