import React from 'react';
import { useFamily } from '../../context/FamilyContext';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useFamily();

  if (toasts.length === 0) return null;

  return (
    <div id="toast-container" className="fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-md w-full px-4 sm:px-0">
      {toasts.map((toast) => {
        let bgClass = 'bg-stone-900 text-stone-50';
        let Icon = Info;

        if (toast.type === 'success') {
          bgClass = 'bg-emerald-900 text-emerald-50 border border-emerald-700';
          Icon = CheckCircle2;
        } else if (toast.type === 'error') {
          bgClass = 'bg-rose-900 text-rose-50 border border-rose-700';
          Icon = AlertCircle;
        } else if (toast.type === 'info') {
          bgClass = 'bg-stone-900 text-stone-50 border border-stone-700 shadow-xl';
          Icon = Info;
        }

        return (
          <div
            key={toast.id}
            className={`flex items-start justify-between gap-3 p-4 rounded-xl shadow-lg text-sm transition-all duration-300 animate-in fade-in slide-in-from-bottom-2 ${bgClass}`}
          >
            <div className="flex items-start gap-3">
              <Icon className="w-5 h-5 mt-0.5 shrink-0" />
              <p className="font-normal leading-relaxed">{toast.text}</p>
            </div>
            <button
              onClick={() => removeToast(toast.id)}
              className="p-1 hover:opacity-75 rounded-lg transition-opacity shrink-0"
              aria-label="Fermer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
