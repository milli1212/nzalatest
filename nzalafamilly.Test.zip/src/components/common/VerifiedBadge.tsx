/**
 * NzalaFamilly - Sceau de Certification Officielle des Comptes
 * Sceau circulaire zigzagué distinctif NzalaFamilly
 * - Rose pour SUPER_ADMIN
 * - Bleu Nzala par défaut pour les membres certifiés
 * - Support de couleurs personnalisées configurées par le Conseil/Super Admin
 */

import React from 'react';
import { UserRole } from '../../types';

interface VerifiedBadgeProps {
  role?: UserRole;
  badgeLabel?: string;
  isVerified?: boolean;
  customColor?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  showLabel?: boolean;
  className?: string;
}

export const VerifiedBadge: React.FC<VerifiedBadgeProps> = ({
  role,
  badgeLabel,
  isVerified = true,
  customColor,
  size = 'md',
  showLabel = false,
  className = '',
}) => {
  if (!isVerified && !badgeLabel) return null;

  const isSuperAdmin = role === 'SUPER_ADMIN';
  const isAdmin = role === 'ADMIN_FAMILIAL';
  const isModerator = role === 'VALIDATEUR';

  const defaultLabel = isSuperAdmin
    ? 'Super Administrateur Certifié'
    : isAdmin
    ? 'Administrateur Familial Certifié'
    : isModerator
    ? 'Modérateur Officiel du Conseil'
    : 'Compte Officiel Certifié Nzala';

  const label = badgeLabel || defaultLabel;

  // Sizing
  const badgeSize =
    size === 'xs' ? 13 : size === 'sm' ? 15 : size === 'lg' ? 22 : size === 'xl' ? 28 : 18;

  // Determine badge color
  // Rule: SUPER_ADMIN = Rose par défaut (#EC4899), Membre certifié = Bleu par défaut (#2563EB), ou couleur personnalisée
  const resolvedColor = customColor
    ? customColor
    : isSuperAdmin
    ? '#EC4899' // Rose distinctif Super Admin
    : isAdmin
    ? '#2563EB' // Bleu Roi
    : isModerator
    ? '#059669' // Émeraude Sagesse
    : '#2563EB'; // Bleu Nzala par défaut

  return (
    <span
      className={`inline-flex items-center gap-1.5 align-middle select-none group/badge relative cursor-help shrink-0 ${className}`}
      title={label}
      aria-label={label}
    >
      <span className="relative inline-flex items-center justify-center shrink-0">
        {/* Sceau circulaire zigzagué officiel NzalaFamilly (16 pointes régulières & biseautées) */}
        <svg
          width={badgeSize}
          height={badgeSize}
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="drop-shadow-xs transition-transform duration-200 group-hover/badge:scale-110"
        >
          {/* Contour extérieur zigzagué / Sceau en rosette */}
          <path
            d="M12 1.25L13.8 3.12L16.36 2.53L17.58 4.79L20.15 5.18L20.59 7.82L22.75 9.24L22.08 11.83L23.15 14.28L21.05 15.65L20.48 18.28L17.9 18.52L16.53 20.72L13.98 20.08L12 21.95L10.02 20.08L7.47 20.72L6.1 18.52L3.52 18.28L2.95 15.65L0.85 14.28L1.92 11.83L1.25 9.24L3.41 7.82L3.85 5.18L6.42 4.79L7.64 2.53L10.2 3.12L12 1.25Z"
            fill={resolvedColor}
          />
          {/* Cercle intérieur subtil */}
          <circle
            cx="12"
            cy="12"
            r="8"
            stroke="#ffffff"
            strokeWidth="0.8"
            strokeOpacity="0.35"
          />
          {/* Coche officielle centrale */}
          <path
            d="M8.2 12.3L10.7 14.8L15.8 9.7"
            stroke="#ffffff"
            strokeWidth="2.4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </span>

      {showLabel && (
        <span
          className="text-[10px] font-bold px-2 py-0.5 rounded-full border"
          style={{
            backgroundColor: `${resolvedColor}15`,
            borderColor: `${resolvedColor}40`,
            color: resolvedColor,
          }}
        >
          {label}
        </span>
      )}
    </span>
  );
};

