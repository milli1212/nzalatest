import React from 'react';
import { useFamily } from '../../context/FamilyContext';
import { StatusBadge, RoleBadge } from '../common/Badges';
import { EventCard } from '../events/EventCard';
import { UpcomingBirthdaysSection } from '../events/UpcomingBirthdaysSection';
import { canUserViewEvent } from '../../services/eventService';
import { StoriesTray } from '../social/StoriesTray';
import {
  HeartHandshake,
  FileCheck2,
  GitFork,
  Calendar,
  Bell,
  ArrowRight,
  ShieldAlert,
  Sparkles,
  Award,
  Building2,
  Cake,
} from 'lucide-react';

export const DashboardView: React.FC = () => {
  const {
    families,
    members,
    alliances,
    verificationRequests,
    visiblePosts,
    events,
    setSelectedEvent,
    currentUser,
    setActiveTab,
    setAdminPublicationModalOpen,
  } = useFamily();

  const nzalaMembers = members.filter((m) => m.familyType === 'NZALA_DIRECT');
  const allieMembers = members.filter((m) => m.familyType === 'ALLIE');
  const alliedFamilies = families.filter((f) => f.type === 'ALLIEE');
  const pendingRequests = verificationRequests.filter(
    (r) => r.status === 'EN_ATTENTE' || r.status === 'EN_VERIFICATION'
  );

  const approvedAlliances = alliances.filter((a) => a.status === 'APPROUVEE');
  const visibleEvents = events.filter((e) => canUserViewEvent(e, currentUser));

  return (
    <div id="dashboard-view" className="space-y-6 sm:space-y-8 pb-10">
      {/* Welcome & Persona Hero Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-md relative overflow-hidden border border-blue-800/40">
        <div className="absolute right-0 top-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-200 border border-blue-400/30">
                Espace Familial
              </span>
              <RoleBadge role={currentUser.role} />
              {currentUser.familyName && (
                <span className="text-xs text-slate-300">
                  Rattaché à : <strong className="text-white">{currentUser.familyName}</strong>
                </span>
              )}
            </div>

            <h1 className="text-2xl sm:text-3xl font-sans font-bold text-white tracking-tight">
              Bienvenue sur NzalaFamilly, {currentUser.name}
            </h1>
            <p className="text-sm sm:text-base text-slate-300 font-normal leading-relaxed">
              Plateforme numérique officielle de la <strong>Famille Nzala</strong> et de son réseau de{' '}
              <strong>familles alliées</strong>. Préservez la généalogie, encadrez les adhésions et célébrez les liens familiaux.
            </p>
          </div>

          {/* Quick Action in Header */}
          <div className="flex flex-wrap gap-2.5 shrink-0">
            <button
              onClick={() => setActiveTab('memoire')}
              className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-blue-100 font-semibold text-xs border border-white/15 transition cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-blue-300" />
              <span>Mémoire Nzala</span>
            </button>
            {(currentUser.role === 'SUPER_ADMIN' ||
              currentUser.role === 'ADMIN_FAMILIAL' ||
              currentUser.role === 'VALIDATEUR') && (
              <button
                onClick={() => setAdminPublicationModalOpen(true)}
                className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition shadow-sm cursor-pointer"
              >
                <Bell className="w-4 h-4" />
                <span>Publier un communiqué</span>
              </button>
            )}
            <button
              onClick={() => setActiveTab('verifications')}
              className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-blue-500 hover:bg-blue-400 text-white font-bold text-xs transition shadow-sm cursor-pointer"
            >
              <FileCheck2 className="w-4 h-4" />
              <span>Vérifications ({pendingRequests.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('genealogy')}
              className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-medium text-xs border border-slate-700 transition cursor-pointer"
            >
              <GitFork className="w-4 h-4 text-blue-400" />
              <span>Arbre</span>
            </button>
          </div>
        </div>

        {/* Visitor or Pending user contextual callout */}
        {currentUser.role === 'VISITEUR' && (
          <div className="mt-6 p-4 rounded-2xl bg-amber-500/10 border border-amber-400/30 text-amber-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-sm text-amber-300">Compte en attente d'affiliation officielle</p>
                <p className="text-xs text-slate-300 mt-0.5">
                  Conformément aux règles de confidentialité de NzalaFamilly, l'accès complet aux archives et à l'arbre généalogique est soumis à la vérification préalable de votre lien par le Conseil de famille.
                </p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('verifications')}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition shrink-0 cursor-pointer shadow-xs"
            >
              Déposer ma demande
            </button>
          </div>
        )}
      </div>

      {/* Stories Tray Section */}
      <StoriesTray />

      {/* Metric Cards - 4 Key Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Membres Directs Nzala */}
        <div
          onClick={() => setActiveTab('members')}
          className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs hover:border-blue-500 hover:shadow-md transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Famille Souche Nzala
            </span>
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center group-hover:scale-105 transition-transform">
              <Award className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold text-slate-900">
              {nzalaMembers.length}
            </span>
            <span className="text-xs text-slate-500 font-medium">membres répertoriés</span>
          </div>
          <p className="mt-2 text-xs text-slate-600 flex items-center gap-1">
            <span>Branche fondatrice &amp; aînée</span>
            <ArrowRight className="w-3.5 h-3.5 text-blue-600 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
          </p>
        </div>

        {/* Metric 2: Familles Alliées */}
        <div
          onClick={() => setActiveTab('alliances')}
          className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs hover:border-sky-500 hover:shadow-md transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Familles Alliées
            </span>
            <div className="w-9 h-9 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center group-hover:scale-105 transition-transform">
              <Building2 className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold text-slate-900">
              {alliedFamilies.length}
            </span>
            <span className="text-xs text-slate-500 font-medium">familles partenaires</span>
          </div>
          <p className="mt-2 text-xs text-slate-600 flex items-center gap-1">
            <span>Mavungu, Kanza, Lukoki...</span>
            <ArrowRight className="w-3.5 h-3.5 text-sky-600 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
          </p>
        </div>

        {/* Metric 3: Alliances Validées */}
        <div
          onClick={() => setActiveTab('alliances')}
          className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs hover:border-emerald-500 hover:shadow-md transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Alliances Reconnues
            </span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:scale-105 transition-transform">
              <HeartHandshake className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold text-slate-900">
              {approvedAlliances.length}
            </span>
            <span className="text-xs text-slate-500 font-medium">pactes &amp; mariages</span>
          </div>
          <p className="mt-2 text-xs text-slate-600 flex items-center gap-1">
            <span>{allieMembers.length} membres alliés actifs</span>
            <ArrowRight className="w-3.5 h-3.5 text-emerald-600 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
          </p>
        </div>

        {/* Metric 4: Demandes en attente */}
        <div
          onClick={() => setActiveTab('verifications')}
          className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs hover:border-amber-500 hover:shadow-md transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Vérifications
            </span>
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center group-hover:scale-105 transition-transform">
              <FileCheck2 className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold text-amber-700">
              {pendingRequests.length}
            </span>
            <span className="text-xs text-slate-500 font-medium">dossiers en cours</span>
          </div>
          <p className="mt-2 text-xs text-slate-600 flex items-center gap-1">
            <span>Examen par le Conseil</span>
            <ArrowRight className="w-3.5 h-3.5 text-amber-600 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
          </p>
        </div>
      </div>

      {/* Main Two-Column Structure: Distinction Famille Nzala vs Familles Alliées & Actualités */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
        {/* Left Column (2 cols): Dual Family Pillars & Alliances Snapshot */}
        <div className="lg:col-span-2 space-y-6">
          {/* Concept Architecture: Famille Nzala vs Familles Alliées */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  Cartographie des Familles &amp; Alliances
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Distinction stricte entre appartenance directe et alliances matrimoniales
                </p>
              </div>
              <button
                onClick={() => setActiveTab('alliances')}
                className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
              >
                <span>Voir tout</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Visual Balance Card */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Box 1: Famille Souche Nzala */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-blue-50/80 to-indigo-50/50 border border-blue-200/80 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-blue-900 uppercase tracking-wide">
                    Famille Souche
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-200/80 text-blue-900">
                    Racine Principale
                  </span>
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-900">Famille Nzala</h3>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    Membres directs issus du sang et de la filiation directe du patriarche fondateur André Nzala.
                  </p>
                </div>
                <div className="pt-2 border-t border-blue-200/60 flex items-center justify-between text-xs text-slate-700 font-medium">
                  <span>{nzalaMembers.length} membres directs répertoriés</span>
                  <button
                    onClick={() => setActiveTab('members')}
                    className="text-blue-700 font-bold hover:underline cursor-pointer"
                  >
                    Consulter
                  </button>
                </div>
              </div>

              {/* Box 2: Familles Alliées */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-sky-50/80 to-slate-50 border border-sky-200/80 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-sky-900 uppercase tracking-wide">
                    Réseau d'Alliances
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-sky-200/80 text-sky-900">
                    {alliedFamilies.length} Familles
                  </span>
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-900">Familles Alliées</h3>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    Personnes liées à la famille Nzala par mariage, descendance d'alliance ou pacte familial officiel.
                  </p>
                </div>
                <div className="pt-2 border-t border-sky-200/60 flex items-center justify-between text-xs text-slate-700 font-medium">
                  <span>{allieMembers.length} membres alliés reconnus</span>
                  <button
                    onClick={() => setActiveTab('alliances')}
                    className="text-sky-800 font-bold hover:underline cursor-pointer"
                  >
                    Explorer
                  </button>
                </div>
              </div>
            </div>

            {/* Active Alliances List snippet */}
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Pactes &amp; Alliances Matrimoniales Récentes
              </h4>
              <div className="space-y-2">
                {alliances.slice(0, 3).map((alliance) => (
                  <div
                    key={alliance.id}
                    className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 hover:bg-slate-100/80 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-sm text-slate-900">
                          {alliance.title}
                        </span>
                        {alliance.status === 'APPROUVEE' ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-emerald-100 text-emerald-800">
                            Validée
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-amber-100 text-amber-800">
                            En cours
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-600 line-clamp-1">{alliance.description}</p>
                    </div>
                    {alliance.startDate && (
                      <span className="text-xs text-slate-500 shrink-0">
                        Depuis {new Date(alliance.startDate).getFullYear()}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Pending Verifications Focus Card */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div className="flex items-center gap-2">
                <FileCheck2 className="w-5 h-5 text-blue-600" />
                <h2 className="text-lg font-bold text-slate-900">
                  Dernières Demandes d'Affiliation
                </h2>
              </div>
              <button
                onClick={() => setActiveTab('verifications')}
                className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
              >
                <span>Gérer les demandes</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3">
              {verificationRequests.slice(0, 3).map((req) => (
                <div
                  key={req.id}
                  className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900">{req.applicantName}</span>
                      <StatusBadge status={req.status} size="sm" />
                    </div>
                    <p className="text-xs text-slate-600">
                      Famille d'origine : <strong>{req.originFamilyName}</strong> • Type revendiqué :{' '}
                      <span className="font-medium text-slate-800">
                        {req.claimedFamilyType === 'NZALA_DIRECT'
                          ? 'Membre Direct Nzala'
                          : 'Famille Alliée'}
                      </span>
                    </p>
                    <p className="text-xs text-slate-500 line-clamp-1 italic">
                      "{req.explanation}"
                    </p>
                  </div>

                  <button
                    onClick={() => setActiveTab('verifications')}
                    className="px-3.5 py-1.5 rounded-xl bg-white border border-slate-300 text-xs font-semibold text-slate-800 hover:bg-slate-100 transition shrink-0 cursor-pointer shadow-xs"
                  >
                    Examiner le dossier
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (1 col): Communiqués & Événements */}
        <div className="space-y-6">
          {/* Section: Fil Familial & Communiqués */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-blue-600" />
                <h3 className="font-bold text-base text-slate-900">
                  Fil Familial &amp; Communiqués
                </h3>
              </div>
              <button
                onClick={() => setActiveTab('announcements')}
                className="text-xs font-semibold text-blue-600 hover:underline cursor-pointer"
              >
                Voir tout ({visiblePosts.length})
              </button>
            </div>

            <div className="space-y-4">
              {visiblePosts.slice(0, 3).map((p) => (
                <div
                  key={p.id}
                  onClick={() => setActiveTab('announcements')}
                  className="space-y-1.5 border-b border-slate-100 last:border-0 pb-3 last:pb-0 cursor-pointer hover:bg-slate-50 p-2 rounded-xl transition"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      {p.isOfficial && (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
                          Officiel
                        </span>
                      )}
                      <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-700">
                        {p.postType.replace('_', ' ')}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400">
                      {new Date(p.publishedAt || p.createdAt).toLocaleDateString('fr-FR')}
                    </span>
                  </div>
                  <h4 className="font-bold text-sm text-slate-900 leading-snug">{p.title}</h4>
                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">{p.content}</p>
                  <div className="flex items-center justify-between pt-1 text-[11px] text-slate-400">
                    <span>Par {p.authorName}</span>
                    <span className="font-semibold text-slate-600 flex items-center gap-2">
                      <span>❤️ {p.reactionsCount}</span>
                      <span>💬 {p.commentsCount}</span>
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section: Événements Prochains */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-blue-600" />
                <h3 className="font-bold text-base text-slate-900">
                  Prochains Événements
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('events')}
                className="text-xs font-semibold text-blue-600 hover:underline cursor-pointer"
              >
                Calendrier complet
              </button>
            </div>

            <div className="space-y-2.5">
              {visibleEvents.slice(0, 3).map((evt) => (
                <EventCard
                  key={evt.id}
                  event={evt}
                  compact={true}
                  onSelect={(e) => {
                    setSelectedEvent(e);
                    setActiveTab('events');
                  }}
                />
              ))}

              {visibleEvents.length === 0 && (
                <p className="text-xs text-slate-500 italic py-2 text-center">
                  Aucun événement planifié pour le moment.
                </p>
              )}
            </div>
          </div>

          {/* Section: Prochains Anniversaires */}
          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Cake className="w-4 h-4 text-rose-500" />
                <h3 className="font-bold text-base text-slate-900">
                  Prochains Anniversaires
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('events')}
                className="text-xs font-semibold text-rose-600 hover:underline cursor-pointer"
              >
                Voir tout
              </button>
            </div>

            <UpcomingBirthdaysSection compact={true} limit={4} />
          </div>
        </div>
      </div>
    </div>
  );
};
