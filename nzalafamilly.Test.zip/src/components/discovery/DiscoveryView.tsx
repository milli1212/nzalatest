/**
 * NzalaFamilly - Module de Découverte Familiale & Exploration
 * Présente les nouveaux membres validés, les familles alliées reconnues,
 * les célébrations à venir, les lives, stories et le patrimoine.
 */

import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { Member, Family, FamilyEvent, FamilyPost } from '../../types';
import { canUserViewMember } from '../../services/search/searchEngine';
import {
  Sparkles,
  Users,
  HeartHandshake,
  Calendar,
  Radio,
  Crown,
  Newspaper,
  ChevronRight,
  ArrowUpRight,
  CheckCircle2,
  Cake,
  ShieldCheck,
  Search,
  ExternalLink,
} from 'lucide-react';

export const DiscoveryView: React.FC = () => {
  const {
    members,
    families,
    events,
    posts,
    stories,
    liveStreams,
    upcomingBirthdays,
    memoryAlbums,
    currentUser,
    setActiveTab,
    setSelectedMember,
    setSelectedFamily,
    setSelectedEvent,
    setSelectedPost,
  } = useFamily();

  const [activeFilter, setActiveFilter] = useState<'ALL' | 'MEMBERS' | 'ALLIANCES' | 'EVENTS' | 'MEMORY'>('ALL');

  // 1. Nouveaux Membres Validés Récemment (filtrés selon la confidentialité)
  const recentMembers = members
    .filter((m) => {
      const { canView } = canUserViewMember(m, currentUser);
      return canView && m.membershipStatus === 'ACTIF';
    })
    .slice(0, 6);

  // 2. Familles Alliées Reconnues
  const alliedFamiliesList = families.filter((f) => f.type === 'ALLIEE');

  // 3. Prochains Événements (filtrés)
  const upcomingEventsList = events
    .filter((e) => e.status !== 'ANNULE')
    .slice(0, 4);

  // 4. Lives Actifs ou Programmés
  const activeLives = liveStreams.filter((l) => l.status === 'LIVE' || l.status === 'SCHEDULED');

  // 5. Stories Actives
  const activeStories = stories.filter(
    (s) => new Date(s.expiresAt).getTime() > Date.now()
  );

  return (
    <div id="discovery-view" className="space-y-8 pb-16">
      {/* Top Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-linear-to-r from-blue-700 via-indigo-700 to-blue-900 text-white p-6 sm:p-8 lg:p-10 shadow-xl">
        <div className="relative z-10 max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-md text-blue-100 text-xs font-bold border border-white/20">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Découverte &amp; Exploration NzalaFamilly</span>
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-serif font-bold tracking-tight text-white">
            Explorez les liens, actualités et alliances de notre communauté
          </h1>

          <p className="text-xs sm:text-sm text-blue-100/90 leading-relaxed">
            Retrouvez les nouveaux membres accueillis, les pactes d'alliances historiques reconnus, les célébrations à venir et les récits de nos aînés, dans le respect absolu de la confidentialité familiale.
          </p>

          {/* Quick Filter Buttons */}
          <div className="pt-2 flex flex-wrap items-center gap-2">
            {[
              { id: 'ALL', label: 'Tout explorer', icon: Sparkles },
              { id: 'MEMBERS', label: 'Nouveaux Membres', icon: Users },
              { id: 'ALLIANCES', label: 'Familles Alliées', icon: HeartHandshake },
              { id: 'EVENTS', label: 'Événements & Célébrations', icon: Calendar },
              { id: 'MEMORY', label: 'Patrimoine & Mémoire', icon: Crown },
            ].map((btn) => {
              const Icon = btn.icon;
              const isActive = activeFilter === btn.id;
              return (
                <button
                  key={btn.id}
                  onClick={() => setActiveFilter(btn.id as any)}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                    isActive
                      ? 'bg-white text-blue-900 shadow-md'
                      : 'bg-white/10 hover:bg-white/20 text-white border border-white/10'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{btn.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Decorative background glow */}
        <div className="absolute right-0 top-0 -mt-12 -mr-12 w-96 h-96 rounded-full bg-blue-400/10 blur-3xl pointer-events-none"></div>
      </div>

      {/* SECTION 1: NOUVEAUX MEMBRES ("BIENVENUE DANS NZALAFAMILLY") */}
      {(activeFilter === 'ALL' || activeFilter === 'MEMBERS') && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-blue-50 text-blue-700 border border-blue-200">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-slate-900">
                  Bienvenue dans NzalaFamilly — Membres Récemment Ajoutés
                </h2>
                <p className="text-xs text-slate-500">
                  Membres de la lignée directe et des familles alliées récemment validés
                </p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('members')}
              className="text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1 transition cursor-pointer"
            >
              <span>Voir tout l'annuaire</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {recentMembers.map((m) => {
              const { sanitizedMember } = canUserViewMember(m, currentUser);
              const isDirect = sanitizedMember.belongingType === 'APPARTENANCE_DIRECTE';

              return (
                <div
                  key={m.id}
                  onClick={() => {
                    setSelectedMember(m);
                    setActiveTab('members');
                  }}
                  className="p-4 rounded-3xl bg-white border border-slate-200 hover:border-blue-300 hover:shadow-md transition cursor-pointer flex items-center gap-3.5 group"
                >
                  {sanitizedMember.avatarUrl ? (
                    <img
                      src={sanitizedMember.avatarUrl}
                      alt={sanitizedMember.firstName}
                      referrerPolicy="no-referrer"
                      className="w-14 h-14 rounded-2xl object-cover border border-slate-200 shadow-2xs shrink-0"
                    />
                  ) : (
                    <div className="w-14 h-14 rounded-2xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-700 font-bold text-lg shrink-0">
                      {sanitizedMember.firstName[0]}
                      {sanitizedMember.lastName[0]}
                    </div>
                  )}

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <h3 className="text-xs sm:text-sm font-bold text-slate-900 group-hover:text-blue-600 truncate transition">
                        {sanitizedMember.firstName} {sanitizedMember.lastName}
                      </h3>
                      <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                    </div>

                    <p className="text-[11px] text-slate-500 truncate mt-0.5">
                      {sanitizedMember.primaryFamilyName}{' '}
                      {sanitizedMember.branchName ? `• ${sanitizedMember.branchName}` : ''}
                    </p>

                    <div className="mt-2 flex items-center gap-1.5">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-semibold border ${
                          isDirect
                            ? 'bg-blue-50 text-blue-700 border-blue-200'
                            : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        }`}
                      >
                        {isDirect ? 'Lignée Nzala' : 'Famille Alliée'}
                      </span>
                      <span className="text-[10px] font-medium text-slate-400">
                        Gén. {sanitizedMember.generationLevel}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* SECTION 2: FAMILLES ALLIÉES RECONNUES */}
      {(activeFilter === 'ALL' || activeFilter === 'ALLIANCES') && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200">
                <HeartHandshake className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-slate-900">
                  Familles Alliées Reconnues &amp; Alliances Scellées
                </h2>
                <p className="text-xs text-slate-500">
                  Alliances ratifiées par le Conseil : Mavungu, Kanza, Lukoki, Ndombe...
                </p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('alliances')}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-900 flex items-center gap-1 transition cursor-pointer"
            >
              <span>Consulter le registre</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {alliedFamiliesList.map((fam) => (
              <div
                key={fam.id}
                onClick={() => {
                  setSelectedFamily(fam);
                  setActiveTab('alliances');
                }}
                className="p-5 rounded-3xl bg-white border border-slate-200 hover:border-emerald-300 hover:shadow-md transition cursor-pointer flex flex-col justify-between space-y-3 group"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                      Alliance Ratifiée
                    </span>
                    <span className="text-[11px] font-bold text-slate-400">
                      {fam.membersCount || 0} membres
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-slate-900 group-hover:text-emerald-700 transition">
                    {fam.name}
                  </h3>

                  <p className="text-xs text-slate-500 line-clamp-2">
                    {fam.description || `Origine : ${fam.originLocation || 'Territoire traditionnel'}`}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-emerald-700">
                  <span>Fiche &amp; Alliances</span>
                  <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition" />
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* SECTION 3: PROCHAINS ÉVÉNEMENTS & ANNIVERSAIRES */}
      {(activeFilter === 'ALL' || activeFilter === 'EVENTS') && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-rose-50 text-rose-700 border border-rose-200">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-slate-900">
                  Prochains Événements &amp; Célébrations d'Anniversaires
                </h2>
                <p className="text-xs text-slate-500">
                  Réunions familiales, commémorations et dates importantes
                </p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('events')}
              className="text-xs font-bold text-rose-700 hover:text-rose-900 flex items-center gap-1 transition cursor-pointer"
            >
              <span>Ouvrir le calendrier</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {upcomingEventsList.map((evt) => (
              <div
                key={evt.id}
                onClick={() => {
                  setSelectedEvent(evt);
                  setActiveTab('events');
                }}
                className="p-5 rounded-3xl bg-white border border-slate-200 hover:border-rose-300 hover:shadow-md transition cursor-pointer flex items-start justify-between gap-4 group"
              >
                <div className="space-y-2 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                      {evt.eventType}
                    </span>
                    <span className="text-xs font-bold text-slate-500">
                      📅 {new Date(evt.startDate).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' })}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-slate-900 group-hover:text-rose-600 truncate transition">
                    {evt.title}
                  </h3>

                  <p className="text-xs text-slate-500 line-clamp-2">
                    {evt.description || `Lieu : ${evt.location}`}
                  </p>
                </div>

                <div className="shrink-0 text-slate-300 group-hover:text-rose-600 transition">
                  <ChevronRight className="w-5 h-5" />
                </div>
              </div>
            ))}
          </div>

          {/* Upcoming Birthdays Preview */}
          {upcomingBirthdays.length > 0 && (
            <div className="p-4 rounded-3xl bg-amber-50/60 border border-amber-200 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-2xl bg-amber-100 text-amber-900">
                  <Cake className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-amber-900">
                    Anniversaires du mois à célébrer
                  </h4>
                  <p className="text-[11px] text-amber-700">
                    {upcomingBirthdays.slice(0, 3).map((b) => b.fullName).join(', ')}
                    {upcomingBirthdays.length > 3 ? ` et ${upcomingBirthdays.length - 3} autre(s)` : ''}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActiveTab('events')}
                className="px-3 py-1.5 rounded-xl bg-amber-600 text-stone-950 font-bold text-xs hover:bg-amber-700 transition cursor-pointer"
              >
                Envoyer des vœux
              </button>
            </div>
          )}
        </section>
      )}

      {/* SECTION 4: PATRIMOINE & MÉMOIRE DES ANCIENS */}
      {(activeFilter === 'ALL' || activeFilter === 'MEMORY') && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-50 text-amber-800 border border-amber-200">
                <Crown className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-slate-900">
                  Mémoire, Archives &amp; Récits Historiques
                </h2>
                <p className="text-xs text-slate-500">
                  Patrimoine, figures fondatrices et archives documentaires
                </p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('memoire')}
              className="text-xs font-bold text-amber-800 hover:text-amber-950 flex items-center gap-1 transition cursor-pointer"
            >
              <span>Explorer les archives</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {memoryAlbums.slice(0, 3).map((album) => (
              <div
                key={album.id}
                onClick={() => setActiveTab('memoire')}
                className="p-4 rounded-3xl bg-white border border-slate-200 hover:border-amber-300 hover:shadow-md transition cursor-pointer space-y-3 group"
              >
                {album.coverUrl && (
                  <img
                    src={album.coverUrl}
                    alt={album.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-36 rounded-2xl object-cover border border-slate-200"
                  />
                )}

                <div className="space-y-1">
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-900 border border-amber-200">
                    {album.historicalEra || 'Patrimoine'}
                  </span>
                  <h3 className="text-sm font-bold text-slate-900 group-hover:text-amber-800 transition">
                    {album.title}
                  </h3>
                  <p className="text-xs text-slate-500 line-clamp-2">
                    {album.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
