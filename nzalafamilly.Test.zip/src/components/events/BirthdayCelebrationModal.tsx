import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { UpcomingBirthday, Member } from '../../types';
import { NzalaLogo } from '../common/NzalaLogo';
import { NzalaAvatar } from '../common/NzalaAvatar';
import {
  X,
  Sparkles,
  Cake,
  Send,
  Heart,
  Gift,
  Calendar,
  Eye,
  MessageCircle,
  Share2,
} from 'lucide-react';

interface BirthdayCelebrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  birthday?: UpcomingBirthday | null;
  initialDraft?: UpcomingBirthday | null;
  onSuccess?: () => void;
}

export const BirthdayCelebrationModal: React.FC<BirthdayCelebrationModalProps> = ({
  isOpen,
  onClose,
  birthday: propBirthday,
  initialDraft,
  onSuccess,
}) => {
  const { currentUser, celebrateBirthday, showToast } = useFamily();
  const birthday = initialDraft || propBirthday;

  if (!isOpen || !birthday) return null;

  const isDeceased = birthday.livingStatus === 'DECEDE';

  // Default suggested message generator
  const defaultText = isDeceased
    ? `En ce jour de commémoration, nous honorons avec recueillement la mémoire et l'héritage de notre cher(e) ${birthday.fullName}.\nQue son exemple d'intégrité et son amour pour la Famille Nzala continuent d'éclairer notre marche.`
    : birthday.daysUntil === 0
    ? `Toute la grande communauté NzalaFamilly adresse ses vœux les plus chaleureux et ses bénédictions fraternelles à notre cher(e) ${birthday.fullName} qui célèbre son anniversaire aujourd'hui !\n\nSanté, prospérité, longévité et bonheur dans ton foyer et dans tous tes projets ! 🎂🎉🥂`
    : `L'anniversaire de notre cher(e) ${birthday.fullName} approche dans ${birthday.daysUntil} jours (le ${birthday.formattedDate}) !\nPréparons-nous tous à lui témoigner notre affection et notre fraternité.`;

  const [customMessage, setCustomMessage] = useState(defaultText);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customMessage.trim()) return;

    setIsSubmitting(true);

    const result = celebrateBirthday({
      personId: birthday.memberId,
      personName: birthday.fullName,
      avatarUrl: birthday.avatarUrl,
      branchName: birthday.branchName,
      familyType: birthday.familyType,
      birthDate: birthday.birthDate,
      age: birthday.showAge ? birthday.ageNext : undefined,
      suggestedMessage: customMessage.trim(),
      isDeceasedHonor: isDeceased,
    });

    setIsSubmitting(false);

    if (result.success) {
      showToast('success', 'Célébration d\'anniversaire publiée avec succès dans le fil familial !');
      onSuccess?.();
      onClose();
    } else {
      showToast('error', result.error || 'Erreur lors de la publication de la célébration.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-xl my-8 bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-amber-600 via-amber-700 to-amber-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-2xl backdrop-blur-xs">
              <Cake className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="font-serif font-bold text-lg text-white">
                {isDeceased ? 'Commémoration & Hommage de Naissance' : 'Célébration d\'Anniversaire Familiale'}
              </h2>
              <p className="text-xs text-amber-100 font-medium">
                Génération automatique du message solennel pour le fil familial
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-amber-200 hover:text-white hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Celebrated Person Card */}
        <div className="p-6 space-y-6">
          <div className="p-4 rounded-2xl bg-amber-50 dark:bg-stone-850 border border-amber-200 dark:border-amber-900/40 flex items-center gap-4">
            <NzalaAvatar
              name={birthday.fullName}
              src={birthday.avatarUrl}
              size="lg"
              livingStatus={birthday.livingStatus}
              familyType={birthday.familyType}
            />

            <div className="space-y-1 min-w-0 flex-1">
              <div className="flex items-center justify-between">
                <h3 className="font-serif font-bold text-base text-stone-900 dark:text-stone-100 truncate">
                  {birthday.fullName}
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-stone-950">
                  {birthday.daysUntil === 0 ? "Aujourd'hui !" : `Dans ${birthday.daysUntil}j`}
                </span>
              </div>

              <p className="text-xs text-stone-600 dark:text-stone-400">
                {birthday.primaryFamilyName} • {birthday.branchName || 'Lignée Directe'}
              </p>

              <div className="flex items-center gap-2 text-xs text-amber-700 dark:text-amber-400 font-semibold">
                <Calendar className="w-3.5 h-3.5" />
                <span>Date de naissance : {birthday.formattedDate}</span>
                {birthday.showAge && birthday.ageNext && (
                  <span className="ml-2 font-bold text-stone-800 dark:text-stone-200">
                    ({birthday.ageNext} ans)
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300">
                Message officiel de bénédiction &amp; vœux
              </label>
              <textarea
                rows={5}
                required
                value={customMessage}
                onChange={(e) => setCustomMessage(e.target.value)}
                className="w-full p-4 rounded-xl bg-stone-50 dark:bg-stone-850 border border-stone-200 dark:border-stone-700 text-sm text-stone-900 dark:text-stone-100 focus:ring-2 focus:ring-amber-500 leading-relaxed font-sans"
              />
            </div>

            <div className="p-3 rounded-xl bg-stone-100 dark:bg-stone-800 text-[11px] text-stone-500 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500 shrink-0" />
              <span>
                Cette publication sera diffusée à l'ensemble de la famille et permettra à chaque membre de commenter et déposer ses félicitations.
              </span>
            </div>

            {/* Actions */}
            <div className="pt-4 border-t border-stone-200 dark:border-stone-800 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 rounded-xl text-xs font-bold text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800 transition cursor-pointer"
              >
                Annuler
              </button>
              <button
                type="submit"
                disabled={isSubmitting || !customMessage.trim()}
                className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs shadow-lg shadow-amber-500/20 flex items-center gap-2 transition cursor-pointer disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                <span>{isSubmitting ? 'Publication...' : 'Publier la célébration'}</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
