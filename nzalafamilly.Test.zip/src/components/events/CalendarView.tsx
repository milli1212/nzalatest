import React, { useState } from 'react';
import { FamilyEvent, UpcomingBirthday, EventType } from '../../types';
import { useFamily } from '../../context/FamilyContext';
import { EventCard } from './EventCard';
import { EventTypeBadge } from './EventBadge';
import { getEventTypeConfig, formatFrenchDate, SYSTEM_TODAY } from '../../services/eventService';
import {
  ChevronLeft,
  ChevronRight,
  Calendar as CalendarIcon,
  Clock,
  MapPin,
  Plus,
  Cake,
  Filter,
  List,
  Grid,
  Sparkles,
} from 'lucide-react';

interface CalendarViewProps {
  events: FamilyEvent[];
  birthdays: UpcomingBirthday[];
  onSelectEvent: (event: FamilyEvent) => void;
  onCreateEventOnDate?: (dateStr: string) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({
  events,
  birthdays,
  onSelectEvent,
  onCreateEventOnDate,
}) => {
  const { can } = useFamily();

  // State: current viewing year & month (Default: August 2026)
  const [currentYear, setCurrentYear] = useState<number>(2026);
  const [currentMonth, setCurrentMonth] = useState<number>(7); // 0-indexed (7 = Août, 8 = Septembre)
  const [calendarMode, setCalendarMode] = useState<'MONTH' | 'LIST'>('MONTH');
  const [showBirthdays, setShowBirthdays] = useState<boolean>(true);
  const [selectedEventType, setSelectedEventType] = useState<EventType | 'ALL'>('ALL');
  const [selectedDayEvents, setSelectedDayEvents] = useState<{
    dateStr: string;
    events: FamilyEvent[];
    birthdays: UpcomingBirthday[];
  } | null>(null);

  const monthNames = [
    'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
    'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
  ];

  const weekdays = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];

  // Handlers for month navigation
  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };

  const handleGoToToday = () => {
    setCurrentYear(SYSTEM_TODAY.getFullYear());
    setCurrentMonth(SYSTEM_TODAY.getMonth());
  };

  // Filter events by selected type
  const filteredEvents = events.filter((evt) => {
    if (selectedEventType !== 'ALL' && evt.eventType !== selectedEventType) {
      return false;
    }
    return true;
  });

  // Calculate calendar grid days
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1);
  const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0);

  // Day of week: 0=Sun, 1=Mon, ..., 6=Sat -> Convert to Monday=0
  const startingDay = (firstDayOfMonth.getDay() + 6) % 7;
  const daysInMonth = lastDayOfMonth.getDate();

  // Previous month fill
  const prevMonthLastDay = new Date(currentYear, currentMonth, 0).getDate();
  const prevDays: { day: number; isCurrentMonth: boolean; dateStr: string }[] = [];
  for (let i = startingDay - 1; i >= 0; i--) {
    const day = prevMonthLastDay - i;
    const prevMonthIdx = currentMonth === 0 ? 11 : currentMonth - 1;
    const prevYear = currentMonth === 0 ? currentYear - 1 : currentYear;
    const dateStr = `${prevYear}-${String(prevMonthIdx + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    prevDays.push({ day, isCurrentMonth: false, dateStr });
  }

  // Current month days
  const currentDays: { day: number; isCurrentMonth: boolean; dateStr: string }[] = [];
  for (let day = 1; day <= daysInMonth; day++) {
    const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    currentDays.push({ day, isCurrentMonth: true, dateStr });
  }

  // Next month fill
  const totalRendered = prevDays.length + currentDays.length;
  const nextDaysCount = (7 - (totalRendered % 7)) % 7;
  const nextDays: { day: number; isCurrentMonth: boolean; dateStr: string }[] = [];
  for (let day = 1; day <= nextDaysCount; day++) {
    const nextMonthIdx = currentMonth === 11 ? 0 : currentMonth + 1;
    const nextYear = currentMonth === 11 ? currentYear + 1 : currentYear;
    const dateStr = `${nextYear}-${String(nextMonthIdx + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    nextDays.push({ day, isCurrentMonth: false, dateStr });
  }

  const allGridDays = [...prevDays, ...currentDays, ...nextDays];

  // Helper: map events and birthdays to date
  const getEventsForDate = (dateStr: string) => {
    return filteredEvents.filter((e) => e.startDate === dateStr || (e.endDate && e.startDate <= dateStr && e.endDate >= dateStr));
  };

  const getBirthdaysForDate = (dateStr: string) => {
    if (!showBirthdays) return [];
    const parts = dateStr.split('-');
    if (parts.length < 3) return [];
    const month = parseInt(parts[1], 10) - 1;
    const day = parseInt(parts[2], 10);
    return birthdays.filter((b) => b.birthMonth === month && b.birthDay === day);
  };

  const isTodayDate = (dateStr: string) => {
    const todayStr = SYSTEM_TODAY.toISOString().split('T')[0];
    return dateStr === todayStr;
  };

  return (
    <div id="calendar-view-container" className="space-y-6">
      {/* Calendar Top Bar */}
      <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Navigation Month / Year */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={handlePrevMonth}
              className="p-2 rounded-xl border border-stone-200 text-stone-600 hover:bg-stone-100 hover:text-stone-900 transition-colors"
              title="Mois précédent"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={handleNextMonth}
              className="p-2 rounded-xl border border-stone-200 text-stone-600 hover:bg-stone-100 hover:text-stone-900 transition-colors"
              title="Mois suivant"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <h2 className="text-lg sm:text-xl font-black text-stone-900 capitalize">
            {monthNames[currentMonth]} {currentYear}
          </h2>

          <button
            type="button"
            onClick={handleGoToToday}
            className="text-xs font-bold px-3 py-1.5 rounded-xl bg-amber-50 text-amber-900 border border-amber-300 hover:bg-amber-100 transition-colors"
          >
            Aujourd'hui
          </button>
        </div>

        {/* Filters & Mode Switch */}
        <div className="flex items-center gap-3 flex-wrap">
          {/* Type Filter */}
          <select
            value={selectedEventType}
            onChange={(e) => setSelectedEventType(e.target.value as EventType | 'ALL')}
            className="text-xs font-semibold px-3 py-2 rounded-xl bg-stone-50 border border-stone-200 focus:bg-white focus:outline-hidden focus:border-amber-600"
          >
            <option value="ALL">Tous les types</option>
            <option value="REUNION_FAMILIALE">Réunions Familiales</option>
            <option value="CONSEIL_FAMILLE">Conseil de Famille</option>
            <option value="ANNIVERSAIRE">Anniversaires</option>
            <option value="MARIAGE">Mariages & Dot</option>
            <option value="NAISSANCE">Naissances</option>
            <option value="COMMEMORATION">Commémorations</option>
            <option value="RENCONTRE_ALLIANCE">Rencontres Alliées</option>
          </select>

          {/* Birthday Toggle */}
          <button
            type="button"
            onClick={() => setShowBirthdays(!showBirthdays)}
            className={`inline-flex items-center gap-1.5 text-xs font-bold px-3 py-2 rounded-xl border transition-colors ${
              showBirthdays
                ? 'bg-rose-50 text-rose-900 border-rose-300'
                : 'bg-stone-50 text-stone-500 border-stone-200 hover:text-stone-800'
            }`}
          >
            <Cake className="w-3.5 h-3.5 text-rose-600" />
            <span>Anniversaires</span>
          </button>

          {/* View Mode */}
          <div className="flex items-center rounded-xl bg-stone-100 p-1 border border-stone-200">
            <button
              type="button"
              onClick={() => setCalendarMode('MONTH')}
              className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                calendarMode === 'MONTH'
                  ? 'bg-white text-stone-900 shadow-2xs'
                  : 'text-stone-500 hover:text-stone-900'
              }`}
              title="Vue Grille Mensuelle"
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setCalendarMode('LIST')}
              className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                calendarMode === 'LIST'
                  ? 'bg-white text-stone-900 shadow-2xs'
                  : 'text-stone-500 hover:text-stone-900'
              }`}
              title="Vue Liste Chronologique"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* MONTH GRID VIEW */}
      {calendarMode === 'MONTH' ? (
        <div className="bg-white rounded-3xl border border-stone-200 shadow-xs overflow-hidden">
          {/* Weekday headers */}
          <div className="grid grid-cols-7 border-b border-stone-200 bg-stone-50 text-center">
            {weekdays.map((w, idx) => (
              <div
                key={idx}
                className="py-3 text-xs font-bold uppercase tracking-wider text-stone-600"
              >
                {w}
              </div>
            ))}
          </div>

          {/* Days Grid */}
          <div className="grid grid-cols-7 divide-x divide-y divide-stone-100">
            {allGridDays.map((gridDay, idx) => {
              const dayEvents = getEventsForDate(gridDay.dateStr);
              const dayBirthdays = getBirthdaysForDate(gridDay.dateStr);
              const isToday = isTodayDate(gridDay.dateStr);
              const hasItems = dayEvents.length > 0 || dayBirthdays.length > 0;

              return (
                <div
                  key={idx}
                  onClick={() => {
                    if (hasItems) {
                      setSelectedDayEvents({
                        dateStr: gridDay.dateStr,
                        events: dayEvents,
                        birthdays: dayBirthdays,
                      });
                    } else if (onCreateEventOnDate && can('CREATE_EVENT')) {
                      onCreateEventOnDate(gridDay.dateStr);
                    }
                  }}
                  className={`min-h-[105px] sm:min-h-[125px] p-2 flex flex-col justify-between transition-colors cursor-pointer group ${
                    gridDay.isCurrentMonth ? 'bg-white' : 'bg-stone-50/60 text-stone-400'
                  } ${isToday ? 'ring-2 ring-amber-500 ring-inset bg-amber-50/20' : ''} hover:bg-stone-50`}
                >
                  {/* Top Day Number Row */}
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-bold px-1.5 py-0.5 rounded-lg ${
                        isToday
                          ? 'bg-amber-800 text-white font-black'
                          : gridDay.isCurrentMonth
                          ? 'text-stone-900 font-extrabold'
                          : 'text-stone-400'
                      }`}
                    >
                      {gridDay.day}
                    </span>

                    {/* Quick + on hover */}
                    {can('CREATE_EVENT') && onCreateEventOnDate && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onCreateEventOnDate(gridDay.dateStr);
                        }}
                        className="opacity-0 group-hover:opacity-100 p-1 text-stone-400 hover:text-amber-800 rounded transition-opacity"
                        title="Ajouter un événement ce jour"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  {/* Badges / Items for this day */}
                  <div className="space-y-1 my-1 flex-1 overflow-hidden">
                    {/* Events */}
                    {dayEvents.slice(0, 2).map((evt) => {
                      const typeCfg = getEventTypeConfig(evt.eventType);
                      return (
                        <div
                          key={evt.id}
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectEvent(evt);
                          }}
                          className={`text-[10px] sm:text-[11px] font-semibold px-2 py-0.5 rounded-md border truncate cursor-pointer transition-transform hover:scale-[1.02] flex items-center gap-1 ${typeCfg.badgeBg} ${typeCfg.badgeText} ${typeCfg.badgeBorder}`}
                          title={`${evt.title} (${evt.startTime || 'Toute la journée'})`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${typeCfg.dotColor}`}></span>
                          <span className="truncate">{evt.title}</span>
                        </div>
                      );
                    })}

                    {/* Birthdays */}
                    {dayBirthdays.slice(0, 1).map((b) => (
                      <div
                        key={b.memberId}
                        className="text-[10px] font-bold px-2 py-0.5 rounded-md border bg-rose-50 text-rose-800 border-rose-200 truncate flex items-center gap-1"
                        title={`Anniversaire : ${b.fullName}`}
                      >
                        <Cake className="w-2.5 h-2.5 text-rose-600 shrink-0" />
                        <span className="truncate">{b.fullName}</span>
                      </div>
                    ))}

                    {/* Overflow count */}
                    {dayEvents.length + dayBirthdays.length > 3 && (
                      <div className="text-[10px] font-bold text-amber-900 text-center py-0.5">
                        +{dayEvents.length + dayBirthdays.length - 3} autres...
                      </div>
                    )}
                  </div>

                  {/* Bottom indicators */}
                  <div className="h-1 flex items-center gap-0.5">
                    {dayEvents.length > 0 && <span className="w-1.5 h-1.5 rounded-full bg-amber-600"></span>}
                    {dayBirthdays.length > 0 && <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* LIST VIEW */
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredEvents.map((evt) => (
              <EventCard key={evt.id} event={evt} onSelect={onSelectEvent} />
            ))}
          </div>

          {filteredEvents.length === 0 && (
            <div className="p-12 text-center bg-white rounded-3xl border border-stone-200">
              <CalendarIcon className="w-12 h-12 text-stone-300 mx-auto mb-3" />
              <h3 className="text-sm font-bold text-stone-700">Aucun événement planifié</h3>
              <p className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
                Aucun événement ne correspond à vos critères de filtrage.
              </p>
            </div>
          )}
        </div>
      )}

      {/* Selected Day Events Quick Drawer Modal */}
      {selectedDayEvents && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 border border-stone-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-900">
                  Agenda du jour
                </span>
                <h3 className="text-base font-bold text-stone-900">
                  {formatFrenchDate(selectedDayEvents.dateStr, { withWeekday: true })}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedDayEvents(null)}
                className="p-1.5 rounded-full text-stone-400 hover:text-stone-700 hover:bg-stone-100"
              >
                ✕
              </button>
            </div>

            {/* Birthdays on this day */}
            {selectedDayEvents.birthdays.length > 0 && (
              <div className="space-y-2">
                <span className="text-xs font-bold text-rose-800 flex items-center gap-1.5">
                  <Cake className="w-3.5 h-3.5 text-rose-600" />
                  Anniversaires ({selectedDayEvents.birthdays.length})
                </span>
                {selectedDayEvents.birthdays.map((b) => (
                  <div
                    key={b.memberId}
                    className="p-3 rounded-xl bg-rose-50/70 border border-rose-200 flex items-center justify-between text-xs"
                  >
                    <div>
                      <p className="font-bold text-rose-950">{b.fullName}</p>
                      <p className="text-[11px] text-stone-500">{b.primaryFamilyName}</p>
                    </div>
                    {b.showAge && b.ageNext && (
                      <span className="font-mono font-bold text-rose-800 bg-white px-2 py-0.5 rounded">
                        {b.ageNext} ans
                      </span>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Events on this day */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-stone-700 flex items-center gap-1.5">
                <CalendarIcon className="w-3.5 h-3.5 text-amber-700" />
                Événements ({selectedDayEvents.events.length})
              </span>
              {selectedDayEvents.events.map((evt) => (
                <div
                  key={evt.id}
                  onClick={() => {
                    setSelectedDayEvents(null);
                    onSelectEvent(evt);
                  }}
                  className="p-3 rounded-xl bg-stone-50 hover:bg-stone-100 border border-stone-200 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-1.5 mb-1">
                    <EventTypeBadge type={evt.eventType} size="sm" />
                  </div>
                  <h4 className="text-xs font-bold text-stone-900">{evt.title}</h4>
                  <div className="flex items-center gap-3 text-[11px] text-stone-500 mt-1">
                    <span>{evt.startTime || 'Journée'}</span>
                    <span>• {evt.location}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-2 flex justify-between items-center">
              {can('CREATE_EVENT') && onCreateEventOnDate && (
                <button
                  type="button"
                  onClick={() => {
                    const date = selectedDayEvents.dateStr;
                    setSelectedDayEvents(null);
                    onCreateEventOnDate(date);
                  }}
                  className="text-xs font-bold text-amber-900 hover:text-amber-950 inline-flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Ajouter un événement
                </button>
              )}
              <button
                type="button"
                onClick={() => setSelectedDayEvents(null)}
                className="text-xs font-bold px-4 py-2 rounded-xl bg-stone-900 text-white hover:bg-stone-800 ml-auto"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
