import React from 'react';
import { EventType, EventVisibility, EventStatus, InvitationStatus } from '../../types';
import { getEventTypeConfig, getEventVisibilityConfig } from '../../services/eventService';
import {
  Calendar,
  Cake,
  Users,
  Shield,
  HeartHandshake,
  Baby,
  Building2,
  Lock,
  Globe,
  Sparkles,
  CheckCircle2,
  Clock,
  XCircle,
  HelpCircle,
} from 'lucide-react';

interface EventTypeBadgeProps {
  type: EventType;
  size?: 'sm' | 'md' | 'lg';
  showIcon?: boolean;
}

export const EventTypeBadge: React.FC<EventTypeBadgeProps> = ({
  type,
  size = 'md',
  showIcon = true,
}) => {
  const config = getEventTypeConfig(type);

  const getIcon = () => {
    switch (type) {
      case 'ANNIVERSAIRE':
        return <Cake className={size === 'sm' ? 'w-3 h-3' : 'w-3.5 h-3.5'} />;
      case 'REUNION_FAMILIALE':
        return <Users className={size === 'sm' ? 'w-3 h-3' : 'w-3.5 h-3.5'} />;
      case 'CONSEIL_FAMILLE':
        return <Shield className={size === 'sm' ? 'w-3 h-3' : 'w-3.5 h-3.5'} />;
      case 'MARIAGE':
        return <HeartHandshake className={size === 'sm' ? 'w-3 h-3' : 'w-3.5 h-3.5'} />;
      case 'NAISSANCE':
        return <Baby className={size === 'sm' ? 'w-3 h-3' : 'w-3.5 h-3.5'} />;
      case 'RENCONTRE_ALLIANCE':
        return <Building2 className={size === 'sm' ? 'w-3 h-3' : 'w-3.5 h-3.5'} />;
      case 'COMMEMORATION':
      case 'CEREMONIE':
      case 'AUTRE':
      default:
        return <Sparkles className={size === 'sm' ? 'w-3 h-3' : 'w-3.5 h-3.5'} />;
    }
  };

  const sizeClasses = {
    sm: 'text-[11px] px-2 py-0.5 gap-1',
    md: 'text-xs px-2.5 py-1 gap-1.5',
    lg: 'text-sm px-3 py-1.5 gap-2',
  };

  return (
    <span
      id={`event-type-badge-${type.toLowerCase()}`}
      className={`inline-flex items-center font-medium rounded-full border ${config.badgeBg} ${config.badgeText} ${config.badgeBorder} ${sizeClasses[size]}`}
      title={config.description}
    >
      {showIcon && getIcon()}
      <span className="truncate">{config.label}</span>
    </span>
  );
};

interface EventVisibilityBadgeProps {
  visibility: EventVisibility;
  size?: 'sm' | 'md';
}

export const EventVisibilityBadge: React.FC<EventVisibilityBadgeProps> = ({
  visibility,
  size = 'sm',
}) => {
  const config = getEventVisibilityConfig(visibility);

  const getIcon = () => {
    switch (visibility) {
      case 'NZALA_INTERNE':
        return <Shield className="w-3 h-3 text-amber-700" />;
      case 'FAMILLE_ALLIEE':
        return <Building2 className="w-3 h-3 text-sky-700" />;
      case 'INTER_FAMILLES':
        return <HeartHandshake className="w-3 h-3 text-emerald-700" />;
      case 'PUBLIC':
        return <Globe className="w-3 h-3 text-blue-700" />;
      case 'PRIVE':
        return <Lock className="w-3 h-3 text-stone-700" />;
    }
  };

  const sizeClass = size === 'sm' ? 'text-[11px] px-2 py-0.5' : 'text-xs px-2.5 py-1';

  return (
    <span
      id={`event-visibility-badge-${visibility.toLowerCase()}`}
      className={`inline-flex items-center gap-1.5 font-medium rounded-full border ${config.badgeBg} ${config.badgeText} ${config.badgeBorder} ${sizeClass}`}
      title={config.description}
    >
      {getIcon()}
      <span>{config.shortLabel}</span>
    </span>
  );
};

interface EventStatusBadgeProps {
  status: EventStatus;
}

export const EventStatusBadge: React.FC<EventStatusBadgeProps> = ({ status }) => {
  switch (status) {
    case 'PLANIFIE':
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
          <Clock className="w-3 h-3" />
          Planifié
        </span>
      );
    case 'EN_COURS':
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-300 animate-pulse">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-600"></span>
          En cours
        </span>
      );
    case 'TERMINE':
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-stone-100 text-stone-700 border border-stone-200">
          <CheckCircle2 className="w-3 h-3" />
          Terminé
        </span>
      );
    case 'ANNULE':
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-rose-50 text-rose-800 border border-rose-200">
          <XCircle className="w-3 h-3" />
          Annulé
        </span>
      );
    case 'REPORTE':
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-purple-50 text-purple-800 border border-purple-200">
          <Clock className="w-3 h-3" />
          Reporté
        </span>
      );
  }
};

interface InvitationStatusBadgeProps {
  status: InvitationStatus;
}

export const InvitationStatusBadge: React.FC<InvitationStatusBadgeProps> = ({ status }) => {
  switch (status) {
    case 'CONFIRME':
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300">
          <CheckCircle2 className="w-3 h-3 text-emerald-700" />
          Confirmé
        </span>
      );
    case 'INVITE':
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-amber-50 text-amber-900 border border-amber-300">
          <Clock className="w-3 h-3 text-amber-700" />
          Invité
        </span>
      );
    case 'PEUT_ETRE':
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-sky-50 text-sky-900 border border-sky-300">
          <HelpCircle className="w-3 h-3 text-sky-700" />
          Peut-être
        </span>
      );
    case 'DECLINE':
      return (
        <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-stone-100 text-stone-600 border border-stone-300">
          <XCircle className="w-3 h-3 text-stone-500" />
          Décliné
        </span>
      );
  }
};
