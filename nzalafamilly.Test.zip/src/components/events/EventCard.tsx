import React from 'react';
import { FamilyEvent, InvitationStatus } from '../../types';
import { EventTypeBadge, EventVisibilityBadge, EventStatusBadge, InvitationStatusBadge } from './EventBadge';
import { getEventCountdown, formatFrenchDate, getEventTypeConfig } from '../../services/eventService';
import { useFamily } from '../../context/FamilyContext';
import {
  Calendar,
  Clock,
  MapPin,
  Users,
  CheckCircle,
  XCircle,
  HelpCircle,
  ChevronRight,
  Shield,
  Building2,
  Lock,
} from 'lucide-react';

interface EventCardProps {
  event: FamilyEvent;
  onSelect: (event: FamilyEvent) => void;
  onEdit?: (event: FamilyEvent) => void;
  compact?: boolean;
}

export const EventCard: React.FC<EventCardProps> = ({
  event,
  onSelect,
  onEdit,
  compact = false,
}) => {
  const { currentUser, rsvpEvent } = useFamily();

  const countdown = getEventCountdown(event.startDate);
  const typeConfig = getEventTypeConfig(event.eventType);

  // Parse start date for box
  const dateObj = new Date(event.startDate + 'T00:00:00Z');
  const dayNumber = isNaN(dateObj.getTime()) ? '?' : dateObj.getUTCDate();
  const monthShort = isNaN(dateObj.getTime())
    ? ''
    : ['JAN', 'FÉV', 'MAR', 'AVR', 'MAI', 'JUIN', 'JUIL', 'AOÛT', 'SEP', 'OCT', 'NOV', 'DÉC'][
        dateObj.getUTCMonth()
      ];

  // User invitation status
  const userInvitation = event.invitations?.find(
    (inv) =>
      (currentUser.id && inv.userId === currentUser.id) ||
      (currentUser.memberId && inv.memberId === currentUser.memberId) ||
      (inv.targetType === 'PERSON' && inv.targetId === currentUser.memberId)
  );

  const isOrganizer =
    event.organizerId === currentUser.id ||
    (currentUser.memberId && event.organizerId === currentUser.memberId);
  const isAdmin = currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL';

  const handleQuickRsvp = (e: React.MouseEvent, status: InvitationStatus) => {
    e.stopPropagation();
    rsvpEvent(event.id, status);
  };

  if (compact) {
    return (
      <div
        id={`event-card-compact-${event.id}`}
        onClick={() => onSelect(event)}
        className="group flex items-start gap-3 p-3 rounded-xl bg-white border border-stone-200 hover:border-amber-400 hover:shadow-xs transition-all cursor-pointer"
      >
        {/* Date Box */}
        <div className="shrink-0 w-12 h-13 rounded-lg bg-stone-100 border border-stone-200 flex flex-col items-center justify-center text-center">
          <span className="text-[10px] font-bold text-amber-900 tracking-wider leading-none">
            {monthShort}
          </span>
          <span className="text-base font-extrabold text-stone-900 leading-tight">
            {dayNumber}
          </span>
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 mb-1 flex-wrap">
            <EventTypeBadge type={event.eventType} size="sm" />
            {event.isConfidential && (
              <span className="inline-flex items-center gap-0.5 text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-100 text-purple-900">
                <Lock className="w-2.5 h-2.5" /> Confidentiel
              </span>
            )}
          </div>

          <h4 className="text-sm font-semibold text-stone-900 group-hover:text-amber-950 transition-colors line-clamp-1">
            {event.title}
          </h4>

          <div className="flex items-center gap-3 text-xs text-stone-500 mt-1">
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3 text-stone-400" />
              {event.startTime ? event.startTime : 'Journée'}
            </span>
            <span className="flex items-center gap-1 truncate">
              <MapPin className="w-3 h-3 text-stone-400 shrink-0" />
              <span className="truncate">{event.location}</span>
            </span>
          </div>
        </div>

        {/* Arrow */}
        <ChevronRight className="w-4 h-4 text-stone-400 group-hover:text-stone-700 transition-transform group-hover:translate-x-0.5 shrink-0 self-center" />
      </div>
    );
  }

  return (
    <div
      id={`event-card-${event.id}`}
      onClick={() => onSelect(event)}
      className={`group relative bg-white rounded-2xl border border-stone-200 hover:border-amber-400 hover:shadow-md transition-all duration-200 overflow-hidden flex flex-col cursor-pointer ${
        event.status === 'ANNULE' ? 'opacity-75 bg-stone-50' : ''
      }`}
    >
      {/* Top Header Row with Date Ribbon & Tags */}
      <div className="p-5 pb-3">
        <div className="flex items-start justify-between gap-3">
          {/* Left: Date badge + Type */}
          <div className="flex items-center gap-3">
            <div className="shrink-0 w-14 h-14 rounded-xl bg-stone-900 text-white flex flex-col items-center justify-center shadow-xs">
              <span className="text-[11px] font-semibold text-amber-300 uppercase tracking-wide">
                {monthShort}
              </span>
              <span className="text-xl font-black leading-tight text-white">{dayNumber}</span>
            </div>

            <div>
              <div className="flex items-center gap-1.5 flex-wrap mb-1">
                <EventTypeBadge type={event.eventType} size="sm" />
                <EventVisibilityBadge visibility={event.visibility} size="sm" />
                {event.status !== 'PLANIFIE' && <EventStatusBadge status={event.status} />}
              </div>
              <p className="text-xs text-stone-500 font-medium">
                {formatFrenchDate(event.startDate, { withWeekday: true })}
              </p>
            </div>
          </div>

          {/* Right: Countdown badge */}
          <span
            className={`shrink-0 text-xs font-semibold px-2.5 py-1 rounded-full border ${
              countdown.isToday
                ? 'bg-amber-100 text-amber-950 border-amber-300 animate-pulse'
                : countdown.isTomorrow
                ? 'bg-sky-50 text-sky-900 border-sky-200'
                : countdown.isPast
                ? 'bg-stone-100 text-stone-600 border-stone-200'
                : 'bg-emerald-50 text-emerald-900 border-emerald-200'
            }`}
          >
            {countdown.text}
          </span>
        </div>

        {/* Title */}
        <h3 className="text-base font-bold text-stone-900 group-hover:text-amber-950 transition-colors mt-3 line-clamp-2">
          {event.title}
        </h3>

        {/* Description preview */}
        <p className="text-xs text-stone-600 mt-2 line-clamp-2 leading-relaxed">
          {event.description}
        </p>

        {/* Location & Time Grid */}
        <div className="mt-4 pt-3 border-t border-stone-100 space-y-1.5 text-xs text-stone-600">
          <div className="flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-stone-400 shrink-0" />
            <span className="font-medium text-stone-700">
              {event.startTime ? `${event.startTime}${event.endTime ? ` - ${event.endTime}` : ''}` : 'Toute la journée'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0" />
            <span className="truncate text-stone-700 font-medium">{event.location}</span>
          </div>

          {/* Allied Family or Branch context tag */}
          {event.alliedFamilyName && (
            <div className="flex items-center gap-2 text-sky-900">
              <Building2 className="w-3.5 h-3.5 text-sky-600 shrink-0" />
              <span className="font-semibold">{event.alliedFamilyName}</span>
            </div>
          )}
        </div>
      </div>

      {/* Footer with Attendees & Quick RSVP Actions */}
      <div className="mt-auto px-5 py-3.5 bg-stone-50 border-t border-stone-100 flex items-center justify-between gap-2 flex-wrap">
        {/* Attendees Count */}
        <div className="flex items-center gap-1.5 text-xs font-semibold text-stone-700">
          <Users className="w-3.5 h-3.5 text-stone-400" />
          <span>
            {event.participantsCount || 0}
            {event.maxParticipants ? ` / ${event.maxParticipants}` : ''} participant{event.participantsCount > 1 ? 's' : ''}
          </span>
        </div>

        {/* RSVP Status or Quick Button */}
        <div className="flex items-center gap-1.5">
          {userInvitation ? (
            <InvitationStatusBadge status={userInvitation.status} />
          ) : (
            currentUser.role !== 'VISITEUR' && event.status === 'PLANIFIE' && (
              <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                <button
                  type="button"
                  onClick={(e) => handleQuickRsvp(e, 'CONFIRME')}
                  className="px-2 py-1 text-[11px] font-semibold rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 transition-colors shadow-2xs"
                  title="Confirmer ma présence"
                >
                  Participer
                </button>
                <button
                  type="button"
                  onClick={(e) => handleQuickRsvp(e, 'PEUT_ETRE')}
                  className="px-2 py-1 text-[11px] font-medium rounded-lg bg-stone-200 text-stone-700 hover:bg-stone-300 transition-colors"
                  title="Présence incertaine"
                >
                  Peut-être
                </button>
              </div>
            )
          )}

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onSelect(event);
            }}
            className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-200/60 rounded-lg transition-colors"
            title="Détails"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
