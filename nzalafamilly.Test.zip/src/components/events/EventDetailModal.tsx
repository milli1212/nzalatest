import React, { useState } from 'react';
import { FamilyEvent, InvitationStatus, InvitationTargetType } from '../../types';
import { EventTypeBadge, EventVisibilityBadge, EventStatusBadge, InvitationStatusBadge } from './EventBadge';
import { formatFrenchDate, getEventCountdown, getEventTypeConfig } from '../../services/eventService';
import { useFamily } from '../../context/FamilyContext';
import {
  X,
  Calendar,
  Clock,
  MapPin,
  Users,
  Shield,
  Building2,
  Lock,
  User,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Share2,
  Copy,
  Check,
  Edit,
  Plus,
  Send,
} from 'lucide-react';

interface EventDetailModalProps {
  event: FamilyEvent;
  isOpen: boolean;
  onClose: () => void;
  onEdit?: (event: FamilyEvent) => void;
  onCancel?: (event: FamilyEvent) => void;
}

export const EventDetailModal: React.FC<EventDetailModalProps> = ({
  event,
  isOpen,
  onClose,
  onEdit,
  onCancel,
}) => {
  const {
    currentUser,
    members,
    families,
    branches,
    rsvpEvent,
    inviteToEvent,
    createPostFromEvent,
    showToast,
    setActiveTab: setAppActiveTab,
  } = useFamily();

  const [activeTab, setActiveTab] = useState<'DETAILS' | 'AGENDA' | 'INVITATIONS'>('DETAILS');
  const [rsvpNote, setRsvpNote] = useState('');
  const [copiedAddress, setCopiedAddress] = useState(false);

  // Invite subform state
  const [showInviteForm, setShowInviteForm] = useState(false);
  const [inviteTargetType, setInviteTargetType] = useState<InvitationTargetType>('PERSON');
  const [selectedTargetId, setSelectedTargetId] = useState('');

  if (!isOpen) return null;

  const countdown = getEventCountdown(event.startDate);
  const typeConfig = getEventTypeConfig(event.eventType);

  // Find user's invitation
  const userInvitation = event.invitations?.find(
    (inv) =>
      (currentUser.id && inv.userId === currentUser.id) ||
      (currentUser.memberId && inv.memberId === currentUser.memberId) ||
      (inv.targetType === 'PERSON' && inv.targetId === currentUser.memberId)
  );

  const isOrganizer =
    event.organizerId === currentUser.id ||
    (currentUser.memberId && event.organizerId === currentUser.memberId);
  const isAdmin = currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL';
  const canManage = isOrganizer || isAdmin;

  const handleRsvp = (status: InvitationStatus) => {
    rsvpEvent(event.id, status, rsvpNote.trim() || undefined);
    setRsvpNote('');
  };

  const handleCopyAddress = () => {
    const fullLoc = `${event.location}${event.addressDetails ? ` — ${event.addressDetails}` : ''}`;
    navigator.clipboard.writeText(fullLoc);
    setCopiedAddress(true);
    showToast('info', 'Adresse copiée dans le presse-papiers.');
    setTimeout(() => setCopiedAddress(false), 2000);
  };

  const handleSendInvite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTargetId) {
      showToast('error', 'Veuillez sélectionner un destinataire.');
      return;
    }

    let targetName = '';
    let targetUserId: string | undefined;
    let targetMemberId: string | undefined;

    if (inviteTargetType === 'PERSON') {
      const member = members.find((m) => m.id === selectedTargetId);
      if (!member) return;
      targetName = `${member.firstName} ${member.lastName}`;
      targetMemberId = member.id;
      targetUserId = member.userId;
    } else if (inviteTargetType === 'FAMILY' || inviteTargetType === 'ALLIED_FAMILY') {
      const fam = families.find((f) => f.id === selectedTargetId);
      if (!fam) return;
      targetName = fam.name;
    } else if (inviteTargetType === 'BRANCH') {
      const br = branches.find((b) => b.id === selectedTargetId);
      if (!br) return;
      targetName = br.name;
    }

    inviteToEvent(event.id, {
      targetType: inviteTargetType,
      targetId: selectedTargetId,
      targetName,
      userId: targetUserId,
      memberId: targetMemberId,
    });

    setSelectedTargetId('');
    setShowInviteForm(false);
  };

  const confirmedCount = event.invitations?.filter((i) => i.status === 'CONFIRME').length || 0;
  const maybeCount = event.invitations?.filter((i) => i.status === 'PEUT_ETRE').length || 0;
  const declinedCount = event.invitations?.filter((i) => i.status === 'DECLINE').length || 0;
  const invitedCount = event.invitations?.filter((i) => i.status === 'INVITE').length || 0;

  return (
    <div
      id="event-detail-modal-backdrop"
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 md:p-6"
    >
      <div
        id="event-detail-modal-dialog"
        className="relative bg-white rounded-2xl sm:rounded-3xl shadow-2xl max-w-3xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] sm:max-h-[90vh] my-auto animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Header Banner */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white p-4 sm:p-6 relative shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3.5 right-3.5 sm:top-5 sm:right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
            title="Fermer"
          >
            <X className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap mb-2.5 pr-8 sm:pr-0">
            <EventTypeBadge type={event.eventType} size="md" />
            <EventVisibilityBadge visibility={event.visibility} size="md" />
            <EventStatusBadge status={event.status} />
            {event.isConfidential && (
              <span className="inline-flex items-center gap-1 text-xs font-bold px-2.5 py-0.5 rounded-full bg-purple-900/80 text-purple-200 border border-purple-400/40">
                <Lock className="w-3 h-3" /> Confidentiel
              </span>
            )}
          </div>

          <h2 className="text-lg sm:text-2xl font-bold text-white pr-8 tracking-tight">
            {event.title}
          </h2>

          <div className="mt-3 flex items-center gap-3 sm:gap-4 text-xs text-slate-300 flex-wrap">
            <div className="flex items-center gap-1.5 font-medium text-blue-300">
              <Calendar className="w-4 h-4 text-blue-400" />
              <span>{formatFrenchDate(event.startDate, { withWeekday: true })}</span>
              {event.endDate && event.endDate !== event.startDate && (
                <span> — {formatFrenchDate(event.endDate)}</span>
              )}
            </div>

            <div className="flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-slate-400" />
              <span>
                {event.startTime ? `${event.startTime}${event.endTime ? ` - ${event.endTime}` : ''}` : 'Toute la journée'}
              </span>
            </div>

            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-500/20 text-blue-300 border border-blue-400/30">
              {countdown.text}
            </span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-4 sm:px-6 overflow-x-auto no-scrollbar shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('DETAILS')}
            className={`py-3 px-3.5 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'DETAILS'
                ? 'border-blue-600 text-blue-600 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Détails de l'événement
          </button>

          {event.agenda && event.agenda.length > 0 && (
            <button
              type="button"
              onClick={() => setActiveTab('AGENDA')}
              className={`py-3 px-3.5 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeTab === 'AGENDA'
                  ? 'border-blue-600 text-blue-600 bg-white'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <span>Ordre du jour &amp; Programme</span>
              <span className="w-4 h-4 rounded-full bg-slate-200 text-slate-700 text-[10px] flex items-center justify-center font-bold">
                {event.agenda.length}
              </span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setActiveTab('INVITATIONS')}
            className={`py-3 px-3.5 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'INVITATIONS'
                ? 'border-blue-600 text-blue-600 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <span>Participants &amp; Invitations</span>
            <span className="w-5 h-4 rounded-full bg-blue-100 text-blue-800 text-[10px] flex items-center justify-center font-bold">
              {confirmedCount}
            </span>
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1 bg-slate-50/40">
          {activeTab === 'DETAILS' && (
            <div className="space-y-5">
              {/* RSVP Action Bar for Logged-In User */}
              {currentUser.role !== 'VISITEUR' && event.status === 'PLANIFIE' && (
                <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 shadow-2xs">
                  <div className="flex items-center justify-between gap-3 mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-blue-950">
                      Votre réponse pour cet événement
                    </span>
                    {userInvitation && (
                      <InvitationStatusBadge status={userInvitation.status} />
                    )}
                  </div>

                  <p className="text-xs text-slate-600 mb-3">
                    Indiquez à la famille si vous serez présent pour faciliter l'organisation logistique et le banquet.
                  </p>

                  <div className="flex items-center gap-2 flex-wrap mb-3">
                    <button
                      type="button"
                      onClick={() => handleRsvp('CONFIRME')}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all shadow-2xs cursor-pointer ${
                        userInvitation?.status === 'CONFIRME'
                          ? 'bg-emerald-600 text-white ring-2 ring-emerald-400'
                          : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                      }`}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Je participe
                    </button>

                    <button
                      type="button"
                      onClick={() => handleRsvp('PEUT_ETRE')}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                        userInvitation?.status === 'PEUT_ETRE'
                          ? 'bg-blue-600 text-white ring-2 ring-blue-400'
                          : 'bg-blue-100 hover:bg-blue-200 text-blue-900'
                      }`}
                    >
                      <HelpCircle className="w-3.5 h-3.5" />
                      Peut-être
                    </button>

                    <button
                      type="button"
                      onClick={() => handleRsvp('DECLINE')}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                        userInvitation?.status === 'DECLINE'
                          ? 'bg-slate-700 text-white ring-2 ring-slate-400'
                          : 'bg-slate-200 hover:bg-slate-300 text-slate-700'
                      }`}
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      Je ne pourrai pas
                    </button>
                  </div>

                  {/* Optional RSVP Note */}
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={rsvpNote}
                      onChange={(e) => setRsvpNote(e.target.value)}
                      placeholder="Note d'accompagnement (ex : Arrivée vers 14h, avec 2 enfants...)"
                      className="flex-1 text-xs px-3 py-1.5 rounded-lg bg-white border border-blue-200 focus:outline-hidden focus:border-blue-500"
                    />
                    {rsvpNote.trim() && (
                      <button
                        type="button"
                        onClick={() => handleRsvp(userInvitation?.status || 'CONFIRME')}
                        className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-blue-600 text-white hover:bg-blue-700 cursor-pointer"
                      >
                        Enregistrer
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* Description */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                  Description &amp; Contexte
                </h4>
                <p className="text-xs sm:text-sm text-slate-800 leading-relaxed whitespace-pre-line bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
                  {event.description}
                </p>
              </div>

              {/* Location & Organization Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {/* Location */}
                <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs">
                  <div className="flex items-center justify-between mb-2">
                    <span className="flex items-center gap-1.5 text-xs font-bold text-slate-700">
                      <MapPin className="w-4 h-4 text-blue-600" />
                      Lieu &amp; Accès
                    </span>
                    <button
                      type="button"
                      onClick={handleCopyAddress}
                      className="p-1 rounded text-slate-400 hover:text-slate-700 cursor-pointer"
                      title="Copier l'adresse"
                    >
                      {copiedAddress ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                  <p className="text-sm font-semibold text-slate-900">{event.location}</p>
                  {event.addressDetails && (
                    <p className="text-xs text-slate-500 mt-1">{event.addressDetails}</p>
                  )}
                </div>

                {/* Organizer */}
                <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs">
                  <span className="flex items-center gap-1.5 text-xs font-bold text-slate-700 mb-2">
                    <User className="w-4 h-4 text-blue-600" />
                    Organisé par
                  </span>
                  <p className="text-sm font-semibold text-slate-900">
                    {event.organizerName || 'Comité d’Organisation'}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    {event.organizerFamily || 'Famille Nzala'}
                  </p>
                </div>
              </div>

              {/* Allied Family & Relations Section (if applicable) */}
              {(event.alliedFamilyName || event.branchName || event.relatedMemberName) && (
                <div className="p-4 rounded-2xl bg-blue-50/50 border border-blue-200 shadow-2xs">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-blue-900 mb-2">
                    Liaisons &amp; Familles Alliées Concernées
                  </h4>
                  <div className="flex items-center gap-2.5 flex-wrap text-xs text-slate-800 font-medium">
                    {event.alliedFamilyName && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-blue-100 border border-blue-300 font-semibold text-blue-900">
                        <Building2 className="w-3.5 h-3.5 text-blue-700" />
                        {event.alliedFamilyName}
                      </span>
                    )}
                    {event.branchName && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-100 text-slate-800 border border-slate-300 font-semibold">
                        <Shield className="w-3.5 h-3.5 text-blue-600" />
                        {event.branchName}
                      </span>
                    )}
                    {event.relatedMemberName && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-rose-50 text-rose-900 border border-rose-200 font-semibold">
                        <User className="w-3.5 h-3.5 text-rose-600" />
                        En l'honneur de : {event.relatedMemberName}
                      </span>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'AGENDA' && event.agenda && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Déroulement &amp; Ordre du Jour
              </h4>
              <div className="space-y-2">
                {event.agenda.map((item, idx) => (
                  <div
                    key={item.id || idx}
                    className="p-3.5 rounded-xl bg-white border border-slate-200 flex items-start gap-3 shadow-2xs"
                  >
                    <span className="shrink-0 px-2.5 py-1 rounded-lg bg-blue-50 text-blue-900 text-xs font-mono font-bold border border-blue-200">
                      {item.time}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-900">{item.title}</p>
                      {item.presenter && (
                        <p className="text-xs text-slate-500 mt-0.5">
                          Intervenant : <span className="font-medium text-slate-700">{item.presenter}</span>
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'INVITATIONS' && (
            <div className="space-y-5">
              {/* Summary stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center">
                <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200">
                  <span className="text-base sm:text-lg font-bold text-emerald-800 block">{confirmedCount}</span>
                  <span className="text-[10px] uppercase font-bold text-emerald-700">Confirmés</span>
                </div>
                <div className="p-3 rounded-2xl bg-blue-50 border border-blue-200">
                  <span className="text-base sm:text-lg font-bold text-blue-800 block">{maybeCount}</span>
                  <span className="text-[10px] uppercase font-bold text-blue-700">Peut-être</span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-100 border border-slate-200">
                  <span className="text-base sm:text-lg font-bold text-slate-700 block">{declinedCount}</span>
                  <span className="text-[10px] uppercase font-bold text-slate-600">Déclinés</span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-base sm:text-lg font-bold text-slate-600 block">{invitedCount}</span>
                  <span className="text-[10px] uppercase font-bold text-slate-500">En attente</span>
                </div>
              </div>

              {/* Add Invitation Form (Admin or Organizer) */}
              {canManage && (
                <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
                      Envoyer une invitation supplémentaire
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowInviteForm(!showInviteForm)}
                      className="text-xs font-semibold text-blue-600 hover:text-blue-700 inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      {showInviteForm ? 'Fermer' : 'Ajouter un invité'}
                    </button>
                  </div>

                  {showInviteForm && (
                    <form onSubmit={handleSendInvite} className="space-y-3 pt-3 border-t border-slate-200">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        <div>
                          <label className="block text-[11px] font-bold text-slate-600 mb-1">
                            Type de cible
                          </label>
                          <select
                            value={inviteTargetType}
                            onChange={(e) => {
                              setInviteTargetType(e.target.value as InvitationTargetType);
                              setSelectedTargetId('');
                            }}
                            className="w-full text-xs px-3 py-2 rounded-lg bg-slate-50 border border-slate-300 focus:outline-hidden focus:border-blue-500"
                          >
                            <option value="PERSON">Membre individuel</option>
                            <option value="FAMILY">Famille entière (Nzala)</option>
                            <option value="ALLIED_FAMILY">Famille Alliée</option>
                            <option value="BRANCH">Branche familiale</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-[11px] font-bold text-slate-600 mb-1">
                            Sélectionner
                          </label>
                          {inviteTargetType === 'PERSON' && (
                            <select
                              value={selectedTargetId}
                              onChange={(e) => setSelectedTargetId(e.target.value)}
                              className="w-full text-xs px-3 py-2 rounded-lg bg-slate-50 border border-slate-300 focus:outline-hidden focus:border-blue-500"
                              required
                            >
                              <option value="">-- Choisir un membre --</option>
                              {members
                                .filter((m) => m.livingStatus === 'VIVANT')
                                .map((m) => (
                                  <option key={m.id} value={m.id}>
                                    {m.firstName} {m.lastName} ({m.primaryFamilyName})
                                  </option>
                                ))}
                            </select>
                          )}

                          {(inviteTargetType === 'FAMILY' || inviteTargetType === 'ALLIED_FAMILY') && (
                            <select
                              value={selectedTargetId}
                              onChange={(e) => setSelectedTargetId(e.target.value)}
                              className="w-full text-xs px-3 py-2 rounded-lg bg-slate-50 border border-slate-300 focus:outline-hidden focus:border-blue-500"
                              required
                            >
                              <option value="">-- Choisir une famille --</option>
                              {families.map((f) => (
                                <option key={f.id} value={f.id}>
                                  {f.name} ({f.type === 'PRINCIPALE' ? 'Famille Souche' : 'Famille Alliée'})
                                </option>
                              ))}
                            </select>
                          )}

                          {inviteTargetType === 'BRANCH' && (
                            <select
                              value={selectedTargetId}
                              onChange={(e) => setSelectedTargetId(e.target.value)}
                              className="w-full text-xs px-3 py-2 rounded-lg bg-slate-50 border border-slate-300 focus:outline-hidden focus:border-blue-500"
                              required
                            >
                              <option value="">-- Choisir une branche --</option>
                              {branches.map((b) => (
                                <option key={b.id} value={b.id}>
                                  {b.name} {b.territory ? `(${b.territory})` : ''}
                                </option>
                              ))}
                            </select>
                          )}
                        </div>
                      </div>

                      <div className="flex justify-end">
                        <button
                          type="submit"
                          className="inline-flex items-center gap-1.5 text-xs font-semibold px-4 py-2 rounded-xl bg-blue-600 text-white hover:bg-blue-700 transition-colors shadow-2xs cursor-pointer"
                        >
                          <Send className="w-3.5 h-3.5" />
                          Envoyer l'invitation
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}

              {/* Guest List */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Liste des Invités ({event.invitations?.length || 0})
                </h4>
                {event.invitations && event.invitations.length > 0 ? (
                  <div className="divide-y divide-slate-100 rounded-2xl bg-white border border-slate-200 overflow-hidden shadow-2xs">
                    {event.invitations.map((inv) => (
                      <div
                        key={inv.id}
                        className="p-3.5 flex items-center justify-between gap-3 text-xs"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center shrink-0 text-xs">
                            {inv.targetName.charAt(0)}
                          </div>
                          <div className="min-w-0">
                            <p className="font-semibold text-slate-900 truncate">
                              {inv.targetName}
                            </p>
                            {inv.responseNote && (
                              <p className="text-[11px] text-slate-500 italic truncate">
                                "{inv.responseNote}"
                              </p>
                            )}
                          </div>
                        </div>

                        <div className="shrink-0 flex items-center gap-2">
                          <InvitationStatusBadge status={inv.status} />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-500 italic p-4 text-center bg-white rounded-2xl border border-slate-200">
                    Aucune invitation spécifique enregistrée pour le moment.
                  </p>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-3.5 sm:p-4 bg-white border-t border-slate-200 flex flex-wrap items-center justify-between gap-2.5 shrink-0">
          <div className="flex items-center gap-2 flex-wrap">
            {canManage && onEdit && (
              <button
                type="button"
                onClick={() => onEdit(event)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700 bg-slate-50 border border-slate-300 hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <Edit className="w-3.5 h-3.5 text-slate-600" />
                Modifier
              </button>
            )}

            {canManage && (
              <button
                type="button"
                onClick={() => {
                  const res = createPostFromEvent(event);
                  if (res.success) {
                    onClose();
                    setAppActiveTab('announcements');
                  }
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-blue-900 bg-blue-50 hover:bg-blue-100 border border-blue-200 transition-colors cursor-pointer"
                title="Créer une annonce automatique sur le fil d'actualité familial"
              >
                <Share2 className="w-3.5 h-3.5 text-blue-700" />
                <span>Publier sur le Fil</span>
              </button>
            )}

            {canManage && onCancel && event.status === 'PLANIFIE' && (
              <button
                type="button"
                onClick={() => onCancel(event)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 hover:bg-rose-100 transition-colors cursor-pointer"
              >
                <XCircle className="w-3.5 h-3.5 text-rose-600" />
                Annuler
              </button>
            )}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-800 transition-colors cursor-pointer ml-auto"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
