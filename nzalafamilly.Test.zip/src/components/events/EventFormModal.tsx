import React, { useState, useEffect } from 'react';
import {
  FamilyEvent,
  EventType,
  EventVisibility,
  EventStatus,
  AgendaItem,
} from '../../types';
import { useFamily } from '../../context/FamilyContext';
import {
  X,
  Calendar,
  Clock,
  MapPin,
  Users,
  Shield,
  Building2,
  Lock,
  Plus,
  Trash2,
  Sparkles,
  Info,
  CheckCircle2,
} from 'lucide-react';

interface EventFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialData?: FamilyEvent | null;
  initialDate?: string;
  initialType?: EventType;
  initialRelatedMemberId?: string;
}

export const EventFormModal: React.FC<EventFormModalProps> = ({
  isOpen,
  onClose,
  initialData,
  initialDate,
  initialType,
  initialRelatedMemberId,
}) => {
  const {
    currentUser,
    members,
    families,
    branches,
    addEvent,
    updateEvent,
    showToast,
  } = useFamily();

  const [title, setTitle] = useState('');
  const [eventType, setEventType] = useState<EventType>('REUNION_FAMILIALE');
  const [visibility, setVisibility] = useState<EventVisibility>('INTER_FAMILLES');
  const [isConfidential, setIsConfidential] = useState(false);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [startTime, setStartTime] = useState('10:00');
  const [endTime, setEndTime] = useState('18:00');
  const [isAllDay, setIsAllDay] = useState(false);
  const [location, setLocation] = useState('');
  const [addressDetails, setAddressDetails] = useState('');
  const [description, setDescription] = useState('');
  const [maxParticipants, setMaxParticipants] = useState<number | undefined>(undefined);
  const [alliedFamilyId, setAlliedFamilyId] = useState('');
  const [branchId, setBranchId] = useState('');
  const [relatedMemberId, setRelatedMemberId] = useState('');
  const [agenda, setAgenda] = useState<AgendaItem[]>([]);
  const [newAgendaTime, setNewAgendaTime] = useState('');
  const [newAgendaTitle, setNewAgendaTitle] = useState('');
  const [newAgendaPresenter, setNewAgendaPresenter] = useState('');

  const [errors, setErrors] = useState<string[]>([]);

  useEffect(() => {
    if (initialData) {
      setTitle(initialData.title);
      setEventType(initialData.eventType);
      setVisibility(initialData.visibility);
      setIsConfidential(initialData.isConfidential || false);
      setStartDate(initialData.startDate);
      setEndDate(initialData.endDate || initialData.startDate);
      setStartTime(initialData.startTime || '');
      setEndTime(initialData.endTime || '');
      setIsAllDay(!initialData.startTime);
      setLocation(initialData.location);
      setAddressDetails(initialData.addressDetails || '');
      setDescription(initialData.description);
      setMaxParticipants(initialData.maxParticipants);
      setAlliedFamilyId(initialData.alliedFamilyId || '');
      setBranchId(initialData.branchId || '');
      setRelatedMemberId(initialData.relatedMemberId || '');
      setAgenda(initialData.agenda || []);
    } else {
      // Reset defaults
      setTitle('');
      setEventType(initialType || 'REUNION_FAMILIALE');
      setVisibility('INTER_FAMILLES');
      setIsConfidential(false);
      setStartDate(initialDate || '2026-09-01');
      setEndDate(initialDate || '2026-09-01');
      setStartTime('10:00');
      setEndTime('17:00');
      setIsAllDay(false);
      setLocation('Kinshasa (Siège Familial)');
      setAddressDetails('');
      setDescription('');
      setMaxParticipants(undefined);
      setAlliedFamilyId('');
      setBranchId('');
      setRelatedMemberId(initialRelatedMemberId || '');
      setAgenda([]);
    }
    setErrors([]);
  }, [initialData, initialDate, initialType, initialRelatedMemberId, isOpen]);

  if (!isOpen) return null;

  const handleAddAgendaItem = () => {
    if (!newAgendaTime || !newAgendaTitle) {
      showToast('error', 'Indiquez l’heure et le titre du point au programme.');
      return;
    }

    const newItem: AgendaItem = {
      id: `ag-${Date.now()}`,
      time: newAgendaTime,
      title: newAgendaTitle,
      presenter: newAgendaPresenter || undefined,
    };

    setAgenda([...agenda, newItem]);
    setNewAgendaTime('');
    setNewAgendaTitle('');
    setNewAgendaPresenter('');
  };

  const handleRemoveAgendaItem = (id: string) => {
    setAgenda(agenda.filter((a) => a.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: string[] = [];

    if (!title.trim() || title.length < 3) {
      newErrors.push('Le titre doit comporter au moins 3 caractères.');
    }
    if (!startDate) {
      newErrors.push('La date de début est requise.');
    }
    if (endDate && endDate < startDate) {
      newErrors.push('La date de fin ne peut pas précéder la date de début.');
    }
    if (!location.trim()) {
      newErrors.push('Le lieu est requis.');
    }
    if (!description.trim() || description.length < 10) {
      newErrors.push('Veuillez fournir une description d’au moins 10 caractères.');
    }

    if (newErrors.length > 0) {
      setErrors(newErrors);
      showToast('error', newErrors[0]);
      return;
    }

    // Resolve allied family name & branch name
    const alliedFam = families.find((f) => f.id === alliedFamilyId);
    const branch = branches.find((b) => b.id === branchId);
    const relatedMem = members.find((m) => m.id === relatedMemberId);

    const eventPayload: Omit<FamilyEvent, 'id' | 'createdAt' | 'updatedAt' | 'participantsCount'> = {
      title: title.trim(),
      description: description.trim(),
      eventType,
      visibility,
      isConfidential: eventType === 'CONSEIL_FAMILLE' ? true : isConfidential,
      startDate,
      endDate: endDate || startDate,
      startTime: isAllDay ? undefined : startTime,
      endTime: isAllDay ? undefined : endTime,
      location: location.trim(),
      addressDetails: addressDetails.trim() || undefined,
      organizerId: initialData?.organizerId || currentUser.id,
      organizerName: initialData?.organizerName || currentUser.name,
      organizerFamily: initialData?.organizerFamily || currentUser.familyName || 'Famille Nzala',
      familyId: 'fam-nzala',
      alliedFamilyId: alliedFamilyId || undefined,
      alliedFamilyName: alliedFam?.name || undefined,
      branchId: branchId || undefined,
      branchName: branch?.name || undefined,
      relatedMemberId: relatedMemberId || undefined,
      relatedMemberName: relatedMem ? `${relatedMem.firstName} ${relatedMem.lastName}` : undefined,
      status: initialData?.status || 'PLANIFIE',
      maxParticipants: maxParticipants ? Number(maxParticipants) : undefined,
      agenda: agenda.length > 0 ? agenda : undefined,
      reminders: [
        { daysBefore: 7, label: 'Rappel 7 jours avant', isActive: true },
        { daysBefore: 1, label: 'Rappel 24h avant', isActive: true },
      ],
      date: startDate,
    };

    if (initialData) {
      const res = updateEvent(initialData.id, eventPayload);
      if (res.success) {
        onClose();
      }
    } else {
      const res = addEvent(eventPayload);
      if (res.success) {
        onClose();
      }
    }
  };

  return (
    <div
      id="event-form-modal-backdrop"
      className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6"
    >
      <div
        id="event-form-modal-dialog"
        className="relative bg-white rounded-3xl shadow-2xl max-w-3xl w-full border border-stone-200 overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Header */}
        <div className="bg-stone-900 text-white p-6 relative flex items-center justify-between">
          <div>
            <h2 className="text-xl font-black text-white">
              {initialData ? 'Modifier l’événement' : 'Programmer un nouvel événement'}
            </h2>
            <p className="text-xs text-stone-300 mt-1">
              Partagez un rassemblement, un anniversaire, une réunion ou une cérémonie coutumière.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-stone-200 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 flex-1">
          {errors.length > 0 && (
            <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-xs text-rose-900 space-y-1">
              <span className="font-bold">Veuillez corriger les points suivants :</span>
              <ul className="list-disc list-inside space-y-0.5">
                {errors.map((err, idx) => (
                  <li key={idx}>{err}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Title */}
          <div>
            <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1.5">
              Titre de l'événement <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ex : Réunion Annuelle de la Branche Ngaliema, Mariage de..."
              required
              className="w-full text-sm px-4 py-2.5 rounded-xl bg-stone-50 border border-stone-300 focus:bg-white focus:outline-hidden focus:border-amber-600 font-medium"
            />
          </div>

          {/* Event Type & Visibility Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Event Type */}
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1.5">
                Type d'événement <span className="text-rose-500">*</span>
              </label>
              <select
                value={eventType}
                onChange={(e) => setEventType(e.target.value as EventType)}
                className="w-full text-xs font-semibold px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-300 focus:bg-white focus:outline-hidden focus:border-amber-600"
              >
                <option value="REUNION_FAMILIALE">Réunion Familiale</option>
                <option value="ANNIVERSAIRE">Anniversaire</option>
                <option value="CONSEIL_FAMILLE">Conseil de Famille (Confidentiel)</option>
                <option value="MARIAGE">Mariage & Dot</option>
                <option value="NAISSANCE">Naissance & Bénédiction</option>
                <option value="CEREMONIE">Cérémonie Coutumière</option>
                <option value="COMMEMORATION">Commémoration & Hommage</option>
                <option value="RENCONTRE_ALLIANCE">Rencontre Inter-Alliances</option>
                <option value="AUTRE">Autre Événement</option>
              </select>
            </div>

            {/* Visibility Scope */}
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1.5">
                Portée de visibilité <span className="text-rose-500">*</span>
              </label>
              <select
                value={visibility}
                onChange={(e) => setVisibility(e.target.value as EventVisibility)}
                className="w-full text-xs font-semibold px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-300 focus:bg-white focus:outline-hidden focus:border-amber-600"
              >
                <option value="INTER_FAMILLES">Inter-Familles (Nzala + Familles Alliées)</option>
                <option value="NZALA_INTERNE">Famille Nzala uniquement (Interne)</option>
                <option value="FAMILLE_ALLIEE">Famille Alliée Spécifique</option>
                <option value="PUBLIC">Public (Visible aux Visiteurs et Membres)</option>
                <option value="PRIVE">Privé (Uniquement sur invitation directe)</option>
              </select>
            </div>
          </div>

          {/* Confidentiality Warning / Toggle */}
          {eventType === 'CONSEIL_FAMILLE' ? (
            <div className="p-3 rounded-xl bg-purple-50 border border-purple-200 flex items-center gap-2 text-xs text-purple-900 font-medium">
              <Lock className="w-4 h-4 text-purple-700 shrink-0" />
              <span>
                Cet événement est classé <strong>Conseil de Famille</strong> et sera strictement confidentiel (visible uniquement par les sages et validateurs).
              </span>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="confidential-check"
                checked={isConfidential}
                onChange={(e) => setIsConfidential(e.target.checked)}
                className="w-4 h-4 rounded text-amber-800 border-stone-300 focus:ring-amber-500"
              />
              <label htmlFor="confidential-check" className="text-xs text-stone-700 font-medium">
                Marquer cet événement comme <strong>Confidentiel</strong> (accès restreint)
              </label>
            </div>
          )}

          {/* Dates & Times */}
          <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-stone-800 uppercase tracking-wider">
                Dates & Horaires
              </span>
              <label className="flex items-center gap-1.5 text-xs text-stone-600 font-medium cursor-pointer">
                <input
                  type="checkbox"
                  checked={isAllDay}
                  onChange={(e) => setIsAllDay(e.target.checked)}
                  className="rounded text-amber-800"
                />
                Toute la journée
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-stone-600 mb-1">
                  Date de début <span className="text-rose-500">*</span>
                </label>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => {
                    setStartDate(e.target.value);
                    if (!endDate || endDate < e.target.value) {
                      setEndDate(e.target.value);
                    }
                  }}
                  required
                  className="w-full text-xs px-3 py-2 rounded-lg bg-white border border-stone-300 font-medium"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-stone-600 mb-1">
                  Date de fin (optionnel)
                </label>
                <input
                  type="date"
                  value={endDate}
                  min={startDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full text-xs px-3 py-2 rounded-lg bg-white border border-stone-300 font-medium"
                />
              </div>

              {!isAllDay && (
                <>
                  <div>
                    <label className="block text-[11px] font-bold text-stone-600 mb-1">
                      Heure de début
                    </label>
                    <input
                      type="time"
                      value={startTime}
                      onChange={(e) => setStartTime(e.target.value)}
                      className="w-full text-xs px-3 py-2 rounded-lg bg-white border border-stone-300 font-medium"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-stone-600 mb-1">
                      Heure de fin
                    </label>
                    <input
                      type="time"
                      value={endTime}
                      onChange={(e) => setEndTime(e.target.value)}
                      className="w-full text-xs px-3 py-2 rounded-lg bg-white border border-stone-300 font-medium"
                    />
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Location */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1.5">
                Lieu ou Lien <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Ex : Ngaliema (Kinshasa) ou Visioconférence Zoom..."
                required
                className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-300 focus:bg-white focus:outline-hidden focus:border-amber-600 font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1.5">
                Précisions d'adresse (optionnel)
              </label>
              <input
                type="text"
                value={addressDetails}
                onChange={(e) => setAddressDetails(e.target.value)}
                placeholder="Ex : Avenue de la Paix, Résidence Doyens, Porte 4"
                className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-300 focus:bg-white focus:outline-hidden focus:border-amber-600 font-medium"
              />
            </div>
          </div>

          {/* Context Links: Allied Family, Branch, Related Member */}
          <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-3">
            <span className="text-xs font-bold text-stone-800 uppercase tracking-wider block">
              Liaisons Familiales & Alliances Concernées
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-stone-600 mb-1">
                  Famille Alliée
                </label>
                <select
                  value={alliedFamilyId}
                  onChange={(e) => setAlliedFamilyId(e.target.value)}
                  className="w-full text-xs px-3 py-2 rounded-lg bg-white border border-stone-300"
                >
                  <option value="">-- Aucune / Non spécifique --</option>
                  {families
                    .filter((f) => f.type === 'ALLIEE')
                    .map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.name}
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-stone-600 mb-1">
                  Branche
                </label>
                <select
                  value={branchId}
                  onChange={(e) => setBranchId(e.target.value)}
                  className="w-full text-xs px-3 py-2 rounded-lg bg-white border border-stone-300"
                >
                  <option value="">-- Non spécifique --</option>
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-stone-600 mb-1">
                  En l'honneur d'un membre
                </label>
                <select
                  value={relatedMemberId}
                  onChange={(e) => setRelatedMemberId(e.target.value)}
                  className="w-full text-xs px-3 py-2 rounded-lg bg-white border border-stone-300"
                >
                  <option value="">-- Aucun --</option>
                  {members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.firstName} {m.lastName} ({m.primaryFamilyName})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1.5">
              Description & Programme Général <span className="text-rose-500">*</span>
            </label>
            <textarea
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Détaillez le but du rassemblement, le déroulement prévu, les instructions d’accès..."
              required
              className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-300 focus:bg-white focus:outline-hidden focus:border-amber-600 font-medium"
            />
          </div>

          {/* Agenda items builder */}
          <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-3">
            <span className="text-xs font-bold text-stone-800 uppercase tracking-wider block">
              Ordre du Jour & Étapes du Programme (optionnel)
            </span>

            {agenda.length > 0 && (
              <div className="space-y-2 mb-3">
                {agenda.map((item) => (
                  <div
                    key={item.id}
                    className="p-2.5 rounded-lg bg-white border border-stone-200 flex items-center justify-between gap-3 text-xs"
                  >
                    <span className="font-mono font-bold text-amber-900 bg-amber-50 px-2 py-0.5 rounded">
                      {item.time}
                    </span>
                    <span className="flex-1 font-semibold text-stone-900 truncate">
                      {item.title}
                    </span>
                    {item.presenter && (
                      <span className="text-stone-500 text-[11px] truncate">
                        ({item.presenter})
                      </span>
                    )}
                    <button
                      type="button"
                      onClick={() => handleRemoveAgendaItem(item.id)}
                      className="text-stone-400 hover:text-rose-600 p-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
              <input
                type="text"
                value={newAgendaTime}
                onChange={(e) => setNewAgendaTime(e.target.value)}
                placeholder="Heure (ex: 14:00)"
                className="text-xs px-3 py-2 rounded-lg bg-white border border-stone-300 font-mono"
              />
              <input
                type="text"
                value={newAgendaTitle}
                onChange={(e) => setNewAgendaTitle(e.target.value)}
                placeholder="Intitulé du point"
                className="sm:col-span-2 text-xs px-3 py-2 rounded-lg bg-white border border-stone-300"
              />
              <button
                type="button"
                onClick={handleAddAgendaItem}
                className="inline-flex items-center justify-center gap-1 text-xs font-bold px-3 py-2 rounded-lg bg-stone-900 text-white hover:bg-stone-800 shadow-2xs"
              >
                <Plus className="w-3.5 h-3.5" />
                Ajouter
              </button>
            </div>
          </div>
        </form>

        {/* Footer */}
        <div className="p-4 sm:p-5 bg-stone-50 border-t border-stone-200 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-bold text-stone-600 hover:text-stone-900 hover:bg-stone-200/60 transition-colors"
          >
            Annuler
          </button>

          <button
            type="button"
            onClick={handleSubmit}
            className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold bg-amber-800 text-white hover:bg-amber-900 transition-colors shadow-xs"
          >
            <CheckCircle2 className="w-4 h-4" />
            {initialData ? 'Enregistrer les modifications' : 'Publier l’événement'}
          </button>
        </div>
      </div>
    </div>
  );
};
