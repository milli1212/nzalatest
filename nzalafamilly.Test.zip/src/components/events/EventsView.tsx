import React, { useState, useMemo } from 'react';
import {
  FamilyEvent,
  EventType,
  EventVisibility,
  UpcomingBirthday,
} from '../../types';
import { useFamily } from '../../context/FamilyContext';
import { CalendarView } from './CalendarView';
import { UpcomingBirthdaysSection } from './UpcomingBirthdaysSection';
import { MyEventsSection } from './MyEventsSection';
import { EventCard } from './EventCard';
import { EventDetailModal } from './EventDetailModal';
import { EventFormModal } from './EventFormModal';
import { canUserViewEvent, getEventCountdown } from '../../services/eventService';
import {
  Calendar,
  Cake,
  Plus,
  Search,
  Filter,
  Users,
  Shield,
  Building2,
  Lock,
  Sparkles,
  List,
  Grid,
  HeartHandshake,
  Baby,
  Clock,
  CheckCircle2,
  ChevronRight,
} from 'lucide-react';

export const EventsView: React.FC = () => {
  const {
    events,
    upcomingBirthdays,
    currentUser,
    can,
    cancelEvent,
    selectedEvent,
    setSelectedEvent,
  } = useFamily();

  // Navigation subtabs
  const [activeTab, setActiveTab] = useState<'CALENDAR' | 'EXPLORE' | 'BIRTHDAYS' | 'MY_EVENTS'>('CALENDAR');

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<EventType | 'ALL'>('ALL');
  const [visibilityFilter, setVisibilityFilter] = useState<EventVisibility | 'ALL'>('ALL');

  // Modal states
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<FamilyEvent | null>(null);
  const [formInitialDate, setFormInitialDate] = useState<string | undefined>(undefined);
  const [formInitialType, setFormInitialType] = useState<EventType | undefined>(undefined);
  const [formInitialRelatedMemberId, setFormInitialRelatedMemberId] = useState<string | undefined>(undefined);

  // Filter events by visibility permissions & active search
  const authorizedEvents = useMemo(() => {
    return events.filter((evt) => canUserViewEvent(evt, currentUser));
  }, [events, currentUser]);

  const filteredEvents = useMemo(() => {
    return authorizedEvents.filter((evt) => {
      if (typeFilter !== 'ALL' && evt.eventType !== typeFilter) {
        return false;
      }
      if (visibilityFilter !== 'ALL' && evt.visibility !== visibilityFilter) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = evt.title.toLowerCase().includes(q);
        const matchesDesc = evt.description.toLowerCase().includes(q);
        const matchesLoc = evt.location.toLowerCase().includes(q);
        const matchesOrg = evt.organizerName?.toLowerCase().includes(q);
        const matchesAllied = evt.alliedFamilyName?.toLowerCase().includes(q);
        return matchesTitle || matchesDesc || matchesLoc || matchesOrg || matchesAllied;
      }
      return true;
    });
  }, [authorizedEvents, typeFilter, visibilityFilter, searchQuery]);

  // Summary counts
  const totalUpcoming = authorizedEvents.filter((e) => e.status === 'PLANIFIE').length;
  const councilEventsCount = authorizedEvents.filter((e) => e.eventType === 'CONSEIL_FAMILLE').length;
  const myPendingInvitations = authorizedEvents.filter((e) =>
    e.invitations?.some(
      (inv) =>
        inv.status === 'INVITE' &&
        ((currentUser.id && inv.userId === currentUser.id) ||
          (currentUser.memberId && inv.memberId === currentUser.memberId))
    )
  ).length;

  const handleOpenCreateModal = (dateStr?: string, type?: EventType, relatedMemberId?: string) => {
    setEditingEvent(null);
    setFormInitialDate(dateStr);
    setFormInitialType(type);
    setFormInitialRelatedMemberId(relatedMemberId);
    setIsFormModalOpen(true);
  };

  const handleEditEvent = (evt: FamilyEvent) => {
    setEditingEvent(evt);
    setIsFormModalOpen(true);
  };

  const handleCancelEvent = (evt: FamilyEvent) => {
    if (confirm(`Êtes-vous sûr de vouloir annuler l'événement "${evt.title}" ?`)) {
      cancelEvent(evt.id, 'Annulation demandée par l’organisateur / administrateur');
      if (selectedEvent?.id === evt.id) {
        setSelectedEvent(null);
      }
    }
  };

  const handleCreateFromBirthday = (birthday: UpcomingBirthday) => {
    // Open create form pre-filled with birthday details
    const currentYear = new Date().getFullYear();
    const bMonth = String(birthday.birthMonth + 1).padStart(2, '0');
    const bDay = String(birthday.birthDay).padStart(2, '0');
    const dateStr = `${currentYear}-${bMonth}-${bDay}`;

    handleOpenCreateModal(dateStr, 'ANNIVERSAIRE', birthday.memberId);
  };

  return (
    <div id="events-main-view" className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="bg-stone-900 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden shadow-xl border border-stone-800">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-80 h-80 bg-amber-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 -mb-10 w-60 h-60 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400">
              <Sparkles className="w-4 h-4" />
              <span>Vie Familiale & Rassemblements</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              Événements, Anniversaires & Calendrier
            </h1>
            <p className="text-stone-300 text-xs sm:text-sm leading-relaxed">
              Consultez l'agenda officiel de la famille Nzala et des familles alliées. Organisez les mariages, réunions de branche, anniversaires et sessions du Conseil de Famille.
            </p>
          </div>

          {can('CREATE_EVENT') && (
            <div className="flex items-center gap-3 shrink-0">
              <button
                type="button"
                onClick={() => handleOpenCreateModal()}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs sm:text-sm shadow-md hover:shadow-lg transition-all active:scale-95"
              >
                <Plus className="w-4 h-4" />
                <span>Programmer un Événement</span>
              </button>
            </div>
          )}
        </div>

        {/* Stats Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-8 pt-6 border-t border-stone-800/80">
          <div className="bg-stone-800/50 backdrop-blur-xs p-3.5 rounded-2xl border border-stone-700/50">
            <div className="flex items-center gap-2 text-stone-400 text-xs mb-1">
              <Calendar className="w-3.5 h-3.5 text-amber-400" />
              <span>À venir</span>
            </div>
            <p className="text-xl font-extrabold text-white">{totalUpcoming}</p>
          </div>

          <div className="bg-stone-800/50 backdrop-blur-xs p-3.5 rounded-2xl border border-stone-700/50">
            <div className="flex items-center gap-2 text-stone-400 text-xs mb-1">
              <Cake className="w-3.5 h-3.5 text-rose-400" />
              <span>Anniversaires</span>
            </div>
            <p className="text-xl font-extrabold text-white">{upcomingBirthdays.length}</p>
          </div>

          <div className="bg-stone-800/50 backdrop-blur-xs p-3.5 rounded-2xl border border-stone-700/50">
            <div className="flex items-center gap-2 text-stone-400 text-xs mb-1">
              <Shield className="w-3.5 h-3.5 text-sky-400" />
              <span>Conseil de Famille</span>
            </div>
            <p className="text-xl font-extrabold text-white">{councilEventsCount}</p>
          </div>

          <div className="bg-stone-800/50 backdrop-blur-xs p-3.5 rounded-2xl border border-stone-700/50">
            <div className="flex items-center gap-2 text-stone-400 text-xs mb-1">
              <Clock className="w-3.5 h-3.5 text-emerald-400" />
              <span>Mes Invitations</span>
            </div>
            <p className="text-xl font-extrabold text-white">{myPendingInvitations}</p>
          </div>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="bg-white p-2 rounded-2xl border border-stone-200 shadow-xs flex items-center gap-1.5 overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('CALENDAR')}
          className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
            activeTab === 'CALENDAR'
              ? 'bg-amber-900 text-white shadow-xs'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Calendrier & Mois</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('EXPLORE')}
          className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
            activeTab === 'EXPLORE'
              ? 'bg-amber-900 text-white shadow-xs'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <List className="w-4 h-4" />
          <span>Tous les Événements</span>
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-stone-200 text-stone-800">
            {authorizedEvents.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('BIRTHDAYS')}
          className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
            activeTab === 'BIRTHDAYS'
              ? 'bg-rose-900 text-white shadow-xs'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <Cake className="w-4 h-4 text-rose-500" />
          <span>Anniversaires</span>
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-rose-100 text-rose-900 font-bold">
            {upcomingBirthdays.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('MY_EVENTS')}
          className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0 ml-auto ${
            activeTab === 'MY_EVENTS'
              ? 'bg-emerald-900 text-white shadow-xs'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          <span>Mes Événements</span>
          {myPendingInvitations > 0 && (
            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-500 text-stone-950 font-black animate-pulse">
              {myPendingInvitations}
            </span>
          )}
        </button>
      </div>

      {/* VIEW: CALENDAR */}
      {activeTab === 'CALENDAR' && (
        <CalendarView
          events={authorizedEvents}
          birthdays={upcomingBirthdays}
          onSelectEvent={(evt) => setSelectedEvent(evt)}
          onCreateEventOnDate={(dateStr) => handleOpenCreateModal(dateStr)}
        />
      )}

      {/* VIEW: EXPLORE ALL EVENTS */}
      {activeTab === 'EXPLORE' && (
        <div className="space-y-6">
          {/* Search and Filters Bar */}
          <div className="bg-white p-4 sm:p-5 rounded-3xl border border-stone-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Rechercher par titre, description, lieu, organisateur ou alliance..."
                className="w-full text-xs pl-10 pr-4 py-2.5 rounded-xl bg-stone-50 border border-stone-200 focus:bg-white focus:outline-hidden focus:border-amber-600 font-medium"
              />
            </div>

            <div className="flex items-center gap-3 flex-wrap">
              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value as EventType | 'ALL')}
                className="text-xs font-semibold px-3 py-2.5 rounded-xl bg-stone-50 border border-stone-200 focus:bg-white focus:outline-hidden focus:border-amber-600"
              >
                <option value="ALL">Tous les types</option>
                <option value="REUNION_FAMILIALE">Réunions Familiales</option>
                <option value="CONSEIL_FAMILLE">Conseil de Famille</option>
                <option value="ANNIVERSAIRE">Anniversaires</option>
                <option value="MARIAGE">Mariages & Dot</option>
                <option value="NAISSANCE">Naissances</option>
                <option value="COMMEMORATION">Commémorations</option>
                <option value="RENCONTRE_ALLIANCE">Rencontres Alliées</option>
              </select>

              <select
                value={visibilityFilter}
                onChange={(e) => setVisibilityFilter(e.target.value as EventVisibility | 'ALL')}
                className="text-xs font-semibold px-3 py-2.5 rounded-xl bg-stone-50 border border-stone-200 focus:bg-white focus:outline-hidden focus:border-amber-600"
              >
                <option value="ALL">Toutes les visibilités</option>
                <option value="INTER_FAMILLES">Inter-Familles</option>
                <option value="NZALA_INTERNE">Nzala Interne</option>
                <option value="FAMILLE_ALLIEE">Familles Alliées</option>
                <option value="PUBLIC">Public</option>
                <option value="PRIVE">Privé</option>
              </select>
            </div>
          </div>

          {/* Events Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredEvents.map((evt) => (
              <EventCard
                key={evt.id}
                event={evt}
                onSelect={(e) => setSelectedEvent(e)}
                onEdit={handleEditEvent}
              />
            ))}
          </div>

          {filteredEvents.length === 0 && (
            <div className="p-12 text-center bg-white rounded-3xl border border-stone-200">
              <Calendar className="w-12 h-12 text-stone-300 mx-auto mb-3" />
              <h3 className="text-sm font-bold text-stone-700">Aucun événement correspondant</h3>
              <p className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
                Modifiez vos filtres de recherche ou programmez un nouvel événement.
              </p>
            </div>
          )}
        </div>
      )}

      {/* VIEW: BIRTHDAYS */}
      {activeTab === 'BIRTHDAYS' && (
        <UpcomingBirthdaysSection
          onCreateBirthdayEvent={handleCreateFromBirthday}
        />
      )}

      {/* VIEW: MY EVENTS & INVITATIONS */}
      {activeTab === 'MY_EVENTS' && (
        <MyEventsSection
          onSelectEvent={(evt) => setSelectedEvent(evt)}
          onCreateEvent={() => handleOpenCreateModal()}
        />
      )}

      {/* Event Details Modal */}
      {selectedEvent && (
        <EventDetailModal
          event={selectedEvent}
          isOpen={Boolean(selectedEvent)}
          onClose={() => setSelectedEvent(null)}
          onEdit={(evt) => {
            setSelectedEvent(null);
            handleEditEvent(evt);
          }}
          onCancel={handleCancelEvent}
        />
      )}

      {/* Event Create / Edit Modal */}
      <EventFormModal
        isOpen={isFormModalOpen}
        onClose={() => {
          setIsFormModalOpen(false);
          setEditingEvent(null);
        }}
        initialData={editingEvent}
        initialDate={formInitialDate}
        initialType={formInitialType}
        initialRelatedMemberId={formInitialRelatedMemberId}
      />
    </div>
  );
};
