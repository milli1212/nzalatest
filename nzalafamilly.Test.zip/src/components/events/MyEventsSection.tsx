import React, { useState } from 'react';
import { FamilyEvent, InvitationStatus } from '../../types';
import { useFamily } from '../../context/FamilyContext';
import { EventCard } from './EventCard';
import { EventTypeBadge, InvitationStatusBadge } from './EventBadge';
import { formatFrenchDate, getEventCountdown } from '../../services/eventService';
import {
  Bell,
  CheckCircle2,
  Calendar,
  Clock,
  MapPin,
  HelpCircle,
  XCircle,
  User,
  Shield,
  Send,
  Plus,
} from 'lucide-react';

interface MyEventsSectionProps {
  onSelectEvent: (event: FamilyEvent) => void;
  onCreateEvent: () => void;
}

export const MyEventsSection: React.FC<MyEventsSectionProps> = ({
  onSelectEvent,
  onCreateEvent,
}) => {
  const { events, currentUser, rsvpEvent, can } = useFamily();
  const [subTab, setSubTab] = useState<'INVITATIONS' | 'PARTICIPATING' | 'ORGANIZING' | 'PAST'>('INVITATIONS');

  const userId = currentUser.id;
  const userMemberId = currentUser.memberId;

  // Filter events where user is invited/participating
  const pendingInvitations: FamilyEvent[] = [];
  const participatingEvents: FamilyEvent[] = [];
  const organizingEvents: FamilyEvent[] = [];
  const pastEvents: FamilyEvent[] = [];

  const nowIso = new Date().toISOString().split('T')[0];

  events.forEach((evt) => {
    const isOrg =
      (userId && evt.organizerId === userId) ||
      (userMemberId && evt.organizerId === userMemberId);

    const userInv = evt.invitations?.find(
      (i) =>
        (userId && i.userId === userId) ||
        (userMemberId && i.memberId === userMemberId) ||
        (i.targetType === 'PERSON' && i.targetId === userMemberId)
    );

    if (isOrg) {
      organizingEvents.push(evt);
    }

    if (userInv) {
      if (userInv.status === 'INVITE') {
        pendingInvitations.push(evt);
      } else if (userInv.status === 'CONFIRME') {
        if (evt.startDate < nowIso || evt.status === 'TERMINE') {
          pastEvents.push(evt);
        } else {
          participatingEvents.push(evt);
        }
      }
    }
  });

  return (
    <div id="my-events-section" className="space-y-6">
      {/* Top summary stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <button
          type="button"
          onClick={() => setSubTab('INVITATIONS')}
          className={`p-4 rounded-2xl border text-left transition-all ${
            subTab === 'INVITATIONS'
              ? 'bg-amber-900 text-white border-amber-950 shadow-sm'
              : 'bg-white text-stone-800 border-stone-200 hover:border-amber-400'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <Bell className={`w-4 h-4 ${subTab === 'INVITATIONS' ? 'text-amber-300' : 'text-amber-700'}`} />
            <span className={`text-lg font-black ${subTab === 'INVITATIONS' ? 'text-white' : 'text-stone-900'}`}>
              {pendingInvitations.length}
            </span>
          </div>
          <p className="text-xs font-bold">Invitations reçues</p>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('PARTICIPATING')}
          className={`p-4 rounded-2xl border text-left transition-all ${
            subTab === 'PARTICIPATING'
              ? 'bg-emerald-900 text-white border-emerald-950 shadow-sm'
              : 'bg-white text-stone-800 border-stone-200 hover:border-emerald-400'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <CheckCircle2 className={`w-4 h-4 ${subTab === 'PARTICIPATING' ? 'text-emerald-300' : 'text-emerald-700'}`} />
            <span className={`text-lg font-black ${subTab === 'PARTICIPATING' ? 'text-white' : 'text-stone-900'}`}>
              {participatingEvents.length}
            </span>
          </div>
          <p className="text-xs font-bold">Je participe</p>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('ORGANIZING')}
          className={`p-4 rounded-2xl border text-left transition-all ${
            subTab === 'ORGANIZING'
              ? 'bg-sky-900 text-white border-sky-950 shadow-sm'
              : 'bg-white text-stone-800 border-stone-200 hover:border-sky-400'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <Calendar className={`w-4 h-4 ${subTab === 'ORGANIZING' ? 'text-sky-300' : 'text-sky-700'}`} />
            <span className={`text-lg font-black ${subTab === 'ORGANIZING' ? 'text-white' : 'text-stone-900'}`}>
              {organizingEvents.length}
            </span>
          </div>
          <p className="text-xs font-bold">Mes organisations</p>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('PAST')}
          className={`p-4 rounded-2xl border text-left transition-all ${
            subTab === 'PAST'
              ? 'bg-stone-800 text-white border-stone-900 shadow-sm'
              : 'bg-white text-stone-800 border-stone-200 hover:border-stone-400'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <Clock className={`w-4 h-4 ${subTab === 'PAST' ? 'text-stone-300' : 'text-stone-500'}`} />
            <span className={`text-lg font-black ${subTab === 'PAST' ? 'text-white' : 'text-stone-900'}`}>
              {pastEvents.length}
            </span>
          </div>
          <p className="text-xs font-bold">Historique passé</p>
        </button>
      </div>

      {/* INVITATIONS PENDING VIEW */}
      {subTab === 'INVITATIONS' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-stone-900">
              Invitations en attente de réponse ({pendingInvitations.length})
            </h3>
          </div>

          {pendingInvitations.length > 0 ? (
            <div className="space-y-3">
              {pendingInvitations.map((evt) => (
                <div
                  key={evt.id}
                  className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                      <EventTypeBadge type={evt.eventType} size="sm" />
                      <span className="text-xs font-bold text-amber-900 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200">
                        {formatFrenchDate(evt.startDate, { withWeekday: true })}
                      </span>
                    </div>

                    <h4
                      onClick={() => onSelectEvent(evt)}
                      className="text-base font-bold text-stone-900 hover:text-amber-950 cursor-pointer transition-colors"
                    >
                      {evt.title}
                    </h4>

                    <div className="flex items-center gap-4 text-xs text-stone-500 mt-2">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-stone-400" />
                        {evt.startTime || 'Toute la journée'}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-stone-400" />
                        {evt.location}
                      </span>
                      <span className="flex items-center gap-1">
                        <User className="w-3.5 h-3.5 text-stone-400" />
                        Invité par {evt.organizerName}
                      </span>
                    </div>
                  </div>

                  {/* Fast Action Buttons */}
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => rsvpEvent(evt.id, 'CONFIRME')}
                      className="inline-flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-2xs transition-colors"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Confirmer
                    </button>
                    <button
                      type="button"
                      onClick={() => rsvpEvent(evt.id, 'PEUT_ETRE')}
                      className="inline-flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-bold bg-sky-100 hover:bg-sky-200 text-sky-900 transition-colors"
                    >
                      <HelpCircle className="w-3.5 h-3.5" />
                      Peut-être
                    </button>
                    <button
                      type="button"
                      onClick={() => rsvpEvent(evt.id, 'DECLINE')}
                      className="inline-flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-bold bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      Décliner
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-12 text-center bg-white rounded-3xl border border-stone-200">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
              <h3 className="text-sm font-bold text-stone-700">Vous êtes à jour !</h3>
              <p className="text-xs text-stone-500 mt-1">
                Aucune invitation n'est en attente de réponse.
              </p>
            </div>
          )}
        </div>
      )}

      {/* PARTICIPATING VIEW */}
      {subTab === 'PARTICIPATING' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-stone-900">
            Événements confirmés auxquels vous participez ({participatingEvents.length})
          </h3>
          {participatingEvents.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {participatingEvents.map((evt) => (
                <EventCard key={evt.id} event={evt} onSelect={onSelectEvent} />
              ))}
            </div>
          ) : (
            <div className="p-12 text-center bg-white rounded-3xl border border-stone-200">
              <Calendar className="w-12 h-12 text-stone-300 mx-auto mb-3" />
              <h3 className="text-sm font-bold text-stone-700">Aucune participation confirmée</h3>
              <p className="text-xs text-stone-500 mt-1">
                Consultez le calendrier pour confirmer votre présence aux rassemblements familiaux.
              </p>
            </div>
          )}
        </div>
      )}

      {/* ORGANIZING VIEW */}
      {subTab === 'ORGANIZING' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-stone-900">
              Événements sous votre responsabilité ({organizingEvents.length})
            </h3>
            {can('CREATE_EVENT') && (
              <button
                type="button"
                onClick={onCreateEvent}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-800 text-white hover:bg-amber-900 transition-colors shadow-2xs"
              >
                <Plus className="w-3.5 h-3.5" />
                Créer un événement
              </button>
            )}
          </div>

          {organizingEvents.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {organizingEvents.map((evt) => (
                <EventCard key={evt.id} event={evt} onSelect={onSelectEvent} />
              ))}
            </div>
          ) : (
            <div className="p-12 text-center bg-white rounded-3xl border border-stone-200">
              <User className="w-12 h-12 text-stone-300 mx-auto mb-3" />
              <h3 className="text-sm font-bold text-stone-700">Aucun événement organisé</h3>
              <p className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
                Vous n'avez pas encore programmé d'événement au nom de votre branche ou famille.
              </p>
            </div>
          )}
        </div>
      )}

      {/* PAST VIEW */}
      {subTab === 'PAST' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-stone-900">
            Historique des événements passés ({pastEvents.length})
          </h3>
          {pastEvents.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {pastEvents.map((evt) => (
                <EventCard key={evt.id} event={evt} onSelect={onSelectEvent} />
              ))}
            </div>
          ) : (
            <div className="p-12 text-center bg-white rounded-3xl border border-stone-200">
              <Clock className="w-12 h-12 text-stone-300 mx-auto mb-3" />
              <h3 className="text-sm font-bold text-stone-700">Aucun événement archivé</h3>
              <p className="text-xs text-stone-500 mt-1">
                L'historique des événements passés apparaîtra ici au fil du temps.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
