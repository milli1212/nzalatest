import React, { useState } from 'react';
import { UpcomingBirthday, Member } from '../../types';
import { useFamily } from '../../context/FamilyContext';
import {
  Cake,
  Calendar,
  Gift,
  Plus,
  Search,
  Filter,
  User,
  Shield,
  Building2,
  Sparkles,
  ChevronRight,
  PartyPopper,
} from 'lucide-react';

interface UpcomingBirthdaysSectionProps {
  onCreateBirthdayEvent?: (birthday: UpcomingBirthday) => void;
  limit?: number;
  compact?: boolean;
}

export const UpcomingBirthdaysSection: React.FC<UpcomingBirthdaysSectionProps> = ({
  onCreateBirthdayEvent,
  limit,
  compact = false,
}) => {
  const {
    upcomingBirthdays,
    currentUser,
    can,
    setBirthdayCelebrationModalOpen,
    setActiveBirthdayDraft,
  } = useFamily();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMonth, setSelectedMonth] = useState<number | 'ALL'>('ALL');

  const monthNames = [
    'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
    'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
  ];

  // Filter list
  let filtered = upcomingBirthdays;

  if (selectedMonth !== 'ALL') {
    filtered = filtered.filter((b) => b.birthMonth === selectedMonth);
  }

  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase();
    filtered = filtered.filter(
      (b) =>
        b.fullName.toLowerCase().includes(q) ||
        b.primaryFamilyName.toLowerCase().includes(q) ||
        (b.branchName && b.branchName.toLowerCase().includes(q))
    );
  }

  if (limit && limit > 0) {
    filtered = filtered.slice(0, limit);
  }

  if (compact) {
    return (
      <div id="upcoming-birthdays-compact" className="space-y-2.5">
        {filtered.slice(0, 5).map((b) => (
          <div
            key={b.memberId}
            className="flex items-center justify-between gap-3 p-2.5 rounded-xl bg-white border border-stone-200 hover:border-rose-300 transition-all text-xs"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-full bg-rose-50 border border-rose-200 text-rose-800 flex items-center justify-center font-bold text-xs shrink-0">
                <Cake className="w-4 h-4 text-rose-600" />
              </div>
              <div className="min-w-0">
                <p className="font-bold text-stone-900 truncate">{b.fullName}</p>
                <p className="text-[11px] text-stone-500 truncate">
                  {b.formattedDate} {b.showAge && b.ageNext ? `(${b.ageNext} ans)` : ''}
                </p>
              </div>
            </div>

            <span
              className={`shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                b.daysUntil === 0
                  ? 'bg-rose-100 text-rose-900 border-rose-300 animate-bounce'
                  : b.daysUntil <= 7
                  ? 'bg-amber-50 text-amber-900 border-amber-300'
                  : 'bg-stone-100 text-stone-700 border-stone-200'
              }`}
            >
              {b.daysUntil === 0
                ? "Aujourd'hui 🎉"
                : b.daysUntil === 1
                ? 'Demain'
                : `Dans ${b.daysUntil} j`}
            </span>
          </div>
        ))}

        {filtered.length === 0 && (
          <p className="text-xs text-stone-500 italic text-center py-3">
            Aucun anniversaire à venir dans les critères sélectionnés.
          </p>
        )}
      </div>
    );
  }

  return (
    <div id="upcoming-birthdays-section" className="space-y-6">
      {/* Header with Search and Month Filter */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 flex items-center justify-center shrink-0 shadow-2xs">
              <PartyPopper className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-stone-900">
                Anniversaires de la Famille & Alliances
              </h2>
              <p className="text-xs text-stone-500">
                Calendrier perpétuel des dates de naissance des membres vivants reconnus.
              </p>
            </div>
          </div>

          {/* Month selector dropdown */}
          <div className="flex items-center gap-2 flex-wrap">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Rechercher un membre..."
                className="text-xs pl-8 pr-3 py-2 rounded-xl bg-stone-50 border border-stone-200 focus:bg-white focus:outline-hidden focus:border-amber-600"
              />
            </div>

            <select
              value={selectedMonth === 'ALL' ? 'ALL' : selectedMonth}
              onChange={(e) =>
                setSelectedMonth(e.target.value === 'ALL' ? 'ALL' : Number(e.target.value))
              }
              className="text-xs font-semibold px-3 py-2 rounded-xl bg-stone-50 border border-stone-200 focus:bg-white focus:outline-hidden focus:border-amber-600"
            >
              <option value="ALL">Tous les mois (Prochains d'abord)</option>
              {monthNames.map((m, idx) => (
                <option key={idx} value={idx}>
                  Mois de {m}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Grid of Birthdays */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((b) => (
          <div
            key={b.memberId}
            className="group relative bg-white p-5 rounded-2xl border border-stone-200 hover:border-rose-400 hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              {/* Top Row: Date Pill & Countdown */}
              <div className="flex items-center justify-between gap-2 mb-3">
                <span className="inline-flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-full bg-rose-50 text-rose-900 border border-rose-200">
                  <Cake className="w-3.5 h-3.5 text-rose-600" />
                  {b.formattedDate}
                </span>

                <span
                  className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                    b.daysUntil === 0
                      ? 'bg-rose-500 text-white border-rose-600 shadow-xs animate-pulse'
                      : b.daysUntil <= 7
                      ? 'bg-amber-100 text-amber-950 border-amber-300'
                      : 'bg-stone-100 text-stone-700 border-stone-200'
                  }`}
                >
                  {b.daysUntil === 0
                    ? "Aujourd'hui 🎉"
                    : b.daysUntil === 1
                    ? 'Demain !'
                    : `Dans ${b.daysUntil} jours`}
                </span>
              </div>

              {/* Member Info */}
              <div className="flex items-start gap-3 mt-2">
                <div className="w-11 h-11 rounded-xl bg-stone-100 border border-stone-200 text-stone-700 flex items-center justify-center font-bold text-sm shrink-0">
                  {b.avatarUrl ? (
                    <img
                      src={b.avatarUrl}
                      alt={b.fullName}
                      className="w-full h-full object-cover rounded-xl"
                    />
                  ) : (
                    <span>{b.firstName.charAt(0)}{b.lastName.charAt(0)}</span>
                  )}
                </div>

                <div className="min-w-0">
                  <h4 className="text-sm font-bold text-stone-900 group-hover:text-rose-950 transition-colors truncate">
                    {b.fullName}
                  </h4>
                  <p className="text-xs text-stone-500 flex items-center gap-1 mt-0.5 truncate">
                    {b.familyType === 'NZALA_DIRECT' ? (
                      <Shield className="w-3 h-3 text-amber-700 shrink-0" />
                    ) : (
                      <Building2 className="w-3 h-3 text-sky-700 shrink-0" />
                    )}
                    <span className="truncate">{b.primaryFamilyName}</span>
                  </p>
                  {b.branchName && (
                    <p className="text-[11px] text-stone-400 truncate mt-0.5">
                      {b.branchName}
                    </p>
                  )}
                </div>
              </div>

              {/* Age Milestone Notice (if authorized) */}
              {b.showAge && b.ageNext && (
                <div className="mt-3 p-2.5 rounded-xl bg-amber-50/60 border border-amber-200/60 flex items-center justify-between text-xs text-amber-950">
                  <span className="font-medium">Prochain âge :</span>
                  <span className="font-extrabold text-sm text-amber-900 font-mono">
                    {b.ageNext} ans
                  </span>
                </div>
              )}
            </div>

            {/* Action footer: Program celebration event & Post celebration */}
            <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between gap-2 flex-wrap">
              <button
                type="button"
                onClick={() => {
                  setActiveBirthdayDraft(b);
                  setBirthdayCelebrationModalOpen(true);
                }}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-900 hover:text-amber-950 bg-amber-50 hover:bg-amber-100 border border-amber-200 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
              >
                <PartyPopper className="w-3.5 h-3.5 text-amber-600" />
                Célébrer sur le fil
              </button>

              {can('CREATE_EVENT') && onCreateBirthdayEvent && (
                <button
                  type="button"
                  onClick={() => onCreateBirthdayEvent(b)}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-rose-800 hover:text-rose-950 hover:bg-rose-50 px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Organiser l'événement
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="p-12 text-center bg-white rounded-3xl border border-stone-200">
          <Cake className="w-12 h-12 text-stone-300 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-stone-700">Aucun anniversaire trouvé</h3>
          <p className="text-xs text-stone-500 mt-1 max-w-md mx-auto">
            Aucun membre vivant ne correspond aux critères de recherche ou au mois sélectionné.
          </p>
        </div>
      )}
    </div>
  );
};
