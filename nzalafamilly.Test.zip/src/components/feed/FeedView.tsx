import React, { useState, useMemo } from 'react';
import { useFamily } from '../../context/FamilyContext';
import {
  FamilyPost,
  PostType,
  PostScope,
} from '../../types';
import { PostCard } from './PostCard';
import { PostFormModal } from './PostFormModal';
import { PostModerationModal } from './PostModerationModal';
import { EventDetailModal } from '../events/EventDetailModal';
import { MemberDetailModal } from '../members/MemberDetailModal';
import { canUserModeratePost } from '../../services/postService';
import {
  Plus,
  Search,
  Filter,
  ShieldCheck,
  Bell,
  Sparkles,
  Pin,
  Calendar,
  HeartHandshake,
  GitBranch,
  Users,
  MessageSquare,
  Flame,
  Clock,
  CheckCircle,
  FileEdit,
  ArrowRight,
  TrendingUp,
  Award,
} from 'lucide-react';
import { StoriesTray } from '../social/StoriesTray';
import { StatusTray } from '../social/StatusTray';
import { PostComposer } from '../social/PostComposer';
import { LiveTray } from '../live/LiveTray';

type FeedTabFilter =
  | 'ALL'
  | 'OFFICIAL'
  | 'CELEBRATIONS'
  | 'MEMOIRE'
  | 'ALLIED_INTER'
  | 'MY_POSTS'
  | 'DRAFTS'
  | 'PENDING_MODERATION';

export const FeedView: React.FC = () => {
  const {
    posts,
    visiblePosts,
    currentUser,
    families,
    branches,
    events,
    members,
    upcomingBirthdays,
    can,
    setSelectedEvent,
    selectedEvent,
    selectedMember,
    setSelectedMember,
    setActiveTab,
  } = useFamily();

  // View state
  const [activeFilterTab, setActiveFilterTab] = useState<FeedTabFilter>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFamilyFilter, setSelectedFamilyFilter] = useState<string>('ALL');
  const [selectedBranchFilter, setSelectedBranchFilter] = useState<string>('ALL');

  // Modal states
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [editingPost, setEditingPost] = useState<FamilyPost | null>(null);
  const [moderatingPost, setModeratingPost] = useState<FamilyPost | null>(null);
  const [viewingEventId, setViewingEventId] = useState<string | null>(null);
  const [viewingMemberId, setViewingMemberId] = useState<string | null>(null);

  const canModerate = canUserModeratePost(currentUser);

  // Count pending moderation for admins/validators
  const pendingModerationCount = useMemo(() => {
    return posts.filter((p) => p.moderationStatus === 'EN_ATTENTE_MODERATION').length;
  }, [posts]);

  // Count drafts for current user
  const userDraftsCount = useMemo(() => {
    return posts.filter((p) => p.authorId === currentUser.id && p.status === 'BROUILLON').length;
  }, [posts, currentUser]);

  // Filtered posts calculation
  const filteredPosts = useMemo(() => {
    return visiblePosts.filter((post) => {
      // 1. Tab Filter
      if (activeFilterTab === 'OFFICIAL') {
        if (!post.isOfficial && post.postType !== 'COMMUNIQUE_OFFICIEL') return false;
      } else if (activeFilterTab === 'CELEBRATIONS') {
        const celebrationTypes: PostType[] = ['MARIAGE', 'NAISSANCE', 'FELICITATION', 'ANNIVERSAIRE'];
        if (!celebrationTypes.includes(post.postType)) return false;
      } else if (activeFilterTab === 'MEMOIRE') {
        const memoireTypes: PostType[] = ['MEMOIRE_FAMILIALE', 'DECES_COMMUNIQUE'];
        if (!memoireTypes.includes(post.postType)) return false;
      } else if (activeFilterTab === 'ALLIED_INTER') {
        if (
          post.scope !== 'FAMILLE_ALLIEE' &&
          post.scope !== 'INTER_FAMILLES' &&
          !post.targetAlliedFamilyId
        ) {
          return false;
        }
      } else if (activeFilterTab === 'MY_POSTS') {
        if (post.authorId !== currentUser.id) return false;
      } else if (activeFilterTab === 'DRAFTS') {
        if (post.authorId !== currentUser.id || post.status !== 'BROUILLON') return false;
      } else if (activeFilterTab === 'PENDING_MODERATION') {
        if (post.moderationStatus !== 'EN_ATTENTE_MODERATION') return false;
      }

      // Hide drafts from main tabs unless specifically in DRAFTS tab
      if (activeFilterTab !== 'DRAFTS' && post.status === 'BROUILLON' && post.authorId !== currentUser.id) {
        return false;
      }

      // 2. Family Filter
      if (selectedFamilyFilter !== 'ALL') {
        if (
          post.targetFamilyId !== selectedFamilyFilter &&
          post.targetAlliedFamilyId !== selectedFamilyFilter &&
          post.authorFamilyId !== selectedFamilyFilter
        ) {
          return false;
        }
      }

      // 3. Branch Filter
      if (selectedBranchFilter !== 'ALL') {
        if (post.targetBranchId !== selectedBranchFilter && post.authorBranchId !== selectedBranchFilter) {
          return false;
        }
      }

      // 4. Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const inTitle = (post.title || '').toLowerCase().includes(q);
        const inContent = (post.content || '').toLowerCase().includes(q);
        const inAuthor = (post.authorName || '').toLowerCase().includes(q);
        const inFamily = (post.authorFamilyName || '').toLowerCase().includes(q) || (post.targetAlliedFamilyName || '').toLowerCase().includes(q);
        const inBranch = (post.targetBranchName || '').toLowerCase().includes(q);
        if (!inTitle && !inContent && !inAuthor && !inFamily && !inBranch) {
          return false;
        }
      }

      return true;
    });
  }, [
    visiblePosts,
    activeFilterTab,
    selectedFamilyFilter,
    selectedBranchFilter,
    searchQuery,
    currentUser,
  ]);

  // Pinned posts
  const pinnedPosts = useMemo(() => {
    return filteredPosts.filter((p) => p.isPinned && p.status === 'PUBLIE');
  }, [filteredPosts]);

  // Regular feed posts
  const regularPosts = useMemo(() => {
    return filteredPosts.filter((p) => !p.isPinned || p.status !== 'PUBLIE');
  }, [filteredPosts]);

  const handleEditPost = (post: FamilyPost) => {
    setEditingPost(post);
    setIsFormModalOpen(true);
  };

  const handleOpenModerate = (post: FamilyPost) => {
    setModeratingPost(post);
  };

  const handleOpenEvent = (eventId: string) => {
    const ev = events.find((e) => e.id === eventId);
    if (ev) {
      setSelectedEvent(ev);
    }
  };

  const handleOpenMember = (memberId: string) => {
    const mem = members.find((m) => m.id === memberId);
    if (mem) {
      setSelectedMember(mem);
    }
  };

  const alliedFamilies = families.filter((f) => f.type === 'ALLIEE');

  return (
    <div id="family-feed-view" className="space-y-6 pb-12">
      {/* Top Banner & Action Header */}
      <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-7 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div className="space-y-1.5 max-w-2xl">
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-wider text-blue-700 font-bold bg-blue-50 px-2.5 py-1 rounded-full border border-blue-200 inline-flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              Vie &amp; Communication Familiale
            </span>
            <span className="text-xs text-slate-500 font-medium">
              • {visiblePosts.length} publications
            </span>
          </div>

          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-slate-900 leading-tight">
            Fil Familial &amp; Communiqués
          </h1>

          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Espace d'échange et d'information de la <strong className="text-slate-800">Grande Famille Nzala</strong> et des <strong className="text-slate-800">Familles Alliées</strong> : communiqués officiels du Conseil, célébrations, hommages, naissances et actualités des branches.
          </p>
        </div>

        {/* Primary CTA */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => {
              setEditingPost(null);
              setIsFormModalOpen(true);
            }}
            className="w-full sm:w-auto px-5 py-2.5 sm:py-3 rounded-2xl bg-blue-600 hover:bg-blue-700 active:scale-98 text-white text-xs sm:text-sm font-bold shadow-xs transition flex items-center justify-center gap-2 cursor-pointer min-h-[44px]"
          >
            <Plus className="w-4 h-4" />
            <span>Nouvelle Publication</span>
          </button>
        </div>
      </div>

      {/* Quick Filter Navigation Tabs */}
      <div className="space-y-3">
        <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1 scrollbar-none">
          <div className="flex items-center gap-1.5 flex-nowrap">
            <button
              onClick={() => setActiveFilterTab('ALL')}
              className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition shrink-0 flex items-center gap-1.5 cursor-pointer ${
                activeFilterTab === 'ALL'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Tout le fil</span>
            </button>

            <button
              onClick={() => setActiveFilterTab('OFFICIAL')}
              className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition shrink-0 flex items-center gap-1.5 cursor-pointer ${
                activeFilterTab === 'OFFICIAL'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Officiels &amp; Conseil</span>
            </button>

            <button
              onClick={() => setActiveFilterTab('CELEBRATIONS')}
              className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition shrink-0 flex items-center gap-1.5 cursor-pointer ${
                activeFilterTab === 'CELEBRATIONS'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
              }`}
            >
              <span>🎉</span>
              <span>Célébrations &amp; Naissances</span>
            </button>

            <button
              onClick={() => setActiveFilterTab('ALLIED_INTER')}
              className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition shrink-0 flex items-center gap-1.5 cursor-pointer ${
                activeFilterTab === 'ALLIED_INTER'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
              }`}
            >
              <HeartHandshake className="w-3.5 h-3.5 text-rose-500" />
              <span>Alliances &amp; Inter-familles</span>
            </button>

            <button
              onClick={() => setActiveFilterTab('MEMOIRE')}
              className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition shrink-0 flex items-center gap-1.5 cursor-pointer ${
                activeFilterTab === 'MEMOIRE'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
              }`}
            >
              <span>🕊️</span>
              <span>Mémoire &amp; Hommages</span>
            </button>

            <button
              onClick={() => setActiveFilterTab('MY_POSTS')}
              className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition shrink-0 flex items-center gap-1.5 cursor-pointer ${
                activeFilterTab === 'MY_POSTS'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
              }`}
            >
              <FileEdit className="w-3.5 h-3.5" />
              <span>Mes publications</span>
            </button>

            {userDraftsCount > 0 && (
              <button
                onClick={() => setActiveFilterTab('DRAFTS')}
                className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition shrink-0 flex items-center gap-1.5 cursor-pointer ${
                  activeFilterTab === 'DRAFTS'
                    ? 'bg-slate-800 text-white'
                    : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
                }`}
              >
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>Brouillons ({userDraftsCount})</span>
              </button>
            )}

            {canModerate && pendingModerationCount > 0 && (
              <button
                onClick={() => setActiveFilterTab('PENDING_MODERATION')}
                className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition shrink-0 flex items-center gap-1.5 cursor-pointer ${
                  activeFilterTab === 'PENDING_MODERATION'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-300'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>À modérer ({pendingModerationCount})</span>
              </button>
            )}
          </div>
        </div>

        {/* Search & Dynamic Selectors */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 sm:gap-3 bg-white p-3.5 rounded-2xl border border-slate-200 shadow-2xs">
          {/* Search bar */}
          <div className="sm:col-span-6 relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher dans les publications, auteurs, sujets..."
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:bg-white transition"
            />
          </div>

          {/* Family selector filter */}
          <div className="sm:col-span-3">
            <select
              value={selectedFamilyFilter}
              onChange={(e) => setSelectedFamilyFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 font-medium text-slate-700"
            >
              <option value="ALL">Toutes les familles</option>
              <option value="fam-nzala">Famille Nzala (Directe)</option>
              {alliedFamilies.map((f) => (
                <option key={f.id} value={f.id}>
                  Famille {f.name} (Alliée)
                </option>
              ))}
            </select>
          </div>

          {/* Branch selector filter */}
          <div className="sm:col-span-3">
            <select
              value={selectedBranchFilter}
              onChange={(e) => setSelectedBranchFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500 font-medium text-slate-700"
            >
              <option value="ALL">Toutes les branches</option>
              {branches.map((b) => (
                <option key={b.id} value={b.id}>
                  Branche {b.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main Layout: 2 Cols on Large Screens (Posts Feed + Right Sidebar Info) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
        {/* Left 2 Columns: Feed Stream */}
        <div className="lg:col-span-2 space-y-6">
          {/* Nzala Live Directs Stream */}
          <LiveTray />

          {/* Stories Tray */}
          <StoriesTray />

          {/* Statuts & Humeurs du Jour */}
          <StatusTray />

          {/* Social Post Composer (Express publication) */}
          <PostComposer />

          {/* Pinned Section if any */}
          {pinnedPosts.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-xs font-bold text-blue-900 uppercase tracking-wider">
                <Pin className="w-3.5 h-3.5 text-blue-600 rotate-45" />
                <span>Publications importantes épinglées</span>
              </div>
              <div className="space-y-4">
                {pinnedPosts.map((post) => (
                  <PostCard
                    key={post.id}
                    post={post}
                    onEdit={handleEditPost}
                    onOpenEvent={handleOpenEvent}
                    onOpenMember={handleOpenMember}
                    onOpenModerate={handleOpenModerate}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Regular Posts Stream */}
          {regularPosts.length > 0 ? (
            <div className="space-y-5">
              {regularPosts.map((post) => (
                <PostCard
                  key={post.id}
                  post={post}
                  onEdit={handleEditPost}
                  onOpenEvent={handleOpenEvent}
                  onOpenMember={handleOpenMember}
                  onOpenModerate={handleOpenModerate}
                />
              ))}
            </div>
          ) : (
            pinnedPosts.length === 0 && (
              <div className="bg-white rounded-3xl border border-slate-200 p-8 sm:p-12 text-center space-y-3">
                <div className="w-14 h-14 mx-auto rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center border border-blue-200">
                  <MessageSquare className="w-7 h-7" />
                </div>
                <h3 className="text-base font-bold text-slate-900">
                  Aucune publication trouvée
                </h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  {searchQuery || selectedFamilyFilter !== 'ALL' || selectedBranchFilter !== 'ALL'
                    ? 'Aucune publication ne correspond à vos critères de recherche ou de filtre.'
                    : 'Soyez le premier à partager une annonce, une bénédiction ou une nouvelle avec la famille !'}
                </p>
                <button
                  onClick={() => {
                    setEditingPost(null);
                    setIsFormModalOpen(true);
                  }}
                  className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 transition inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Rédiger une publication</span>
                </button>
              </div>
            )
          )}
        </div>

        {/* Right Column: Widgets & Family Highlights */}
        <div className="space-y-6">
          {/* Quick Council Broadcast Banner */}
          <div className="bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-950 text-slate-100 p-5 sm:p-6 rounded-3xl shadow-sm space-y-3 border border-blue-900/40">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-blue-500/20 flex items-center justify-center text-blue-400 border border-blue-400/30">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <span className="text-xs uppercase font-bold text-blue-300 tracking-wider">
                Conseil de Famille
              </span>
            </div>

            <h4 className="text-sm font-bold text-white leading-snug">
              Charte de Communication Fraternelle
            </h4>

            <p className="text-xs text-slate-300 leading-relaxed">
              Le fil d'actualité est un espace sacré de concorde, de respect des aînés et de préservation de la mémoire commune des Nzala et des familles alliées.
            </p>

            <div className="pt-2">
              <button
                onClick={() => {
                  setEditingPost(null);
                  setIsFormModalOpen(true);
                }}
                className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Publier un message</span>
              </button>
            </div>
          </div>

          {/* Upcoming Events Highlights */}
          <div className="bg-white rounded-3xl border border-slate-200 p-5 space-y-4 shadow-xs">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-blue-600" />
                <span>Événements à venir</span>
              </h4>
              <button
                onClick={() => setActiveTab('events')}
                className="text-[11px] font-semibold text-blue-600 hover:underline flex items-center gap-0.5 cursor-pointer"
              >
                <span>Calendrier</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <div className="space-y-2.5">
              {events.slice(0, 3).map((ev) => (
                <div
                  key={ev.id}
                  onClick={() => setSelectedEvent(ev)}
                  className="p-3 bg-slate-50 hover:bg-blue-50/60 rounded-2xl border border-slate-200/80 cursor-pointer transition text-xs space-y-1"
                >
                  <div className="flex items-center justify-between text-[11px] text-slate-500 font-medium">
                    <span className="text-blue-700 font-bold">{ev.startDate}</span>
                    <span>{ev.location}</span>
                  </div>
                  <div className="font-bold text-slate-900 line-clamp-1">{ev.title}</div>
                  <div className="text-[11px] text-slate-500 line-clamp-1">{ev.description}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Upcoming Birthdays */}
          {upcomingBirthdays.length > 0 && (
            <div className="bg-white rounded-3xl border border-slate-200 p-5 space-y-3 shadow-xs">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                <span>🎂</span>
                <span>Prochains Anniversaires</span>
              </h4>

              <div className="space-y-2">
                {upcomingBirthdays.slice(0, 4).map((b) => (
                  <div
                    key={b.memberId}
                    className="flex items-center justify-between p-2.5 bg-slate-50 rounded-2xl text-xs"
                  >
                    <div>
                      <div className="font-bold text-slate-900">{b.fullName}</div>
                      <div className="text-[11px] text-slate-500">
                        {b.formattedDate} {b.ageNext ? `(${b.ageNext} ans)` : ''}
                      </div>
                    </div>
                    <span className="px-2 py-0.5 bg-blue-100 text-blue-800 rounded-lg text-[10px] font-bold">
                      {b.daysUntil === 0 ? "Aujourd'hui !" : `Dans ${b.daysUntil}j`}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Post Form Modal (Create / Edit) */}
      <PostFormModal
        isOpen={isFormModalOpen}
        onClose={() => {
          setIsFormModalOpen(false);
          setEditingPost(null);
        }}
        initialPost={editingPost}
      />

      {/* Post Moderation Modal */}
      <PostModerationModal
        isOpen={Boolean(moderatingPost)}
        onClose={() => setModeratingPost(null)}
        post={moderatingPost}
      />

      {/* Linked Event Modal */}
      {selectedEvent && (
        <EventDetailModal
          event={selectedEvent}
          isOpen={Boolean(selectedEvent)}
          onClose={() => setSelectedEvent(null)}
        />
      )}

      {/* Linked Member Modal */}
      {selectedMember && (
        <MemberDetailModal
          member={selectedMember}
          onClose={() => setSelectedMember(null)}
        />
      )}
    </div>
  );
};
