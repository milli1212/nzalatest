import React, { useState } from 'react';
import {
  FamilyPost,
  ReactionType,
  PostComment,
} from '../../types';
import { useFamily } from '../../context/FamilyContext';
import {
  getPostTypeBadgeInfo,
  getPostScopeBadgeInfo,
  getReactionConfig,
  canUserEditPost,
  canUserDeletePost,
  canUserModeratePost,
  canUserComment,
  canUserReact,
} from '../../services/postService';
import {
  Pin,
  ShieldCheck,
  MoreVertical,
  Edit,
  Trash2,
  Archive,
  Ban,
  CheckCircle,
  XCircle,
  MessageSquare,
  Share2,
  Calendar,
  User,
  Users,
  Flag,
  CornerDownRight,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Clock,
  Sparkles,
  HeartHandshake,
  Send,
  AlertCircle,
  Smile,
  Shield,
  EyeOff,
  GitBranch,
  Reply,
  AtSign,
} from 'lucide-react';
import { MediaGrid } from '../social/MediaGrid';
import { LinkPreviewCard } from '../social/LinkPreviewCard';
import { PostShareModal } from '../social/PostShareModal';
import { PostAudioPlayer } from '../social/PostAudioPlayer';
import { VerifiedBadge } from '../common/VerifiedBadge';
import { BlockUserModal } from '../common/BlockUserModal';
import { IssueReportModal } from '../common/IssueReportModal';

interface PostCardProps {
  post: FamilyPost;
  onEdit?: (post: FamilyPost) => void;
  onOpenEvent?: (eventId: string) => void;
  onOpenMember?: (memberId: string) => void;
  onOpenModerate?: (post: FamilyPost) => void;
}

export const PostCard: React.FC<PostCardProps> = ({
  post,
  onEdit,
  onOpenEvent,
  onOpenMember,
  onOpenModerate,
}) => {
  const {
    currentUser,
    members,
    addPostReaction,
    addPostComment,
    deletePostComment,
    reportPostComment,
    moderatePostComment,
    togglePinPost,
    archivePost,
    suspendPost,
    restorePost,
    deletePost,
    showToast,
  } = useFamily();

  const [isCommentsOpen, setIsCommentsOpen] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [replyingToCommentId, setReplyingToCommentId] = useState<string | null>(null);
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showReactionPicker, setShowReactionPicker] = useState(false);
  const [showReactionsDetail, setShowReactionsDetail] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isBlockModalOpen, setIsBlockModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);

  const typeInfo = getPostTypeBadgeInfo(post.postType);
  const scopeInfo = getPostScopeBadgeInfo(post.scope);

  const canEdit = canUserEditPost(post, currentUser);
  const canDelete = canUserDeletePost(post, currentUser);
  const canModerate = canUserModeratePost(currentUser);
  const canComment = canUserComment(post, currentUser);
  const canReact = canUserReact(post, currentUser);

  // User current reaction
  const userReaction = post.reactions.find(
    (r) => r.userId === currentUser.id || (currentUser.memberId && r.memberId === currentUser.memberId)
  );

  // Grouped reactions
  const reactionGroups: Record<ReactionType, number> = {
    LIKE: 0,
    SUPPORT: 0,
    CONGRATS: 0,
    HOMAGE: 0,
    BRAVO: 0,
    JOY: 0,
  };
  post.reactions.forEach((r) => {
    if (reactionGroups[r.reactionType] !== undefined) {
      reactionGroups[r.reactionType]++;
    }
  });

  const handleReactionClick = (type: ReactionType) => {
    if (!canReact) {
      showToast('error', 'Vous devez avoir un profil affilié pour réagir.');
      return;
    }
    addPostReaction(post.id, type);
    setShowReactionPicker(false);
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    setIsSubmittingComment(true);
    const res = addPostComment(post.id, commentText);
    if (res.success) {
      setCommentText('');
      setReplyingToCommentId(null);
      setIsCommentsOpen(true);
    }
    setIsSubmittingComment(false);
  };

  const handleShare = () => {
    setIsShareModalOpen(true);
  };

  const formattedDate = new Date(post.publishedAt || post.createdAt).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  // Rendu avec mise en évidence des mentions @Nom
  const renderHighlightedContent = (text: string) => {
    if (!text) return null;
    const parts = text.split(/(@[a-zA-ZÀ-ÿ0-9_-]+)/g);

    return parts.map((part, idx) => {
      if (part.startsWith('@')) {
        const handle = part.slice(1).replace(/_/g, ' ').toLowerCase();
        const matchedMember = members.find((m) => {
          const full = `${m.firstName} ${m.lastName}`.toLowerCase();
          return full === handle || m.firstName.toLowerCase() === handle || m.lastName.toLowerCase() === handle;
        });

        return (
          <span
            key={idx}
            onClick={() => matchedMember && onOpenMember && onOpenMember(matchedMember.id)}
            className={`font-bold px-1.5 py-0.5 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 transition ${
              matchedMember ? 'cursor-pointer' : ''
            }`}
            title={matchedMember ? `Voir le profil de ${matchedMember.firstName}` : undefined}
          >
            {part}
          </span>
        );
      }
      return <span key={idx}>{part}</span>;
    });
  };

  return (
    <article
      id={`post-${post.id}`}
      className={`bg-white rounded-2xl sm:rounded-3xl border transition-all duration-200 overflow-hidden shadow-xs hover:shadow-md ${
        post.isPinned
          ? 'border-blue-400/80 bg-linear-to-b from-blue-50/40 via-white to-white ring-1 ring-blue-300/60'
          : post.isOfficial
          ? 'border-blue-300/80'
          : 'border-slate-200'
      }`}
    >
      {/* Pinned & Official Top Ribbon */}
      {(post.isPinned || post.isOfficial || post.status === 'BROUILLON' || post.moderationStatus === 'EN_ATTENTE_MODERATION' || post.status === 'SUSPENDU') && (
        <div className="px-4 sm:px-5 py-2 bg-slate-50 border-b border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs font-medium">
          <div className="flex items-center gap-2 flex-wrap">
            {post.isPinned && (
              <span className="inline-flex items-center gap-1 text-blue-800 font-semibold bg-blue-100/90 px-2.5 py-0.5 rounded-full border border-blue-300">
                <Pin className="w-3 h-3 rotate-45 text-blue-700" /> Épinglé en tête du fil
              </span>
            )}
            {post.isOfficial && (
              <span className="inline-flex items-center gap-1 text-blue-950 font-bold bg-blue-100 px-2.5 py-0.5 rounded-full border border-blue-300">
                <ShieldCheck className="w-3.5 h-3.5 text-blue-700" /> Publication Officielle du Conseil
              </span>
            )}
            {post.status === 'BROUILLON' && (
              <span className="inline-flex items-center gap-1 text-slate-700 bg-slate-200 px-2 py-0.5 rounded-full">
                <Clock className="w-3 h-3" /> Brouillon non publié
              </span>
            )}
            {post.moderationStatus === 'EN_ATTENTE_MODERATION' && (
              <span className="inline-flex items-center gap-1 text-amber-900 bg-amber-100 px-2 py-0.5 rounded-full border border-amber-300">
                <AlertCircle className="w-3 h-3" /> En attente de validation du Conseil
              </span>
            )}
            {post.status === 'SUSPENDU' && (
              <span className="inline-flex items-center gap-1 text-rose-800 bg-rose-100 px-2 py-0.5 rounded-full border border-rose-300">
                <Ban className="w-3 h-3" /> Publication suspendue
              </span>
            )}
          </div>

          {post.targetFamilyName && post.scope === 'INTER_FAMILLES' && (
            <span className="text-slate-500 font-normal text-xs">
              Alliance : <strong className="text-slate-800">Nzala &amp; {post.targetAlliedFamilyName || post.targetFamilyName}</strong>
            </span>
          )}
        </div>
      )}

      {/* Main Card Header */}
      <div className="p-4 sm:p-6 pb-3 sm:pb-4">
        <div className="flex items-start justify-between gap-3">
          {/* Author Block */}
          <div className="flex items-center gap-3">
            <div className="relative shrink-0">
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-slate-100 flex items-center justify-center font-bold text-slate-800 border border-slate-200 shadow-xs overflow-hidden">
                {post.authorAvatar ? (
                  <img
                    src={post.authorAvatar}
                    alt={post.authorName}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <User className="w-5 h-5 sm:w-6 sm:h-6 text-slate-500" />
                )}
              </div>
              {post.isOfficial && (
                <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-blue-600 text-white rounded-full flex items-center justify-center border-2 border-white shadow-xs">
                  <ShieldCheck className="w-3 h-3" />
                </div>
              )}
            </div>

            <div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <span
                  onClick={() => post.relatedMemberId && onOpenMember && onOpenMember(post.relatedMemberId)}
                  className={`font-bold text-slate-900 text-sm sm:text-base ${
                    post.relatedMemberId ? 'cursor-pointer hover:underline text-blue-700' : ''
                  }`}
                >
                  {post.authorName}
                </span>

                <VerifiedBadge
                  role={post.authorRole}
                  isVerified={post.isOfficial || post.authorRole === 'SUPER_ADMIN' || post.authorRole === 'ADMIN_FAMILIAL'}
                />

                {post.authorType === 'CONSEIL_FAMILLE' && (
                  <span className="text-[10px] sm:text-[11px] font-semibold px-2 py-0.5 bg-blue-900 text-blue-100 rounded-md">
                    Conseil de Famille
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5 flex-wrap">
                <span>{post.authorFamilyName || 'Famille Nzala'}</span>
                {post.authorBranchName && (
                  <>
                    <span>•</span>
                    <span className="inline-flex items-center gap-1 text-slate-600">
                      <GitBranch className="w-3 h-3 text-slate-400" />
                      {post.authorBranchName}
                    </span>
                  </>
                )}
                <span>•</span>
                <span>{formattedDate}</span>
              </div>
            </div>
          </div>

          {/* Type Badge & Actions Menu */}
          <div className="flex items-center gap-2">
            <div className="hidden sm:flex flex-col items-end gap-1">
              <span
                className={`inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-1 rounded-full border ${typeInfo.bgClass} ${typeInfo.borderClass}`}
              >
                {typeInfo.label}
              </span>
              <span className="text-[10px] text-slate-500 font-medium flex items-center gap-1">
                Portée : <strong className="text-slate-700">{scopeInfo.label}</strong>
              </span>
            </div>

            {/* Menu options dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="w-9 h-9 rounded-xl hover:bg-slate-100 text-slate-500 hover:text-slate-800 flex items-center justify-center transition cursor-pointer"
                title="Options"
              >
                <MoreVertical className="w-4 h-4" />
              </button>

              {isMenuOpen && (
                <>
                  <div
                    className="fixed inset-0 z-30"
                    onClick={() => setIsMenuOpen(false)}
                  />
                  <div className="absolute right-0 top-10 z-40 w-56 bg-white rounded-2xl border border-slate-200 shadow-xl py-1.5 text-xs text-slate-700 animate-in fade-in zoom-in-95">
                    {canEdit && onEdit && (
                      <button
                        onClick={() => {
                          setIsMenuOpen(false);
                          onEdit(post);
                        }}
                        className="w-full px-4 py-2 text-left hover:bg-slate-50 flex items-center gap-2 text-slate-700 cursor-pointer"
                      >
                        <Edit className="w-3.5 h-3.5 text-slate-500" /> Modifier la publication
                      </button>
                    )}

                    {canModerate && (
                      <button
                        onClick={() => {
                          setIsMenuOpen(false);
                          togglePinPost(post.id);
                        }}
                        className="w-full px-4 py-2 text-left hover:bg-slate-50 flex items-center gap-2 text-blue-900 cursor-pointer"
                      >
                        <Pin className="w-3.5 h-3.5 text-blue-700" />
                        {post.isPinned ? 'Désépingler du fil' : 'Épingler en tête de fil'}
                      </button>
                    )}

                    {canModerate && onOpenModerate && post.moderationStatus === 'EN_ATTENTE_MODERATION' && (
                      <button
                        onClick={() => {
                          setIsMenuOpen(false);
                          onOpenModerate(post);
                        }}
                        className="w-full px-4 py-2 text-left hover:bg-slate-50 flex items-center gap-2 text-emerald-800 font-semibold cursor-pointer"
                      >
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600" /> Modérer / Décision du Conseil
                      </button>
                    )}

                    {canModerate && post.status === 'PUBLIE' && (
                      <button
                        onClick={() => {
                          setIsMenuOpen(false);
                          suspendPost(post.id, 'Suspendu par modérateur');
                        }}
                        className="w-full px-4 py-2 text-left hover:bg-slate-50 flex items-center gap-2 text-rose-700 cursor-pointer"
                      >
                        <Ban className="w-3.5 h-3.5 text-rose-600" /> Suspendre la publication
                      </button>
                    )}

                    {canModerate && post.status === 'SUSPENDU' && (
                      <button
                        onClick={() => {
                          setIsMenuOpen(false);
                          restorePost(post.id);
                        }}
                        className="w-full px-4 py-2 text-left hover:bg-slate-50 flex items-center gap-2 text-emerald-700 cursor-pointer"
                      >
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600" /> Restaurer la publication
                      </button>
                    )}

                    {canEdit && post.status === 'PUBLIE' && (
                      <button
                        onClick={() => {
                          setIsMenuOpen(false);
                          archivePost(post.id);
                        }}
                        className="w-full px-4 py-2 text-left hover:bg-slate-50 flex items-center gap-2 text-slate-600 cursor-pointer"
                      >
                        <Archive className="w-3.5 h-3.5 text-slate-500" /> Archiver la publication
                      </button>
                    )}

                    <div className="my-1 border-t border-slate-100" />

                    <button
                      onClick={() => {
                        setIsMenuOpen(false);
                        handleShare();
                      }}
                      className="w-full px-4 py-2 text-left hover:bg-slate-50 flex items-center gap-2 text-slate-600 cursor-pointer"
                    >
                      <Share2 className="w-3.5 h-3.5 text-slate-500" /> Partager le lien
                    </button>

                    <button
                      onClick={() => {
                        setIsMenuOpen(false);
                        setIsReportModalOpen(true);
                      }}
                      className="w-full px-4 py-2 text-left hover:bg-slate-50 flex items-center gap-2 text-slate-600 cursor-pointer"
                    >
                      <Flag className="w-3.5 h-3.5 text-amber-600" /> Signaler cette publication
                    </button>

                    {currentUser.id !== post.authorId && (
                      <button
                        onClick={() => {
                          setIsMenuOpen(false);
                          setIsBlockModalOpen(true);
                        }}
                        className="w-full px-4 py-2 text-left hover:bg-rose-50 flex items-center gap-2 text-rose-600 cursor-pointer"
                      >
                        <Ban className="w-3.5 h-3.5 text-rose-500" /> Bloquer l'auteur
                      </button>
                    )}

                    {canDelete && (
                      <button
                        onClick={() => {
                          setIsMenuOpen(false);
                          if (window.confirm('Êtes-vous sûr de vouloir supprimer définitivement cette publication ?')) {
                            deletePost(post.id);
                          }
                        }}
                        className="w-full px-4 py-2 text-left hover:bg-rose-50 flex items-center gap-2 text-rose-700 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-rose-600" /> Supprimer définitivement
                      </button>
                    )}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Type & Scope Badges */}
        <div className="sm:hidden mt-3 flex items-center justify-between gap-2 flex-wrap">
          <span
            className={`inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full border ${typeInfo.bgClass} ${typeInfo.borderClass}`}
          >
            {typeInfo.label}
          </span>
          <span className="text-[10px] text-slate-500 font-medium">
            Portée : <strong className="text-slate-700">{scopeInfo.label}</strong>
          </span>
        </div>

        {/* Post Title */}
        <h3 className="mt-3 text-base sm:text-lg font-bold text-slate-900 leading-snug">
          {post.title}
        </h3>

        {/* Post Summary / Intro if present */}
        {post.summary && (
          <p className="mt-1 text-xs text-slate-500 italic">
            « {post.summary} »
          </p>
        )}

        {/* Post Body Content */}
        <div className="mt-3 text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line break-words font-sans">
          {renderHighlightedContent(post.content)}
        </div>

        {/* Media Attachments (Multi-photo, Video, or legacy single image) */}
        {post.media && post.media.length > 0 ? (
          <div className="mt-4">
            <MediaGrid media={post.media} />
          </div>
        ) : post.imageUrl ? (
          <div className="mt-4 rounded-2xl overflow-hidden border border-slate-200 bg-slate-100">
            <img
              src={post.imageUrl}
              alt={post.title || ''}
              className="w-full max-h-96 object-cover"
              referrerPolicy="no-referrer"
            />
            {post.mediaCaption && (
              <p className="p-2.5 text-xs text-slate-500 bg-slate-50 border-t border-slate-100">
                {post.mediaCaption}
              </p>
            )}
          </div>
        ) : null}

        {/* Link Preview Card */}
        {post.linkPreview && (
          <div className="mt-4">
            <LinkPreviewCard preview={post.linkPreview} />
          </div>
        )}

        {/* Audio Track / Soundtrack Player */}
        {post.audioTrack && (
          <PostAudioPlayer audioTrack={post.audioTrack} />
        )}

        {/* Shared Post Quote Block */}
        {post.sharedPost && (
          <div className="mt-4 p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center">
                {post.sharedPost.authorName.charAt(0)}
              </div>
              <span className="text-xs font-bold text-slate-900">{post.sharedPost.authorName}</span>
              <span className="text-[11px] text-slate-400">• {post.sharedPost.authorFamilyName || 'Famille Nzala'}</span>
            </div>
            {post.sharedPost.title && (
              <h4 className="text-xs font-bold text-slate-800">{post.sharedPost.title}</h4>
            )}
            <p className="text-xs text-slate-600 line-clamp-3 whitespace-pre-line">
              {post.sharedPost.content}
            </p>
            {post.sharedPost.media && post.sharedPost.media.length > 0 && (
              <div className="max-h-48 overflow-hidden rounded-xl">
                <MediaGrid media={post.sharedPost.media.slice(0, 2)} />
              </div>
            )}
          </div>
        )}

        {/* Linked Event or Member Badge */}
        {(post.relatedEventId || post.relatedMemberId || post.targetBranchName || post.targetAlliedFamilyName) && (
          <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center gap-2 text-xs">
            {post.relatedEventId && (
              <button
                onClick={() => onOpenEvent && onOpenEvent(post.relatedEventId!)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 rounded-xl font-medium transition cursor-pointer min-h-[34px]"
              >
                <Calendar className="w-3.5 h-3.5 text-blue-700" />
                <span>Événement : <strong>{post.relatedEventTitle || 'Voir le programme'}</strong></span>
                <ExternalLink className="w-3 h-3 text-blue-600" />
              </button>
            )}

            {post.targetBranchName && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-indigo-50 text-indigo-900 border border-indigo-200 rounded-xl font-medium">
                <GitBranch className="w-3 h-3 text-indigo-700" />
                Branche : {post.targetBranchName}
              </span>
            )}

            {post.targetAlliedFamilyName && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-rose-50 text-rose-900 border border-rose-200 rounded-xl font-medium">
                <HeartHandshake className="w-3 h-3 text-rose-700" />
                Famille Alliée : {post.targetAlliedFamilyName}
              </span>
            )}
          </div>
        )}
      </div>

      {/* Social Bar (Reactions Breakdown & Counts) */}
      <div className="px-4 sm:px-6 py-2.5 bg-slate-50/80 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
        {/* Reactions icons and count */}
        <div className="flex items-center gap-2">
          {post.reactionsCount > 0 ? (
            <button
              onClick={() => setShowReactionsDetail(!showReactionsDetail)}
              className="flex items-center gap-1.5 hover:text-slate-800 transition cursor-pointer min-h-[32px]"
              title="Voir qui a réagi"
            >
              <div className="flex -space-x-1 text-sm">
                {reactionGroups.LIKE > 0 && <span>❤️</span>}
                {reactionGroups.SUPPORT > 0 && <span>🙏</span>}
                {reactionGroups.CONGRATS > 0 && <span>🎉</span>}
                {reactionGroups.HOMAGE > 0 && <span>🕊️</span>}
                {reactionGroups.BRAVO > 0 && <span>👏</span>}
                {reactionGroups.JOY > 0 && <span>😂</span>}
              </div>
              <span className="font-semibold text-slate-700">{post.reactionsCount}</span>
              <span>réaction{post.reactionsCount > 1 ? 's' : ''}</span>
            </button>
          ) : (
            <span className="text-slate-400">Soyez le premier à réagir</span>
          )}
        </div>

        {/* Comments count */}
        <div>
          <button
            onClick={() => setIsCommentsOpen(!isCommentsOpen)}
            className="hover:text-slate-800 transition font-medium flex items-center gap-1 cursor-pointer min-h-[32px]"
          >
            <span>{post.commentsCount} commentaire{post.commentsCount > 1 ? 's' : ''}</span>
          </button>
        </div>
      </div>

      {/* Reactions Detail Modal / Drawer */}
      {showReactionsDetail && post.reactions.length > 0 && (
        <div className="px-4 sm:px-6 py-3 bg-blue-50/40 border-t border-blue-100 text-xs animate-fadeIn">
          <div className="flex items-center justify-between mb-2">
            <span className="font-semibold text-blue-950">Membres ayant réagi :</span>
            <button
              onClick={() => setShowReactionsDetail(false)}
              className="text-slate-400 hover:text-slate-600 font-bold p-1 cursor-pointer"
            >
              ×
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {post.reactions.map((r) => {
              const cfg = getReactionConfig(r.reactionType);
              return (
                <span
                  key={r.id}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-white rounded-xl border border-slate-200 shadow-xs"
                >
                  <span>{cfg.emoji}</span>
                  <strong className="text-slate-800">{r.userName}</strong>
                  {r.userFamilyName && <span className="text-slate-400 text-[10px]">({r.userFamilyName})</span>}
                </span>
              );
            })}
          </div>
        </div>
      )}

      {/* Interaction Buttons Bar */}
      <div className="px-3 sm:px-5 py-2 border-t border-slate-100 flex items-center justify-between gap-1 relative">
        {/* Reaction Trigger Button with Hover / Click Popover */}
        <div className="relative">
          <button
            onClick={() => {
              if (userReaction) {
                addPostReaction(post.id, userReaction.reactionType);
              } else {
                setShowReactionPicker(!showReactionPicker);
              }
            }}
            onMouseEnter={() => setShowReactionPicker(true)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition cursor-pointer min-h-[38px] ${
              userReaction
                ? getReactionConfig(userReaction.reactionType).activeClass
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            {userReaction ? (
              <>
                <span>{getReactionConfig(userReaction.reactionType).emoji}</span>
                <span>{getReactionConfig(userReaction.reactionType).label}</span>
              </>
            ) : (
              <>
                <Smile className="w-4 h-4 text-slate-500" />
                <span>Réagir</span>
              </>
            )}
          </button>

          {/* Reaction Picker Popover with 6 reactions */}
          {showReactionPicker && (
            <div
              onMouseLeave={() => setShowReactionPicker(false)}
              className="absolute left-0 bottom-full mb-1 z-30 bg-white rounded-2xl border border-slate-200 shadow-xl p-1.5 flex items-center gap-1 animate-fadeIn"
            >
              {(['LIKE', 'SUPPORT', 'CONGRATS', 'HOMAGE', 'BRAVO', 'JOY'] as ReactionType[]).map((type) => {
                const cfg = getReactionConfig(type);
                const isSelected = userReaction?.reactionType === type;
                return (
                  <button
                    key={type}
                    onClick={() => handleReactionClick(type)}
                    className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-medium hover:scale-110 active:scale-95 transition-all cursor-pointer min-h-[36px] ${
                      isSelected ? 'bg-blue-100 font-bold scale-105' : 'hover:bg-slate-100'
                    }`}
                    title={cfg.label}
                  >
                    <span className="text-lg">{cfg.emoji}</span>
                    <span className="hidden md:inline text-slate-700 text-[11px]">{cfg.label}</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Comment Toggle Button */}
        <button
          onClick={() => setIsCommentsOpen(!isCommentsOpen)}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition cursor-pointer min-h-[38px] ${
            isCommentsOpen ? 'bg-slate-100 text-slate-900' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <MessageSquare className="w-4 h-4 text-slate-500" />
          <span>Commenter</span>
          {post.commentsCount > 0 && (
            <span className="ml-0.5 px-1.5 py-0.2 bg-slate-200 text-slate-800 rounded-full text-[10px]">
              {post.commentsCount}
            </span>
          )}
        </button>

        {/* Share Button */}
        <button
          onClick={handleShare}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition cursor-pointer min-h-[38px]"
        >
          <Share2 className="w-4 h-4 text-slate-500" />
          <span className="hidden sm:inline">Partager</span>
        </button>
      </div>

      {/* Comments Section */}
      {isCommentsOpen && (
        <div className="bg-slate-50/90 border-t border-slate-100 p-3.5 sm:p-6 space-y-4 animate-fadeIn">
          {/* New Comment Input */}
          {canComment ? (
            <form onSubmit={handleCommentSubmit} className="space-y-2">
              {replyingToCommentId && (
                <div className="flex items-center justify-between px-3 py-1.5 rounded-xl bg-blue-50 border border-blue-200 text-xs text-blue-800">
                  <span className="flex items-center gap-1">
                    <Reply className="w-3.5 h-3.5" /> Réponse à un commentaire
                  </span>
                  <button
                    type="button"
                    onClick={() => setReplyingToCommentId(null)}
                    className="text-blue-600 hover:text-blue-900 font-bold cursor-pointer"
                  >
                    Annuler
                  </button>
                </div>
              )}
              <div className="flex items-start gap-2.5">
                <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                  {currentUser.name.charAt(0)}
                </div>
                <div className="flex-1 relative">
                  <input
                    type="text"
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    placeholder={
                      replyingToCommentId
                        ? 'Écrire votre réponse...'
                        : 'Écrire un message d’encouragement, félicitation ou bénédiction...'
                    }
                    className="w-full px-4 py-2.5 text-xs sm:text-sm bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 pr-10 shadow-xs min-h-[42px]"
                  />
                  <button
                    type="submit"
                    disabled={isSubmittingComment || !commentText.trim()}
                    className="absolute right-1.5 top-1.5 bottom-1.5 px-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white rounded-lg flex items-center justify-center transition cursor-pointer"
                    title="Envoyer"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </form>
          ) : (
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-2xl text-xs text-blue-900 text-center">
              Pour commenter, votre compte doit être affilié et validé au sein de la famille.
            </div>
          )}

          {/* Comments List with Threaded Replies */}
          {post.comments.length > 0 ? (
            <div className="space-y-3 pt-2">
              {post.comments.map((comment) => {
                const isCommentAuthor = comment.authorId === currentUser.id;
                const canModComment = canModerate;

                if (comment.status === 'SUPPRIME') {
                  return (
                    <div key={comment.id} className="text-xs text-slate-400 italic py-1 pl-4 border-l-2 border-slate-200">
                      Ce commentaire a été supprimé par le modérateur.
                    </div>
                  );
                }

                if (comment.status === 'MASQUE' && !canModComment && !isCommentAuthor) {
                  return (
                    <div key={comment.id} className="text-xs text-slate-400 italic py-1 pl-4 border-l-2 border-slate-200">
                      Commentaire masqué pour examen.
                    </div>
                  );
                }

                const commentDate = new Date(comment.createdAt).toLocaleDateString('fr-FR', {
                  day: 'numeric',
                  month: 'short',
                  hour: '2-digit',
                  minute: '2-digit',
                });

                return (
                  <div
                    key={comment.id}
                    className={`flex items-start gap-2.5 text-xs ${
                      comment.isReported && canModComment ? 'bg-rose-50/70 p-2.5 rounded-2xl border border-rose-200' : ''
                    }`}
                  >
                    <div className="w-7 h-7 rounded-full bg-slate-200 flex items-center justify-center font-bold text-slate-700 text-[11px] shrink-0 mt-0.5">
                      {comment.authorName.charAt(0)}
                    </div>

                    <div className="flex-1 bg-white p-3 rounded-2xl border border-slate-200/80 shadow-xs">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-bold text-slate-900">{comment.authorName}</span>
                          {comment.authorFamilyName && (
                            <span className="text-[10px] text-slate-400">({comment.authorFamilyName})</span>
                          )}
                          {comment.authorRole === 'SUPER_ADMIN' && (
                            <span className="text-[9px] px-1.5 py-0.2 bg-blue-900 text-white rounded-md font-semibold">
                              Admin
                            </span>
                          )}
                          {comment.authorRole === 'VALIDATEUR' && (
                            <span className="text-[9px] px-1.5 py-0.2 bg-sky-800 text-white rounded-md font-semibold">
                              Validateur
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                          <span>{commentDate}</span>

                          {/* Reply trigger button */}
                          {canComment && (
                            <button
                              type="button"
                              onClick={() => {
                                setReplyingToCommentId(comment.id);
                                setCommentText(`@${comment.authorName.replace(/\s+/g, '_')} `);
                              }}
                              className="text-slate-400 hover:text-blue-600 transition p-1 cursor-pointer"
                              title="Répondre à ce commentaire"
                            >
                              <Reply className="w-3 h-3" />
                            </button>
                          )}

                          {/* Comment Options */}
                          {(isCommentAuthor || canModComment) && (
                            <button
                              onClick={() => {
                                if (window.confirm('Voulez-vous supprimer ce commentaire ?')) {
                                  deletePostComment(post.id, comment.id);
                                }
                              }}
                              className="text-slate-400 hover:text-rose-600 transition p-1 cursor-pointer"
                              title="Supprimer mon commentaire"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          )}

                          {!isCommentAuthor && !comment.isReported && (
                            <button
                              onClick={() => {
                                const reason = window.prompt('Motif du signalement aux modérateurs :');
                                if (reason) {
                                  reportPostComment(post.id, comment.id, reason);
                                }
                              }}
                              className="text-slate-400 hover:text-blue-700 transition p-1 cursor-pointer"
                              title="Signaler ce commentaire"
                            >
                              <Flag className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>

                      <p className="mt-1 text-slate-700 whitespace-pre-line leading-relaxed">
                        {renderHighlightedContent(comment.content)}
                      </p>

                      {/* Moderator alert badge if reported */}
                      {comment.isReported && canModComment && (
                        <div className="mt-2 pt-2 border-t border-rose-200 flex items-center justify-between text-[11px] text-rose-800">
                          <span>
                            ⚠️ Signalé ({comment.reportCount}x) : <em>{comment.reportReason}</em>
                          </span>
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => moderatePostComment(post.id, comment.id, 'MASQUE')}
                              className="px-2 py-0.5 bg-rose-100 hover:bg-rose-200 rounded-md font-semibold cursor-pointer"
                            >
                              Masquer
                            </button>
                            <button
                              onClick={() => moderatePostComment(post.id, comment.id, 'SUPPRIME')}
                              className="px-2 py-0.5 bg-rose-800 hover:bg-rose-900 text-white rounded-md font-semibold cursor-pointer"
                            >
                              Supprimer
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-xs text-slate-400 text-center py-2">
              Aucun commentaire pour le moment.
            </p>
          )}
        </div>
      )}

      {/* Share / Repost Modal */}
      <PostShareModal
        post={post}
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
      />

      {/* Block Author Modal */}
      <BlockUserModal
        isOpen={isBlockModalOpen}
        targetUserId={post.authorId}
        targetUserName={post.authorName}
        onClose={() => setIsBlockModalOpen(false)}
      />

      {/* Report Post Modal */}
      <IssueReportModal
        isOpen={isReportModalOpen}
        defaultCategory="PUBLICATION"
        onClose={() => setIsReportModalOpen(false)}
      />
    </article>
  );
};
