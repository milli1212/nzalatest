import React, { useState, useEffect } from 'react';
import {
  FamilyPost,
  PostType,
  PostScope,
  AuthorType,
  FamilyAudioTrack,
} from '../../types';
import { useFamily } from '../../context/FamilyContext';
import {
  canUserCreateOfficialPost,
  getPostTypeBadgeInfo,
  getPostScopeBadgeInfo,
} from '../../services/postService';
import { CURATED_FAMILY_AUDIO_TRACKS } from '../../services/mediaStorage';
import {
  X,
  Send,
  Save,
  Image as ImageIcon,
  Calendar,
  Users,
  ShieldCheck,
  Pin,
  Lock,
  Globe,
  Sparkles,
  HeartHandshake,
  GitBranch,
  AlertCircle,
  Info,
  Check,
  Music2,
  Disc3,
} from 'lucide-react';

interface PostFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPost?: FamilyPost | null;
  defaultRelatedEventId?: string;
  defaultScope?: PostScope;
  defaultType?: PostType;
}

const PRESET_IMAGES = [
  {
    label: 'Conseil & Assemblée',
    url: 'https://images.unsplash.com/photo-1577495508048-b635879837f1?auto=format&fit=crop&w=1200&q=80',
  },
  {
    label: 'Célébration & Mariage',
    url: 'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=80',
  },
  {
    label: 'Naissance & Joie',
    url: 'https://images.unsplash.com/photo-1555252333-9f8e92e65df9?auto=format&fit=crop&w=1200&q=80',
  },
  {
    label: 'Mémoire & Recueillement',
    url: 'https://images.unsplash.com/photo-1518241353330-0f7941c2d9b5?auto=format&fit=crop&w=1200&q=80',
  },
  {
    label: 'Rencontre Familiale',
    url: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&w=1200&q=80',
  },
];

export const PostFormModal: React.FC<PostFormModalProps> = ({
  isOpen,
  onClose,
  initialPost,
  defaultRelatedEventId,
  defaultScope,
  defaultType,
}) => {
  const {
    currentUser,
    families,
    branches,
    members,
    alliances,
    events,
    createPost,
    updatePost,
    showToast,
  } = useFamily();

  const isEditing = Boolean(initialPost);
  const canMakeOfficial = canUserCreateOfficialPost(currentUser);

  // Form states
  const [title, setTitle] = useState('');
  const [summary, setSummary] = useState('');
  const [content, setContent] = useState('');
  const [postType, setPostType] = useState<PostType>('ACTUALITE_FAMILIALE');
  const [scope, setScope] = useState<PostScope>('NZALA_INTERNE');
  const [targetFamilyId, setTargetFamilyId] = useState<string>('');
  const [targetAlliedFamilyId, setTargetAlliedFamilyId] = useState<string>('');
  const [targetBranchId, setTargetBranchId] = useState<string>('');
  const [targetAllianceId, setTargetAllianceId] = useState<string>('');
  const [relatedEventId, setRelatedEventId] = useState<string>('');
  const [relatedMemberId, setRelatedMemberId] = useState<string>('');
  const [imageUrl, setImageUrl] = useState<string>('');
  const [mediaCaption, setMediaCaption] = useState<string>('');
  const [audioTrack, setAudioTrack] = useState<FamilyAudioTrack | undefined>(undefined);
  const [isOfficial, setIsOfficial] = useState(false);
  const [isPinned, setIsPinned] = useState(false);
  const [isImportant, setIsImportant] = useState(false);
  const [authorType, setAuthorType] = useState<AuthorType>('MEMBRE');
  const [errors, setErrors] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Initialize or reset form
  useEffect(() => {
    if (isOpen) {
      if (initialPost) {
        setTitle(initialPost.title || '');
        setSummary(initialPost.summary || '');
        setContent(initialPost.content);
        setPostType(initialPost.postType);
        setScope(initialPost.scope);
        setTargetFamilyId(initialPost.targetFamilyId || '');
        setTargetAlliedFamilyId(initialPost.targetAlliedFamilyId || '');
        setTargetBranchId(initialPost.targetBranchId || '');
        setTargetAllianceId(initialPost.targetAllianceId || '');
        setRelatedEventId(initialPost.relatedEventId || '');
        setRelatedMemberId(initialPost.relatedMemberId || '');
        setImageUrl(initialPost.imageUrl || '');
        setMediaCaption(initialPost.mediaCaption || '');
        setAudioTrack(initialPost.audioTrack);
        setIsOfficial(Boolean(initialPost.isOfficial));
        setIsPinned(Boolean(initialPost.isPinned));
        setIsImportant(Boolean(initialPost.isImportant));
        setAuthorType(initialPost.authorType || 'MEMBRE');
      } else {
        setTitle('');
        setSummary('');
        setContent('');
        setPostType(defaultType || 'ACTUALITE_FAMILIALE');
        setScope(defaultScope || 'NZALA_INTERNE');
        setTargetFamilyId('fam-nzala');
        setTargetAlliedFamilyId('');
        setTargetBranchId('');
        setTargetAllianceId('');
        setRelatedEventId(defaultRelatedEventId || '');
        setRelatedMemberId('');
        setImageUrl('');
        setMediaCaption('');
        setAudioTrack(undefined);
        setIsOfficial(canMakeOfficial && defaultType === 'COMMUNIQUE_OFFICIEL');
        setIsPinned(false);
        setIsImportant(false);
        setAuthorType(
          currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL'
            ? 'CONSEIL_FAMILLE'
            : 'MEMBRE'
        );
      }
      setErrors([]);
    }
  }, [isOpen, initialPost, defaultRelatedEventId, defaultScope, defaultType, canMakeOfficial, currentUser]);

  if (!isOpen) return null;

  const alliedFamilies = families.filter((f) => f.type === 'ALLIEE');
  const alliedMembers = members.filter((m) => m.familyType === 'ALLIE');
  const nzalaMembers = members.filter((m) => m.familyType === 'NZALA_DIRECT');

  const handleSubmit = (asDraft: boolean = false) => {
    const errs: string[] = [];
    if (!title.trim()) errs.push('Le titre de la publication est obligatoire.');
    if (!content.trim()) errs.push('Le texte de la publication ne peut pas être vide.');
    if (title.trim().length < 4) errs.push('Le titre doit contenir au moins 4 caractères.');
    if (content.trim().length < 10) errs.push('Le contenu doit contenir au moins 10 caractères.');

    if (errs.length > 0) {
      setErrors(errs);
      return;
    }

    setIsSubmitting(true);

    const relatedEvent = events.find((e) => e.id === relatedEventId);
    const relatedMem = members.find((m) => m.id === relatedMemberId);
    const targetBranch = branches.find((b) => b.id === targetBranchId);
    const targetAllied = families.find((f) => f.id === targetAlliedFamilyId);

    const postPayload: Partial<FamilyPost> = {
      title: title.trim(),
      summary: summary.trim() || undefined,
      content: content.trim(),
      postType,
      scope,
      status: asDraft ? 'BROUILLON' : 'PUBLIE',
      authorType,
      targetFamilyId: targetFamilyId || 'fam-nzala',
      targetFamilyName: targetFamilyId === 'fam-nzala' ? 'Famille Nzala' : families.find((f) => f.id === targetFamilyId)?.name,
      targetAlliedFamilyId: targetAlliedFamilyId || undefined,
      targetAlliedFamilyName: targetAllied?.name || undefined,
      targetBranchId: targetBranchId || undefined,
      targetBranchName: targetBranch?.name || undefined,
      targetAllianceId: targetAllianceId || undefined,
      relatedEventId: relatedEventId || undefined,
      relatedEventTitle: relatedEvent?.title || undefined,
      relatedMemberId: relatedMemberId || undefined,
      relatedMemberName: relatedMem ? `${relatedMem.firstName} ${relatedMem.lastName}` : undefined,
      imageUrl: imageUrl.trim() || undefined,
      mediaCaption: mediaCaption.trim() || undefined,
      audioTrack,
      isOfficial: isOfficial || postType === 'COMMUNIQUE_OFFICIEL',
      isPinned,
      isImportant,
    };

    if (isEditing && initialPost) {
      const res = updatePost(initialPost.id, postPayload);
      if (res.success) {
        onClose();
      }
    } else {
      const res = createPost(postPayload);
      if (res.success) {
        onClose();
      }
    }

    setIsSubmitting(false);
  };

  const POST_TYPES: { type: PostType; label: string; desc: string; icon: string }[] = [
    { type: 'COMMUNIQUE_OFFICIEL', label: 'Communiqué Officiel', desc: 'Décisions, avis et déclarations du Conseil', icon: '📜' },
    { type: 'ACTUALITE_FAMILIALE', label: 'Actualité Familiale', desc: 'Nouvelles générales de la grande famille', icon: '📰' },
    { type: 'ANNONCE', label: 'Annonce Générale', desc: 'Informations diverses et avis aux membres', icon: '📢' },
    { type: 'EVENEMENT', label: 'Événement & Retrouvailles', desc: 'Rassemblements, cultes, réunions', icon: '🗓️' },
    { type: 'MARIAGE', label: 'Mariage & Dot Coutumière', desc: 'Unions et alliances entre familles', icon: '💍' },
    { type: 'NAISSANCE', label: 'Naissance & Bénédiction', desc: 'Nouveau-nés et présentations', icon: '👶' },
    { type: 'FELICITATION', label: 'Félicitations & Succès', desc: 'Diplômes, promotions, accomplissements', icon: '🎓' },
    { type: 'MEMOIRE_FAMILIALE', label: 'Mémoire & Hommage', desc: 'Commémorations des aïeux et défunts', icon: '🕊️' },
    { type: 'DECES_COMMUNIQUE', label: 'Avis de Décès & Obsèques', desc: 'Nécrologies et programmes de deuil', icon: '🕯️' },
    { type: 'ANNIVERSAIRE', label: 'Anniversaire', desc: 'Célébration des aînés et cadets', icon: '🎂' },
    { type: 'AUTRE', label: 'Autre Publication', desc: 'Partages libres respectant la charte', icon: '✨' },
  ];

  const POST_SCOPES: { scope: PostScope; label: string; desc: string; icon: any }[] = [
    { scope: 'NZALA_INTERNE', label: 'Nzala Interne', desc: 'Uniquement visible par les membres vérifiés de la famille Nzala', icon: Lock },
    { scope: 'BRANCHE', label: 'Branche Spécifique', desc: 'Réservé aux membres d’une branche précise (ex: Makula)', icon: GitBranch },
    { scope: 'FAMILLE_ALLIEE', label: 'Famille Alliée', desc: 'Partagé avec une famille alliée désignée', icon: HeartHandshake },
    { scope: 'INTER_FAMILLES', label: 'Inter-Familles (Alliances)', desc: 'Visible par les Nzala et toutes les familles alliées', icon: Users },
    { scope: 'PUBLIC', label: 'Espace Public', desc: 'Visible par tous les visiteurs et membres', icon: Globe },
    { scope: 'PRIVE', label: 'Confidentiel / Conseil', desc: 'Visible uniquement par les administrateurs et anciens', icon: ShieldCheck },
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl border border-stone-200 shadow-2xl max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="px-6 py-5 bg-stone-900 text-stone-100 flex items-center justify-between border-b border-stone-800">
          <div>
            <span className="text-xs uppercase tracking-wider text-amber-400 font-semibold">
              Fil d'Actualité Familial
            </span>
            <h2 className="text-lg sm:text-xl font-serif font-bold text-white mt-0.5">
              {isEditing ? 'Modifier la publication' : 'Créer une nouvelle publication'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-stone-800 hover:bg-stone-700 text-stone-300 flex items-center justify-center transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body (Scrollable Form) */}
        <div className="p-6 overflow-y-auto space-y-6 text-stone-800 flex-1">
          {errors.length > 0 && (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-800 space-y-1">
              <div className="font-bold flex items-center gap-1.5 text-rose-900">
                <AlertCircle className="w-4 h-4" /> Veuillez corriger les points suivants :
              </div>
              <ul className="list-disc list-inside pl-1 space-y-0.5">
                {errors.map((err, i) => (
                  <li key={i}>{err}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Type of Post Selector */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-2">
              Type de publication *
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
              {POST_TYPES.map((pt) => {
                const isSelected = postType === pt.type;
                return (
                  <button
                    type="button"
                    key={pt.type}
                    onClick={() => {
                      setPostType(pt.type);
                      if (pt.type === 'COMMUNIQUE_OFFICIEL' && canMakeOfficial) {
                        setIsOfficial(true);
                      }
                    }}
                    className={`p-2.5 rounded-2xl border text-left transition flex flex-col justify-between ${
                      isSelected
                        ? 'border-amber-500 bg-amber-50/80 ring-2 ring-amber-400/40'
                        : 'border-stone-200 hover:border-stone-300 bg-white hover:bg-stone-50'
                    }`}
                  >
                    <div className="text-xl mb-1">{pt.icon}</div>
                    <div>
                      <div className="font-bold text-xs text-stone-900 leading-tight">{pt.label}</div>
                      <div className="text-[10px] text-stone-500 mt-0.5 line-clamp-1">{pt.desc}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Title and Short Summary */}
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-1">
                Titre de la publication *
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ex : Grande assemblée annuelle de la lignée Nzala..."
                className="w-full px-4 py-2.5 text-sm bg-white border border-stone-300 rounded-2xl focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-1">
                Chapeau ou résumé succinct <span className="font-normal text-stone-400">(optionnel)</span>
              </label>
              <input
                type="text"
                value={summary}
                onChange={(e) => setSummary(e.target.value)}
                placeholder="Une phrase d’introduction résumant le message..."
                className="w-full px-4 py-2 text-xs bg-white border border-stone-300 rounded-2xl focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-1">
                Contenu détaillé de la publication *
              </label>
              <textarea
                rows={5}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Rédigez ici votre message complet, les informations, bénédictions ou compte-rendu..."
                className="w-full px-4 py-3 text-xs sm:text-sm bg-white border border-stone-300 rounded-2xl focus:ring-2 focus:ring-amber-500 focus:outline-hidden leading-relaxed font-sans"
              />
            </div>
          </div>

          {/* Scope / Visibility */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-2">
              Portée et confidentialité de diffusion *
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
              {POST_SCOPES.map((sc) => {
                const isSelected = scope === sc.scope;
                const Icon = sc.icon;
                return (
                  <button
                    type="button"
                    key={sc.scope}
                    onClick={() => setScope(sc.scope)}
                    className={`p-3 rounded-2xl border text-left transition flex items-start gap-2.5 ${
                      isSelected
                        ? 'border-amber-500 bg-amber-50/70 ring-2 ring-amber-400/30'
                        : 'border-stone-200 hover:border-stone-300 bg-white'
                    }`}
                  >
                    <Icon className={`w-4 h-4 mt-0.5 shrink-0 ${isSelected ? 'text-amber-800' : 'text-stone-500'}`} />
                    <div>
                      <div className="font-bold text-xs text-stone-900">{sc.label}</div>
                      <div className="text-[10px] text-stone-500 mt-0.5 leading-snug">{sc.desc}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Dynamic Scope Target Selectors */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-stone-50 p-4 rounded-2xl border border-stone-200 text-xs">
            {scope === 'BRANCHE' && (
              <div>
                <label className="block font-bold text-stone-700 mb-1">
                  Branche Nzala ciblée *
                </label>
                <select
                  value={targetBranchId}
                  onChange={(e) => setTargetBranchId(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl"
                >
                  <option value="">Sélectionner une branche...</option>
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name} ({b.territory || 'Région'})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {(scope === 'FAMILLE_ALLIEE' || scope === 'INTER_FAMILLES') && (
              <div>
                <label className="block font-bold text-stone-700 mb-1">
                  Famille Alliée concernée
                </label>
                <select
                  value={targetAlliedFamilyId}
                  onChange={(e) => setTargetAlliedFamilyId(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl"
                >
                  <option value="">Toutes les familles alliées ou spécifique...</option>
                  {alliedFamilies.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.name} ({f.territory || f.originLocation || 'Alliée'})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Related Event Picker */}
            <div>
              <label className="block font-bold text-stone-700 mb-1">
                Lier à un événement du calendrier
              </label>
              <select
                value={relatedEventId}
                onChange={(e) => setRelatedEventId(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl"
              >
                <option value="">Aucun événement lié</option>
                {events.map((ev) => (
                  <option key={ev.id} value={ev.id}>
                    {ev.title} ({ev.startDate})
                  </option>
                ))}
              </select>
            </div>

            {/* Related Member Picker */}
            <div>
              <label className="block font-bold text-stone-700 mb-1">
                Mettre à l’honneur un membre de la famille
              </label>
              <select
                value={relatedMemberId}
                onChange={(e) => setRelatedMemberId(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl"
              >
                <option value="">Aucun membre spécifique</option>
                {members.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.firstName} {m.lastName} ({m.familyType === 'NZALA_DIRECT' ? 'Nzala' : m.primaryFamilyName || 'Allié'})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Visual Attachment & Presets */}
          <div className="space-y-3">
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-600">
              Illustration &amp; Photo de la publication
            </label>

            <div className="flex gap-2">
              <input
                type="url"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="Coller l'URL d'une image (https://...)"
                className="flex-1 px-4 py-2 text-xs bg-white border border-stone-300 rounded-2xl focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
              />
              {imageUrl && (
                <button
                  type="button"
                  onClick={() => setImageUrl('')}
                  className="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-600 rounded-2xl text-xs"
                >
                  Effacer
                </button>
              )}
            </div>

            {/* Preset Suggestions */}
            <div>
              <span className="text-[11px] text-stone-500 font-medium">Ou choisir une photo thématique de la bibliothèque :</span>
              <div className="flex flex-wrap gap-2 mt-1.5">
                {PRESET_IMAGES.map((preset, idx) => (
                  <button
                    type="button"
                    key={idx}
                    onClick={() => setImageUrl(preset.url)}
                    className={`px-3 py-1 rounded-xl text-xs border transition flex items-center gap-1.5 ${
                      imageUrl === preset.url
                        ? 'bg-amber-100 text-amber-900 border-amber-300 font-bold'
                        : 'bg-stone-50 text-stone-600 hover:bg-stone-100 border-stone-200'
                    }`}
                  >
                    <ImageIcon className="w-3 h-3 text-stone-400" />
                    <span>{preset.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {imageUrl && (
              <div className="p-3 bg-stone-50 rounded-2xl border border-stone-200 flex items-center gap-4">
                <img
                  src={imageUrl}
                  alt="Aperçu"
                  className="w-16 h-16 rounded-xl object-cover border border-stone-200"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-1">
                  <input
                    type="text"
                    value={mediaCaption}
                    onChange={(e) => setMediaCaption(e.target.value)}
                    placeholder="Légende ou crédit photo (optionnel)..."
                    className="w-full px-3 py-1.5 text-xs bg-white border border-stone-300 rounded-xl"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Audio Soundtrack Attachment (Musique / Bande-son) */}
          <div className="space-y-3 p-4 bg-amber-950/5 border border-amber-900/15 rounded-2xl">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold uppercase tracking-wider text-amber-950 flex items-center gap-2">
                <Music2 className="w-4 h-4 text-amber-600" />
                <span>Bande-son ou Musique associée (Optionnel)</span>
              </label>
              {audioTrack && (
                <button
                  type="button"
                  onClick={() => setAudioTrack(undefined)}
                  className="text-xs text-rose-600 hover:text-rose-800 font-semibold cursor-pointer"
                >
                  Retirer la musique
                </button>
              )}
            </div>

            <p className="text-[11px] text-stone-500">
              Associez une ambiance sonore ou un chant traditionnel pour accompagner votre publication.
            </p>

            {/* Curated list buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {CURATED_FAMILY_AUDIO_TRACKS.map((track) => {
                const isSelected = audioTrack?.id === track.id;
                return (
                  <button
                    key={track.id}
                    type="button"
                    onClick={() => {
                      if (isSelected) {
                        setAudioTrack(undefined);
                      } else {
                        setAudioTrack({
                          id: track.id,
                          title: track.title,
                          artistOrTradition: track.artistOrTradition,
                          category: track.category,
                          url: track.url,
                          durationSec: track.durationSec,
                        });
                      }
                    }}
                    className={`p-2.5 rounded-xl border text-left transition flex items-center gap-2.5 cursor-pointer ${
                      isSelected
                        ? 'bg-amber-100 border-amber-500 text-amber-950 shadow-xs'
                        : 'bg-white border-stone-200 text-stone-700 hover:bg-stone-50'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs shrink-0 ${
                      isSelected ? 'bg-amber-600 text-white' : 'bg-stone-100 text-stone-600'
                    }`}>
                      <Disc3 className={`w-4 h-4 ${isSelected ? 'animate-spin' : ''}`} style={{ animationDuration: '3s' }} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-bold truncate">{track.title}</div>
                      <div className="text-[10px] text-stone-500 truncate">{track.artistOrTradition} • {track.durationSec}s</div>
                    </div>
                    {isSelected && (
                      <Check className="w-4 h-4 text-amber-700 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Admin & Council Badges & Pinning Options */}
          {(currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL' || currentUser.role === 'VALIDATEUR') && (
            <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-2xl space-y-3 text-xs">
              <div className="font-bold text-amber-950 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-800" /> Options Administratives &amp; Gouvernance
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isOfficial}
                    onChange={(e) => setIsOfficial(e.target.checked)}
                    className="w-4 h-4 text-amber-700 rounded border-stone-300 focus:ring-amber-500"
                  />
                  <span className="text-stone-800 font-semibold">
                    Publier sous l'autorité du Conseil de Famille
                  </span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isPinned}
                    onChange={(e) => setIsPinned(e.target.checked)}
                    className="w-4 h-4 text-amber-700 rounded border-stone-300 focus:ring-amber-500"
                  />
                  <span className="text-stone-800 font-semibold">
                    Épingler en haut du fil d'actualité
                  </span>
                </label>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-stone-50 border-t border-stone-200 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900 bg-white border border-stone-300 rounded-xl hover:bg-stone-100 transition"
          >
            Annuler
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => handleSubmit(true)}
              className="px-4 py-2 text-xs font-semibold text-stone-700 hover:text-stone-900 bg-stone-200 hover:bg-stone-300 rounded-xl transition flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" /> Enregistrer brouillon
            </button>

            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => handleSubmit(false)}
              className="px-5 py-2 text-xs font-bold text-white bg-amber-800 hover:bg-amber-900 active:scale-98 rounded-xl shadow-xs transition flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" /> {isEditing ? 'Mettre à jour' : 'Publier sur le fil'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
