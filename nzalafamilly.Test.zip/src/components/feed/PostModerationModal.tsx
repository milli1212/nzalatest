import React, { useState } from 'react';
import { FamilyPost } from '../../types';
import { useFamily } from '../../context/FamilyContext';
import {
  X,
  CheckCircle,
  XCircle,
  ShieldCheck,
  AlertCircle,
  FileText,
  User,
  GitBranch,
  Calendar,
} from 'lucide-react';

interface PostModerationModalProps {
  isOpen: boolean;
  onClose: () => void;
  post: FamilyPost | null;
}

export const PostModerationModal: React.FC<PostModerationModalProps> = ({
  isOpen,
  onClose,
  post,
}) => {
  const { moderatePost, currentUser } = useFamily();
  const [decisionNotes, setDecisionNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen || !post) return null;

  const handleDecision = (decision: 'APPROUVE' | 'REFUSE') => {
    setIsSubmitting(true);
    const res = moderatePost(post.id, decision, decisionNotes.trim() || undefined);
    if (res.success) {
      onClose();
    }
    setIsSubmitting(false);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-950/75 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl border border-stone-200 shadow-2xl max-w-xl w-full overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-5 bg-stone-900 text-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-600/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-serif font-bold text-white">
                Examen &amp; Modération du Conseil
              </h2>
              <p className="text-xs text-stone-400">
                Validation avant diffusion générale sur le fil familial
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 text-stone-400 hover:text-white flex items-center justify-center transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Review */}
        <div className="p-6 space-y-4 text-xs text-stone-700">
          <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
            <div className="flex items-center justify-between text-stone-500 text-[11px]">
              <span className="font-semibold text-stone-800 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-stone-400" />
                {post.authorName} ({post.authorFamilyName || 'Famille Nzala'})
              </span>
              <span>
                {new Date(post.createdAt).toLocaleDateString('fr-FR', {
                  day: 'numeric',
                  month: 'short',
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </span>
            </div>

            <div className="text-sm font-serif font-bold text-stone-900">
              {post.title}
            </div>

            <div className="text-stone-700 whitespace-pre-line leading-relaxed max-h-48 overflow-y-auto pr-1">
              {post.content}
            </div>

            {post.imageUrl && (
              <div className="pt-2">
                <img
                  src={post.imageUrl}
                  alt="Illustration"
                  className="w-full h-32 object-cover rounded-xl border border-stone-200"
                  referrerPolicy="no-referrer"
                />
              </div>
            )}
          </div>

          {/* Decision Notes */}
          <div>
            <label className="block font-bold text-stone-800 mb-1">
              Notes de décision ou motif du Conseil <span className="font-normal text-stone-400">(facultatif)</span>
            </label>
            <textarea
              rows={3}
              value={decisionNotes}
              onChange={(e) => setDecisionNotes(e.target.value)}
              placeholder="Ex : Publication conforme aux valeurs familiales / Message à préciser..."
              className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
            />
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-stone-50 border-t border-stone-200 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-stone-600 bg-white border border-stone-300 rounded-xl hover:bg-stone-100 transition"
          >
            Annuler
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => handleDecision('REFUSE')}
              className="px-4 py-2 text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-300 rounded-xl transition flex items-center gap-1.5"
            >
              <XCircle className="w-4 h-4" /> Rejeter / Refuser
            </button>

            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => handleDecision('APPROUVE')}
              className="px-5 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 active:scale-98 rounded-xl shadow-xs transition flex items-center gap-1.5"
            >
              <CheckCircle className="w-4 h-4" /> Valider &amp; Diffuser
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
