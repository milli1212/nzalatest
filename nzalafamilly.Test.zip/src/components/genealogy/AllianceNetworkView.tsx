import React, { useState, useMemo } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { Member, Alliance, Family } from '../../types';
import {
  AllianceStatusBadge,
  BelongingBadge,
  LivingStatusBadge,
} from '../common/Badges';
import {
  HeartHandshake,
  Heart,
  Users,
  Calendar,
  Sparkles,
  Building2,
  ChevronRight,
  ShieldCheck,
  Link2,
  ExternalLink,
} from 'lucide-react';

interface AllianceNetworkViewProps {
  onSelectMember: (m: Member) => void;
  onOpenAddRelationship: (memberId?: string) => void;
}

export const AllianceNetworkView: React.FC<AllianceNetworkViewProps> = ({
  onSelectMember,
  onOpenAddRelationship,
}) => {
  const { alliances, members, families, relationships } = useFamily();

  const [selectedFamilyId, setSelectedFamilyId] = useState<string>('ALL');

  const alliedFamilies = useMemo(() => {
    return families.filter((f) => f.type === 'ALLIEE');
  }, [families]);

  const filteredAlliances = useMemo(() => {
    if (selectedFamilyId === 'ALL') return alliances;
    return alliances.filter((a) => a.alliedFamilyId === selectedFamilyId);
  }, [alliances, selectedFamilyId]);

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-sky-50 text-sky-700 border border-sky-200 flex items-center justify-center shrink-0">
            <HeartHandshake className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-serif font-bold text-lg text-stone-900">
                Matrice des Alliances Inter-Familles
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-sky-50 text-sky-900 border border-sky-300">
                {alliances.length} Alliances Scellées
              </span>
            </div>
            <p className="text-xs text-stone-500 mt-0.5">
              Visualisation des liens d'union entre la Famille Souche Nzala et les lignées alliées.
            </p>
          </div>
        </div>

        {/* Filter by Allied Family */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-stone-500 font-semibold hidden sm:inline">Famille Alliée :</span>
          <select
            value={selectedFamilyId}
            onChange={(e) => setSelectedFamilyId(e.target.value)}
            className="px-3.5 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs font-bold text-stone-800 focus:outline-none focus:ring-2 focus:ring-sky-500 cursor-pointer"
          >
            <option value="ALL">Toutes les familles alliées ({alliedFamilies.length})</option>
            {alliedFamilies.map((f) => (
              <option key={f.id} value={f.id}>
                {f.name} {f.territory || f.originLocation ? `(${f.territory || f.originLocation})` : ''}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Alliance Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredAlliances.map((alliance) => {
          const nzalaMember = members.find((m) => m.id === alliance.primaryMemberSourceId);
          const allieMember = members.find((m) => m.id === alliance.primaryMemberAlliedId);

          // Find direct children resulting from this alliance
          const nzalaId = alliance.primaryMemberSourceId;
          const allieId = alliance.primaryMemberAlliedId;

          const childrenOfUnion = members.filter((m) => {
            const hasNzalaParent = relationships.some(
              (r) =>
                r.relationshipType === 'PARENT_ENFANT' &&
                r.memberAId === nzalaId &&
                r.memberBId === m.id &&
                r.status === 'VALIDEE'
            );
            const hasAllieParent = relationships.some(
              (r) =>
                r.relationshipType === 'PARENT_ENFANT' &&
                r.memberAId === allieId &&
                r.memberBId === m.id &&
                r.status === 'VALIDEE'
            );
            return hasNzalaParent || hasAllieParent;
          });

          return (
            <div
              key={alliance.id}
              className="p-6 rounded-3xl bg-white border border-stone-200 shadow-xs hover:border-sky-300 hover:shadow-md transition-all duration-200 space-y-5"
            >
              {/* Card Title & Status */}
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <h3 className="font-serif font-bold text-base text-stone-900 flex items-center gap-2">
                    <span>{alliance.title}</span>
                  </h3>
                  <p className="text-xs text-sky-800 font-semibold flex items-center gap-1.5">
                    <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
                    <span>Alliance avec la {alliance.alliedFamilyName}</span>
                  </p>
                </div>

                <AllianceStatusBadge status={alliance.status} />
              </div>

              {/* Spouses Bridge Visualization */}
              <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200/80 grid grid-cols-1 sm:grid-cols-2 gap-3 relative">
                {/* Spouse 1 (Nzala) */}
                <div
                  onClick={() => nzalaMember && onSelectMember(nzalaMember)}
                  className={`p-3 rounded-xl bg-white border border-amber-200/80 space-y-1 ${
                    nzalaMember ? 'cursor-pointer hover:border-amber-400' : ''
                  }`}
                >
                  <span className="text-[10px] uppercase font-bold text-amber-800 block">
                    👑 Côté Famille Nzala
                  </span>
                  <p className="font-bold text-xs sm:text-sm text-stone-900 truncate">
                    {nzalaMember
                      ? `${nzalaMember.firstName} ${nzalaMember.lastName}`
                      : alliance.primaryMemberSourceName || 'Membre Nzala'}
                  </p>
                  {nzalaMember && (
                    <span className="text-[11px] text-stone-500 font-mono block">
                      G{nzalaMember.generationLevel} • {nzalaMember.branchName || 'Branche Principale'}
                    </span>
                  )}
                </div>

                {/* Spouse 2 (Allied) */}
                <div
                  onClick={() => allieMember && onSelectMember(allieMember)}
                  className={`p-3 rounded-xl bg-white border border-sky-200/80 space-y-1 ${
                    allieMember ? 'cursor-pointer hover:border-sky-400' : ''
                  }`}
                >
                  <span className="text-[10px] uppercase font-bold text-sky-800 block">
                    💍 Côté {alliance.alliedFamilyName}
                  </span>
                  <p className="font-bold text-xs sm:text-sm text-stone-900 truncate">
                    {allieMember
                      ? `${allieMember.firstName} ${allieMember.lastName}`
                      : alliance.primaryMemberAlliedName || 'Membre Allié'}
                  </p>
                  {allieMember && (
                    <span className="text-[11px] text-stone-500 font-mono block">
                      G{allieMember.generationLevel} • {allieMember.primaryFamilyName}
                    </span>
                  )}
                </div>
              </div>

              {/* Alliance Narrative Description */}
              <p className="text-xs text-stone-600 leading-relaxed">
                {alliance.description}
              </p>

              {/* Descendants of this union */}
              {childrenOfUnion.length > 0 && (
                <div className="pt-3 border-t border-stone-100 space-y-2">
                  <span className="text-[11px] font-bold text-stone-700 flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Descendance issue de cette union ({childrenOfUnion.length}) :</span>
                  </span>

                  <div className="flex flex-wrap gap-1.5">
                    {childrenOfUnion.map((child) => (
                      <button
                        key={child.id}
                        onClick={() => onSelectMember(child)}
                        className="px-2.5 py-1 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-xs font-semibold text-emerald-900 transition cursor-pointer flex items-center gap-1"
                      >
                        <span>{child.firstName} {child.lastName}</span>
                        <span className="text-[10px] text-emerald-700 font-mono">G{child.generationLevel}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Footer info & date */}
              <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-400">
                {alliance.startDate ? (
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-stone-400" />
                    <span>Union célébrée le : <strong>{alliance.startDate}</strong></span>
                  </span>
                ) : (
                  <span>Union coutumière établie</span>
                )}

                <button
                  onClick={() => onOpenAddRelationship(nzalaMember?.id)}
                  className="text-sky-700 hover:text-sky-900 font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Link2 className="w-3 h-3" />
                  <span>Ajouter relation</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
