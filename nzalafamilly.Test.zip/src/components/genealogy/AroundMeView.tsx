import React, { useState, useMemo } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { Member, Relationship } from '../../types';
import { getAroundMeNetwork } from '../../services/genealogyLayoutEngine';
import {
  BelongingBadge,
  LivingStatusBadge,
  GenerationBadge,
} from '../common/Badges';
import {
  Compass,
  Users,
  Heart,
  GitFork,
  Layers,
  ChevronRight,
  User,
  ShieldCheck,
  Link2,
  Sparkles,
  ArrowRight,
  MapPin,
} from 'lucide-react';

interface AroundMeViewProps {
  initialCenterMemberId?: string;
  onSelectMember: (m: Member) => void;
  onOpenAddRelationship: (memberId?: string) => void;
}

export const AroundMeView: React.FC<AroundMeViewProps> = ({
  initialCenterMemberId,
  onSelectMember,
  onOpenAddRelationship,
}) => {
  const { members, relationships, currentUser, getFilteredMember } = useFamily();

  // Determine initial center member (logged-in user's linked member or first active elder)
  const defaultMemberId = useMemo(() => {
    if (initialCenterMemberId) return initialCenterMemberId;
    if (currentUser.memberId) return currentUser.memberId;
    const directNzala = members.find((m) => m.familyType === 'NZALA_DIRECT');
    return directNzala ? directNzala.id : members[0]?.id || '';
  }, [initialCenterMemberId, currentUser.memberId, members]);

  const [centerMemberId, setCenterMemberId] = useState<string>(defaultMemberId);
  const [depth, setDepth] = useState<number>(1);

  const network = useMemo(() => {
    if (!centerMemberId) return null;
    return getAroundMeNetwork(centerMemberId, depth, members, relationships);
  }, [centerMemberId, depth, members, relationships]);

  const centerMember = members.find((m) => m.id === centerMemberId);

  // Group relative nodes by category
  const categorized = useMemo(() => {
    if (!network) return { parents: [], children: [], spouses: [], siblings: [], extended: [] };

    const parents = network.relativeNodes.filter((r) => r.category === 'PARENTS');
    const children = network.relativeNodes.filter((r) => r.category === 'CHILDREN');
    const spouses = network.relativeNodes.filter((r) => r.category === 'SPOUSE');
    const siblings = network.relativeNodes.filter((r) => r.category === 'SIBLING');
    const extended = network.relativeNodes.filter((r) => r.category === 'EXTENDED');

    return { parents, children, spouses, siblings, extended };
  }, [network]);

  if (!centerMember) {
    return (
      <div className="p-8 text-center bg-white rounded-3xl border border-stone-200 text-stone-500">
        <Compass className="w-8 h-8 text-amber-600 mx-auto mb-2 opacity-50" />
        <p>Veuillez sélectionner un membre pour afficher son réseau familial proche.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Configuration & Selection Header */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-700 border border-amber-200 flex items-center justify-center shrink-0">
              <Compass className="w-6 h-6" />
            </div>
            <div>
              <h2 className="font-serif font-bold text-lg text-stone-900">
                Mode « Autour de Moi » &amp; Proximité Familiale
              </h2>
              <p className="text-xs text-stone-500">
                Explorez le premier cercle relationnel et l'ascendance directe d'un membre.
              </p>
            </div>
          </div>

          {/* Quick Select Center Member */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-stone-500 font-semibold hidden sm:inline">
              Membre central :
            </span>
            <select
              value={centerMemberId}
              onChange={(e) => setCenterMemberId(e.target.value)}
              className="px-3.5 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs font-bold text-stone-800 focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer"
            >
              {members.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.firstName} {m.lastName} (G{m.generationLevel} • {m.primaryFamilyName})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Depth Selector Radios / Tabs */}
        <div className="pt-4 border-t border-stone-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-xs font-bold text-stone-700 block">
              Rayon de profondeur généalogique :
            </span>
            <p className="text-[11px] text-stone-400">
              {depth === 1 && 'Profondeur 1 : Premier cercle direct (Parents, Conjoints, Enfants, Frères/Sœurs)'}
              {depth === 2 && 'Profondeur 2 : Relations proches (+ Grands-parents, Petits-enfants, Alliances)'}
              {depth === 3 && 'Profondeur 3 : Réseau familial élargi (+ Cousins, Oncles/Tantes, Branches)'}
            </p>
          </div>

          <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-stone-100 border border-stone-200 shrink-0">
            {[1, 2, 3].map((d) => (
              <button
                key={`depth-${d}`}
                onClick={() => setDepth(d)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                  depth === d
                    ? 'bg-amber-600 text-stone-950 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                Niveau {d}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Focus Center Card */}
      <div className="relative p-6 rounded-3xl bg-gradient-to-br from-stone-900 via-stone-950 to-amber-950 text-stone-100 border border-amber-500/30 shadow-xl overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start sm:items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border-2 border-amber-400/50 flex items-center justify-center font-serif font-bold text-2xl text-amber-300 shrink-0 shadow-lg shadow-amber-950/40">
              {centerMember.firstName.charAt(0)}
              {centerMember.lastName.charAt(0)}
            </div>

            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2">
                <BelongingBadge
                  belonging={centerMember.belongingType}
                  familyType={centerMember.familyType}
                  size="sm"
                />
                <GenerationBadge level={centerMember.generationLevel} />
                <LivingStatusBadge
                  status={centerMember.livingStatus}
                  deathDate={centerMember.deathDate}
                  burialPlace={centerMember.burialPlace}
                  size="sm"
                />
              </div>

              <h3 className="font-serif font-bold text-xl sm:text-2xl text-stone-100">
                {centerMember.firstName} {centerMember.lastName}
              </h3>

              <div className="flex flex-wrap items-center gap-3 text-xs text-stone-400">
                <span className="text-amber-300 font-semibold">{centerMember.primaryFamilyName}</span>
                {centerMember.branchName && (
                  <>
                    <span>•</span>
                    <span>{centerMember.branchName}</span>
                  </>
                )}
                {centerMember.location && (
                  <>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-stone-500" />
                      {centerMember.location}
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              onClick={() => onSelectMember(centerMember)}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs shadow-md shadow-amber-950/30 transition cursor-pointer"
            >
              <User className="w-4 h-4" />
              <span>Consulter la fiche</span>
            </button>

            <button
              onClick={() => onOpenAddRelationship(centerMember.id)}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-semibold text-xs border border-stone-700 transition cursor-pointer"
            >
              <Link2 className="w-4 h-4 text-amber-400" />
              <span>Lier une relation</span>
            </button>
          </div>
        </div>
      </div>

      {/* Relatives Orbit / Grid categorized */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. Parents / Ascendance */}
        <div className="p-5 rounded-3xl bg-white border border-stone-200 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold text-stone-900">
              <Users className="w-4 h-4 text-amber-600" />
              <span>Parents direct(s)</span>
            </div>
            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
              {categorized.parents.length}
            </span>
          </div>

          {categorized.parents.length > 0 ? (
            <div className="space-y-2">
              {categorized.parents.map(({ member: p, relationToTarget }) => (
                <RelativeCard
                  key={p.id}
                  member={p}
                  relationLabel={relationToTarget}
                  onSelect={onSelectMember}
                  onSetCenter={setCenterMemberId}
                />
              ))}
            </div>
          ) : (
            <p className="text-xs text-stone-400 italic py-3 text-center">
              Aucun parent répertorié.
            </p>
          )}
        </div>

        {/* 2. Spouses / Alliances */}
        <div className="p-5 rounded-3xl bg-white border border-stone-200 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold text-stone-900">
              <Heart className="w-4 h-4 text-rose-500" />
              <span>Conjoint(s) &amp; Union</span>
            </div>
            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-rose-50 text-rose-800 border border-rose-200">
              {categorized.spouses.length}
            </span>
          </div>

          {categorized.spouses.length > 0 ? (
            <div className="space-y-2">
              {categorized.spouses.map(({ member: sp, relationToTarget }) => (
                <RelativeCard
                  key={sp.id}
                  member={sp}
                  relationLabel={relationToTarget}
                  onSelect={onSelectMember}
                  onSetCenter={setCenterMemberId}
                />
              ))}
            </div>
          ) : (
            <p className="text-xs text-stone-400 italic py-3 text-center">
              Aucun conjoint répertorié.
            </p>
          )}
        </div>

        {/* 3. Siblings / Fratrie */}
        <div className="p-5 rounded-3xl bg-white border border-stone-200 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold text-stone-900">
              <Users className="w-4 h-4 text-blue-600" />
              <span>Frères &amp; Sœurs</span>
            </div>
            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-800 border border-blue-200">
              {categorized.siblings.length}
            </span>
          </div>

          {categorized.siblings.length > 0 ? (
            <div className="space-y-2">
              {categorized.siblings.map(({ member: sib, relationToTarget }) => (
                <RelativeCard
                  key={sib.id}
                  member={sib}
                  relationLabel={relationToTarget}
                  onSelect={onSelectMember}
                  onSetCenter={setCenterMemberId}
                />
              ))}
            </div>
          ) : (
            <p className="text-xs text-stone-400 italic py-3 text-center">
              Aucun frère ou sœur répertorié.
            </p>
          )}
        </div>

        {/* 4. Children / Descendance */}
        <div className="p-5 rounded-3xl bg-white border border-stone-200 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold text-stone-900">
              <GitFork className="w-4 h-4 text-emerald-600" />
              <span>Enfants direct(s)</span>
            </div>
            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
              {categorized.children.length}
            </span>
          </div>

          {categorized.children.length > 0 ? (
            <div className="space-y-2">
              {categorized.children.map(({ member: c, relationToTarget }) => (
                <RelativeCard
                  key={c.id}
                  member={c}
                  relationLabel={relationToTarget}
                  onSelect={onSelectMember}
                  onSetCenter={setCenterMemberId}
                />
              ))}
            </div>
          ) : (
            <p className="text-xs text-stone-400 italic py-3 text-center">
              Aucun enfant répertorié.
            </p>
          )}
        </div>
      </div>

      {/* Extended Ring (Depth 2 & 3) */}
      {depth > 1 && categorized.extended.length > 0 && (
        <div className="p-6 rounded-3xl bg-white border border-stone-200 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-amber-600" />
              <h3 className="font-serif font-bold text-base text-stone-900">
                Réseau de Parenté Élargi ({categorized.extended.length} personnes)
              </h3>
            </div>
            <span className="text-xs text-stone-500">
              Grands-parents, petits-enfants et collatéraux
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {categorized.extended.map(({ member: ext, depth: d, relationToTarget }) => (
              <RelativeCard
                key={ext.id}
                member={ext}
                relationLabel={relationToTarget}
                badge={`Niveau ${d}`}
                onSelect={onSelectMember}
                onSetCenter={setCenterMemberId}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

const RelativeCard: React.FC<{
  member: Member;
  relationLabel: string;
  badge?: string;
  onSelect: (m: Member) => void;
  onSetCenter: (id: string) => void;
}> = ({ member, relationLabel, badge, onSelect, onSetCenter }) => {
  const isDirect = member.familyType === 'NZALA_DIRECT';

  return (
    <div
      onClick={() => onSelect(member)}
      className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 hover:border-amber-400 hover:bg-white transition cursor-pointer space-y-2 group"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <div
            className={`w-8 h-8 rounded-lg flex items-center justify-center font-serif font-bold text-xs shrink-0 border ${
              isDirect
                ? 'bg-amber-100 text-amber-900 border-amber-300'
                : 'bg-sky-100 text-sky-900 border-sky-300'
            }`}
          >
            {member.firstName.charAt(0)}
            {member.lastName.charAt(0)}
          </div>
          <div className="min-w-0">
            <h4 className="font-bold text-xs text-stone-900 truncate group-hover:text-amber-700 transition">
              {member.firstName} {member.lastName}
            </h4>
            <span className="text-[10px] font-semibold text-amber-800 block">
              {relationLabel}
            </span>
          </div>
        </div>

        <LivingStatusBadge
          status={member.livingStatus}
          deathDate={member.deathDate}
          burialPlace={member.burialPlace}
          size="sm"
        />
      </div>

      <div className="pt-2 border-t border-stone-200/80 flex items-center justify-between text-[10px]">
        <span className="text-stone-400 font-mono">G{member.generationLevel} • {member.primaryFamilyName}</span>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onSetCenter(member.id);
          }}
          className="text-amber-700 hover:text-amber-900 font-bold flex items-center gap-0.5 cursor-pointer"
          title="Centrer la vue autour de ce membre"
        >
          <span>Centrer</span>
          <ArrowRight className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
};
