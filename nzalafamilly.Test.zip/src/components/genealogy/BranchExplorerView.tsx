import React, { useState, useMemo } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { Member, FamilyBranch, Alliance } from '../../types';
import {
  BelongingBadge,
  LivingStatusBadge,
  GenerationBadge,
} from '../common/Badges';
import {
  Building2,
  Users,
  MapPin,
  GitFork,
  Crown,
  HeartHandshake,
  ChevronRight,
  User,
  Link2,
} from 'lucide-react';

interface BranchExplorerViewProps {
  onSelectMember: (m: Member) => void;
  onOpenAddRelationship: (memberId?: string) => void;
}

export const BranchExplorerView: React.FC<BranchExplorerViewProps> = ({
  onSelectMember,
  onOpenAddRelationship,
}) => {
  const { branches, members, alliances, relationships } = useFamily();

  const [selectedBranchId, setSelectedBranchId] = useState<string>(branches[0]?.id || '');

  const activeBranch = branches.find((b) => b.id === selectedBranchId) || branches[0];

  const branchMembers = useMemo(() => {
    if (!activeBranch) return [];
    return members.filter((m) => m.branchId === activeBranch.id);
  }, [activeBranch, members]);

  // Find branch elder/head
  const branchHead = useMemo(() => {
    if (!activeBranch) return undefined;
    return (
      members.find((m) => m.id === activeBranch.foundingElderId) ||
      branchMembers.sort((a, b) => (Number(a.generationLevel) || 99) - (Number(b.generationLevel) || 99))[0]
    );
  }, [activeBranch, members, branchMembers]);

  // Branch statistics
  const stats = useMemo(() => {
    const directCount = branchMembers.filter((m) => m.familyType === 'NZALA_DIRECT').length;
    const livingCount = branchMembers.filter((m) => m.livingStatus === 'VIVANT').length;
    const genNumbers: number[] = Array.from(new Set(branchMembers.map((m) => m.generationLevel)));
    const gens = genNumbers.sort((a, b) => a - b);

    // Alliances involving branch members
    const branchMemberIds = new Set(branchMembers.map((m) => m.id));
    const linkedAlliances = alliances.filter(
      (a) =>
        (a.primaryMemberSourceId && branchMemberIds.has(a.primaryMemberSourceId)) ||
        (a.primaryMemberAlliedId && branchMemberIds.has(a.primaryMemberAlliedId))
    );

    return { directCount, livingCount, gens, linkedAlliances };
  }, [branchMembers, alliances]);

  if (!activeBranch) {
    return (
      <div className="p-8 text-center bg-white rounded-3xl border border-stone-200 text-stone-500">
        <Building2 className="w-8 h-8 text-amber-600 mx-auto mb-2 opacity-50" />
        <p>Aucune branche familiale configurée.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Branch Navigation Pills */}
      <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-amber-600" />
            <h2 className="font-serif font-bold text-base text-stone-900">
              Branches de la Famille Souche Nzala
            </h2>
          </div>
          <span className="text-xs text-stone-500 font-semibold">
            {branches.length} Branches Officielles
          </span>
        </div>

        <div className="flex flex-wrap gap-2">
          {branches.map((branch) => {
            const count = members.filter((m) => m.branchId === branch.id).length;
            const isSelected = branch.id === activeBranch.id;

            return (
              <button
                key={branch.id}
                onClick={() => setSelectedBranchId(branch.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition cursor-pointer ${
                  isSelected
                    ? 'bg-amber-900 text-amber-50 shadow-md shadow-amber-950/20'
                    : 'bg-stone-50 text-stone-700 hover:bg-stone-100 border border-stone-200'
                }`}
              >
                <span>{branch.name}</span>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] ${
                    isSelected ? 'bg-amber-800 text-amber-200' : 'bg-stone-200 text-stone-600'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Branch Showcase Hero */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-stone-900 via-stone-950 to-amber-950 text-stone-100 border border-amber-500/30 shadow-xl space-y-6">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-400/30 text-amber-300 text-xs font-semibold">
              <Crown className="w-3.5 h-3.5" />
              <span>Branche Souveraine</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-stone-100">
              {activeBranch.name}
            </h1>

            <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
              {activeBranch.description ||
                "Branche historique établie par l'aînesse et la descendance directe des patriarches fondateurs."}
            </p>

            <div className="flex flex-wrap items-center gap-4 text-xs text-stone-400 pt-1">
              {activeBranch.territory && (
                <span className="flex items-center gap-1.5 text-stone-300">
                  <MapPin className="w-4 h-4 text-amber-400" />
                  <span>Territoire / Siège : {activeBranch.territory}</span>
                </span>
              )}

              {branchHead && (
                <span className="flex items-center gap-1.5 text-amber-200">
                  <Crown className="w-4 h-4 text-amber-400" />
                  <span>Aîné / Patriarche : {branchHead.firstName} {branchHead.lastName}</span>
                </span>
              )}
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 shrink-0">
            <div className="p-3.5 rounded-2xl bg-stone-900/80 border border-stone-800 text-center">
              <span className="text-2xl font-serif font-bold text-amber-400 block">
                {branchMembers.length}
              </span>
              <span className="text-[11px] text-stone-400 font-semibold">Membres</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-stone-900/80 border border-stone-800 text-center">
              <span className="text-2xl font-serif font-bold text-emerald-400 block">
                {stats.gens.length}
              </span>
              <span className="text-[11px] text-stone-400 font-semibold">Générations</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-stone-900/80 border border-stone-800 text-center col-span-2 sm:col-span-1">
              <span className="text-2xl font-serif font-bold text-sky-400 block">
                {stats.linkedAlliances.length}
              </span>
              <span className="text-[11px] text-stone-400 font-semibold">Alliances</span>
            </div>
          </div>
        </div>
      </div>

      {/* Branch Members Directory */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-600" />
            <h3 className="font-serif font-bold text-base text-stone-900">
              Membres de la {activeBranch.name} ({branchMembers.length})
            </h3>
          </div>
          <span className="text-xs text-stone-500">
            Classés par génération et rang familial
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {branchMembers.map((member) => (
            <div
              key={member.id}
              onClick={() => onSelectMember(member)}
              className="p-4 rounded-3xl bg-stone-50 border border-stone-200 hover:border-amber-400 hover:bg-white transition cursor-pointer space-y-2.5 group"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-900 border border-amber-300 flex items-center justify-center font-serif font-bold text-sm shrink-0">
                    {member.firstName.charAt(0)}
                    {member.lastName.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-stone-900 group-hover:text-amber-800 transition leading-tight">
                      {member.firstName} {member.lastName}
                    </h4>
                    <p className="text-[11px] text-stone-500 font-mono">G{member.generationLevel}</p>
                  </div>
                </div>

                <LivingStatusBadge
                  status={member.livingStatus}
                  deathDate={member.deathDate}
                  burialPlace={member.burialPlace}
                  size="sm"
                />
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                <BelongingBadge
                  belonging={member.belongingType}
                  familyType={member.familyType}
                  size="sm"
                />
              </div>

              {member.spouseName && (
                <div className="text-[11px] text-sky-900 bg-sky-50/70 p-2 rounded-xl border border-sky-200/50">
                  Union : <strong>{member.spouseName}</strong>
                </div>
              )}

              <div className="pt-2 border-t border-stone-200/70 flex items-center justify-between text-xs text-stone-400">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenAddRelationship(member.id);
                  }}
                  className="flex items-center gap-1 hover:text-amber-700 transition text-[11px] font-semibold cursor-pointer"
                >
                  <Link2 className="w-3.5 h-3.5 text-amber-600" />
                  <span>Lier</span>
                </button>

                <span className="text-amber-700 font-bold text-[11px] flex items-center gap-0.5 group-hover:translate-x-0.5 transition">
                  <span>Fiche</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
