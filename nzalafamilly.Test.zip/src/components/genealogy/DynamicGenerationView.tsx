import React, { useState, useMemo } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { Member, Relationship } from '../../types';
import { computeDynamicGenerations } from '../../services/genealogyLayoutEngine';
import {
  BelongingBadge,
  LivingStatusBadge,
  GenerationBadge,
} from '../common/Badges';
import {
  Layers,
  Users,
  GitFork,
  ChevronDown,
  ChevronUp,
  MapPin,
  Heart,
  Award,
  Link2,
  User,
  ShieldCheck,
} from 'lucide-react';

interface DynamicGenerationViewProps {
  onSelectMember: (m: Member) => void;
  onOpenAddRelationship: (memberId?: string) => void;
  selectedBranchId: string;
  filterFamilyType: 'ALL' | 'NZALA_ONLY' | 'ALLIES_ONLY';
  searchQuery: string;
}

export const DynamicGenerationView: React.FC<DynamicGenerationViewProps> = ({
  onSelectMember,
  onOpenAddRelationship,
  selectedBranchId,
  filterFamilyType,
  searchQuery,
}) => {
  const { members, relationships } = useFamily();

  // Dynamic generation calculation
  const genMap = useMemo(() => {
    return computeDynamicGenerations(members, relationships);
  }, [members, relationships]);

  // Filter members
  const filteredMembers = useMemo(() => {
    return members.filter((m) => {
      if (selectedBranchId !== 'ALL' && m.branchId !== selectedBranchId) return false;
      if (filterFamilyType === 'NZALA_ONLY' && m.familyType !== 'NZALA_DIRECT') return false;
      if (filterFamilyType === 'ALLIES_ONLY' && m.familyType !== 'ALLIE') return false;

      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const fullName = `${m.firstName} ${m.lastName}`.toLowerCase();
        const branch = (m.branchName || '').toLowerCase();
        const family = (m.primaryFamilyName || '').toLowerCase();
        return fullName.includes(query) || branch.includes(query) || family.includes(query);
      }
      return true;
    });
  }, [members, selectedBranchId, filterFamilyType, searchQuery]);

  // Group members dynamically by generation
  const generationGroups = useMemo(() => {
    const groups = new Map<number, Member[]>();

    filteredMembers.forEach((m) => {
      const g = genMap.get(m.id) || m.generationLevel || 1;
      if (!groups.has(g)) {
        groups.set(g, []);
      }
      groups.get(g)!.push(m);
    });

    return Array.from(groups.entries()).sort(([gA], [gB]) => gA - gB);
  }, [filteredMembers, genMap]);

  // Collapsible state for each generation tier
  const [collapsedGens, setCollapsedGens] = useState<Record<number, boolean>>({});

  const toggleGen = (gen: number) => {
    setCollapsedGens((prev) => ({ ...prev, [gen]: !prev[gen] }));
  };

  const getGenerationDescription = (genLevel: number) => {
    switch (genLevel) {
      case 1:
        return 'Patriarcat Fondateur — Racines ancestrales et fondateurs de la grande famille';
      case 2:
        return 'Aînés & Piliers de Branches — Gardiens de la coutume et grandes alliances familiales';
      case 3:
        return 'Descendance & Forces Vives — Génération active portant le développement et le rayonnement';
      case 4:
        return 'Jeunesse & Avenir — Enfants et espoir de la pérennité familiale';
      default:
        return `Génération G${genLevel} — Descendance dynastique`;
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Overview Info Bar */}
      <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-serif font-bold text-lg text-stone-900">
              Lignées par Générations Dynamiques
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-900 border border-amber-300">
              {generationGroups.length} Tiers Générationnels Détectés
            </span>
          </div>
          <p className="text-xs text-stone-500 mt-1">
            Chaque génération est hiérarchisée dynamiquement à partir des liens de filiation validés.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-semibold text-stone-600">
          <span className="px-3 py-1.5 rounded-xl bg-stone-100 border border-stone-200">
            Total affiché : <strong className="text-stone-900">{filteredMembers.length}</strong> membres
          </span>
        </div>
      </div>

      {/* Generation Tiers */}
      <div className="space-y-6">
        {generationGroups.map(([genLevel, genMembers]) => {
          const isCollapsed = !!collapsedGens[genLevel];
          const directCount = genMembers.filter((m) => m.familyType === 'NZALA_DIRECT').length;
          const alliedCount = genMembers.filter((m) => m.familyType === 'ALLIE').length;
          const livingCount = genMembers.filter((m) => m.livingStatus === 'VIVANT').length;

          return (
            <div
              key={`gen-group-${genLevel}`}
              className="bg-white rounded-3xl border border-stone-200 shadow-xs overflow-hidden transition-all duration-200"
            >
              {/* Header */}
              <div
                onClick={() => toggleGen(genLevel)}
                className="p-5 sm:p-6 bg-stone-50 hover:bg-stone-100/80 transition cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-200"
              >
                <div className="flex items-start sm:items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-amber-900 text-amber-100 border border-amber-800 flex items-center justify-center font-serif font-bold text-lg shrink-0 shadow-sm">
                    G{genLevel}
                  </div>

                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-serif font-bold text-base sm:text-lg text-stone-900">
                        Génération {genLevel}
                      </h3>
                      <span className="text-xs text-stone-400 font-mono">•</span>
                      <span className="text-xs font-semibold text-amber-800">
                        {genMembers.length} membre(s)
                      </span>
                    </div>

                    <p className="text-xs text-stone-500 mt-0.5">
                      {getGenerationDescription(genLevel)}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className="px-2.5 py-1 rounded-xl text-[11px] font-semibold bg-amber-100 text-amber-900 border border-amber-300">
                    👑 {directCount} Nzala
                  </span>
                  {alliedCount > 0 && (
                    <span className="px-2.5 py-1 rounded-xl text-[11px] font-semibold bg-sky-100 text-sky-900 border border-sky-300">
                      💍 {alliedCount} Allié(s)
                    </span>
                  )}
                  <span className="px-2.5 py-1 rounded-xl text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                    🌿 {livingCount} Vivant(s)
                  </span>

                  <div className="p-1.5 rounded-xl bg-white border border-stone-200 text-stone-600 ml-2">
                    {isCollapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
                  </div>
                </div>
              </div>

              {/* Members Grid in Generation */}
              {!isCollapsed && (
                <div className="p-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {genMembers.map((member) => (
                    <GenerationMemberCard
                      key={member.id}
                      member={member}
                      onSelect={onSelectMember}
                      onOpenAddRelationship={onOpenAddRelationship}
                    />
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

const GenerationMemberCard: React.FC<{
  member: Member;
  onSelect: (m: Member) => void;
  onOpenAddRelationship: (id?: string) => void;
}> = ({ member, onSelect, onOpenAddRelationship }) => {
  const isDirect = member.familyType === 'NZALA_DIRECT';

  return (
    <div
      onClick={() => onSelect(member)}
      className={`p-4 rounded-3xl bg-white border transition-all duration-200 hover:shadow-md cursor-pointer flex flex-col justify-between space-y-3 group ${
        isDirect ? 'border-stone-200 hover:border-amber-400' : 'border-stone-200 hover:border-sky-400'
      }`}
    >
      <div className="space-y-2.5">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <div
              className={`w-10 h-10 rounded-2xl flex items-center justify-center font-serif font-bold text-sm shrink-0 border ${
                isDirect
                  ? 'bg-amber-50 text-amber-900 border-amber-300'
                  : 'bg-sky-50 text-sky-900 border-sky-300'
              }`}
            >
              {member.firstName.charAt(0)}
              {member.lastName.charAt(0)}
            </div>

            <div className="min-w-0">
              <h4 className="font-bold text-sm text-stone-900 truncate group-hover:text-amber-800 transition">
                {member.firstName} {member.lastName}
              </h4>
              <p className="text-[11px] text-stone-500 truncate">{member.primaryFamilyName}</p>
            </div>
          </div>

          <LivingStatusBadge
            status={member.livingStatus}
            deathDate={member.deathDate}
            burialPlace={member.burialPlace}
            size="sm"
          />
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <BelongingBadge belonging={member.belongingType} familyType={member.familyType} size="sm" />
        </div>

        {member.branchName && (
          <p className="text-[11px] text-stone-600 font-medium truncate">
            {member.branchName}
          </p>
        )}

        {member.spouseName && (
          <div className="text-[11px] text-sky-900 bg-sky-50/80 p-2 rounded-xl border border-sky-200/60 leading-tight">
            Union : <strong>{member.spouseName}</strong> ({member.spouseFamilyName})
          </div>
        )}
      </div>

      <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs text-stone-400">
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onOpenAddRelationship(member.id);
          }}
          className="flex items-center gap-1 hover:text-amber-700 transition text-[11px] font-semibold cursor-pointer"
          title="Lier une relation"
        >
          <Link2 className="w-3.5 h-3.5 text-amber-600" />
          <span>Lier relation</span>
        </button>

        <span className="text-amber-700 font-bold text-[11px] flex items-center gap-0.5">
          <span>Détails</span>
          <span className="group-hover:translate-x-0.5 transition">→</span>
        </span>
      </div>
    </div>
  );
};
