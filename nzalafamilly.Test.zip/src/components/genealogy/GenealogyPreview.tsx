import React, { useState, useMemo } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { Member, Alliance } from '../../types';
import { InteractiveFamilyTree } from './InteractiveFamilyTree';
import { DynamicGenerationView } from './DynamicGenerationView';
import { AroundMeView } from './AroundMeView';
import { BranchExplorerView } from './BranchExplorerView';
import { AllianceNetworkView } from './AllianceNetworkView';
import { GenealogySearchFilterBar } from './GenealogySearchFilterBar';
import { MemberDetailModal } from '../members/MemberDetailModal';
import { AddRelationshipModal } from '../relationships/AddRelationshipModal';
import { auditGenealogicalConsistency } from '../../services/genealogyLayoutEngine';
import {
  GitFork,
  Layers,
  Compass,
  Building2,
  HeartHandshake,
  Link2,
  AlertTriangle,
  CheckCircle2,
  Sparkles,
  Info,
  Users,
} from 'lucide-react';

type GenealogyMode = 'interactive_tree' | 'generations' | 'around_me' | 'branches' | 'alliances';

export const GenealogyPreview: React.FC = () => {
  const {
    members,
    alliances,
    branches,
    selectedMember,
    setSelectedMember,
    relationships,
    currentUser,
  } = useFamily();

  const [activeMode, setActiveMode] = useState<GenealogyMode>('interactive_tree');
  const [selectedGen, setSelectedGen] = useState<number | 'ALL'>('ALL');
  const [selectedBranchId, setSelectedBranchId] = useState<string>('ALL');
  const [filterFamilyType, setFilterFamilyType] = useState<'ALL' | 'NZALA_ONLY' | 'ALLIES_ONLY'>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isAddRelModalOpen, setIsAddRelModalOpen] = useState(false);
  const [prefilledMemberId, setPrefilledMemberId] = useState<string | undefined>(undefined);
  const [aroundMeTargetId, setAroundMeTargetId] = useState<string | undefined>(undefined);
  const [showConsistencyDetails, setShowConsistencyDetails] = useState(false);

  // Check consistency
  const consistencyIssues = useMemo(() => {
    return auditGenealogicalConsistency(members, relationships);
  }, [members, relationships]);

  const handleOpenAddRelationship = (memberId?: string) => {
    setPrefilledMemberId(memberId);
    setIsAddRelModalOpen(true);
  };

  const handleFocusAroundMember = (memberId: string) => {
    setAroundMeTargetId(memberId);
    setActiveMode('around_me');
  };

  const handleSelectSearchResult = (m: Member) => {
    setSelectedMember(m);
  };

  return (
    <div id="genealogy-preview" className="space-y-6 pb-16">
      {/* Top Sovereign Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white p-6 sm:p-7 rounded-3xl border border-stone-200 shadow-xs">
        <div className="space-y-1">
          <div className="flex flex-wrap items-center gap-2.5">
            <h1 className="text-xl sm:text-2xl font-serif font-bold text-stone-900">
              Registre &amp; Arbre Généalogique Nzala
            </h1>
            <span className="px-3 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-900 border border-amber-300">
              Dynamique &amp; Évolutif
            </span>
          </div>
          <p className="text-xs sm:text-sm text-stone-500 max-w-3xl">
            Exploration interactive de la lignée directe Nzala, des filiations multigénérationnelles et des alliances inter-familles scellées.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            onClick={() => handleOpenAddRelationship()}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-amber-600 hover:bg-amber-700 text-stone-950 font-bold text-xs shadow-md shadow-amber-950/20 transition cursor-pointer"
          >
            <Link2 className="w-4 h-4" />
            <span>Formaliser une relation</span>
          </button>
        </div>
      </div>

      {/* Consistency Banner (if any issues/warnings detected) */}
      {consistencyIssues.length > 0 && (
        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-300 flex items-center justify-between gap-3 text-xs text-amber-900">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              <strong>Contrôle de cohérence :</strong> {consistencyIssues.length} remarque(s) ou avertissement(s) généalogique(s) détecté(s).
            </span>
          </div>

          <button
            onClick={() => setShowConsistencyDetails(!showConsistencyDetails)}
            className="text-xs font-bold underline text-amber-950 hover:text-amber-700 cursor-pointer"
          >
            {showConsistencyDetails ? 'Masquer' : 'Voir les détails'}
          </button>
        </div>
      )}

      {showConsistencyDetails && consistencyIssues.length > 0 && (
        <div className="p-4 rounded-2xl bg-white border border-amber-200 shadow-sm space-y-2 text-xs">
          <h4 className="font-bold text-stone-900">Détails des vérifications de cohérence :</h4>
          <ul className="space-y-1 text-stone-600 list-disc list-inside">
            {consistencyIssues.map((issue) => (
              <li key={issue.id} className={issue.severity === 'ERROR' ? 'text-rose-700 font-semibold' : 'text-amber-800'}>
                [{issue.type}] {issue.message}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Mode Navigation Tabs */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-1.5 p-1.5 rounded-2xl bg-stone-100 border border-stone-200 overflow-x-auto max-w-full">
          <button
            onClick={() => setActiveMode('interactive_tree')}
            className={`flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
              activeMode === 'interactive_tree'
                ? 'bg-white text-stone-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <GitFork className="w-4 h-4 text-amber-600" />
            <span>Arbre Visuel Interactif</span>
          </button>

          <button
            onClick={() => setActiveMode('generations')}
            className={`flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
              activeMode === 'generations'
                ? 'bg-white text-stone-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Layers className="w-4 h-4 text-amber-700" />
            <span>Lignées par Générations</span>
          </button>

          <button
            onClick={() => setActiveMode('around_me')}
            className={`flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
              activeMode === 'around_me'
                ? 'bg-white text-stone-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Compass className="w-4 h-4 text-amber-600" />
            <span>Autour de Moi</span>
          </button>

          <button
            onClick={() => setActiveMode('branches')}
            className={`flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
              activeMode === 'branches'
                ? 'bg-white text-stone-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Building2 className="w-4 h-4 text-stone-700" />
            <span>Explorer une Branche</span>
          </button>

          <button
            onClick={() => setActiveMode('alliances')}
            className={`flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
              activeMode === 'alliances'
                ? 'bg-white text-stone-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <HeartHandshake className="w-4 h-4 text-sky-600" />
            <span>Alliances ({alliances.length})</span>
          </button>
        </div>
      </div>

      {/* Global Search & Dynamic Filter Bar (Available for Interactive Tree & Generations views) */}
      {(activeMode === 'interactive_tree' || activeMode === 'generations') && (
        <GenealogySearchFilterBar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          selectedGeneration={selectedGen}
          onGenerationChange={setSelectedGen}
          selectedBranchId={selectedBranchId}
          onBranchChange={setSelectedBranchId}
          filterFamilyType={filterFamilyType}
          onFamilyTypeChange={setFilterFamilyType}
          onSelectSearchResult={handleSelectSearchResult}
        />
      )}

      {/* ACTIVE MODE VIEWPORT */}
      {activeMode === 'interactive_tree' && (
        <div className="space-y-4">
          <InteractiveFamilyTree
            onSelectMember={setSelectedMember}
            onFocusAroundMember={handleFocusAroundMember}
            onOpenAddRelationship={handleOpenAddRelationship}
            selectedMemberId={selectedMember?.id}
            filterGeneration={selectedGen}
            filterBranchId={selectedBranchId}
            filterFamilyType={filterFamilyType}
            searchQuery={searchQuery}
          />
        </div>
      )}

      {activeMode === 'generations' && (
        <DynamicGenerationView
          onSelectMember={setSelectedMember}
          onOpenAddRelationship={handleOpenAddRelationship}
          selectedBranchId={selectedBranchId}
          filterFamilyType={filterFamilyType}
          searchQuery={searchQuery}
        />
      )}

      {activeMode === 'around_me' && (
        <AroundMeView
          initialCenterMemberId={aroundMeTargetId || selectedMember?.id}
          onSelectMember={setSelectedMember}
          onOpenAddRelationship={handleOpenAddRelationship}
        />
      )}

      {activeMode === 'branches' && (
        <BranchExplorerView
          onSelectMember={setSelectedMember}
          onOpenAddRelationship={handleOpenAddRelationship}
        />
      )}

      {activeMode === 'alliances' && (
        <AllianceNetworkView
          onSelectMember={setSelectedMember}
          onOpenAddRelationship={handleOpenAddRelationship}
        />
      )}

      {/* Member Details Modal */}
      {selectedMember && (
        <MemberDetailModal
          member={selectedMember}
          onClose={() => setSelectedMember(null)}
        />
      )}

      {/* Add / Propose Relationship Modal */}
      {isAddRelModalOpen && (
        <AddRelationshipModal
          isOpen={isAddRelModalOpen}
          initialMemberAId={prefilledMemberId}
          onClose={() => {
            setIsAddRelModalOpen(false);
            setPrefilledMemberId(undefined);
          }}
        />
      )}
    </div>
  );
};
