import React, { useState, useMemo } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { Member } from '../../types';
import { computeDynamicGenerations } from '../../services/genealogyLayoutEngine';
import {
  Search,
  Filter,
  X,
  Sparkles,
  GitFork,
  Layers,
  Crown,
  HeartHandshake,
  UserCheck,
  Compass,
} from 'lucide-react';

interface GenealogySearchFilterBarProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  selectedGeneration: number | 'ALL';
  onGenerationChange: (gen: number | 'ALL') => void;
  selectedBranchId: string;
  onBranchChange: (bId: string) => void;
  filterFamilyType: 'ALL' | 'NZALA_ONLY' | 'ALLIES_ONLY';
  onFamilyTypeChange: (type: 'ALL' | 'NZALA_ONLY' | 'ALLIES_ONLY') => void;
  onSelectSearchResult: (member: Member) => void;
}

export const GenealogySearchFilterBar: React.FC<GenealogySearchFilterBarProps> = ({
  searchQuery,
  onSearchChange,
  selectedGeneration,
  onGenerationChange,
  selectedBranchId,
  onBranchChange,
  filterFamilyType,
  onFamilyTypeChange,
  onSelectSearchResult,
}) => {
  const { members, branches, relationships } = useFamily();
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  // Compute dynamic distinct generations
  const dynamicGenerations = useMemo(() => {
    const genMap = computeDynamicGenerations(members, relationships);
    const gens = Array.from(new Set(Array.from(genMap.values()))).sort((a, b) => a - b);
    return gens.length > 0 ? gens : [1, 2, 3, 4];
  }, [members, relationships]);

  // Search Autocomplete results
  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase();
    return members
      .filter((m) => {
        const name = `${m.firstName} ${m.lastName}`.toLowerCase();
        const branch = (m.branchName || '').toLowerCase();
        const family = (m.primaryFamilyName || '').toLowerCase();
        return name.includes(q) || branch.includes(q) || family.includes(q);
      })
      .slice(0, 6);
  }, [searchQuery, members]);

  return (
    <div className="bg-white p-4 sm:p-5 rounded-3xl border border-stone-200 shadow-xs space-y-4">
      {/* Top Search Field & Direct Quick Filters */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search Input with Auto-Suggest Dropdown */}
        <div className="relative flex-1">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              onFocus={() => setIsSearchFocused(true)}
              onBlur={() => setTimeout(() => setIsSearchFocused(false), 250)}
              placeholder="Rechercher par prénom, nom, branche, famille..."
              className="w-full pl-10 pr-10 py-2.5 rounded-2xl bg-stone-50 border border-stone-200 text-xs sm:text-sm font-medium text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white transition"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-3 p-1 text-stone-400 hover:text-stone-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Autocomplete Dropdown */}
          {isSearchFocused && searchResults.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-2 p-2 bg-white rounded-2xl border border-stone-200 shadow-xl z-50 space-y-1">
              <span className="text-[10px] uppercase font-bold text-stone-400 px-3 py-1 block">
                Résultats suggérés ({searchResults.length})
              </span>
              {searchResults.map((m) => (
                <button
                  key={m.id}
                  onMouseDown={() => {
                    onSelectSearchResult(m);
                    onSearchChange(`${m.firstName} ${m.lastName}`);
                  }}
                  className="w-full px-3 py-2 rounded-xl text-left hover:bg-stone-50 flex items-center justify-between transition cursor-pointer text-xs"
                >
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-[10px] ${
                        m.familyType === 'NZALA_DIRECT'
                          ? 'bg-amber-100 text-amber-900'
                          : 'bg-sky-100 text-sky-900'
                      }`}
                    >
                      {m.firstName.charAt(0)}
                    </div>
                    <div>
                      <strong className="text-stone-900">
                        {m.firstName} {m.lastName}
                      </strong>
                      <span className="text-stone-400 text-[11px] ml-1.5">
                        ({m.primaryFamilyName})
                      </span>
                    </div>
                  </div>

                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-stone-100 text-stone-600">
                    G{m.generationLevel}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Lineage Segment Switcher */}
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-stone-100 border border-stone-200 shrink-0">
          <button
            onClick={() => onFamilyTypeChange('ALL')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              filterFamilyType === 'ALL'
                ? 'bg-white text-stone-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Tous ({members.length})
          </button>

          <button
            onClick={() => onFamilyTypeChange('NZALA_ONLY')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              filterFamilyType === 'NZALA_ONLY'
                ? 'bg-amber-700 text-stone-100 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Crown className="w-3.5 h-3.5 text-amber-400" />
            <span>Lignée Nzala</span>
          </button>

          <button
            onClick={() => onFamilyTypeChange('ALLIES_ONLY')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              filterFamilyType === 'ALLIES_ONLY'
                ? 'bg-sky-700 text-stone-100 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <HeartHandshake className="w-3.5 h-3.5 text-sky-300" />
            <span>Alliances</span>
          </button>
        </div>
      </div>

      {/* Generation Pills & Branch Selector */}
      <div className="pt-3 border-t border-stone-100 flex flex-wrap items-center justify-between gap-3">
        {/* Dynamic Generation Pills */}
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-xs text-stone-400 font-semibold mr-1 hidden sm:inline">
            Générations :
          </span>

          <button
            onClick={() => onGenerationChange('ALL')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              selectedGeneration === 'ALL'
                ? 'bg-stone-900 text-stone-100 shadow-xs'
                : 'bg-stone-50 text-stone-700 hover:bg-stone-100 border border-stone-200'
            }`}
          >
            Toutes
          </button>

          {dynamicGenerations.map((gen) => (
            <button
              key={`gen-pill-${gen}`}
              onClick={() => onGenerationChange(gen)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                selectedGeneration === gen
                  ? 'bg-amber-800 text-amber-50 shadow-xs'
                  : 'bg-stone-50 text-stone-700 hover:bg-stone-100 border border-stone-200'
              }`}
            >
              G{gen}
            </button>
          ))}
        </div>

        {/* Branch Filter */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-stone-500 font-semibold hidden sm:inline">Branche :</span>
          <select
            value={selectedBranchId}
            onChange={(e) => onBranchChange(e.target.value)}
            className="px-3.5 py-1.5 rounded-xl bg-stone-50 border border-stone-200 text-xs font-bold text-stone-800 focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer"
          >
            <option value="ALL">Toutes les branches ({branches.length})</option>
            {branches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
};
