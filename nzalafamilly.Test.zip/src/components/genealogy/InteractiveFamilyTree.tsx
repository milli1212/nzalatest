import React, { useState, useRef, useEffect, useMemo } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { Member, Relationship } from '../../types';
import {
  calculateTreeLayout,
  TreeNode,
  TreeLink,
} from '../../services/genealogyLayoutEngine';
import {
  BelongingBadge,
  LivingStatusBadge,
  GenerationBadge,
} from '../common/Badges';
import {
  ZoomIn,
  ZoomOut,
  Maximize2,
  Minimize2,
  RotateCcw,
  User,
  Heart,
  GitFork,
  Compass,
  Link2,
  Sparkles,
  Info,
  ChevronRight,
  ShieldCheck,
  Eye,
} from 'lucide-react';

interface InteractiveFamilyTreeProps {
  onSelectMember: (member: Member) => void;
  onFocusAroundMember: (memberId: string) => void;
  onOpenAddRelationship: (memberId?: string) => void;
  selectedMemberId?: string | null;
  filterGeneration: number | 'ALL';
  filterBranchId: string;
  filterFamilyType: 'ALL' | 'NZALA_ONLY' | 'ALLIES_ONLY';
  searchQuery: string;
}

export const InteractiveFamilyTree: React.FC<InteractiveFamilyTreeProps> = ({
  onSelectMember,
  onFocusAroundMember,
  onOpenAddRelationship,
  selectedMemberId,
  filterGeneration,
  filterBranchId,
  filterFamilyType,
  searchQuery,
}) => {
  const { members, relationships, currentUser } = useFamily();

  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 40, y: 30 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [hoveredNodeId, setHoveredNodeId] = useState<string | null>(null);

  // Compute Layout
  const layout = useMemo(() => {
    return calculateTreeLayout(members, relationships, {
      filterGeneration,
      filterBranchId,
      filterFamilyType,
      searchQuery,
      nodeWidth: 270,
      nodeHeight: 140,
      horizontalGap: 50,
      verticalGap: 140,
    });
  }, [members, relationships, filterGeneration, filterBranchId, filterFamilyType, searchQuery]);

  // Center on search selection or selectedMemberId
  useEffect(() => {
    if (selectedMemberId && containerRef.current) {
      const targetNode = layout.nodes.find((n) => n.id === selectedMemberId);
      if (targetNode) {
        const containerWidth = containerRef.current.clientWidth || 900;
        const containerHeight = containerRef.current.clientHeight || 600;

        const targetX = containerWidth / 2 - (targetNode.x + targetNode.width / 2) * zoom;
        const targetY = containerHeight / 2 - (targetNode.y + targetNode.height / 2) * zoom;

        setPan({ x: targetX, y: targetY });
      }
    }
  }, [selectedMemberId, layout.nodes, zoom]);

  // Mouse pan handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return; // only left click
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Wheel zoom handler
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.08 : 0.92;
    const newZoom = Math.min(Math.max(zoom * zoomFactor, 0.4), 2.2);
    setZoom(newZoom);
  };

  // Touch gesture handlers for mobile
  const touchState = useRef<{ lastX: number; lastY: number; lastDist: number }>({
    lastX: 0,
    lastY: 0,
    lastDist: 0,
  });

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      touchState.current.lastX = e.touches[0].clientX;
      touchState.current.lastY = e.touches[0].clientY;
      setIsDragging(true);
    } else if (e.touches.length === 2) {
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      touchState.current.lastDist = dist;
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 1 && isDragging) {
      const deltaX = e.touches[0].clientX - touchState.current.lastX;
      const deltaY = e.touches[0].clientY - touchState.current.lastY;
      touchState.current.lastX = e.touches[0].clientX;
      touchState.current.lastY = e.touches[0].clientY;
      setPan((prev) => ({ x: prev.x + deltaX, y: prev.y + deltaY }));
    } else if (e.touches.length === 2) {
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      if (touchState.current.lastDist > 0) {
        const factor = dist / touchState.current.lastDist;
        setZoom((prev) => Math.min(Math.max(prev * factor, 0.4), 2.2));
      }
      touchState.current.lastDist = dist;
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
    touchState.current.lastDist = 0;
  };

  const resetView = () => {
    setZoom(0.85);
    setPan({ x: 50, y: 40 });
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!isFullscreen) {
      if (containerRef.current.requestFullscreen) {
        containerRef.current.requestFullscreen();
      }
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
      setIsFullscreen(false);
    }
  };

  return (
    <div
      ref={containerRef}
      id="interactive-family-tree-viewport"
      className={`relative w-full overflow-hidden select-none bg-stone-900 border border-stone-800 rounded-3xl shadow-xl transition-all duration-300 ${
        isFullscreen ? 'fixed inset-0 z-50 rounded-none h-screen' : 'h-[640px] sm:h-[720px]'
      }`}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onWheel={handleWheel}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      style={{ cursor: isDragging ? 'grabbing' : 'grab' }}
    >
      {/* Visual Canvas Background Texture Grid */}
      <div
        className="absolute inset-0 pointer-events-none opacity-20"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, #f59e0b 1px, transparent 0)`,
          backgroundSize: `${36 * zoom}px ${36 * zoom}px`,
          backgroundPosition: `${pan.x}px ${pan.y}px`,
        }}
      />

      {/* Floating Canvas Controls (Zoom, Pan, Reset, Fullscreen) */}
      <div className="absolute top-4 right-4 z-20 flex flex-col gap-2 bg-stone-950/80 backdrop-blur-md p-2 rounded-2xl border border-stone-800 shadow-2xl">
        <button
          onClick={() => setZoom((prev) => Math.min(prev + 0.15, 2.2))}
          className="p-2.5 rounded-xl bg-stone-800/80 hover:bg-amber-600 hover:text-stone-950 text-stone-300 transition cursor-pointer"
          title="Zoom avant (+)"
          aria-label="Zoom avant"
        >
          <ZoomIn className="w-4 h-4" />
        </button>

        <button
          onClick={() => setZoom((prev) => Math.max(prev - 0.15, 0.4))}
          className="p-2.5 rounded-xl bg-stone-800/80 hover:bg-amber-600 hover:text-stone-950 text-stone-300 transition cursor-pointer"
          title="Zoom arrière (-)"
          aria-label="Zoom arrière"
        >
          <ZoomOut className="w-4 h-4" />
        </button>

        <button
          onClick={resetView}
          className="p-2.5 rounded-xl bg-stone-800/80 hover:bg-amber-600 hover:text-stone-950 text-stone-300 transition cursor-pointer"
          title="Réinitialiser la vue"
          aria-label="Réinitialiser la vue"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        <button
          onClick={toggleFullscreen}
          className="p-2.5 rounded-xl bg-stone-800/80 hover:bg-amber-600 hover:text-stone-950 text-stone-300 transition cursor-pointer"
          title={isFullscreen ? 'Quitter le plein écran' : 'Plein écran'}
          aria-label="Plein écran"
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>
      </div>

      {/* Floating Status & Quick Legend Overlay */}
      <div className="absolute bottom-4 left-4 z-20 hidden sm:flex items-center gap-3 bg-stone-950/85 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-stone-800 text-xs shadow-2xl">
        <div className="flex items-center gap-2 text-stone-300">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shadow-xs shadow-amber-500"></span>
          <span className="font-semibold text-amber-200">Lignée Nzala</span>
        </div>

        <span className="text-stone-700">|</span>

        <div className="flex items-center gap-2 text-stone-300">
          <span className="w-2.5 h-2.5 rounded-full bg-sky-400 shadow-xs shadow-sky-400"></span>
          <span className="font-semibold text-sky-200">Famille Alliée</span>
        </div>

        <span className="text-stone-700">|</span>

        <div className="text-stone-400 text-[11px]">
          Zoom : <strong className="text-stone-200">{Math.round(zoom * 100)}%</strong> • Nœuds :{' '}
          <strong className="text-amber-300">{layout.nodes.length}</strong>
        </div>
      </div>

      {/* Main Scalable & Pannable Graph World */}
      <div
        className="absolute top-0 left-0 transition-transform origin-top-left"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          width: `${layout.width}px`,
          height: `${layout.height}px`,
        }}
      >
        {/* Generation Layer Backdrops & Banners */}
        {layout.generations.map((gen, idx) => {
          const yPos = 80 + idx * (140 + 140) - 35;
          return (
            <div
              key={`gen-row-${gen}`}
              className="absolute left-0 right-0 border-t border-dashed border-stone-800/80 pointer-events-none flex items-center"
              style={{ top: `${yPos}px`, width: `${layout.width}px` }}
            >
              <div className="sticky left-4 z-0 inline-flex items-center gap-2 px-3 py-1 rounded-xl bg-stone-950/90 border border-stone-800 text-stone-400 text-xs font-serif font-bold shadow-md">
                <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                <span>Génération G{gen}</span>
              </div>
            </div>
          );
        })}

        {/* SVG Link Curves Layer */}
        <svg
          className="absolute inset-0 pointer-events-none"
          width={layout.width}
          height={layout.height}
          style={{ overflow: 'visible' }}
        >
          <defs>
            {/* Linear Gradient for Parent -> Child Connections */}
            <linearGradient id="parentChildGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#d97706" stopOpacity="0.4" />
            </linearGradient>

            {/* Linear Gradient for Spouse Alliances */}
            <linearGradient id="spouseGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.9" />
              <stop offset="50%" stopColor="#fbbf24" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.9" />
            </linearGradient>

            {/* Marker for Parent-Child Arrowhead */}
            <marker
              id="arrowhead"
              markerWidth="8"
              markerHeight="6"
              refX="6"
              refY="3"
              orient="auto"
            >
              <polygon points="0 0, 8 3, 0 6" fill="#f59e0b" />
            </marker>
          </defs>

          {/* Render Link Paths */}
          {layout.links.map((link) => {
            const isSpouse = link.type === 'CONJOINT';
            const isHighlighted =
              hoveredNodeId === link.sourceId || hoveredNodeId === link.targetId;

            return (
              <g key={link.id}>
                {/* Background glow when hovered */}
                {isHighlighted && (
                  <path
                    d={link.path}
                    fill="none"
                    stroke={isSpouse ? '#38bdf8' : '#f59e0b'}
                    strokeWidth="6"
                    strokeOpacity="0.4"
                    strokeLinecap="round"
                  />
                )}

                {/* Main Path */}
                <path
                  d={link.path}
                  fill="none"
                  stroke={isSpouse ? 'url(#spouseGrad)' : 'url(#parentChildGrad)'}
                  strokeWidth={isHighlighted ? 3 : isSpouse ? 2.5 : 2}
                  strokeDasharray={isSpouse ? '6,4' : 'none'}
                  strokeLinecap="round"
                  markerEnd={!isSpouse ? 'url(#arrowhead)' : undefined}
                  className="transition-all duration-200"
                />
              </g>
            );
          })}
        </svg>

        {/* DOM Interactive Member Cards */}
        {layout.nodes.map((node) => {
          const isSelected = selectedMemberId === node.id;
          const isHovered = hoveredNodeId === node.id;
          const isDirect = node.isDirectNzala;
          const m = node.member;

          return (
            <div
              key={node.id}
              style={{
                position: 'absolute',
                left: `${node.x}px`,
                top: `${node.y}px`,
                width: `${node.width}px`,
                height: `${node.height}px`,
              }}
              onMouseEnter={() => setHoveredNodeId(node.id)}
              onMouseLeave={() => setHoveredNodeId(null)}
              onClick={() => onSelectMember(m)}
              className={`group p-3.5 rounded-2xl bg-stone-950/95 border transition-all duration-200 cursor-pointer shadow-lg flex flex-col justify-between ${
                isSelected
                  ? 'ring-2 ring-amber-400 border-amber-400 shadow-amber-950/60 scale-[1.03] z-30'
                  : isDirect
                  ? 'border-amber-500/40 hover:border-amber-400 hover:shadow-amber-950/40 hover:scale-[1.02] z-10'
                  : 'border-sky-500/40 hover:border-sky-400 hover:shadow-sky-950/40 hover:scale-[1.02] z-10'
              }`}
            >
              {/* Card Header (Avatar + Name + Status) */}
              <div className="flex items-start justify-between gap-2.5">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center font-serif font-bold text-sm shrink-0 border ${
                      isDirect
                        ? 'bg-amber-950/80 text-amber-300 border-amber-500/50 shadow-inner'
                        : 'bg-sky-950/80 text-sky-300 border-sky-500/50 shadow-inner'
                    }`}
                  >
                    {m.firstName.charAt(0)}
                    {m.lastName.charAt(0)}
                  </div>

                  <div className="min-w-0 flex-1">
                    <h4 className="font-serif font-bold text-xs sm:text-sm text-stone-100 truncate leading-tight group-hover:text-amber-200 transition">
                      {m.firstName} {m.lastName}
                    </h4>
                    <p className="text-[10px] text-stone-400 truncate mt-0.5">
                      {m.primaryFamilyName}
                    </p>
                  </div>
                </div>

                <LivingStatusBadge
                  status={m.livingStatus}
                  deathDate={m.deathDate}
                  burialPlace={m.burialPlace}
                  size="sm"
                />
              </div>

              {/* Badges and tags */}
              <div className="flex flex-wrap items-center gap-1.5 mt-1">
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                    isDirect
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      : 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                  }`}
                >
                  {isDirect ? '👑 Lignée Nzala' : '💍 Alliance'}
                </span>

                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-stone-800 text-stone-300 border border-stone-700">
                  G{node.generation}
                </span>

                {m.branchName && (
                  <span className="px-2 py-0.5 rounded text-[10px] text-stone-400 bg-stone-900 border border-stone-800 truncate max-w-[110px]">
                    {m.branchName.replace('Branche ', '')}
                  </span>
                )}
              </div>

              {/* Bottom Card Action Bar */}
              <div className="pt-2 border-t border-stone-800/80 flex items-center justify-between text-[11px] text-stone-400">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onFocusAroundMember(m.id);
                  }}
                  className="flex items-center gap-1 hover:text-amber-300 transition text-[10px] font-semibold cursor-pointer"
                  title="Explorer la famille proche autour de cette personne"
                >
                  <Compass className="w-3 h-3 text-amber-500" />
                  <span>Autour de moi</span>
                </button>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenAddRelationship(m.id);
                    }}
                    className="p-1 rounded-md hover:bg-stone-800 text-stone-400 hover:text-amber-300 transition cursor-pointer"
                    title="Proposer ou lier une relation"
                  >
                    <Link2 className="w-3 h-3" />
                  </button>

                  <span className="text-amber-400 font-bold flex items-center gap-0.5 text-[10px] group-hover:translate-x-0.5 transition">
                    <span>Fiche</span>
                    <ChevronRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
