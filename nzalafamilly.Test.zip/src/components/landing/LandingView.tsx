import React from 'react';
import { useFamily } from '../../context/FamilyContext';
import {
  Building2,
  GitFork,
  ArrowRight,
  Sparkles,
  FileCheck2,
  HeartHandshake,
  ShieldCheck,
  Award,
} from 'lucide-react';

interface LandingViewProps {
  onOpenAuth: (mode: 'LOGIN' | 'REGISTER') => void;
}

export const LandingView: React.FC<LandingViewProps> = ({ onOpenAuth }) => {
  const { families, members, alliances, currentUser, setActiveTab } = useFamily();

  const directNzalaCount = members.filter((m) => m.familyType === 'NZALA_DIRECT').length;
  const alliedFamilies = families.filter((f) => f.type === 'ALLIEE');

  return (
    <div id="landing-view-container" className="space-y-10 sm:space-y-12 pb-16">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white p-8 sm:p-12 border border-blue-800/40 shadow-xl">
        <div className="absolute -right-16 -bottom-16 w-96 h-96 bg-blue-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-16 -top-16 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/20 text-blue-200 border border-blue-400/30 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-blue-300" />
            <span>Plateforme Numérique Officielle de la Famille Nzala &amp; Familles Alliées</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-sans font-bold text-white tracking-tight leading-tight">
            Transmettre la mémoire, fédérer les lignées et honorer nos alliances.
          </h1>

          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            NzalaFamilly est l'espace numérique sécurisé conçu pour recenser les membres de la <strong>Famille Souche Nzala</strong>, formaliser les liens avec les <strong>familles alliées</strong>, préserver notre généalogie et célébrer nos transmissions.
          </p>

          <div className="flex flex-wrap items-center gap-3.5 pt-2">
            {currentUser.role === 'VISITEUR' ? (
              <>
                <button
                  onClick={() => onOpenAuth('REGISTER')}
                  className="px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm shadow-md transition flex items-center gap-2 cursor-pointer"
                >
                  <span>Créer mon compte d'accès</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={() => onOpenAuth('LOGIN')}
                  className="px-6 py-3.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs sm:text-sm border border-white/20 transition cursor-pointer"
                >
                  Se connecter
                </button>
              </>
            ) : (
              <button
                onClick={() => setActiveTab('dashboard')}
                className="px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm shadow-md transition flex items-center gap-2 cursor-pointer"
              >
                <span>Accéder au Tableau de Bord</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            <button
              onClick={() => setActiveTab('affiliation')}
              className="px-5 py-3.5 rounded-xl bg-white/10 hover:bg-white/15 text-blue-200 font-semibold text-xs sm:text-sm border border-blue-400/30 transition flex items-center gap-2 cursor-pointer"
            >
              <FileCheck2 className="w-4 h-4 text-blue-300" />
              <span>Déclarer une affiliation</span>
            </button>
          </div>
        </div>
      </div>

      {/* Key Metrics Counters */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1.5 hover:border-blue-300 transition">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Membres Directs Nzala</span>
            <Award className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-3xl font-bold text-slate-900">{directNzalaCount}</div>
          <p className="text-[11px] text-slate-500">Lignée sanguine référencée</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1.5 hover:border-sky-300 transition">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Familles Alliées</span>
            <Building2 className="w-4 h-4 text-sky-600" />
          </div>
          <div className="text-3xl font-bold text-sky-900">{alliedFamilies.length}</div>
          <p className="text-[11px] text-slate-500">Mavungu, Kanza, Lukoki, Ndombe...</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1.5 hover:border-emerald-300 transition">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Alliances Enregistrées</span>
            <HeartHandshake className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-3xl font-bold text-emerald-900">{alliances.length}</div>
          <p className="text-[11px] text-slate-500">Mariages &amp; pactes reconnus</p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1.5 hover:border-indigo-300 transition">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Générations Préservées</span>
            <GitFork className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-3xl font-bold text-indigo-900">4</div>
          <p className="text-[11px] text-slate-500">Des patriarches à la jeunesse</p>
        </div>
      </div>

      {/* The 3-Step Governance Process (Inscription -> Affiliation -> Validation) */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-6">
        <div className="max-w-2xl">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600">
            Processus de Gouvernance &amp; Sécurité
          </span>
          <h2 className="text-2xl font-bold text-slate-900 mt-1">
            Comment rejoindre la communauté NzalaFamilly ?
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1.5">
            Pour préserver l'intégrité de la généalogie et la confidentialité des familles, l'accès se déroule en 3 étapes claires :
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Step 1 */}
          <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center font-bold text-sm">
              1
            </div>
            <h3 className="font-bold text-base text-slate-900">Création de Compte</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Vous créez un compte personnel sécurisé (email, mot de passe, coordonnées). Votre statut initial est <strong>Visiteur</strong> avec des accès limités de consultation.
            </p>
          </div>

          {/* Step 2 */}
          <div className="p-6 rounded-2xl bg-blue-50/70 border border-blue-200 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-sm">
              2
            </div>
            <h3 className="font-bold text-base text-slate-900">Déclaration d'Affiliation</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Vous indiquez votre lien précis (Membre direct Nzala, conjoint, descendant d'alliance ou famille alliée) et citez vos aînés référents.
            </p>
          </div>

          {/* Step 3 */}
          <div className="p-6 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">
              3
            </div>
            <h3 className="font-bold text-base text-slate-900">Validation Collégiale</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Le Conseil de Famille et les validateurs examinent votre demande. Une fois approuvée, votre compte est élevé et vous intégrez l'annuaire familial.
            </p>
          </div>
        </div>
      </div>

      {/* Allied Families Network Section */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-sky-700">
              Réseau des Alliances
            </span>
            <h2 className="text-2xl font-bold text-slate-900 mt-0.5">
              Les Familles Alliées Reconnues
            </h2>
          </div>
          <button
            onClick={() => setActiveTab('alliances')}
            className="text-xs font-bold text-blue-600 hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>Consulter les pactes et alliances</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {alliedFamilies.map((fam) => (
            <div
              key={fam.id}
              className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3 flex flex-col justify-between hover:border-sky-300 transition"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-900">
                    {fam.code}
                  </span>
                  <span className="text-[11px] text-slate-500 font-semibold">
                    {fam.originLocation}
                  </span>
                </div>
                <h3 className="font-bold text-base text-slate-900">{fam.name}</h3>
                <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                  {fam.description}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
                <span>{fam.membersCount} membres</span>
                <span>{fam.alliancesCount} alliances</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
