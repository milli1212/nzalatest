/**
 * NzalaFamilly - Modale de Création / Programmation de Direct (Nzala Live)
 */

import React, { useState } from 'react';
import {
  Radio,
  Calendar,
  Clock,
  Globe,
  Users,
  Lock,
  Sparkles,
  X,
  Play,
  CheckCircle,
} from 'lucide-react';
import { PostScope } from '../../types';
import { useFamily } from '../../context/FamilyContext';

interface CreateLiveModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLiveCreated?: (liveId: string) => void;
}

export const CreateLiveModal: React.FC<CreateLiveModalProps> = ({
  isOpen,
  onClose,
  onLiveCreated,
}) => {
  const { currentUser, branches, alliedFamilies, startNewLiveStream, showToast } = useFamily();
  const [isScheduled, setIsScheduled] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [scope, setScope] = useState<PostScope>('NZALA_INTERNE');
  const [targetBranchId, setTargetBranchId] = useState('');
  const [targetAlliedFamilyId, setTargetAlliedFamilyId] = useState('');
  const [scheduledDate, setScheduledDate] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim()) {
      showToast('error', 'Veuillez saisir un titre pour le Live.');
      return;
    }

    if (isScheduled && (!scheduledDate || !scheduledTime)) {
      showToast('error', 'Veuillez préciser la date et l\'heure de programmation.');
      return;
    }

    const scheduledTimestamp = isScheduled
      ? `${scheduledDate}T${scheduledTime}:00`
      : undefined;

    const branch = branches.find((b) => b.id === targetBranchId);
    const allied = alliedFamilies.find((f) => f.id === targetAlliedFamilyId);

    const newLive = startNewLiveStream({
      title: title.trim(),
      description: description.trim() || undefined,
      scope,
      status: isScheduled ? 'SCHEDULED' : 'LIVE',
      scheduledFor: scheduledTimestamp,
      targetBranchId: targetBranchId || undefined,
      targetBranchName: branch?.name,
      targetFamilyId: targetAlliedFamilyId || undefined,
      targetFamilyName: allied?.name,
    });

    showToast('success', isScheduled ? 'Direct programmé avec succès !' : 'Votre Live est lancé !');
    if (onLiveCreated && newLive.liveStream) onLiveCreated(newLive.liveStream.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-lg w-full p-5 sm:p-7 shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-slate-900">
                {isScheduled ? 'Programmer un Direct Familial' : 'Lancer un Direct (Nzala Live)'}
              </h3>
              <p className="text-xs text-slate-500">Partagez un moment précieux en direct avec vos proches</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          {/* Mode Switcher */}
          <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-slate-100 border border-slate-200 text-xs font-bold">
            <button
              type="button"
              onClick={() => setIsScheduled(false)}
              className={`py-2 rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                !isScheduled
                  ? 'bg-rose-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Radio className="w-3.5 h-3.5" />
              <span>Direct Immédiat</span>
            </button>
            <button
              type="button"
              onClick={() => setIsScheduled(true)}
              className={`py-2 rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                isScheduled
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Programmer</span>
            </button>
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Titre de la diffusion *
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ex: Célébration en famille, Échange avec les Aînés..."
              className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm text-slate-900 outline-none focus:ring-2 focus:ring-rose-500"
              required
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Description ou sujet (optionnel)
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              placeholder="De quoi allons-nous parler lors de ce direct ?"
              className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs sm:text-sm text-slate-900 outline-none focus:ring-2 focus:ring-rose-500 resize-none"
            />
          </div>

          {/* Scope */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Audience & Visibilité
            </label>
            <select
              value={scope}
              onChange={(e) => setScope(e.target.value as PostScope)}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800 outline-none focus:ring-2 focus:ring-rose-500"
            >
              <option value="NZALA_INTERNE">🔒 Famille Nzala Uniquement</option>
              <option value="BRANCHE">🌿 Branche Familiale Spécifique</option>
              <option value="FAMILLE_ALLIEE">🤝 Famille Alliée Spécifique</option>
              <option value="INTER_FAMILLES">🌐 Inter-Familles (Nzala + Alliées)</option>
              <option value="PUBLIC">🌍 Public</option>
            </select>
          </div>

          {/* If Scope = BRANCHE */}
          {scope === 'BRANCHE' && (
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Branche ciblée</label>
              <select
                value={targetBranchId}
                onChange={(e) => setTargetBranchId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800"
                required
              >
                <option value="">Sélectionnez une branche...</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>
          )}

          {/* If Scheduled: Date & Time */}
          {isScheduled && (
            <div className="grid grid-cols-2 gap-3 p-3 rounded-2xl bg-blue-50 border border-blue-100">
              <div>
                <label className="block text-xs font-bold text-blue-900 mb-1">Date</label>
                <input
                  type="date"
                  value={scheduledDate}
                  onChange={(e) => setScheduledDate(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-white border border-blue-200 text-xs text-slate-900"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-blue-900 mb-1">Heure</label>
                <input
                  type="time"
                  value={scheduledTime}
                  onChange={(e) => setScheduledTime(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-white border border-blue-200 text-xs text-slate-900"
                  required
                />
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold cursor-pointer"
            >
              Annuler
            </button>
            <button
              type="submit"
              className={`px-5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 text-white shadow-md transition active:scale-95 cursor-pointer ${
                isScheduled
                  ? 'bg-blue-600 hover:bg-blue-700'
                  : 'bg-rose-600 hover:bg-rose-700'
              }`}
            >
              {isScheduled ? <Calendar className="w-4 h-4" /> : <Radio className="w-4 h-4" />}
              <span>{isScheduled ? 'Enregistrer le Direct' : 'Démarrer le Direct'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
