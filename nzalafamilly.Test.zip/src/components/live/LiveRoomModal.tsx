/**
 * NzalaFamilly - Salle de Diffusion en Direct (Nzala Live Room)
 * Gère à la fois le mode Diffuseur (Host) et Spectateur (Viewer), avec réactions flottantes, commentaires en temps réel et modération.
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Radio,
  Users,
  Mic,
  MicOff,
  Video as VideoIcon,
  VideoOff,
  SwitchCamera,
  Heart,
  Send,
  X,
  Share2,
  Shield,
  Trash2,
  Pin,
  AlertTriangle,
  Sparkles,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { LiveStream, LiveComment } from '../../types/socialFeatures';
import { useFamily } from '../../context/FamilyContext';
import { VerifiedBadge } from '../common/VerifiedBadge';

interface LiveRoomModalProps {
  isOpen: boolean;
  live: LiveStream | null;
  onClose: () => void;
}

const LIVE_REACTION_EMOJIS = ['❤️', '🔥', '👏', '🦁', '👑', '✨', '🙏', '🎉'];

const QUICK_GREETINGS = [
  '👋 Bonjour la famille !',
  '🕊️ Paix sur notre lignée',
  '🙌 Fierté de nos racines',
  '❤️ Amour et union fraternelle',
];

export const LiveRoomModal: React.FC<LiveRoomModalProps> = ({
  isOpen,
  live,
  onClose,
}) => {
  const {
    currentUser,
    endLiveStream,
    sendLiveComment,
    sendLiveReaction,
    deleteLiveComment,
    showToast,
  } = useFamily();

  const [commentText, setCommentText] = useState('');
  const [isMicOn, setIsMicOn] = useState(live?.isMicOn ?? true);
  const [isVideoOn, setIsVideoOn] = useState(live?.isCameraOn ?? true);
  const [isSoundMuted, setIsSoundMuted] = useState(false);
  const [floatingHearts, setFloatingHearts] = useState<{ id: number; emoji: string; x: number }[]>([]);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  const videoElementRef = useRef<HTMLVideoElement | null>(null);
  const commentsEndRef = useRef<HTMLDivElement | null>(null);

  const isHost = live ? live.hostUserId === currentUser.id : false;
  const isCouncilOrAdmin =
    currentUser.role === 'SUPER_ADMIN' ||
    currentUser.role === 'ADMIN_FAMILIAL' ||
    currentUser.role === 'VALIDATEUR';

  // Timer de durée du direct
  useEffect(() => {
    if (!isOpen || !live || live.status !== 'LIVE') return;

    const interval = setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen, live]);

  // Initialisation de la caméra / micro si Host
  useEffect(() => {
    if (!isOpen || !live || !isHost) return;

    let mediaStream: MediaStream | null = null;

    async function initCamera() {
      try {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          mediaStream = await navigator.mediaDevices.getUserMedia({
            video: true,
            audio: true,
          });
          if (videoElementRef.current) {
            videoElementRef.current.srcObject = mediaStream;
          }
        }
      } catch (err) {
        // En environnement sandbox sans webcam, affichage automatique du flux dynamique simulé
      }
    }

    initCamera();

    return () => {
      if (mediaStream) {
        mediaStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [isOpen, live, isHost]);

  // Auto-scroll des commentaires
  useEffect(() => {
    commentsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [live?.comments]);

  if (!isOpen || !live) return null;

  const handleSendComment = (e?: React.FormEvent, customText?: string) => {
    if (e) e.preventDefault();
    const textToSend = customText || commentText;
    if (!textToSend.trim()) return;

    sendLiveComment(live.id, textToSend.trim());
    setCommentText('');
  };

  const handleTriggerReaction = (emoji: string) => {
    sendLiveReaction(live.id, emoji);

    // Ajouter un emoji flottant animé
    const newHeart = {
      id: Date.now() + Math.random(),
      emoji,
      x: Math.floor(Math.random() * 60) + 20, // 20% to 80% width
    };
    setFloatingHearts((prev) => [...prev, newHeart]);

    setTimeout(() => {
      setFloatingHearts((prev) => prev.filter((h) => h.id !== newHeart.id));
    }, 2000);
  };

  const handleEndLive = () => {
    if (window.confirm('Voulez-vous vraiment terminer cette diffusion en direct ?')) {
      endLiveStream(live.id);
      showToast('info', 'Le Live est terminé.');
      onClose();
    }
  };

  const formatElapsedTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div
      id="live-room-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 select-none"
    >
      {/* Floating Animated Emojis Layer */}
      <div className="absolute inset-0 pointer-events-none z-30 overflow-hidden">
        {floatingHearts.map((heart) => (
          <div
            key={heart.id}
            className="absolute bottom-20 text-3xl animate-floatUp opacity-90 transition-all"
            style={{ left: `${heart.x}%` }}
          >
            {heart.emoji}
          </div>
        ))}
      </div>

      {/* Main Container */}
      <div className="relative w-full h-full max-w-5xl mx-auto flex flex-col md:flex-row bg-stone-950 overflow-hidden">
        {/* Left / Top: Live Video Stage */}
        <div className="flex-1 relative flex items-center justify-center bg-stone-900 overflow-hidden min-h-[50vh] md:min-h-full">
          {/* Real video or dynamic stylized backdrop */}
          {isHost ? (
            <video
              ref={videoElementRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full relative flex items-center justify-center bg-gradient-to-br from-indigo-950 via-slate-900 to-amber-950/40">
              {live.thumbnailUrl ? (
                <img
                  src={live.thumbnailUrl}
                  alt={live.title}
                  className="w-full h-full object-cover opacity-60 filter blur-xs"
                />
              ) : null}

              {/* Central Host Card Representation */}
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 bg-black/40">
                <div className="relative mb-4">
                  <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full border-4 border-rose-500 overflow-hidden shadow-2xl animate-pulse">
                    {live.hostAvatar ? (
                      <img src={live.hostAvatar} alt={live.hostName} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-blue-600 flex items-center justify-center text-white text-3xl font-bold">
                        {live.hostName.charAt(0)}
                      </div>
                    )}
                  </div>
                  <span className="absolute bottom-0 right-0 bg-rose-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                    En Direct
                  </span>
                </div>

                <h2 className="text-xl sm:text-2xl font-bold text-white max-w-md">{live.title}</h2>
                <div className="flex items-center justify-center gap-1.5 text-xs sm:text-sm text-stone-300 mt-1">
                  <span>Présenté par</span>
                  <strong className="text-amber-400 font-bold">{live.hostName}</strong>
                  <VerifiedBadge
                    role={live.hostRole}
                    isVerified={live.isHostVerified ?? true}
                    badgeLabel={live.hostVerifiedBadge}
                    size="sm"
                  />
                </div>
                {live.description && (
                  <p className="text-xs text-stone-400 max-w-sm mt-2 line-clamp-2">{live.description}</p>
                )}
              </div>
            </div>
          )}

          {/* Top Live Bar Overlay */}
          <div className="absolute top-4 inset-x-4 flex items-center justify-between z-20">
            {/* Live Badge & Viewers */}
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-600 text-white text-xs font-bold shadow-lg animate-pulse">
                <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                <span>DIRECT</span>
              </div>

              <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-white text-xs font-mono border border-white/10">
                <Users className="w-3.5 h-3.5 text-blue-400" />
                <span>{live.viewersCount}</span>
              </div>

              <div className="px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-white text-xs font-mono border border-white/10">
                {formatElapsedTime(elapsedSeconds)}
              </div>
            </div>

            {/* Close / Controls */}
            <div className="flex items-center gap-2">
              {isHost && (
                <button
                  type="button"
                  onClick={handleEndLive}
                  className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition cursor-pointer"
                >
                  Terminer
                </button>
              )}

              <button
                type="button"
                onClick={onClose}
                className="w-8 h-8 rounded-full bg-black/60 backdrop-blur-md text-white flex items-center justify-center hover:bg-black/80 transition cursor-pointer border border-white/10"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Host Media Controls (Bottom Left of Video) */}
          {isHost && (
            <div className="absolute bottom-4 left-4 flex items-center gap-2 z-20 bg-black/60 backdrop-blur-md p-1.5 rounded-2xl border border-white/10">
              <button
                type="button"
                onClick={() => setIsMicOn(!isMicOn)}
                className={`p-2 rounded-xl transition cursor-pointer ${
                  isMicOn ? 'bg-white/20 text-white' : 'bg-rose-600 text-white'
                }`}
                title={isMicOn ? 'Couper le micro' : 'Activer le micro'}
              >
                {isMicOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
              </button>

              <button
                type="button"
                onClick={() => setIsVideoOn(!isVideoOn)}
                className={`p-2 rounded-xl transition cursor-pointer ${
                  isVideoOn ? 'bg-white/20 text-white' : 'bg-rose-600 text-white'
                }`}
                title={isVideoOn ? 'Couper la caméra' : 'Activer la caméra'}
              >
                {isVideoOn ? <VideoIcon className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
              </button>
            </div>
          )}
        </div>

        {/* Right / Bottom: Comments Stream & Reactions Bar */}
        <div className="w-full md:w-96 bg-stone-900 border-t md:border-t-0 md:border-l border-stone-800 flex flex-col h-[50vh] md:h-full">
          {/* Header of Chat Stream */}
          <div className="p-3 border-b border-stone-800 flex items-center justify-between">
            <span className="text-xs font-bold text-stone-200 flex items-center gap-2">
              <span>💬 Fil de discussion en direct</span>
            </span>
            <span className="text-[10px] text-stone-400 bg-stone-800 px-2 py-0.5 rounded-full">
              {live.comments?.length || 0} messages
            </span>
          </div>

          {/* Comments List */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
            {/* Host Welcome System Message */}
            <div className="p-2.5 rounded-xl bg-blue-950/60 border border-blue-800/40 text-xs text-blue-200">
              <div className="flex items-center gap-1.5 font-bold text-[11px] text-amber-400 mb-0.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Bienvenue sur le Direct Nzala</span>
              </div>
              <p className="text-[11px] opacity-90">
                Respectons la parole et célébrons notre fraternité en toute bienveillance.
              </p>
            </div>

            {live.comments?.map((comment) => (
              <div
                key={comment.id}
                className={`p-2 rounded-xl text-xs flex items-start justify-between gap-2 group transition ${
                  comment.isHost
                    ? 'bg-amber-950/40 border border-amber-800/50 text-amber-100'
                    : 'bg-stone-800/60 border border-stone-700/40 text-stone-200'
                }`}
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="font-bold text-[11px] text-stone-100 truncate">
                      {comment.userName}
                    </span>
                    {comment.isHost && (
                      <span className="text-[9px] font-bold bg-amber-500 text-stone-950 px-1 rounded">
                        HÔTE
                      </span>
                    )}
                    <VerifiedBadge
                      role={comment.userRole}
                      isVerified={comment.isVerified}
                      badgeLabel={comment.verifiedBadge}
                      size="sm"
                    />
                  </div>
                  <p className="text-xs text-stone-300 mt-0.5 break-words">{comment.content}</p>
                </div>

                {/* Moderate comment if host or admin */}
                {(isHost || isCouncilOrAdmin) && (
                  <button
                    type="button"
                    onClick={() => deleteLiveComment(live.id, comment.id)}
                    className="opacity-0 group-hover:opacity-100 p-1 text-stone-400 hover:text-rose-400 transition cursor-pointer"
                    title="Supprimer ce commentaire"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                )}
              </div>
            ))}
            <div ref={commentsEndRef} />
          </div>

          {/* Quick Greetings Chips */}
          <div className="p-2 border-t border-stone-800 flex gap-1.5 overflow-x-auto no-scrollbar">
            {QUICK_GREETINGS.map((greet, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSendComment(undefined, greet)}
                className="shrink-0 px-2.5 py-1 rounded-full bg-stone-800 hover:bg-stone-700 text-stone-300 text-[11px] transition cursor-pointer border border-stone-700"
              >
                {greet}
              </button>
            ))}
          </div>

          {/* Emoji Floating Reactions Bar */}
          <div className="px-3 py-2 border-t border-stone-800 flex items-center justify-between gap-1">
            {LIVE_REACTION_EMOJIS.map((emoji) => (
              <button
                key={emoji}
                type="button"
                onClick={() => handleTriggerReaction(emoji)}
                className="p-1.5 rounded-xl hover:bg-stone-800 text-lg transition hover:scale-125 active:scale-95 cursor-pointer"
              >
                {emoji}
              </button>
            ))}
          </div>

          {/* Bottom Send Comment Input */}
          <form
            onSubmit={handleSendComment}
            className="p-2.5 border-t border-stone-800 flex items-center gap-2"
          >
            <input
              type="text"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder="Votre réaction en direct..."
              className="flex-1 bg-stone-800 text-white text-xs rounded-xl px-3 py-2 outline-none border border-stone-700 focus:border-blue-500"
            />
            <button
              type="submit"
              disabled={!commentText.trim()}
              className="p-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white transition cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
