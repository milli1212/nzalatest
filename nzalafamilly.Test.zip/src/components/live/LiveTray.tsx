/**
 * NzalaFamilly - Bandeau des Directs Actifs & Programmés (Live Tray)
 */

import React, { useState } from 'react';
import {
  Radio,
  Calendar,
  Users,
  Play,
  Plus,
  Bell,
  Sparkles,
  ChevronRight,
} from 'lucide-react';
import { useFamily } from '../../context/FamilyContext';
import { LiveStream } from '../../types/socialFeatures';
import { LiveRoomModal } from './LiveRoomModal';
import { CreateLiveModal } from './CreateLiveModal';
import { VerifiedBadge } from '../common/VerifiedBadge';

export const LiveTray: React.FC = () => {
  const { liveStreams, joinLiveStream, showToast } = useFamily();
  const [selectedLive, setSelectedLive] = useState<LiveStream | null>(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  const activeLives = liveStreams.filter((l) => l.status === 'LIVE');
  const scheduledLives = liveStreams.filter((l) => l.status === 'SCHEDULED');

  if (activeLives.length === 0 && scheduledLives.length === 0) {
    return (
      <div className="flex items-center justify-between p-3.5 rounded-2xl bg-gradient-to-r from-rose-900/10 via-amber-900/5 to-transparent border border-rose-200/60 shadow-xs mb-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center shadow-xs">
            <Radio className="w-4 h-4" />
          </div>
          <div>
            <h4 className="font-bold text-xs sm:text-sm text-slate-900">Nzala Live • Directs Familiaux</h4>
            <p className="text-[11px] text-slate-500">Transmettez et échangez en vidéo en direct avec toute la famille</p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setIsCreateOpen(true)}
          className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-1.5 transition shadow-xs cursor-pointer shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Lancer un Live</span>
        </button>

        <CreateLiveModal
          isOpen={isCreateOpen}
          onClose={() => setIsCreateOpen(false)}
          onLiveCreated={(liveId) => {
            const found = liveStreams.find((l) => l.id === liveId);
            if (found && found.status === 'LIVE') {
              setSelectedLive(found);
            }
          }}
        />
      </div>
    );
  }

  return (
    <div className="mb-4 space-y-2.5">
      {/* Active Lives Carousel / Grid */}
      {activeLives.length > 0 && (
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-rose-950 via-slate-900 to-indigo-950 text-white shadow-md border border-rose-800/40">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="flex h-2.5 w-2.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
              </span>
              <h3 className="font-bold text-xs sm:text-sm tracking-wide uppercase text-rose-300">
                Diffusions en Direct Actives ({activeLives.length})
              </h3>
            </div>
            <button
              type="button"
              onClick={() => setIsCreateOpen(true)}
              className="px-2.5 py-1 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold flex items-center gap-1 transition cursor-pointer"
            >
              <Plus className="w-3 h-3" />
              <span>Nouveau Live</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {activeLives.map((live) => (
              <div
                key={live.id}
                onClick={() => {
                  joinLiveStream(live.id);
                  setSelectedLive(live);
                }}
                className="group relative p-3 rounded-xl bg-white/10 hover:bg-white/15 border border-white/10 backdrop-blur-md cursor-pointer transition flex items-center justify-between gap-3 shadow-xs"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative shrink-0">
                    <div className="w-11 h-11 rounded-full border-2 border-rose-500 overflow-hidden bg-blue-600 flex items-center justify-center font-bold text-white shadow-md">
                      {live.hostAvatar ? (
                        <img src={live.hostAvatar} alt={live.hostName} className="w-full h-full object-cover" />
                      ) : (
                        live.hostName.charAt(0)
                      )}
                    </div>
                    <span className="absolute -bottom-1 -right-1 bg-rose-600 text-white text-[8px] font-bold px-1 rounded-full uppercase">
                      Live
                    </span>
                  </div>

                  <div className="min-w-0">
                    <h4 className="font-bold text-xs sm:text-sm text-white truncate group-hover:text-rose-300 transition">
                      {live.title}
                    </h4>
                    <div className="flex items-center gap-1 text-[11px] text-stone-300 truncate">
                      <span>Par {live.hostName}</span>
                      <VerifiedBadge
                        role={live.hostRole}
                        isVerified={live.isHostVerified ?? true}
                        badgeLabel={live.hostVerifiedBadge}
                        size="sm"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className="flex items-center gap-1 text-[11px] font-mono bg-black/40 px-2 py-0.5 rounded-full text-stone-200">
                    <Users className="w-3 h-3 text-rose-400" />
                    {live.viewersCount}
                  </span>
                  <div className="w-8 h-8 rounded-full bg-rose-600 group-hover:scale-110 text-white flex items-center justify-center transition shadow-md">
                    <Play className="w-3.5 h-3.5 ml-0.5" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Scheduled Lives Banner */}
      {scheduledLives.length > 0 && (
        <div className="p-3 rounded-2xl bg-blue-50 border border-blue-200/80 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0">
              <Calendar className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-bold text-xs text-blue-950">Direct Programmé</span>
                <span className="text-[10px] bg-blue-200/60 text-blue-900 px-1.5 py-0.2 rounded-full font-semibold">
                  {scheduledLives[0].scheduledFor ? new Date(scheduledLives[0].scheduledFor).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' }) : 'Bientôt'}
                </span>
              </div>
              <p className="text-xs text-blue-800 truncate font-semibold">
                « {scheduledLives[0].title} » par {scheduledLives[0].hostName}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => showToast('info', 'Rappel configuré ! Vous recevrez une notification au début du direct.')}
            className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1.5 transition shrink-0 cursor-pointer shadow-xs"
          >
            <Bell className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Me rappeler</span>
          </button>
        </div>
      )}

      {/* Live Room Modal */}
      {selectedLive && (
        <LiveRoomModal
          isOpen={!!selectedLive}
          live={selectedLive}
          onClose={() => setSelectedLive(null)}
        />
      )}

      {/* Create Live Modal */}
      <CreateLiveModal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        onLiveCreated={(liveId) => {
          const found = liveStreams.find((l) => l.id === liveId);
          if (found && found.status === 'LIVE') {
            setSelectedLive(found);
          }
        }}
      />
    </div>
  );
};
