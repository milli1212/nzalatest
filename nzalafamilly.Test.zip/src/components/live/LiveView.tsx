import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { LiveStream } from '../../types/socialFeatures';
import { CreateLiveModal } from './CreateLiveModal';
import { LiveRoomModal } from './LiveRoomModal';
import { VerifiedBadge } from '../common/VerifiedBadge';
import {
  Radio,
  Plus,
  Play,
  Calendar,
  Users,
  Clock,
  Sparkles,
  ShieldCheck,
  Video,
  Volume2,
  Film,
  Search,
} from 'lucide-react';

export const LiveView: React.FC = () => {
  const { liveStreams, joinLiveStream, currentUser, showToast } = useFamily();

  const [selectedLive, setSelectedLive] = useState<LiveStream | null>(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [filterTab, setFilterTab] = useState<'ALL' | 'ACTIVE' | 'SCHEDULED' | 'REPLAYS'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const activeLives = liveStreams.filter((l) => l.status === 'LIVE');
  const scheduledLives = liveStreams.filter((l) => l.status === 'SCHEDULED');
  const endedLives = liveStreams.filter((l) => l.status === 'ENDED');

  const filteredLives = liveStreams.filter((live) => {
    if (filterTab === 'ACTIVE' && live.status !== 'LIVE') return false;
    if (filterTab === 'SCHEDULED' && live.status !== 'SCHEDULED') return false;
    if (filterTab === 'REPLAYS' && live.status !== 'ENDED') return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const inTitle = live.title.toLowerCase().includes(q);
      const inHost = live.hostName.toLowerCase().includes(q);
      const inDesc = (live.description || '').toLowerCase().includes(q);
      if (!inTitle && !inHost && !inDesc) return false;
    }
    return true;
  });

  const canCreateLive =
    currentUser.role === 'SUPER_ADMIN' ||
    currentUser.role === 'ADMIN_FAMILIAL' ||
    currentUser.role === 'VALIDATEUR' ||
    currentUser.role === 'MEMBRE_NZALA';

  return (
    <div id="live-view-container" className="space-y-5 max-w-5xl mx-auto pb-12 animate-fadeIn">
      {/* Hero Header */}
      <div className="rounded-3xl bg-gradient-to-r from-rose-950 via-slate-900 to-indigo-950 text-white p-5 sm:p-7 shadow-xl border border-rose-900/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5 mb-1.5">
            <div className="w-10 h-10 rounded-2xl bg-rose-600 flex items-center justify-center text-white shadow-md">
              <Radio className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
                Nzala Live
                {activeLives.length > 0 && (
                  <span className="flex items-center gap-1.5 text-xs px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bold uppercase tracking-wider">
                    <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                    {activeLives.length} en direct
                  </span>
                )}
              </h1>
              <p className="text-xs sm:text-sm text-slate-300">
                Directs vidéo familiaux, assemblées, célébrations et prises de parole officielles
              </p>
            </div>
          </div>
        </div>

        {canCreateLive && (
          <button
            type="button"
            onClick={() => setIsCreateOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white text-xs sm:text-sm font-bold shadow-md transition cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Lancer un Direct</span>
          </button>
        )}
      </div>

      {/* Filter Tabs & Search */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-2">
        <div className="flex items-center gap-1.5 overflow-x-auto">
          {[
            { id: 'ALL', label: 'Toutes les diffusions', count: liveStreams.length },
            { id: 'ACTIVE', label: 'En direct', count: activeLives.length },
            { id: 'SCHEDULED', label: 'Programmées', count: scheduledLives.length },
            { id: 'REPLAYS', label: 'Replays / Archives', count: endedLives.length },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setFilterTab(tab.id as any)}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                filterTab === tab.id
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              <span>{tab.label}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                  filterTab === tab.id ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
                }`}
              >
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        <div className="relative min-w-[200px] sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher un direct..."
            className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-900 text-xs focus:border-rose-500 outline-none"
          />
        </div>
      </div>

      {/* Directs Grid */}
      {filteredLives.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredLives.map((live) => {
            const isLive = live.status === 'LIVE';
            const isScheduled = live.status === 'SCHEDULED';
            const isEnded = live.status === 'ENDED';

            return (
              <div
                key={live.id}
                className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition flex flex-col group"
              >
                {/* Thumbnail / Header Video Cover */}
                <div className="relative h-44 bg-slate-900 overflow-hidden flex items-center justify-center">
                  {live.thumbnailUrl ? (
                    <img
                      src={live.thumbnailUrl}
                      alt=""
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-500 opacity-85"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-tr from-slate-900 via-rose-950 to-indigo-950 flex items-center justify-center">
                      <Radio className="w-12 h-12 text-rose-500/40" />
                    </div>
                  )}

                  {/* Gradient shadow */}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-slate-950/40" />

                  {/* Badges on Top */}
                  <div className="absolute top-3 left-3 flex items-center gap-2">
                    {isLive && (
                      <span className="flex items-center gap-1.5 bg-rose-600 text-white text-[10px] font-black px-2.5 py-1 rounded-full uppercase tracking-wider shadow-md">
                        <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
                        En Direct
                      </span>
                    )}
                    {isScheduled && (
                      <span className="flex items-center gap-1.5 bg-blue-600 text-white text-[10px] font-bold px-2.5 py-1 rounded-full shadow-md">
                        <Calendar className="w-3 h-3" />
                        Programmé
                      </span>
                    )}
                    {isEnded && (
                      <span className="flex items-center gap-1.5 bg-slate-800 text-slate-200 text-[10px] font-bold px-2.5 py-1 rounded-full shadow-md">
                        <Film className="w-3 h-3" />
                        Replay
                      </span>
                    )}
                  </div>

                  {isLive && (
                    <div className="absolute top-3 right-3 bg-slate-950/70 backdrop-blur-xs text-white text-xs font-mono px-2.5 py-1 rounded-full flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-rose-400" />
                      <span>{live.viewersCount} spectateurs</span>
                    </div>
                  )}

                  {/* Play Button Overlay */}
                  <button
                    type="button"
                    onClick={() => {
                      if (isLive) {
                        joinLiveStream(live.id);
                        setSelectedLive(live);
                      } else if (isEnded) {
                        setSelectedLive(live);
                      } else {
                        showToast('info', `Rappel enregistré pour le direct « ${live.title} »`);
                      }
                    }}
                    className="absolute inset-0 flex items-center justify-center bg-transparent group-hover:bg-slate-950/30 transition cursor-pointer"
                  >
                    <div className="w-12 h-12 rounded-full bg-rose-600 group-hover:scale-110 text-white flex items-center justify-center shadow-xl transition">
                      <Play className="w-5 h-5 ml-0.5" />
                    </div>
                  </button>
                </div>

                {/* Details */}
                <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 group-hover:text-rose-600 transition line-clamp-1">
                      {live.title}
                    </h3>
                    {live.description && (
                      <p className="text-xs text-slate-600 line-clamp-2 mt-1">
                        {live.description}
                      </p>
                    )}
                  </div>

                  {/* Host info & Actions */}
                  <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-100">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-slate-200 overflow-hidden shrink-0 flex items-center justify-center font-bold text-xs text-slate-700">
                        {live.hostAvatar ? (
                          <img src={live.hostAvatar} alt="" className="w-full h-full object-cover" />
                        ) : (
                          live.hostName.charAt(0)
                        )}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1">
                          <p className="text-xs font-bold text-slate-900 truncate">{live.hostName}</p>
                          <VerifiedBadge
                            role={live.hostRole}
                            isVerified={live.isHostVerified ?? true}
                            badgeLabel={live.hostVerifiedBadge}
                            size="sm"
                          />
                        </div>
                        <p className="text-[10px] text-slate-500 truncate">
                          {live.hostFamilyName || 'Famille Nzala'}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        if (isLive) {
                          joinLiveStream(live.id);
                          setSelectedLive(live);
                        } else if (isEnded) {
                          setSelectedLive(live);
                        } else {
                          showToast('info', `Notification activée pour « ${live.title} »`);
                        }
                      }}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
                        isLive
                          ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-xs'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                      }`}
                    >
                      {isLive ? 'Rejoindre' : isEnded ? 'Regarder' : 'M’avertir'}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 space-y-3">
          <div className="w-14 h-14 rounded-2xl bg-rose-50 text-rose-600 mx-auto flex items-center justify-center">
            <Radio className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-slate-900">Aucun direct trouvé</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Aucun direct ne correspond aux filtres actuels. Lancez une diffusion pour rassembler la famille en direct !
          </p>
        </div>
      )}

      {/* Modals */}
      <CreateLiveModal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        onLiveCreated={(liveId) => {
          const created = liveStreams.find((l) => l.id === liveId);
          if (created && created.status === 'LIVE') {
            setSelectedLive(created);
          }
        }}
      />

      {selectedLive && (
        <LiveRoomModal
          live={selectedLive}
          isOpen={Boolean(selectedLive)}
          onClose={() => setSelectedLive(null)}
        />
      )}
    </div>
  );
};
