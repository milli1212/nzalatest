import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { MemberBelonging, Gender, LivingStatus, VisibilityLevel, GenerationStatus } from '../../types';
import { X, UserPlus, Sparkles, AlertTriangle, ShieldCheck, Calendar, MapPin, Briefcase } from 'lucide-react';

interface AddMemberModalProps {
  onClose: () => void;
}

export const AddMemberModal: React.FC<AddMemberModalProps> = ({ onClose }) => {
  const { families, branches, userAccounts, addMember, showToast } = useFamily();

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [middleName, setMiddleName] = useState('');
  const [maidenName, setMaidenName] = useState('');
  const [gender, setGender] = useState<Gender>('M');
  const [livingStatus, setLivingStatus] = useState<LivingStatus>('VIVANT');
  const [deathDate, setDeathDate] = useState('');
  const [burialPlace, setBurialPlace] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [birthPlace, setBirthPlace] = useState('');
  const [profession, setProfession] = useState('');
  const [location, setLocation] = useState('');
  const [primaryFamilyId, setPrimaryFamilyId] = useState(families[0]?.id || 'fam-nzala');
  const [belongingType, setBelongingType] = useState<MemberBelonging>('APPARTENANCE_DIRECTE');
  const [generationLevel, setGenerationLevel] = useState<number>(3);
  const [generationStatus, setGenerationStatus] = useState<GenerationStatus>('VALIDEE');
  const [branchId, setBranchId] = useState('');
  const [visibilityLevel, setVisibilityLevel] = useState<VisibilityLevel>('FAMILY');
  const [linkedUserId, setLinkedUserId] = useState('');
  const [bio, setBio] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState<string | null>(null);

  // Unlinked user accounts
  const unlinkedAccounts = userAccounts.filter((u) => !u.memberId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!firstName.trim() || !lastName.trim()) {
      setError('Le prénom et le nom sont obligatoires.');
      return;
    }

    const selectedFamily = families.find((f) => f.id === primaryFamilyId);
    const familyType = selectedFamily?.type === 'PRINCIPALE' ? 'NZALA_DIRECT' : 'ALLIE';
    const selectedBranch = branches.find((b) => b.id === branchId);

    const res = addMember({
      userId: linkedUserId || undefined,
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      middleName: middleName.trim() || undefined,
      maidenName: maidenName.trim() || undefined,
      gender,
      livingStatus,
      deathDate: livingStatus === 'DECEDE' ? deathDate || undefined : undefined,
      burialPlace: livingStatus === 'DECEDE' ? burialPlace.trim() || undefined : undefined,
      birthDate: birthDate || undefined,
      birthPlace: birthPlace.trim() || undefined,
      profession: profession.trim() || undefined,
      location: location.trim() || undefined,
      primaryFamilyId,
      primaryFamilyName: selectedFamily ? selectedFamily.name : 'Famille Nzala',
      familyType,
      belongingType,
      membershipStatus: 'ACTIF',
      generationLevel,
      generationStatus,
      branchId: branchId || undefined,
      branchName: selectedBranch ? selectedBranch.name : undefined,
      visibilityLevel,
      bio: bio.trim() || undefined,
      email: email.trim() || undefined,
      phone: phone.trim() || undefined,
    });

    if (!res.success) {
      setError(res.error || 'Erreur lors de la création de la fiche membre.');
    } else {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-stone-900 text-stone-100 p-6 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-serif font-bold text-stone-100">
                Enregistrer un Nouveau Membre
              </h2>
              <p className="text-xs text-stone-400">
                Création de fiche généalogique (membre vivant ou ancêtre décédé)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full text-stone-400 hover:text-stone-100 hover:bg-stone-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto text-xs flex-1">
          {/* Identity row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-stone-800 mb-1">
                Prénom <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                placeholder="Ex: André, Marie-Thérèse..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-800 mb-1">
                Nom de Famille <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                placeholder="Ex: Nzala, Mavungu, Kanza..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Post-nom (optionnel)</label>
              <input
                type="text"
                value={middleName}
                onChange={(e) => setMiddleName(e.target.value)}
                placeholder="Ex: Kimbangu, Mambu..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">
                Nom de jeune fille (si applicable)
              </label>
              <input
                type="text"
                value={maidenName}
                onChange={(e) => setMaidenName(e.target.value)}
                placeholder="Ex: Mabiala, Lelo..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 focus:bg-white text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          {/* Gender & Living Status */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-stone-800 mb-1">Genre</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setGender('M')}
                  className={`py-2 px-3 rounded-xl border text-center font-bold transition cursor-pointer ${
                    gender === 'M'
                      ? 'bg-amber-100 border-amber-400 text-amber-950'
                      : 'bg-stone-50 border-stone-200 text-stone-700'
                  }`}
                >
                  Homme (M)
                </button>
                <button
                  type="button"
                  onClick={() => setGender('F')}
                  className={`py-2 px-3 rounded-xl border text-center font-bold transition cursor-pointer ${
                    gender === 'F'
                      ? 'bg-amber-100 border-amber-400 text-amber-950'
                      : 'bg-stone-50 border-stone-200 text-stone-700'
                  }`}
                >
                  Femme (F)
                </button>
              </div>
            </div>

            <div>
              <label className="block font-bold text-stone-800 mb-1">Statut vital</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setLivingStatus('VIVANT')}
                  className={`py-2 px-3 rounded-xl border text-center font-bold transition cursor-pointer ${
                    livingStatus === 'VIVANT'
                      ? 'bg-emerald-100 border-emerald-400 text-emerald-950'
                      : 'bg-stone-50 border-stone-200 text-stone-700'
                  }`}
                >
                  🟢 Vivant(e)
                </button>
                <button
                  type="button"
                  onClick={() => setLivingStatus('DECEDE')}
                  className={`py-2 px-3 rounded-xl border text-center font-bold transition cursor-pointer ${
                    livingStatus === 'DECEDE'
                      ? 'bg-stone-200 border-stone-400 text-stone-900'
                      : 'bg-stone-50 border-stone-200 text-stone-700'
                  }`}
                >
                  🕊️ Décédé(e)
                </button>
              </div>
            </div>
          </div>

          {/* Conditional Death details if deceased */}
          {livingStatus === 'DECEDE' && (
            <div className="p-4 rounded-2xl bg-stone-100 border border-stone-300 grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-stone-800 mb-1">Date de décès</label>
                <input
                  type="date"
                  value={deathDate}
                  onChange={(e) => setDeathDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white text-stone-900"
                />
              </div>
              <div>
                <label className="block font-bold text-stone-800 mb-1">Lieu de repos / sépulture</label>
                <input
                  type="text"
                  value={burialPlace}
                  onChange={(e) => setBurialPlace(e.target.value)}
                  placeholder="Ex: Cimetière de Boma, Matadi..."
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white text-stone-900"
                />
              </div>
            </div>
          )}

          {/* Family & Belonging */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-stone-800 mb-1">
                Famille d'Appartenance <span className="text-rose-500">*</span>
              </label>
              <select
                value={primaryFamilyId}
                onChange={(e) => setPrimaryFamilyId(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 text-stone-900 font-semibold"
              >
                {families.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name} ({f.type === 'PRINCIPALE' ? 'Famille Souche' : 'Famille Alliée'})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-bold text-stone-800 mb-1">Nature du rattachement</label>
              <select
                value={belongingType}
                onChange={(e) => setBelongingType(e.target.value as MemberBelonging)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 text-stone-900 font-medium"
              >
                <option value="APPARTENANCE_DIRECTE">👑 Appartenance Directe (Lignée Sanguine Nzala)</option>
                <option value="ALLIANCE_MARIAGE">💍 Alliance par Mariage (Conjoint)</option>
                <option value="ALLIANCE_DESCENDANCE">🌿 Descendant issu d'une Alliance</option>
                <option value="ALLIANCE_AUTRE">🤝 Autre lien familial coutumier</option>
              </select>
            </div>
          </div>

          {/* Generation & Branch */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-stone-800 mb-1">Niveau Générationnel</label>
              <select
                value={generationLevel}
                onChange={(e) => setGenerationLevel(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 text-stone-900 font-semibold"
              >
                <option value={1}>G1 — Patriarcat Fondateur (Ancêtres / Patriarches)</option>
                <option value={2}>G2 — Aînés &amp; Piliers de Branches</option>
                <option value={3}>G3 — Descendants &amp; Forces Vives</option>
                <option value={4}>G4 — Jeunesse &amp; Avenir</option>
                <option value={5}>G5 — Cinquième Génération</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-stone-800 mb-1">Branche Familiale</label>
              <select
                value={branchId}
                onChange={(e) => setBranchId(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 text-stone-900"
              >
                <option value="">-- Aucune / Branche Principale --</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name} ({b.familyName})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Civil & Location */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Date de Naissance</label>
              <input
                type="date"
                value={birthDate}
                onChange={(e) => setBirthDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 text-stone-900"
              />
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">Lieu de Naissance</label>
              <input
                type="text"
                value={birthPlace}
                onChange={(e) => setBirthPlace(e.target.value)}
                placeholder="Ex: Boma, Kinshasa, Matadi..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 text-stone-900"
              />
            </div>
          </div>

          {/* Profession & Residence */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Profession / Rôle</label>
              <input
                type="text"
                value={profession}
                onChange={(e) => setProfession(e.target.value)}
                placeholder="Ex: Médecin, Enseignant, Juriste..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 text-stone-900"
              />
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">Résidence Actuelle</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Ex: Kinshasa (Ngaliema), Paris, Boma..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 text-stone-900"
              />
            </div>
          </div>

          {/* Visibility & Optional Account Link */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-stone-50 border border-stone-200">
            <div>
              <label className="block font-bold text-stone-800 mb-1">
                Niveau de Visibilité &amp; Confidentialité
              </label>
              <select
                value={visibilityLevel}
                onChange={(e) => setVisibilityLevel(e.target.value as VisibilityLevel)}
                className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white text-stone-900 font-semibold"
              >
                <option value="PUBLIC">🌐 Public (Consultable par tous)</option>
                <option value="FAMILY">🔒 Famille (Membres connectés seulement)</option>
                <option value="PRIVATE">🛡️ Privé (Réservé aux Administrateurs)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-stone-800 mb-1">
                Liaison Compte Utilisateur (Optionnel)
              </label>
              <select
                value={linkedUserId}
                onChange={(e) => setLinkedUserId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white text-stone-900"
              >
                <option value="">-- Aucun compte (Fiche sans compte) --</option>
                {unlinkedAccounts.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.firstName} {acc.lastName} ({acc.email})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Biography */}
          <div>
            <label className="block font-semibold text-stone-700 mb-1">
              Biographie &amp; Notes Historiques
            </label>
            <textarea
              rows={2}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Parcours de vie, faits marquants, rôle dans la famille..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 text-stone-900 focus:bg-white"
            />
          </div>

          {error && (
            <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold cursor-pointer"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-stone-950 font-bold shadow-xs cursor-pointer"
            >
              Créer la Fiche Membre
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
