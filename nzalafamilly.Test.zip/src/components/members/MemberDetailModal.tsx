import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { Member } from '../../types';
import {
  BelongingBadge,
  LivingStatusBadge,
  GenerationBadge,
  VisibilityBadge,
} from '../common/Badges';
import { AddRelationshipModal } from '../relationships/AddRelationshipModal';
import { PostCard } from '../feed/PostCard';
import {
  X,
  Heart,
  MapPin,
  Briefcase,
  Phone,
  Mail,
  Calendar,
  ShieldCheck,
  Link2,
  Users,
  Archive,
  KeyRound,
  Info,
  Newspaper,
  UserCheck,
} from 'lucide-react';

interface MemberDetailModalProps {
  member: Member;
  onClose: () => void;
}

export const MemberDetailModal: React.FC<MemberDetailModalProps> = ({ member, onClose }) => {
  const {
    currentUser,
    visiblePosts,
    setSelectedMember,
    getRelatives,
    getFilteredMember,
    userAccounts,
    updateMember,
    archiveMember,
    validateRelationshipAction,
  } = useFamily();

  const [activeTab, setActiveTab] = useState<'profile' | 'relationships' | 'alliance' | 'account' | 'posts'>('profile');
  const [showAddRelModal, setShowAddRelModal] = useState(false);
  const [isEditingVisibility, setIsEditingVisibility] = useState(false);
  const [selectedVisibility, setSelectedVisibility] = useState(member.visibilityLevel);

  const filtered = getFilteredMember(member);
  const relatives = getRelatives(member.id);

  // Publications liées au membre ou dont il est l'auteur
  const memberPosts = visiblePosts.filter(
    (p) =>
      p.authorId === member.id ||
      p.relatedMemberId === member.id ||
      (member.userId && p.authorId === member.userId)
  );

  const linkedUserAccount = member.userId
    ? userAccounts.find((u) => u.id === member.userId)
    : userAccounts.find(
        (u) => member.email && u.email.toLowerCase() === member.email.toLowerCase()
      );

  const canManageMembers =
    currentUser.role === 'SUPER_ADMIN' ||
    currentUser.role === 'ADMIN_FAMILIAL' ||
    currentUser.role === 'VALIDATEUR';

  const canEditMember =
    canManageMembers ||
    currentUser.memberId === member.id ||
    (currentUser.email && member.email && currentUser.email.toLowerCase() === member.email.toLowerCase());

  const handleSaveVisibility = () => {
    updateMember(member.id, { visibilityLevel: selectedVisibility });
    setIsEditingVisibility(false);
  };

  const handleArchive = () => {
    if (window.confirm(`Confirmez-vous l'archivage de la fiche de ${member.firstName} ${member.lastName} ?`)) {
      archiveMember(member.id);
      onClose();
    }
  };

  return (
    <>
      <div
        id="member-detail-backdrop"
        className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-slate-900/60 backdrop-blur-xs overflow-y-auto"
      >
        <div
          id="member-detail-modal"
          className="relative w-full max-w-3xl bg-white rounded-2xl sm:rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200 flex flex-col max-h-[92vh] sm:max-h-[90vh]"
        >
          {/* Modal Header */}
          <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white p-4 sm:p-6 relative shrink-0">
            <button
              onClick={onClose}
              className="absolute top-3.5 right-3.5 sm:top-5 sm:right-5 p-2 rounded-full bg-white/10 text-slate-300 hover:text-white hover:bg-white/20 transition cursor-pointer"
              aria-label="Fermer"
            >
              <X className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>

            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3.5 sm:gap-5 pr-8 sm:pr-0">
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-blue-600/30 border-2 border-blue-400/40 flex items-center justify-center text-xl sm:text-2xl font-bold text-blue-200 shrink-0 shadow-md">
                {member.firstName.charAt(0)}
                {member.lastName.charAt(0)}
              </div>

              <div className="space-y-1.5 flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
                  <BelongingBadge belonging={member.belongingType} familyType={member.familyType} />
                  <GenerationBadge level={member.generationLevel} status={member.generationStatus} />
                  <LivingStatusBadge
                    status={member.livingStatus}
                    deathDate={member.deathDate}
                    burialPlace={member.burialPlace}
                  />
                  <VisibilityBadge level={member.visibilityLevel} />
                </div>

                <div>
                  <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight truncate">
                    {member.firstName} {member.lastName}{' '}
                    {member.middleName && (
                      <span className="font-normal text-slate-300 text-sm">({member.middleName})</span>
                    )}
                  </h2>
                  {member.maidenName && (
                    <p className="text-xs text-blue-300 font-medium">
                      Nom de jeune fille : {member.maidenName}
                    </p>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs text-slate-300">
                  <span className="font-semibold text-blue-300">{member.primaryFamilyName}</span>
                  {member.branchName && (
                    <>
                      <span className="text-slate-500">•</span>
                      <span>{member.branchName}</span>
                    </>
                  )}
                  {member.location && (
                    <>
                      <span className="text-slate-500">•</span>
                      <span className="inline-flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                        <span className="truncate">{member.location}</span>
                      </span>
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Navigation Tabs inside Modal */}
            <div className="flex items-center gap-1.5 sm:gap-2 mt-4 sm:mt-5 border-t border-slate-700/60 pt-3 overflow-x-auto no-scrollbar">
              <button
                onClick={() => setActiveTab('profile')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition whitespace-nowrap cursor-pointer shrink-0 ${
                  activeTab === 'profile'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                Fiche &amp; Biographie
              </button>
              <button
                onClick={() => setActiveTab('relationships')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer shrink-0 ${
                  activeTab === 'relationships'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Link2 className="w-3.5 h-3.5" />
                <span>Réseau Familial ({relatives?.allRelationships.length || 0})</span>
                {relatives && relatives.pendingProposals.length > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-blue-400 text-slate-950 text-[10px] font-bold">
                    {relatives.pendingProposals.length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('alliance')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition whitespace-nowrap cursor-pointer shrink-0 ${
                  activeTab === 'alliance'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                Alliances ({relatives?.allies.length || 0})
              </button>
              <button
                onClick={() => setActiveTab('account')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer shrink-0 ${
                  activeTab === 'account'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <KeyRound className="w-3.5 h-3.5" />
                <span>Compte Utilisateur</span>
              </button>
              <button
                onClick={() => setActiveTab('posts')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer shrink-0 ${
                  activeTab === 'posts'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Newspaper className="w-3.5 h-3.5" />
                <span>Publications ({memberPosts.length})</span>
              </button>
            </div>
          </div>

          {/* Modal Body */}
          <div className="p-4 sm:p-6 space-y-5 overflow-y-auto flex-1 bg-slate-50/40">
            {/* TAB 1: Profile & Civil Info */}
            {activeTab === 'profile' && (
              <div className="space-y-5">
                {/* Primary Family & Branch Card */}
                <div className="p-4 rounded-2xl bg-white border border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs shadow-2xs">
                  <div>
                    <span className="text-slate-400 font-semibold uppercase tracking-wider block mb-1">
                      Famille de Rattachement
                    </span>
                    <span className="font-bold text-sm text-slate-900">{member.primaryFamilyName}</span>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {member.familyType === 'NZALA_DIRECT' ? 'Lignée Sanguine Nzala' : 'Famille Alliée'}
                    </p>
                  </div>

                  <div>
                    <span className="text-slate-400 font-semibold uppercase tracking-wider block mb-1">
                      Branche / Rameau
                    </span>
                    <span className="font-bold text-sm text-slate-900">
                      {member.branchName || 'Branche Principale'}
                    </span>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Génération G{member.generationLevel} ({member.generationStatus.toLowerCase()})
                    </p>
                  </div>
                </div>

                {/* Civil Details */}
                <div className="space-y-2.5">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    État Civil &amp; Lieux
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                    <div className="flex items-center gap-2.5 p-3 rounded-xl bg-white border border-slate-200 text-slate-800 shadow-2xs">
                      <Calendar className="w-4 h-4 text-blue-600 shrink-0" />
                      <div>
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">Naissance</span>
                        <span className="font-medium">
                          {filtered.birthDate ? filtered.birthDate : 'Non renseignée'}{' '}
                          {filtered.birthPlace && `à ${filtered.birthPlace}`}
                        </span>
                      </div>
                    </div>

                    {member.livingStatus === 'DECEDE' ? (
                      <div className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-100 border border-slate-300 text-slate-800 shadow-2xs">
                        <span className="text-base">🕊️</span>
                        <div>
                          <span className="text-slate-500 block text-[10px] uppercase font-bold">Décès &amp; Sépulture</span>
                          <span className="font-medium">
                            {member.deathDate || 'Date non précisée'}{' '}
                            {member.burialPlace && `(${member.burialPlace})`}
                          </span>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2.5 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 shadow-2xs">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0"></span>
                        <div>
                          <span className="text-emerald-700 block text-[10px] uppercase font-bold">Statut</span>
                          <span className="font-bold">Membre vivant</span>
                        </div>
                      </div>
                    )}

                    {filtered.profession && (
                      <div className="flex items-center gap-2.5 p-3 rounded-xl bg-white border border-slate-200 text-slate-800 shadow-2xs">
                        <Briefcase className="w-4 h-4 text-slate-500 shrink-0" />
                        <div>
                          <span className="text-slate-400 block text-[10px] uppercase font-bold">Profession</span>
                          <span className="font-medium">{filtered.profession}</span>
                        </div>
                      </div>
                    )}

                    {filtered.location && (
                      <div className="flex items-center gap-2.5 p-3 rounded-xl bg-white border border-slate-200 text-slate-800 shadow-2xs">
                        <MapPin className="w-4 h-4 text-slate-500 shrink-0" />
                        <div>
                          <span className="text-slate-400 block text-[10px] uppercase font-bold">Résidence</span>
                          <span className="font-medium">{filtered.location}</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Biography */}
                {filtered.bio && (
                  <div className="space-y-2">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Biographie &amp; Rôle Familial
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-700 leading-relaxed p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs">
                      {filtered.bio}
                    </p>
                  </div>
                )}

                {/* Contact (Subject to audience visibility) */}
                {(filtered.email || filtered.phone) && (
                  <div className="space-y-2">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Coordonnées de Contact
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                      {filtered.email && (
                        <div className="flex items-center gap-2 p-3 rounded-xl bg-white border border-slate-200 text-slate-800 shadow-2xs">
                          <Mail className="w-4 h-4 text-slate-400 shrink-0" />
                          <span className="truncate">{filtered.email}</span>
                        </div>
                      )}
                      {filtered.phone && (
                        <div className="flex items-center gap-2 p-3 rounded-xl bg-white border border-slate-200 text-slate-800 shadow-2xs">
                          <Phone className="w-4 h-4 text-slate-400 shrink-0" />
                          <span className="truncate">{filtered.phone}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Visibility Controls for Admins or Self */}
                {canEditMember && (
                  <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-3 shadow-2xs">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <ShieldCheck className="w-4 h-4 text-blue-600" />
                        <span className="font-bold text-xs text-slate-900">
                          Niveau de Confidentialité &amp; Visibilité
                        </span>
                      </div>
                      {!isEditingVisibility ? (
                        <button
                          onClick={() => setIsEditingVisibility(true)}
                          className="text-xs text-blue-600 hover:text-blue-700 font-semibold cursor-pointer"
                        >
                          Modifier
                        </button>
                      ) : (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={handleSaveVisibility}
                            className="px-3 py-1 rounded-lg bg-blue-600 text-white font-semibold text-xs cursor-pointer hover:bg-blue-700 transition"
                          >
                            Enregistrer
                          </button>
                          <button
                            onClick={() => setIsEditingVisibility(false)}
                            className="text-xs text-slate-500 cursor-pointer hover:text-slate-700"
                          >
                            Annuler
                          </button>
                        </div>
                      )}
                    </div>

                    {!isEditingVisibility ? (
                      <p className="text-xs text-slate-600">
                        Cette fiche est actuellement configurée en visibilité{' '}
                        <strong className="text-slate-900">{member.visibilityLevel}</strong>.
                      </p>
                    ) : (
                      <div className="grid grid-cols-3 gap-2 text-xs">
                        {(['PUBLIC', 'FAMILY', 'PRIVATE'] as const).map((lvl) => (
                          <button
                            key={lvl}
                            type="button"
                            onClick={() => setSelectedVisibility(lvl)}
                            className={`p-2.5 rounded-xl border text-center font-semibold cursor-pointer transition ${
                              selectedVisibility === lvl
                                ? 'bg-blue-50 border-blue-400 text-blue-900 shadow-2xs'
                                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                            }`}
                          >
                            {lvl === 'PUBLIC' && '🌐 Public'}
                            {lvl === 'FAMILY' && '🔒 Famille'}
                            {lvl === 'PRIVATE' && '🛡️ Privé'}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: Family Relationships Network */}
            {activeTab === 'relationships' && (
              <div className="space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="font-bold text-sm text-slate-900">
                      Réseau de parenté &amp; Filiations validées
                    </h3>
                    <p className="text-xs text-slate-500">
                      Liens généalogiques directs enregistrés dans le grand livre familial.
                    </p>
                  </div>

                  <button
                    onClick={() => setShowAddRelModal(true)}
                    className="flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-2xs transition cursor-pointer self-start sm:self-auto"
                  >
                    <Link2 className="w-3.5 h-3.5" />
                    <span>
                      {canManageMembers ? 'Ajouter une relation' : 'Proposer une relation'}
                    </span>
                  </button>
                </div>

                {/* Pending Proposals Section */}
                {relatives && relatives.pendingProposals.length > 0 && (
                  <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200 space-y-3">
                    <div className="flex items-center gap-2 text-xs font-bold text-amber-950">
                      <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
                      <span>Propositions de relations en attente d'examen ({relatives.pendingProposals.length}) :</span>
                    </div>

                    <div className="space-y-2">
                      {relatives.pendingProposals.map((prop) => (
                        <div
                          key={prop.id}
                          className="p-3 rounded-xl bg-white border border-amber-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5 text-xs shadow-2xs"
                        >
                          <div>
                            <div className="font-bold text-slate-900">
                              {prop.roleLabel} : {prop.relatedMember.firstName} {prop.relatedMember.lastName}
                            </div>
                            <div className="text-[11px] text-slate-500">
                              Proposé par {prop.proposedByName || 'un membre'} {prop.notes && `• "${prop.notes}"`}
                            </div>
                          </div>

                          {canManageMembers && (
                            <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-auto">
                              <button
                                onClick={() => validateRelationshipAction(prop.id, 'VALIDEE')}
                                className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs transition cursor-pointer"
                              >
                                Valider
                              </button>
                              <button
                                onClick={() => validateRelationshipAction(prop.id, 'REFUSEE')}
                                className="px-2.5 py-1 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-semibold transition cursor-pointer"
                              >
                                Refuser
                              </button>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Structured Relatives Groups */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  {/* Parents */}
                  <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-2.5 shadow-2xs">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-blue-600" />
                      <span>Parents &amp; Ascendance ({relatives?.parents.length || 0})</span>
                    </h4>
                    {relatives && relatives.parents.length > 0 ? (
                      <div className="space-y-2">
                        {relatives.parents.map(({ member: p }) => (
                          <div
                            key={p.id}
                            onClick={() => setSelectedMember(p)}
                            className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 hover:border-blue-400 transition cursor-pointer flex items-center justify-between"
                          >
                            <div className="text-xs">
                              <span className="font-bold text-slate-900 block">
                                {p.firstName} {p.lastName}
                              </span>
                              <span className="text-[11px] text-slate-500">
                                {p.gender === 'F' ? 'Mère' : 'Père'} • G{p.generationLevel} ({p.primaryFamilyName})
                              </span>
                            </div>
                            <span className="text-[11px] text-blue-600 font-semibold">Voir →</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-slate-400 italic">Aucun parent répertorié pour le moment.</p>
                    )}
                  </div>

                  {/* Children */}
                  <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-2.5 shadow-2xs">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Enfants &amp; Descendance ({relatives?.children.length || 0})</span>
                    </h4>
                    {relatives && relatives.children.length > 0 ? (
                      <div className="space-y-2">
                        {relatives.children.map(({ member: c }) => (
                          <div
                            key={c.id}
                            onClick={() => setSelectedMember(c)}
                            className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 hover:border-blue-400 transition cursor-pointer flex items-center justify-between"
                          >
                            <div className="text-xs">
                              <span className="font-bold text-slate-900 block">
                                {c.firstName} {c.lastName}
                              </span>
                              <span className="text-[11px] text-slate-500">
                                {c.gender === 'F' ? 'Fille' : 'Fils'} • G{c.generationLevel}
                              </span>
                            </div>
                            <span className="text-[11px] text-blue-600 font-semibold">Voir →</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-slate-400 italic">Aucun enfant répertorié.</p>
                    )}
                  </div>

                  {/* Spouses */}
                  <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-2.5 shadow-2xs">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                      <Heart className="w-3.5 h-3.5 text-rose-600" />
                      <span>Conjoint(s) &amp; Alliances ({relatives?.spouses.length || 0})</span>
                    </h4>
                    {relatives && relatives.spouses.length > 0 ? (
                      <div className="space-y-2">
                        {relatives.spouses.map(({ member: sp }) => (
                          <div
                            key={sp.id}
                            onClick={() => setSelectedMember(sp)}
                            className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 hover:border-blue-400 transition cursor-pointer flex items-center justify-between"
                          >
                            <div className="text-xs">
                              <span className="font-bold text-slate-900 block">
                                {sp.firstName} {sp.lastName}
                              </span>
                              <span className="text-[11px] text-slate-500">
                                {sp.gender === 'F' ? 'Épouse' : 'Époux'} • {sp.primaryFamilyName}
                              </span>
                            </div>
                            <span className="text-[11px] text-blue-600 font-semibold">Voir →</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-slate-400 italic">Aucun conjoint répertorié.</p>
                    )}
                  </div>

                  {/* Siblings */}
                  <div className="p-4 rounded-2xl bg-white border border-slate-200 space-y-2.5 shadow-2xs">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-teal-600" />
                      <span>Frères &amp; Sœurs ({relatives?.siblings.length || 0})</span>
                    </h4>
                    {relatives && relatives.siblings.length > 0 ? (
                      <div className="space-y-2">
                        {relatives.siblings.map(({ member: sib }) => (
                          <div
                            key={sib.id}
                            onClick={() => setSelectedMember(sib)}
                            className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 hover:border-blue-400 transition cursor-pointer flex items-center justify-between"
                          >
                            <div className="text-xs">
                              <span className="font-bold text-slate-900 block">
                                {sib.firstName} {sib.lastName}
                              </span>
                              <span className="text-[11px] text-slate-500">
                                {sib.gender === 'F' ? 'Sœur' : 'Frère'} • G{sib.generationLevel}
                              </span>
                            </div>
                            <span className="text-[11px] text-blue-600 font-semibold">Voir →</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-xs text-slate-400 italic">Aucun membre de la fratrie répertorié.</p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: Alliances & Allied Families */}
            {activeTab === 'alliance' && (
              <div className="space-y-4">
                <div>
                  <h3 className="font-bold text-sm text-slate-900">
                    Liaisons aux Familles Alliées
                  </h3>
                  <p className="text-xs text-slate-500">
                    Ponts coutumiers et mariages reliant la personne à une famille partenaire.
                  </p>
                </div>

                {relatives && relatives.allies.length > 0 ? (
                  <div className="space-y-3">
                    {relatives.allies.map(({ member: allie, allianceTitle }) => (
                      <div
                        key={allie.id}
                        className="p-4 rounded-2xl bg-white border border-slate-200 space-y-2 text-xs shadow-2xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-sm text-slate-900">
                            {allie.firstName} {allie.lastName}
                          </span>
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-800 border border-blue-200">
                            {allie.primaryFamilyName}
                          </span>
                        </div>
                        {allianceTitle && (
                          <p className="text-xs text-indigo-900 font-semibold">
                            📜 {allianceTitle}
                          </p>
                        )}
                        <p className="text-slate-600">
                          Alliance formalisée par {allie.gender === 'F' ? 'l\'épouse' : 'l\'époux'} issue de la {allie.primaryFamilyName}.
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-8 rounded-2xl bg-white border border-slate-200 text-center text-xs text-slate-500 space-y-2">
                    <p>Aucune alliance officielle rattachée directement à cette fiche membre.</p>
                    <p className="text-[11px] text-slate-400">
                      Les alliances sont scellées lors des mariages entre la Famille Nzala et les Familles Alliées.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* TAB 4: User Account & Platform Identity */}
            {activeTab === 'account' && (
              <div className="space-y-4">
                <div>
                  <h3 className="font-bold text-sm text-slate-900">
                    Compte Utilisateur &amp; Sécurité
                  </h3>
                  <p className="text-xs text-slate-500">
                    Statut du compte numérique permettant à cette personne d'accéder à la plateforme.
                  </p>
                </div>

                {linkedUserAccount ? (
                  <div className="p-4 sm:p-5 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-3 text-xs text-emerald-950">
                    <div className="flex items-center gap-2 font-bold text-sm text-emerald-900">
                      <ShieldCheck className="w-5 h-5 text-emerald-700" />
                      <span>Compte numérique actif et associé</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-slate-700">
                      <div>
                        <span className="text-slate-400 uppercase text-[10px] font-bold block">Identifiant email</span>
                        <span className="font-semibold text-slate-900 break-all">{linkedUserAccount.email}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 uppercase text-[10px] font-bold block">Rôle Plateforme</span>
                        <span className="font-semibold text-slate-900">{linkedUserAccount.role}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 uppercase text-[10px] font-bold block">Statut du compte</span>
                        <span className="font-semibold text-slate-900">{linkedUserAccount.accountStatus}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 uppercase text-[10px] font-bold block">Sécurité 2FA</span>
                        <span>{linkedUserAccount.twoFactorEnabled ? 'Activée (Sécurisé)' : 'Désactivée'}</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="p-5 rounded-2xl bg-white border border-slate-200 space-y-3 text-xs text-slate-700 shadow-2xs">
                    <div className="flex items-center gap-2 font-bold text-slate-900">
                      <Info className="w-4 h-4 text-blue-600" />
                      <span>Fiche sans compte utilisateur actif</span>
                    </div>
                    <p className="text-slate-600 leading-relaxed">
                      {member.livingStatus === 'DECEDE'
                        ? 'Cette personne est un ancêtre ou aîné décédé inscrit au grand livre généalogique pour la mémoire historique de la famille.'
                        : 'Cette personne ne possède pas encore de compte de connexion personnel sur NzalaFamilly, ou son compte n\'a pas encore été rattaché par un administrateur.'}
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* TAB 5: Member Posts & Publications */}
            {activeTab === 'posts' && (
              <div className="space-y-4">
                <div>
                  <h3 className="font-bold text-sm text-slate-900">
                    Publications &amp; Communiqués liés
                  </h3>
                  <p className="text-xs text-slate-500">
                    Messages rédigés par {member.firstName} ou le concernant sur le fil d'actualité.
                  </p>
                </div>

                {memberPosts.length > 0 ? (
                  <div className="space-y-4">
                    {memberPosts.map((post) => (
                      <PostCard key={post.id} post={post} />
                    ))}
                  </div>
                ) : (
                  <div className="p-8 rounded-2xl bg-white border border-slate-200 text-center text-xs text-slate-500 space-y-2">
                    <p>Aucune publication publique ou accessible pour ce membre pour le moment.</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Modal Footer */}
          <div className="p-3.5 sm:p-4 bg-white border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
            {canManageMembers && (
              <button
                onClick={handleArchive}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold border border-slate-300 transition cursor-pointer"
              >
                <Archive className="w-3.5 h-3.5 text-slate-500" />
                <span>Archiver la fiche</span>
              </button>
            )}

            <div className="flex items-center gap-2 ml-auto">
              <button
                onClick={onClose}
                className="px-5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold transition cursor-pointer"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Embedded Add/Propose Relationship Modal */}
      {showAddRelModal && (
        <AddRelationshipModal
          isOpen={showAddRelModal}
          onClose={() => setShowAddRelModal(false)}
          initialMemberAId={member.id}
        />
      )}
    </>
  );
};

