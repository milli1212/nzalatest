import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { Member, MemberBelonging, LivingStatus } from '../../types';
import {
  BelongingBadge,
  FamilyTypeBadge,
  LivingStatusBadge,
  GenerationBadge,
  VisibilityBadge,
} from '../common/Badges';
import { MemberDetailModal } from './MemberDetailModal';
import { AddMemberModal } from './AddMemberModal';
import { AddRelationshipModal } from '../relationships/AddRelationshipModal';
import {
  Users,
  Search,
  Plus,
  Filter,
  Award,
  HeartHandshake,
  MapPin,
  Briefcase,
  ChevronRight,
  Sparkles,
  Link2,
  KeyRound,
  Eye,
  CheckCircle2,
} from 'lucide-react';

export const MembersView: React.FC = () => {
  const {
    members,
    families,
    selectedMember,
    setSelectedMember,
    currentUser,
    can,
    getFilteredMember,
  } = useFamily();

  const [activeFilter, setActiveFilter] = useState<'ALL' | 'NZALA' | 'ALLIES' | 'GEN_1' | 'GEN_2' | 'GEN_3' | 'GEN_4' | 'LIVING' | 'DECEASED'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFamilyId, setSelectedFamilyId] = useState<string>('ALL');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isAddRelModalOpen, setIsAddRelModalOpen] = useState(false);

  // Filter members logic
  const filteredMembers = members.filter((rawMember) => {
    const member = getFilteredMember(rawMember);

    // Category filter
    if (activeFilter === 'NZALA' && member.familyType !== 'NZALA_DIRECT') return false;
    if (activeFilter === 'ALLIES' && member.familyType !== 'ALLIE') return false;
    if (activeFilter === 'GEN_1' && member.generationLevel !== 1) return false;
    if (activeFilter === 'GEN_2' && member.generationLevel !== 2) return false;
    if (activeFilter === 'GEN_3' && member.generationLevel !== 3) return false;
    if (activeFilter === 'GEN_4' && member.generationLevel !== 4) return false;
    if (activeFilter === 'LIVING' && member.livingStatus !== 'VIVANT') return false;
    if (activeFilter === 'DECEASED' && member.livingStatus !== 'DECEDE') return false;

    // Specific Family filter
    if (selectedFamilyId !== 'ALL' && member.primaryFamilyId !== selectedFamilyId) return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = `${member.firstName} ${member.lastName} ${member.middleName || ''} ${member.maidenName || ''}`.toLowerCase();
      const matchFamily = member.primaryFamilyName.toLowerCase();
      const matchProfession = (member.profession || '').toLowerCase();
      const matchLocation = (member.location || '').toLowerCase();
      const matchBranch = (member.branchName || '').toLowerCase();

      return (
        matchName.includes(q) ||
        matchFamily.includes(q) ||
        matchProfession.includes(q) ||
        matchLocation.includes(q) ||
        matchBranch.includes(q)
      );
    }

    return true;
  });

  const nzalaCount = members.filter((m) => m.familyType === 'NZALA_DIRECT').length;
  const alliesCount = members.filter((m) => m.familyType === 'ALLIE').length;
  const livingCount = members.filter((m) => m.livingStatus === 'VIVANT').length;
  const deceasedCount = members.filter((m) => m.livingStatus === 'DECEDE').length;

  const canAddMember =
    currentUser.role === 'SUPER_ADMIN' ||
    currentUser.role === 'ADMIN_FAMILIAL' ||
    can('MANAGE_FAMILIES');

  return (
    <div id="members-view" className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-stone-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-serif font-bold text-stone-900">
              Grand Registre &amp; Annuaire Familial
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-stone-100 text-stone-700 border border-stone-300">
              {filteredMembers.length} fiches affichées
            </span>
          </div>
          <p className="text-xs sm:text-sm text-stone-500 mt-1">
            Répertoire souverain distinguant la <strong>Lignée Sanguine Nzala</strong> et les <strong>Familles Alliées</strong> (G1 à G4).
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={() => setIsAddRelModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-xs border border-stone-300 transition cursor-pointer"
          >
            <Link2 className="w-4 h-4 text-amber-700" />
            <span>Lier / Proposer une relation</span>
          </button>

          {canAddMember && (
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-stone-950 font-bold text-xs transition shadow-md shadow-amber-950/20 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Créer une fiche membre</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Main Filter Chips */}
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setActiveFilter('ALL')}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition cursor-pointer ${
                activeFilter === 'ALL'
                  ? 'bg-stone-900 text-stone-100 shadow-xs'
                  : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
              }`}
            >
              Tous ({members.length})
            </button>

            <button
              onClick={() => setActiveFilter('NZALA')}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                activeFilter === 'NZALA'
                  ? 'bg-amber-700 text-amber-50 shadow-xs'
                  : 'bg-white text-amber-900 hover:bg-amber-50 border border-amber-300'
              }`}
            >
              <Award className="w-3.5 h-3.5" />
              <span>Lignée Nzala ({nzalaCount})</span>
            </button>

            <button
              onClick={() => setActiveFilter('ALLIES')}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer ${
                activeFilter === 'ALLIES'
                  ? 'bg-sky-700 text-sky-50 shadow-xs'
                  : 'bg-white text-sky-900 hover:bg-sky-50 border border-sky-300'
              }`}
            >
              <HeartHandshake className="w-3.5 h-3.5" />
              <span>Familles Alliées ({alliesCount})</span>
            </button>

            <button
              onClick={() => setActiveFilter('LIVING')}
              className={`px-3 py-2 rounded-xl text-xs font-medium transition cursor-pointer ${
                activeFilter === 'LIVING'
                  ? 'bg-emerald-800 text-emerald-50 shadow-xs'
                  : 'bg-white text-emerald-900 hover:bg-emerald-50 border border-emerald-300'
              }`}
            >
              🟢 Vivants ({livingCount})
            </button>

            <button
              onClick={() => setActiveFilter('DECEASED')}
              className={`px-3 py-2 rounded-xl text-xs font-medium transition cursor-pointer ${
                activeFilter === 'DECEASED'
                  ? 'bg-stone-800 text-stone-100 shadow-xs'
                  : 'bg-white text-stone-700 hover:bg-stone-100 border border-stone-300'
              }`}
            >
              🕊️ En mémoire ({deceasedCount})
            </button>

            <button
              onClick={() => setActiveFilter('GEN_1')}
              className={`px-3 py-2 rounded-xl text-xs font-medium transition cursor-pointer ${
                activeFilter === 'GEN_1'
                  ? 'bg-stone-800 text-stone-100'
                  : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
              }`}
            >
              G1 (Fondateurs)
            </button>

            <button
              onClick={() => setActiveFilter('GEN_2')}
              className={`px-3 py-2 rounded-xl text-xs font-medium transition cursor-pointer ${
                activeFilter === 'GEN_2'
                  ? 'bg-stone-800 text-stone-100'
                  : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
              }`}
            >
              G2 (Aînés)
            </button>

            <button
              onClick={() => setActiveFilter('GEN_3')}
              className={`px-3 py-2 rounded-xl text-xs font-medium transition cursor-pointer ${
                activeFilter === 'GEN_3'
                  ? 'bg-stone-800 text-stone-100'
                  : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
              }`}
            >
              G3 (Descendants)
            </button>
          </div>

          {/* Family specific filter dropdown */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-stone-500 font-medium hidden sm:inline">Famille spécifique :</span>
            <select
              value={selectedFamilyId}
              onChange={(e) => setSelectedFamilyId(e.target.value)}
              className="px-3 py-2 rounded-xl bg-white border border-stone-200 text-xs font-medium text-stone-700 focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer"
            >
              <option value="ALL">Toutes les familles</option>
              {families.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name} ({f.type === 'PRINCIPALE' ? 'Famille Souche' : 'Famille Alliée'})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Search input */}
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher par nom, prénom, famille, profession, branche, ville..."
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white border border-stone-200 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 shadow-xs"
          />
        </div>
      </div>

      {/* Members Grid */}
      {filteredMembers.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredMembers.map((rawMember) => {
            const member = getFilteredMember(rawMember);
            const isNzalaDirect = member.familyType === 'NZALA_DIRECT';

            return (
              <div
                key={member.id}
                onClick={() => setSelectedMember(rawMember)}
                className={`p-5 rounded-3xl bg-white border transition-all duration-200 hover:shadow-md cursor-pointer flex flex-col justify-between space-y-4 group ${
                  isNzalaDirect
                    ? 'border-stone-200 hover:border-amber-400'
                    : 'border-stone-200 hover:border-sky-400'
                }`}
              >
                <div className="space-y-3">
                  {/* Card Top / Avatar + Badges */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-12 h-12 rounded-2xl flex items-center justify-center font-serif font-bold text-base shrink-0 border shadow-xs ${
                          isNzalaDirect
                            ? 'bg-amber-50 text-amber-900 border-amber-200 group-hover:bg-amber-100'
                            : 'bg-sky-50 text-sky-900 border-sky-200 group-hover:bg-sky-100'
                        }`}
                      >
                        {member.firstName.charAt(0)}
                        {member.lastName.charAt(0)}
                      </div>

                      <div>
                        <div className="flex items-center gap-1.5">
                          <h3 className="font-serif font-bold text-stone-900 text-base leading-snug group-hover:text-amber-800 transition-colors">
                            {member.firstName} {member.lastName}
                          </h3>
                        </div>
                        {member.middleName && (
                          <p className="text-xs text-stone-500">{member.middleName}</p>
                        )}
                        {member.maidenName && (
                          <p className="text-[11px] text-amber-700 font-medium">
                            née {member.maidenName}
                          </p>
                        )}
                      </div>
                    </div>

                    <GenerationBadge level={member.generationLevel} />
                  </div>

                  {/* Status Badges Row */}
                  <div className="flex flex-wrap items-center gap-1.5">
                    <BelongingBadge
                      belonging={member.belongingType}
                      familyType={member.familyType}
                      size="sm"
                    />
                    <LivingStatusBadge
                      status={member.livingStatus}
                      deathDate={member.deathDate}
                      burialPlace={member.burialPlace}
                      size="sm"
                    />
                  </div>

                  {/* Family and Branch */}
                  <div className="text-xs space-y-1 pt-1">
                    <div className="flex items-center gap-1 text-stone-600">
                      <span className="font-semibold text-stone-800">Famille :</span>
                      <span className="font-medium text-stone-900">{member.primaryFamilyName}</span>
                    </div>

                    {member.branchName && (
                      <div className="text-stone-500 truncate">
                        Branche : {member.branchName}
                      </div>
                    )}
                  </div>

                  {/* Location & Profession */}
                  <div className="pt-2 border-t border-stone-100 flex flex-wrap gap-2 text-[11px] text-stone-500">
                    {member.location && (
                      <span className="inline-flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-stone-400" />
                        {member.location}
                      </span>
                    )}
                    {member.profession && (
                      <span className="inline-flex items-center gap-1">
                        <Briefcase className="w-3 h-3 text-stone-400" />
                        {member.profession}
                      </span>
                    )}
                  </div>
                </div>

                {/* Footer action */}
                <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-xs font-semibold text-amber-800 group-hover:text-amber-900">
                  <span className="flex items-center gap-1">
                    <Eye className="w-3.5 h-3.5" />
                    <span>Consulter la fiche &amp; filiations</span>
                  </span>
                  <ChevronRight className="w-4 h-4 text-amber-600 transition-transform group-hover:translate-x-0.5" />
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="p-12 text-center bg-white rounded-3xl border border-stone-200 space-y-3">
          <Users className="w-10 h-10 text-stone-400 mx-auto" />
          <h3 className="text-base font-bold text-stone-800">Aucun membre ne correspond aux critères</h3>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            Essayez de modifier vos filtres de recherche ou de réinitialiser la sélection de famille.
          </p>
          <button
            onClick={() => {
              setActiveFilter('ALL');
              setSelectedFamilyId('ALL');
              setSearchQuery('');
            }}
            className="px-4 py-2 rounded-xl bg-stone-900 text-stone-100 text-xs font-semibold cursor-pointer"
          >
            Réinitialiser les filtres
          </button>
        </div>
      )}

      {/* Member Details Modal */}
      {selectedMember && (
        <MemberDetailModal
          member={selectedMember}
          onClose={() => setSelectedMember(null)}
        />
      )}

      {/* Add Member Modal */}
      {isAddModalOpen && <AddMemberModal onClose={() => setIsAddModalOpen(false)} />}

      {/* Add / Propose Relationship Modal */}
      {isAddRelModalOpen && (
        <AddRelationshipModal
          isOpen={isAddRelModalOpen}
          onClose={() => setIsAddRelModalOpen(false)}
        />
      )}
    </div>
  );
};
