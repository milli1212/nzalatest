import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { NzalaLogo } from '../common/NzalaLogo';
import { NzalaAvatar } from '../common/NzalaAvatar';
import { RoleBadge } from '../common/Badges';
import { LightboxModal } from '../social/LightboxModal';
import {
  BookOpen,
  Image as ImageIcon,
  Sparkles,
  Award,
  Crown,
  History,
  Feather,
  Quote,
  ShieldCheck,
  Calendar,
  MapPin,
  Heart,
  MessageSquare,
  Share2,
  Filter,
  Search,
  PlusCircle,
  ExternalLink,
  ChevronRight,
  Bookmark,
  Users,
  Compass,
  CheckCircle2,
} from 'lucide-react';
import { MemoryAlbum, MemoryAlbumCategory, HistoricalPublication, MediaItem, Member } from '../../types';

export const MemoireNzalaView: React.FC = () => {
  const {
    members,
    memoryAlbums,
    historicalPublications,
    currentUser,
    setActiveTab,
    setSelectedMember,
    can,
    showToast,
  } = useFamily();

  // Tab: 'NARRATIVES' (Récits Historiques) | 'ALBUMS' (Galerie d'Archives) | 'ELDERS' (Figures & Fondateurs)
  const [activeSubTab, setActiveSubTab] = useState<'NARRATIVES' | 'ALBUMS' | 'ELDERS'>('NARRATIVES');

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  // Lightbox viewer state
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxMedia, setLightboxMedia] = useState<MediaItem[]>([]);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  // Selected Narrative for Detail View
  const [selectedNarrative, setSelectedNarrative] = useState<HistoricalPublication | null>(null);

  // Selected Album for Detail View
  const [selectedAlbum, setSelectedAlbum] = useState<MemoryAlbum | null>(null);

  // Historical elders (deceased or G1/G2 founders)
  const historicalElders = members.filter(
    (m) => m.livingStatus === 'DECEDE' || m.generationLevel === 1 || m.isHistoricalFigure
  );

  // Filtered narratives
  const filteredNarratives = historicalPublications.filter((pub) => {
    const matchesSearch =
      pub.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      pub.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      pub.fullNarrative.toLowerCase().includes(searchQuery.toLowerCase()) ||
      pub.relatedPersonNames.some((n) => n.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesSearch;
  });

  // Filtered albums
  const filteredAlbums = memoryAlbums.filter((alb) => {
    const matchesCat = selectedCategory === 'ALL' || alb.category === selectedCategory;
    const matchesSearch =
      alb.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      alb.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const openLightbox = (mediaItems: MediaItem[], initialIndex = 0) => {
    if (!mediaItems || mediaItems.length === 0) return;
    setLightboxMedia(mediaItems);
    setLightboxIndex(initialIndex);
    setLightboxOpen(true);
  };

  const handleShare = (title: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      showToast('info', 'Lien du récit historique copié dans le presse-papiers.');
    }
  };

  return (
    <div id="memoire-nzala-view" className="space-y-8 pb-16">
      {/* Hero Patrimoine & Mémoire */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-stone-950 via-stone-900 to-amber-950/70 border border-amber-500/30 text-stone-100 p-6 sm:p-10 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none -ml-16 -mb-16" />

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold uppercase tracking-widest">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Patrimoine &amp; Mémoire Nzala</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-stone-100 tracking-tight leading-tight">
            Mémoire des Grands &amp; Archives Historiques
          </h1>

          <p className="text-sm sm:text-base text-stone-300 leading-relaxed font-normal">
            Préserver les récits des fondateurs, honorer nos ancêtres disparus et transmettre aux générations futures
            les pactes d'alliances, photographies d'époque et enseignements coutumiers de la <strong>Famille Nzala</strong>.
          </p>

          {/* Quick Metrics Bar */}
          <div className="pt-3 flex flex-wrap items-center gap-4 text-xs text-stone-300">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-900/80 border border-stone-800">
              <History className="w-4 h-4 text-amber-400" />
              <span><strong>{historicalPublications.length}</strong> Récits Archivés</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-900/80 border border-stone-800">
              <ImageIcon className="w-4 h-4 text-amber-400" />
              <span><strong>{memoryAlbums.length}</strong> Albums d'Époque</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-900/80 border border-stone-800">
              <Crown className="w-4 h-4 text-amber-400" />
              <span><strong>{historicalElders.length}</strong> Figures &amp; Patriarches</span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-stone-200 dark:border-stone-800 pb-4">
        <div className="flex items-center gap-2 p-1 bg-stone-200 dark:bg-stone-800 rounded-2xl">
          <button
            id="tab-narratives"
            onClick={() => {
              setActiveSubTab('NARRATIVES');
              setSelectedNarrative(null);
              setSelectedAlbum(null);
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
              activeSubTab === 'NARRATIVES'
                ? 'bg-amber-600 text-stone-950 shadow-md'
                : 'text-stone-700 dark:text-stone-300 hover:text-stone-950 dark:hover:text-white'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Récits Historiques ({historicalPublications.length})</span>
          </button>

          <button
            id="tab-albums"
            onClick={() => {
              setActiveSubTab('ALBUMS');
              setSelectedNarrative(null);
              setSelectedAlbum(null);
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
              activeSubTab === 'ALBUMS'
                ? 'bg-amber-600 text-stone-950 shadow-md'
                : 'text-stone-700 dark:text-stone-300 hover:text-stone-950 dark:hover:text-white'
            }`}
          >
            <ImageIcon className="w-4 h-4" />
            <span>Albums de Mémoire ({memoryAlbums.length})</span>
          </button>

          <button
            id="tab-elders"
            onClick={() => {
              setActiveSubTab('ELDERS');
              setSelectedNarrative(null);
              setSelectedAlbum(null);
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
              activeSubTab === 'ELDERS'
                ? 'bg-amber-600 text-stone-950 shadow-md'
                : 'text-stone-700 dark:text-stone-300 hover:text-stone-950 dark:hover:text-white'
            }`}
          >
            <Crown className="w-4 h-4" />
            <span>Figures &amp; Patriarches ({historicalElders.length})</span>
          </button>
        </div>

        {/* Search Field */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Rechercher une figure, date, souvenir..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9.5 pr-4 py-2 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 text-xs sm:text-sm text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-hidden focus:ring-2 focus:ring-amber-500"
          />
        </div>
      </div>

      {/* --- SUB-TAB 1: RÉCITS HISTORIQUES --- */}
      {activeSubTab === 'NARRATIVES' && !selectedNarrative && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredNarratives.map((pub) => (
              <article
                key={pub.id}
                className="bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-sm hover:border-amber-500/50 hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col justify-between group"
              >
                <div>
                  {/* Photo Preview if available */}
                  {pub.photos && pub.photos.length > 0 && (
                    <div
                      className="relative h-56 sm:h-64 w-full overflow-hidden bg-stone-950 cursor-pointer"
                      onClick={() => openLightbox(pub.photos, 0)}
                    >
                      <img
                        src={pub.photos[0].url}
                        alt={pub.photos[0].caption || pub.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-stone-950/20 to-transparent" />
                      <div className="absolute top-4 left-4">
                        <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-amber-500 text-stone-950 shadow-md">
                          {pub.historicalPeriod}
                        </span>
                      </div>
                      {pub.photos.length > 1 && (
                        <div className="absolute bottom-3 right-3 px-2.5 py-1 rounded-lg bg-stone-900/80 text-amber-300 text-xs font-bold backdrop-blur-xs flex items-center gap-1.5">
                          <ImageIcon className="w-3.5 h-3.5" />
                          <span>+{pub.photos.length - 1} photos</span>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="p-6 space-y-3">
                    <div className="flex items-center justify-between text-xs text-stone-500 dark:text-stone-400">
                      {pub.location && (
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-amber-500" />
                          <span>{pub.location}</span>
                        </span>
                      )}
                      {pub.verifiedByCouncil && (
                        <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold">
                          <ShieldCheck className="w-3.5 h-3.5" />
                          <span>Certifié par le Conseil</span>
                        </span>
                      )}
                    </div>

                    <h2 className="text-xl sm:text-2xl font-serif font-bold text-stone-900 dark:text-stone-100 leading-snug group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors">
                      {pub.title}
                    </h2>

                    <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-300 line-clamp-3 leading-relaxed">
                      {pub.summary}
                    </p>

                    {/* Personnes concernées */}
                    <div className="pt-2 flex flex-wrap gap-1.5">
                      {pub.relatedPersonNames.map((name, i) => (
                        <span
                          key={i}
                          className="px-2 py-0.5 rounded-md bg-stone-100 dark:bg-stone-800 text-[11px] font-semibold text-stone-700 dark:text-stone-300"
                        >
                          👤 {name}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="p-6 pt-0 flex items-center justify-between border-t border-stone-100 dark:border-stone-800/80 mt-4 text-xs">
                  <div className="text-stone-500 dark:text-stone-400 font-medium">
                    Par <strong className="text-stone-700 dark:text-stone-200">{pub.authorName}</strong>
                  </div>

                  <button
                    onClick={() => setSelectedNarrative(pub)}
                    className="flex items-center gap-1.5 font-bold text-amber-600 dark:text-amber-400 hover:text-amber-700 transition cursor-pointer"
                  >
                    <span>Lire le récit complet</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      )}

      {/* Detail View of a Single Historical Narrative */}
      {selectedNarrative && (
        <div className="bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-xl overflow-hidden animate-in fade-in duration-200">
          <div className="p-6 sm:p-10 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between">
            <button
              onClick={() => setSelectedNarrative(null)}
              className="flex items-center gap-2 text-xs sm:text-sm font-bold text-stone-600 dark:text-stone-300 hover:text-amber-600 transition cursor-pointer"
            >
              <ChevronRight className="w-4 h-4 rotate-180" />
              <span>Retour aux récits historiques</span>
            </button>

            <button
              onClick={() => handleShare(selectedNarrative.title)}
              className="p-2 rounded-xl bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300 hover:text-amber-500 transition cursor-pointer"
              title="Partager ce témoignage"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>

          <div className="p-6 sm:p-10 max-w-4xl mx-auto space-y-8">
            <div className="space-y-3">
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="px-3 py-1 rounded-full font-bold bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-500/30">
                  {selectedNarrative.historicalPeriod}
                </span>
                {selectedNarrative.location && (
                  <span className="flex items-center gap-1 text-stone-500">
                    <MapPin className="w-3.5 h-3.5 text-amber-500" />
                    {selectedNarrative.location}
                  </span>
                )}
                {selectedNarrative.verifiedByCouncil && (
                  <span className="flex items-center gap-1 text-emerald-600 font-bold ml-auto">
                    <ShieldCheck className="w-4 h-4" />
                    Certifié et consigné par le Conseil des Sages
                  </span>
                )}
              </div>

              <h1 className="text-2xl sm:text-4xl font-serif font-bold text-stone-900 dark:text-stone-100 leading-tight">
                {selectedNarrative.title}
              </h1>

              <p className="text-sm font-serif italic text-amber-700 dark:text-amber-300/90 leading-relaxed border-l-3 border-amber-500 pl-4 py-1">
                "{selectedNarrative.summary}"
              </p>
            </div>

            {/* Photos Gallery within the article */}
            {selectedNarrative.photos && selectedNarrative.photos.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {selectedNarrative.photos.map((photo, idx) => (
                  <div
                    key={photo.id}
                    className="group relative rounded-2xl overflow-hidden border border-stone-200 dark:border-stone-800 bg-stone-950 cursor-pointer"
                    onClick={() => openLightbox(selectedNarrative.photos, idx)}
                  >
                    <img
                      src={photo.url}
                      alt={photo.caption || selectedNarrative.title}
                      className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                      referrerPolicy="no-referrer"
                    />
                    {photo.caption && (
                      <div className="p-3 bg-stone-900/90 text-stone-200 text-xs leading-snug">
                        {photo.caption}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Full narrative text */}
            <div className="prose dark:prose-invert max-w-none text-sm sm:text-base text-stone-800 dark:text-stone-200 leading-loose space-y-4 whitespace-pre-line font-sans">
              {selectedNarrative.fullNarrative}
            </div>

            {/* Sources & Citations */}
            {selectedNarrative.sources && selectedNarrative.sources.length > 0 && (
              <div className="p-5 rounded-2xl bg-amber-50 dark:bg-stone-850 border border-amber-200 dark:border-amber-900/40 space-y-2 text-xs">
                <div className="flex items-center gap-2 font-bold text-amber-900 dark:text-amber-300">
                  <Bookmark className="w-4 h-4" />
                  <span>Sources &amp; Témoignages Enregistrés</span>
                </div>
                <ul className="list-disc list-inside space-y-1 text-stone-700 dark:text-stone-300">
                  {selectedNarrative.sources.map((src, i) => (
                    <li key={i}>{src}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Author Footer */}
            <div className="pt-6 border-t border-stone-200 dark:border-stone-800 flex items-center justify-between text-xs text-stone-500">
              <div>
                Rédigé et archivé par <strong>{selectedNarrative.authorName}</strong> ({selectedNarrative.authorRole})
              </div>
              <div>Publié le {new Date(selectedNarrative.publishedAt).toLocaleDateString('fr-FR')}</div>
            </div>
          </div>
        </div>
      )}

      {/* --- SUB-TAB 2: ALBUMS DE MÉMOIRE (GALERIE D'ARCHIVES) --- */}
      {activeSubTab === 'ALBUMS' && !selectedAlbum && (
        <div className="space-y-6">
          {/* Category Filter Chips */}
          <div className="flex flex-wrap items-center gap-2">
            {[
              { id: 'ALL', label: 'Tous les Albums' },
              { id: 'FONDATEURS', label: 'Fondateurs & Sages' },
              { id: 'MARIAGES_ANCIENS', label: 'Mariages Coutumiers' },
              { id: 'CEREMONIES', label: 'Cérémonies Traditionnelles' },
              { id: 'DIASPORA', label: 'Diaspora & Études' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-amber-600 text-stone-950 shadow-xs'
                    : 'bg-white dark:bg-stone-900 text-stone-600 dark:text-stone-300 border border-stone-200 dark:border-stone-800 hover:bg-stone-100'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAlbums.map((album) => (
              <div
                key={album.id}
                onClick={() => setSelectedAlbum(album)}
                className="bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-sm hover:border-amber-500/50 hover:shadow-xl transition-all duration-300 overflow-hidden cursor-pointer group flex flex-col justify-between"
              >
                <div>
                  <div className="relative h-48 w-full bg-stone-950 overflow-hidden">
                    {album.coverUrl ? (
                      <img
                        src={album.coverUrl}
                        alt={album.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-stone-600">
                        <ImageIcon className="w-10 h-10" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-transparent" />
                    <div className="absolute top-3 left-3">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-stone-950">
                        {album.historicalEra || 'Archive'}
                      </span>
                    </div>
                    <div className="absolute bottom-3 right-3 px-2 py-0.5 rounded-md bg-stone-900/90 text-amber-300 text-xs font-bold">
                      📸 {album.photoCount} documents
                    </div>
                  </div>

                  <div className="p-5 space-y-2">
                    <h3 className="font-serif font-bold text-lg text-stone-900 dark:text-stone-100 group-hover:text-amber-600 transition-colors">
                      {album.title}
                    </h3>
                    <p className="text-xs text-stone-600 dark:text-stone-300 line-clamp-2 leading-relaxed">
                      {album.description}
                    </p>
                  </div>
                </div>

                <div className="p-5 pt-0 flex items-center justify-between text-xs text-stone-500 border-t border-stone-100 dark:border-stone-800 mt-2">
                  <span>Conservateur : <strong>{album.curatorName}</strong></span>
                  <ChevronRight className="w-4 h-4 text-amber-500 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Album Detail View */}
      {selectedAlbum && (
        <div className="bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 shadow-xl overflow-hidden animate-in fade-in duration-200">
          <div className="p-6 sm:p-8 border-b border-stone-200 dark:border-stone-800 flex items-center justify-between">
            <button
              onClick={() => setSelectedAlbum(null)}
              className="flex items-center gap-2 text-xs sm:text-sm font-bold text-stone-600 dark:text-stone-300 hover:text-amber-600 transition cursor-pointer"
            >
              <ChevronRight className="w-4 h-4 rotate-180" />
              <span>Retour aux albums d'archives</span>
            </button>
          </div>

          <div className="p-6 sm:p-10 space-y-6">
            <div className="space-y-2">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-400">
                {selectedAlbum.historicalEra} • {selectedAlbum.category}
              </span>
              <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-900 dark:text-stone-100">
                {selectedAlbum.title}
              </h2>
              <p className="text-sm text-stone-600 dark:text-stone-300">{selectedAlbum.description}</p>
            </div>

            {/* Photos Grid in Album */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {selectedAlbum.photos && selectedAlbum.photos.map((photo, idx) => (
                <div
                  key={photo.id}
                  onClick={() => openLightbox(selectedAlbum.photos, idx)}
                  className="group relative rounded-2xl overflow-hidden border border-stone-200 dark:border-stone-800 bg-stone-950 cursor-pointer aspect-4/3"
                >
                  <img
                    src={photo.url}
                    alt={photo.caption || selectedAlbum.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-950/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
                    <p className="text-xs text-stone-200 leading-snug">{photo.caption}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* --- SUB-TAB 3: FIGURES & PATRIARCHES (ELDERS & ANCESTORS) --- */}
      {activeSubTab === 'ELDERS' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {historicalElders.map((elder) => (
              <div
                key={elder.id}
                className="bg-white dark:bg-stone-900 rounded-3xl border border-stone-200 dark:border-stone-800 p-6 shadow-sm hover:border-amber-500/50 hover:shadow-xl transition-all duration-300 space-y-4"
              >
                <div className="flex items-start gap-4">
                  <NzalaAvatar
                    name={`${elder.firstName} ${elder.lastName}`}
                    src={elder.avatarUrl}
                    size="xl"
                    livingStatus={elder.livingStatus}
                    familyType={elder.familyType}
                  />

                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-700 dark:text-amber-300">
                        Génération {elder.generationLevel}
                      </span>
                      {elder.livingStatus === 'DECEDE' && (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-stone-200 dark:bg-stone-800 text-stone-700 dark:text-stone-300">
                          🕊️ En Mémoire
                        </span>
                      )}
                    </div>

                    <h3 className="font-serif font-bold text-lg text-stone-900 dark:text-stone-100 truncate">
                      {elder.firstName} {elder.lastName}
                    </h3>
                    <p className="text-xs text-stone-500 dark:text-stone-400 font-medium">
                      {elder.profession || 'Doyen familial'}
                    </p>
                  </div>
                </div>

                {/* Dates & Places */}
                <div className="p-3 rounded-2xl bg-stone-50 dark:bg-stone-850 space-y-1 text-xs text-stone-600 dark:text-stone-300">
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-amber-500" />
                    <span>
                      {elder.birthDate ? new Date(elder.birthDate).getFullYear() : '—'}
                      {elder.deathDate ? ` — ${new Date(elder.deathDate).getFullYear()}` : ' (Vivant)'}
                    </span>
                  </div>
                  {elder.birthPlace && (
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-amber-500" />
                      <span>Lieu : {elder.birthPlace}</span>
                    </div>
                  )}
                  {elder.burialPlace && (
                    <div className="flex items-center gap-1.5 text-stone-500 dark:text-stone-400">
                      <span>🕊️ Repose à : {elder.burialPlace}</span>
                    </div>
                  )}
                </div>

                {/* Bio snippet */}
                {elder.bio && (
                  <p className="text-xs text-stone-600 dark:text-stone-300 line-clamp-3 leading-relaxed">
                    "{elder.bio}"
                  </p>
                )}

                {/* Button to view in genealogy */}
                <button
                  onClick={() => {
                    setSelectedMember(elder);
                    setActiveTab('members');
                  }}
                  className="w-full py-2 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-amber-600 hover:text-stone-950 dark:hover:bg-amber-600 dark:hover:text-stone-950 text-stone-700 dark:text-stone-200 text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>Consulter la fiche généalogique</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Lightbox Modal */}
      <LightboxModal
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        mediaList={lightboxMedia}
        initialIndex={lightboxIndex}
      />
    </div>
  );
};
