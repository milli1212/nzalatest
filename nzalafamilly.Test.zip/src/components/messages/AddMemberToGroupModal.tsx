/**
 * NzalaFamilly - Modale pour Ajouter des Membres à un Groupe Existant
 */

import React, { useState } from 'react';
import { X, UserPlus, Search, Check } from 'lucide-react';
import { FamilyConversation } from '../../types/messaging';
import { useFamily } from '../../context/FamilyContext';

interface AddMemberToGroupModalProps {
  conversation: FamilyConversation;
  isOpen: boolean;
  onClose: () => void;
}

export const AddMemberToGroupModal: React.FC<AddMemberToGroupModalProps> = ({
  conversation,
  isOpen,
  onClose,
}) => {
  const { userAccounts, addGroupParticipants } = useFamily();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);

  if (!isOpen) return null;

  const existingParticipantIds = conversation.participants.map((p) => p.userId);

  // Available users not already in group
  const nonParticipants = userAccounts.filter(
    (u) => !existingParticipantIds.includes(u.id) && u.role !== 'VISITEUR'
  );

  const filteredUsers = nonParticipants.filter((u) => {
    const q = searchQuery.toLowerCase();
    const fullName = `${u.firstName || ''} ${u.lastName || ''}`.trim();
    return (
      fullName.toLowerCase().includes(q) ||
      u.email.toLowerCase().includes(q) ||
      u.primaryFamilyName?.toLowerCase().includes(q)
    );
  });

  const toggleSelect = (userId: string) => {
    if (selectedUserIds.includes(userId)) {
      setSelectedUserIds((prev) => prev.filter((id) => id !== userId));
    } else {
      setSelectedUserIds((prev) => [...prev, userId]);
    }
  };

  const handleConfirmAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedUserIds.length === 0) return;

    addGroupParticipants(conversation.id, selectedUserIds);
    onClose();
  };

  return (
    <div
      id="add-member-group-modal"
      className="fixed inset-0 z-50 bg-stone-950/80 backdrop-blur-xs flex items-center justify-center p-3 select-none animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md bg-white rounded-3xl border border-stone-200 shadow-2xl overflow-hidden flex flex-col max-h-[80vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-stone-100 bg-stone-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-blue-600" />
            <h3 className="text-base font-bold text-stone-900">Ajouter au groupe</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 rounded-xl hover:bg-stone-200/60 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search */}
        <div className="p-3 border-b border-stone-100">
          <div className="relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher par nom ou famille..."
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs sm:text-sm text-stone-900 outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* Scrollable list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {filteredUsers.length > 0 ? (
            filteredUsers.map((u) => {
              const isSelected = selectedUserIds.includes(u.id);
              const fullName = `${u.firstName || ''} ${u.lastName || ''}`.trim() || u.email;
              const familyLabel = u.primaryFamilyName || 'Famille Nzala';
              return (
                <div
                  key={u.id}
                  onClick={() => toggleSelect(u.id)}
                  className={`p-2.5 rounded-2xl border flex items-center justify-between cursor-pointer transition ${
                    isSelected
                      ? 'bg-blue-50 border-blue-400 text-blue-900'
                      : 'bg-white border-stone-200 text-stone-800 hover:bg-stone-50'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-xl bg-blue-600 text-white text-xs font-bold flex items-center justify-center shrink-0">
                      {fullName.charAt(0)}
                    </div>
                    <div className="truncate">
                      <p className="text-xs font-bold truncate">{fullName}</p>
                      <p className="text-[10px] text-stone-500 truncate">{familyLabel}</p>
                    </div>
                  </div>

                  <div
                    className={`w-5 h-5 rounded-lg border flex items-center justify-center ${
                      isSelected ? 'bg-blue-600 border-blue-600 text-white' : 'border-stone-300'
                    }`}
                  >
                    {isSelected && <Check className="w-3.5 h-3.5" />}
                  </div>
                </div>
              );
            })
          ) : (
            <p className="text-xs text-stone-400 italic text-center py-6">
              Aucun autre membre disponible à ajouter.
            </p>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-stone-100 flex items-center justify-end gap-2 bg-stone-50">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-stone-600 hover:bg-stone-200/60 text-xs font-semibold cursor-pointer"
          >
            Annuler
          </button>
          <button
            type="button"
            disabled={selectedUserIds.length === 0}
            onClick={handleConfirmAdd}
            className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-bold shadow transition cursor-pointer"
          >
            Ajouter ({selectedUserIds.length})
          </button>
        </div>
      </div>
    </div>
  );
};
