/**
 * NzalaFamilly - Lecteur Audio / Message Vocal haute fidélité
 * Prise en charge de la timeline cliquable, changement de vitesse et synchronisation de métadonnées audio réelles.
 */

import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Volume2 } from 'lucide-react';
import { MessagingService } from '../../services/messagingService';

interface AudioMessagePlayerProps {
  audioUrl: string;
  durationSec?: number;
  isSentByMe?: boolean;
}

export const AudioMessagePlayer: React.FC<AudioMessagePlayerProps> = ({
  audioUrl,
  durationSec = 10,
  isSentByMe = false,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [realDuration, setRealDuration] = useState<number>(durationSec || 10);
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    const handleLoadedMetadata = () => {
      if (audio.duration && !isNaN(audio.duration) && isFinite(audio.duration)) {
        setRealDuration(Math.round(audio.duration));
      }
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
    };
  }, [audioUrl]);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play().then(() => {
        setIsPlaying(true);
      }).catch((err) => {
        console.warn('Audio playback error:', err);
        setIsPlaying(false);
      });
    }
  };

  const handleSpeedChange = (e: React.MouseEvent) => {
    e.stopPropagation();
    const audio = audioRef.current;
    if (!audio) return;
    const rates = [1, 1.5, 2];
    const nextIndex = (rates.indexOf(playbackRate) + 1) % rates.length;
    const nextRate = rates[nextIndex];
    setPlaybackRate(nextRate);
    audio.playbackRate = nextRate;
  };

  const handleSeek = (idx: number, totalBars: number) => {
    const audio = audioRef.current;
    if (!audio) return;
    const effectiveDuration = realDuration > 0 ? realDuration : 10;
    const seekTime = (idx / totalBars) * effectiveDuration;
    audio.currentTime = seekTime;
    setCurrentTime(seekTime);
  };

  const effectiveDuration = realDuration > 0 ? realDuration : (durationSec || 10);
  const progressPercent = Math.min(100, (currentTime / effectiveDuration) * 100);

  // Waveform bars profile
  const bars = [32, 58, 42, 85, 60, 95, 78, 48, 100, 68, 88, 52, 74, 98, 44, 62, 82, 54, 72, 38, 64, 92, 46, 32];

  return (
    <div
      className={`flex items-center gap-3 p-2.5 sm:p-3 rounded-2xl transition-all select-none max-w-full ${
        isSentByMe
          ? 'bg-blue-600 text-white shadow-xs'
          : 'bg-slate-100 text-slate-900 border border-slate-200 shadow-xs'
      }`}
    >
      <audio ref={audioRef} src={audioUrl} preload="metadata" />

      {/* Play/Pause Button */}
      <button
        type="button"
        onClick={togglePlay}
        className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center shrink-0 transition-transform active:scale-95 cursor-pointer shadow-sm ${
          isSentByMe
            ? 'bg-white text-blue-700 hover:bg-slate-50'
            : 'bg-blue-600 text-white hover:bg-blue-700'
        }`}
        title={isPlaying ? 'Mettre en pause' : 'Écouter le message vocal'}
      >
        {isPlaying ? (
          <Pause className="w-4 h-4 sm:w-5 sm:h-5 fill-current" />
        ) : (
          <Play className="w-4 h-4 sm:w-5 sm:h-5 fill-current ml-0.5" />
        )}
      </button>

      {/* Interactive Waveform & Timeline */}
      <div className="flex-1 min-w-0 space-y-1">
        <div className="flex items-center gap-0.5 h-6 cursor-pointer py-1">
          {bars.map((height, idx) => {
            const barProgress = (idx / bars.length) * 100;
            const isPlayed = barProgress <= progressPercent;

            return (
              <div
                key={idx}
                onClick={() => handleSeek(idx, bars.length)}
                className={`flex-1 rounded-full transition-all duration-100 hover:opacity-80 ${
                  isPlayed
                    ? isSentByMe
                      ? 'bg-white'
                      : 'bg-blue-600'
                    : isSentByMe
                    ? 'bg-blue-400/50 hover:bg-blue-300'
                    : 'bg-slate-300 hover:bg-slate-400'
                }`}
                style={{ height: `${height}%` }}
              />
            );
          })}
        </div>

        {/* Time & Type Tag */}
        <div className="flex items-center justify-between text-[11px] font-medium leading-none">
          <span className={isSentByMe ? 'text-blue-100 font-mono' : 'text-slate-500 font-mono'}>
            {MessagingService.formatDuration(currentTime > 0 ? currentTime : effectiveDuration)}
          </span>
          <span className={`text-[10px] flex items-center gap-1 font-medium ${isSentByMe ? 'text-blue-200' : 'text-slate-400'}`}>
            <Volume2 className="w-3 h-3" />
            <span>Vocal</span>
          </span>
        </div>
      </div>

      {/* Speed Rate Switcher */}
      <button
        type="button"
        onClick={handleSpeedChange}
        className={`px-2 py-1 rounded-lg text-[10px] font-bold tracking-wider uppercase transition cursor-pointer shrink-0 ${
          isSentByMe
            ? 'bg-blue-700/80 text-blue-100 hover:bg-blue-800 border border-blue-400/40'
            : 'bg-slate-200 text-slate-700 hover:bg-slate-300 border border-slate-300'
        }`}
        title="Changer la vitesse (1x, 1.5x, 2x)"
      >
        {playbackRate}x
      </button>
    </div>
  );
};
