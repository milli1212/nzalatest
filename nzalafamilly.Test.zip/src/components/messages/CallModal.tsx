/**
 * NzalaFamilly - Modale d'Appel Audio & Vidéo Haute Définition
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  PhoneOff,
  Mic,
  MicOff,
  Video,
  VideoOff,
  Maximize2,
  Volume2,
  Users,
  Sparkles,
} from 'lucide-react';
import { FamilyConversation } from '../../types/messaging';
import { MessagingService } from '../../services/messagingService';

interface CallModalProps {
  isOpen: boolean;
  onClose: () => void;
  conversation: FamilyConversation;
  currentUserId: string;
  callType: 'AUDIO' | 'VIDEO';
}

export const CallModal: React.FC<CallModalProps> = ({
  isOpen,
  onClose,
  conversation,
  currentUserId,
  callType,
}) => {
  const [callDuration, setCallDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoEnabled, setIsVideoEnabled] = useState(callType === 'VIDEO');
  const [isConnecting, setIsConnecting] = useState(true);

  const localVideoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    if (!isOpen) {
      setCallDuration(0);
      setIsConnecting(true);
      return;
    }

    // Connect after 1.5s
    const connectTimer = setTimeout(() => {
      setIsConnecting(false);
    }, 1500);

    const interval = setInterval(() => {
      setCallDuration((prev) => prev + 1);
    }, 1000);

    // Try camera stream if video call
    if (callType === 'VIDEO' && navigator.mediaDevices?.getUserMedia) {
      navigator.mediaDevices
        .getUserMedia({ video: true, audio: true })
        .then((stream) => {
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream;
          }
        })
        .catch((err) => {
          console.warn('Camera access unavailable or iframe blocked:', err);
        });
    }

    return () => {
      clearTimeout(connectTimer);
      clearInterval(interval);
      if (localVideoRef.current?.srcObject) {
        const stream = localVideoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [isOpen, callType]);

  if (!isOpen) return null;

  const title = MessagingService.getConversationTitle(conversation, currentUserId);
  const avatar = MessagingService.getConversationAvatar(conversation, currentUserId);

  return (
    <div
      id="call-modal-overlay"
      className="fixed inset-0 z-50 bg-stone-950/95 backdrop-blur-md flex items-center justify-center p-4 select-none animate-fadeIn"
    >
      <div className="w-full max-w-2xl h-[80vh] max-h-[600px] bg-stone-900 rounded-3xl border border-stone-800 shadow-2xl flex flex-col justify-between overflow-hidden relative text-white">
        {/* Top bar info */}
        <div className="p-4 sm:p-6 z-20 flex items-center justify-between bg-gradient-to-b from-black/80 to-transparent">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-600/30 border border-blue-500/40 flex items-center justify-center text-amber-400 font-bold">
              {callType === 'VIDEO' ? <Video className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white leading-tight">{title}</h3>
              <p className="text-xs text-stone-400">
                {isConnecting
                  ? 'Connexion sécurisée en cours...'
                  : `${callType === 'VIDEO' ? 'Appel vidéo chiffré' : 'Appel audio'} • ${MessagingService.formatDuration(
                      callDuration
                    )}`}
              </p>
            </div>
          </div>

          <span className="px-3 py-1 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
            Nzala Connect
          </span>
        </div>

        {/* Center Stage: Video feed or Audio Avatar pulse */}
        <div className="flex-1 relative flex items-center justify-center p-4">
          {callType === 'VIDEO' && isVideoEnabled ? (
            <div className="w-full h-full rounded-2xl overflow-hidden bg-stone-950 relative flex items-center justify-center border border-stone-800">
              {/* Simulated remote background feed */}
              <img
                src={avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80'}
                alt="Participant"
                className="w-full h-full object-cover opacity-80"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30" />

              {/* Local video mini picture-in-picture */}
              <div className="absolute bottom-4 right-4 w-28 sm:w-36 h-36 sm:h-48 rounded-2xl bg-stone-900 border-2 border-stone-700 shadow-2xl overflow-hidden z-20">
                <video
                  ref={localVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
                <span className="absolute bottom-1 left-2 text-[9px] font-bold text-white/80">Vous</span>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center space-y-4 text-center">
              <div className="relative">
                {/* Audio pulse waves */}
                {!isConnecting && (
                  <>
                    <span className="absolute -inset-4 rounded-full bg-blue-500/20 animate-ping opacity-75" />
                    <span className="absolute -inset-8 rounded-full bg-blue-500/10 animate-pulse opacity-50" />
                  </>
                )}

                {avatar ? (
                  <img
                    src={avatar}
                    alt={title}
                    className="w-28 h-28 sm:w-36 sm:h-36 rounded-full object-cover border-4 border-blue-500/50 shadow-2xl relative z-10"
                  />
                ) : (
                  <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-full bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-4xl font-bold font-serif shadow-2xl relative z-10">
                    {title.charAt(0)}
                  </div>
                )}
              </div>

              <div className="z-10">
                <h4 className="text-lg sm:text-xl font-bold text-white">{title}</h4>
                <p className="text-xs text-amber-400 font-medium mt-1">
                  {isConnecting ? 'Sonnerie...' : 'En communication'}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Call Controls */}
        <div className="p-4 sm:p-6 z-20 bg-gradient-to-t from-black/90 to-transparent flex items-center justify-center gap-4">
          {/* Mute button */}
          <button
            type="button"
            onClick={() => setIsMuted(!isMuted)}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition active:scale-90 cursor-pointer shadow-lg ${
              isMuted
                ? 'bg-rose-600 text-white hover:bg-rose-700'
                : 'bg-stone-800 text-stone-200 hover:bg-stone-700'
            }`}
            title={isMuted ? 'Activer le micro' : 'Couper le micro'}
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* Toggle Video */}
          <button
            type="button"
            onClick={() => setIsVideoEnabled(!isVideoEnabled)}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition active:scale-90 cursor-pointer shadow-lg ${
              !isVideoEnabled
                ? 'bg-stone-800 text-stone-400 hover:bg-stone-700'
                : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
            title={isVideoEnabled ? 'Couper la caméra' : 'Activer la caméra'}
          >
            {isVideoEnabled ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
          </button>

          {/* End Call Button */}
          <button
            type="button"
            onClick={onClose}
            className="w-14 h-14 rounded-full bg-rose-600 hover:bg-rose-700 text-white flex items-center justify-center shadow-xl transition active:scale-95 cursor-pointer"
            title="Raccrocher"
          >
            <PhoneOff className="w-6 h-6" />
          </button>
        </div>
      </div>
    </div>
  );
};
