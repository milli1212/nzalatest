/**
 * NzalaFamilly - Zone de Chat & Timeline des Messages
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Phone,
  Video,
  Info,
  Search,
  ChevronLeft,
  ChevronUp,
  ChevronDown,
  X,
  Shield,
  Users,
  MessageSquare,
  Lock,
} from 'lucide-react';
import { FamilyConversation, FamilyMessage, QuotedMessage, MessageMediaType, MessageAttachment } from '../../types/messaging';
import { useFamily } from '../../context/FamilyContext';
import { MessagingService } from '../../services/messagingService';
import { MessageBubble } from './MessageBubble';
import { MessageComposer } from './MessageComposer';
import { ConversationInfoDrawer } from './ConversationInfoDrawer';
import { CallModal } from './CallModal';
import { MessageReportModal } from './MessageReportModal';
import { LightboxModal } from '../social/LightboxModal';
import { MediaItem } from '../../types';

interface ChatAreaProps {
  conversation: FamilyConversation;
  onBackMobile: () => void;
  onOpenAddMemberModal: () => void;
}

export const ChatArea: React.FC<ChatAreaProps> = ({
  conversation,
  onBackMobile,
  onOpenAddMemberModal,
}) => {
  const {
    currentUser,
    messages,
    presences,
    sendMessage,
    editMessage,
    deleteMessage,
    markConversationAsRead,
    showToast,
    startCall,
    setReportingTarget,
  } = useFamily();

  // Filter messages for current conversation and sort chronologically
  const conversationMessages = messages
    .filter((m) => m.conversationId === conversation.id)
    .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  // Interactive states
  const [quotedMessage, setQuotedMessage] = useState<FamilyMessage | null>(null);
  const [editingMessage, setEditingMessage] = useState<FamilyMessage | null>(null);
  const [reportingMessage, setReportingMessage] = useState<FamilyMessage | null>(null);

  // In-chat search state
  const [showInChatSearch, setShowInChatSearch] = useState(false);
  const [chatSearchQuery, setChatSearchQuery] = useState('');
  const [currentMatchIndex, setCurrentMatchIndex] = useState(0);

  // Modals & Panels
  const [isInfoDrawerOpen, setIsInfoDrawerOpen] = useState(false);
  const [callModalData, setCallModalData] = useState<{ open: boolean; type: 'AUDIO' | 'VIDEO' }>({
    open: false,
    type: 'AUDIO',
  });
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);

  // Lightbox
  const [lightboxData, setLightboxData] = useState<{
    isOpen: boolean;
    items: MediaItem[];
    index: number;
  }>({
    isOpen: false,
    items: [],
    index: 0,
  });

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll on conversation switch or message add
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    markConversationAsRead(conversation.id);
  }, [conversation.id, conversationMessages.length]);

  // Handle in-chat search matching
  const matchingMessageIds = chatSearchQuery.trim()
    ? conversationMessages
        .filter((m) => m.content?.toLowerCase().includes(chatSearchQuery.toLowerCase()))
        .map((m) => m.id)
    : [];

  const handleScrollToMatch = (index: number) => {
    if (matchingMessageIds.length === 0) return;
    const targetId = matchingMessageIds[index];
    const el = document.getElementById(`message-${targetId}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      el.classList.add('bg-amber-100/50');
      setTimeout(() => el.classList.remove('bg-amber-100/50'), 2000);
    }
  };

  const handleNextMatch = () => {
    if (matchingMessageIds.length === 0) return;
    const nextIdx = (currentMatchIndex + 1) % matchingMessageIds.length;
    setCurrentMatchIndex(nextIdx);
    handleScrollToMatch(nextIdx);
  };

  const handlePrevMatch = () => {
    if (matchingMessageIds.length === 0) return;
    const prevIdx = (currentMatchIndex - 1 + matchingMessageIds.length) % matchingMessageIds.length;
    setCurrentMatchIndex(prevIdx);
    handleScrollToMatch(prevIdx);
  };

  const handleScrollToMessage = (messageId: string) => {
    const el = document.getElementById(`message-${messageId}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      el.classList.add('bg-blue-100/60');
      setTimeout(() => el.classList.remove('bg-blue-100/60'), 2000);
    }
  };

  // Group messages by date
  const groupedMessages: { dateLabel: string; messages: FamilyMessage[] }[] = [];
  let currentDate = '';
  let currentGroup: FamilyMessage[] = [];

  conversationMessages.forEach((msg) => {
    const msgDate = new Date(msg.createdAt).toLocaleDateString('fr-FR', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });

    if (msgDate !== currentDate) {
      if (currentGroup.length > 0) {
        groupedMessages.push({ dateLabel: currentDate, messages: currentGroup });
      }
      currentDate = msgDate;
      currentGroup = [msg];
    } else {
      currentGroup.push(msg);
    }
  });
  if (currentGroup.length > 0) {
    groupedMessages.push({ dateLabel: currentDate, messages: currentGroup });
  }

  const title = MessagingService.getConversationTitle(conversation, currentUser.id);
  const subtitle = MessagingService.getConversationSubtitle(conversation, currentUser.id, presences);
  const avatar = MessagingService.getConversationAvatar(conversation, currentUser.id);
  const isOnline = MessagingService.isConversationOnline(conversation, currentUser.id, presences);

  return (
    <div className="w-full h-full flex flex-col bg-stone-50/50 relative overflow-hidden select-none">
      {/* Top Navbar */}
      <div className="p-3 sm:px-4 sm:py-3 bg-white border-b border-stone-200 flex items-center justify-between z-20 shadow-xs">
        {/* Left: Mobile back & Identity */}
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          {/* Back button on mobile */}
          <button
            type="button"
            onClick={onBackMobile}
            className="p-1.5 -ml-1 rounded-xl text-stone-600 hover:bg-stone-100 md:hidden cursor-pointer"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Avatar with click to open info */}
          <div
            onClick={() => setIsInfoDrawerOpen(true)}
            className="relative cursor-pointer shrink-0"
          >
            {avatar ? (
              <img
                src={avatar}
                alt={title}
                className="w-10 h-10 rounded-2xl object-cover border border-stone-200 shadow-xs"
              />
            ) : (
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white flex items-center justify-center font-bold font-serif shadow-xs">
                {conversation.type === 'GROUP' ? <Users className="w-5 h-5" /> : title.charAt(0)}
              </div>
            )}

            {conversation.type === 'DIRECT' && isOnline && (
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white" />
            )}

            {conversation.isCouncilGroup && (
              <span
                className="absolute -bottom-1 -right-1 p-0.5 bg-amber-500 text-stone-950 rounded-lg shadow"
                title="Conseil de Famille"
              >
                <Shield className="w-3 h-3" />
              </span>
            )}
          </div>

          {/* Title & Presence */}
          <div
            onClick={() => setIsInfoDrawerOpen(true)}
            className="min-w-0 cursor-pointer"
          >
            <div className="flex items-center gap-1.5">
              <h3 className="text-xs sm:text-sm font-bold text-stone-900 truncate">{title}</h3>
              {conversation.isCouncilGroup && (
                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-100 text-amber-900 border border-amber-300 shrink-0">
                  Conseil
                </span>
              )}
            </div>
            <p className="text-[11px] text-stone-500 truncate">{subtitle}</p>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* In-chat search trigger */}
          <button
            type="button"
            onClick={() => {
              setShowInChatSearch(!showInChatSearch);
              if (showInChatSearch) {
                setChatSearchQuery('');
              }
            }}
            className={`p-2 rounded-xl transition cursor-pointer ${
              showInChatSearch
                ? 'bg-blue-100 text-blue-800'
                : 'text-stone-500 hover:text-stone-800 hover:bg-stone-100'
            }`}
            title="Rechercher dans la conversation"
          >
            <Search className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          {/* Audio Call */}
          <button
            type="button"
            onClick={() => {
              const other = conversation.participants.find((p) => p.userId !== currentUser.id);
              startCall(
                {
                  id: other ? other.userId : conversation.id,
                  name: title,
                  avatarUrl: avatar,
                },
                'AUDIO'
              );
            }}
            className="p-2 rounded-xl text-stone-500 hover:text-blue-600 hover:bg-blue-50 transition cursor-pointer"
            title="Appel audio"
          >
            <Phone className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          {/* Video Call */}
          <button
            type="button"
            onClick={() => {
              const other = conversation.participants.find((p) => p.userId !== currentUser.id);
              startCall(
                {
                  id: other ? other.userId : conversation.id,
                  name: title,
                  avatarUrl: avatar,
                },
                'VIDEO'
              );
            }}
            className="p-2 rounded-xl text-stone-500 hover:text-indigo-600 hover:bg-indigo-50 transition cursor-pointer"
            title="Appel vidéo"
          >
            <Video className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          {/* Info Drawer trigger */}
          <button
            type="button"
            onClick={() => setIsInfoDrawerOpen(true)}
            className="p-2 rounded-xl text-stone-500 hover:text-stone-800 hover:bg-stone-100 transition cursor-pointer"
            title="Détails de la conversation"
          >
            <Info className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>
        </div>
      </div>

      {/* In-Chat Search Bar (Dropdown) */}
      {showInChatSearch && (
        <div className="p-2.5 bg-stone-100 border-b border-stone-200 flex items-center gap-2 z-10 animate-fadeIn text-xs">
          <Search className="w-4 h-4 text-stone-400 shrink-0" />
          <input
            type="text"
            autoFocus
            value={chatSearchQuery}
            onChange={(e) => {
              setChatSearchQuery(e.target.value);
              setCurrentMatchIndex(0);
            }}
            placeholder="Rechercher des messages..."
            className="flex-1 bg-white px-3 py-1.5 rounded-xl border border-stone-200 outline-none text-xs"
          />

          {matchingMessageIds.length > 0 && (
            <div className="flex items-center gap-1 text-stone-600 font-bold text-[11px] shrink-0">
              <span>
                {currentMatchIndex + 1} / {matchingMessageIds.length}
              </span>
              <button
                type="button"
                onClick={handlePrevMatch}
                className="p-1 rounded hover:bg-stone-200 cursor-pointer"
              >
                <ChevronUp className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={handleNextMatch}
                className="p-1 rounded hover:bg-stone-200 cursor-pointer"
              >
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          <button
            type="button"
            onClick={() => {
              setShowInChatSearch(false);
              setChatSearchQuery('');
            }}
            className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-200 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Messages Scrollable Timeline */}
      <div className="flex-1 overflow-y-auto p-3 sm:p-5 space-y-4">
        {/* Confidentiality Notice */}
        <div className="max-w-md mx-auto p-3 rounded-2xl bg-amber-50/70 border border-amber-200/80 text-center space-y-1">
          <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-amber-900">
            <Lock className="w-3.5 h-3.5 text-amber-600" />
            <span>Chiffrement et Confidentialité Familiale</span>
          </div>
          <p className="text-[11px] text-amber-800">
            {conversation.isCouncilGroup
              ? 'Cette discussion est protégée sous le sceau du Conseil des Sages NzalaFamilly.'
              : 'Les échanges sont réservés aux membres autorisés de la communauté familiale.'}
          </p>
        </div>

        {groupedMessages.map((group, gIdx) => (
          <div key={gIdx} className="space-y-3">
            {/* Date separator pill */}
            <div className="flex justify-center my-4">
              <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-stone-200/80 text-stone-600 shadow-xs border border-stone-300/40">
                {group.dateLabel}
              </span>
            </div>

            {/* Messages in this date */}
            {group.messages.map((msg) => (
              <MessageBubble
                key={msg.id}
                message={msg}
                isGroup={conversation.type === 'GROUP'}
                onReply={(m) => setQuotedMessage(m)}
                onEdit={(m) => setEditingMessage(m)}
                onDelete={(mId) => {
                  if (window.confirm('Voulez-vous supprimer ce message ?')) {
                    deleteMessage(mId);
                  }
                }}
                onReport={(m) => {
                  setReportingMessage(m);
                  setIsReportModalOpen(true);
                }}
                onSelectMediaForLightbox={(mediaList, initialIdx) => {
                  setLightboxData({
                    isOpen: true,
                    items: mediaList,
                    index: initialIdx,
                  });
                }}
                onScrollToMessage={handleScrollToMessage}
              />
            ))}
          </div>
        ))}

        <div ref={messagesEndRef} />
      </div>

      {/* Message Composer Area */}
      <MessageComposer
        conversationId={conversation.id}
        participants={conversation.participants}
        quotedMessage={quotedMessage}
        editingMessage={editingMessage}
        onClearQuote={() => setQuotedMessage(null)}
        onClearEdit={() => setEditingMessage(null)}
        onSendMessage={(data) => {
          sendMessage({
            conversationId: conversation.id,
            content: data.content,
            mediaType: data.mediaType,
            attachments: data.attachments,
            quotedMessage: data.quotedMessage,
            mentions: data.mentions,
            isViewOnce: data.isViewOnce,
          });
        }}
        onSaveEdit={(messageId, content) => {
          editMessage(messageId, content);
        }}
      />

      {/* Info Side Drawer */}
      <ConversationInfoDrawer
        conversation={conversation}
        messages={conversationMessages}
        isOpen={isInfoDrawerOpen}
        onClose={() => setIsInfoDrawerOpen(false)}
        onOpenReportModal={() => {
          setReportingMessage(null);
          setIsReportModalOpen(true);
        }}
        onOpenAddMemberModal={onOpenAddMemberModal}
        onSelectMediaForLightbox={(mediaList, initialIdx) => {
          setLightboxData({
            isOpen: true,
            items: mediaList,
            index: initialIdx,
          });
        }}
      />

      {/* Audio/Video Call Modal */}
      <CallModal
        isOpen={callModalData.open}
        onClose={() => setCallModalData({ open: false, type: 'AUDIO' })}
        conversation={conversation}
        currentUserId={currentUser.id}
        callType={callModalData.type}
      />

      {/* Report Modal */}
      <MessageReportModal
        isOpen={isReportModalOpen}
        onClose={() => {
          setIsReportModalOpen(false);
          setReportingMessage(null);
        }}
        conversationId={conversation.id}
        message={reportingMessage}
      />

      {/* Lightbox for Photos */}
      <LightboxModal
        isOpen={lightboxData.isOpen}
        media={lightboxData.items}
        initialIndex={lightboxData.index}
        onClose={() => setLightboxData({ isOpen: false, items: [], index: 0 })}
      />
    </div>
  );
};
