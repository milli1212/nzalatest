/**
 * NzalaFamilly - Panneau d'Informations & Administration de Conversation
 */

import React, { useState } from 'react';
import {
  X,
  Users,
  Shield,
  UserPlus,
  UserMinus,
  Crown,
  Image,
  Video,
  FileText,
  Calendar,
  LogOut,
  Ban,
  Flag,
  Sparkles,
  Link,
  ChevronRight,
  Search,
} from 'lucide-react';
import { FamilyConversation, FamilyMessage } from '../../types/messaging';
import { useFamily } from '../../context/FamilyContext';
import { MessagingService } from '../../services/messagingService';
import { MediaItem } from '../../types';

interface ConversationInfoDrawerProps {
  conversation: FamilyConversation;
  messages: FamilyMessage[];
  isOpen: boolean;
  onClose: () => void;
  onOpenReportModal: () => void;
  onOpenAddMemberModal: () => void;
  onSelectMediaForLightbox?: (mediaList: MediaItem[], initialIndex: number) => void;
}

export const ConversationInfoDrawer: React.FC<ConversationInfoDrawerProps> = ({
  conversation,
  messages,
  isOpen,
  onClose,
  onOpenReportModal,
  onOpenAddMemberModal,
  onSelectMediaForLightbox,
}) => {
  const {
    currentUser,
    userAccounts,
    toggleGroupAdminRole,
    removeGroupParticipant,
    leaveGroupConversation,
    blockContact,
    showToast,
  } = useFamily();

  const [activeMediaTab, setActiveMediaTab] = useState<'PHOTOS' | 'VIDEOS' | 'FILES' | 'LINKS'>('PHOTOS');

  if (!isOpen) return null;

  const isGroup = conversation.type === 'GROUP';
  const isCurrentUserAdmin = isGroup && conversation.admins.includes(currentUser.id);
  const otherParticipant = !isGroup
    ? conversation.participants.find((p) => p.userId !== currentUser.id)
    : null;

  // Extract shared media from messages
  const sharedImages: MediaItem[] = [];
  const sharedVideos: any[] = [];
  const sharedFiles: any[] = [];
  const sharedPostsAndEvents: any[] = [];

  messages.forEach((msg) => {
    msg.attachments?.forEach((att) => {
      if (att.type === 'IMAGE') {
        sharedImages.push({
          id: att.id,
          type: 'IMAGE',
          url: att.url,
          caption: att.caption || `Partagé par ${msg.senderName}`,
        });
      } else if (att.type === 'VIDEO') {
        sharedVideos.push({ ...att, senderName: msg.senderName });
      } else if (att.type === 'FILE') {
        sharedFiles.push({ ...att, senderName: msg.senderName, date: msg.createdAt });
      }
    });

    if (msg.sharedPost) {
      sharedPostsAndEvents.push({ type: 'POST', item: msg.sharedPost, senderName: msg.senderName });
    }
    if (msg.sharedEvent) {
      sharedPostsAndEvents.push({ type: 'EVENT', item: msg.sharedEvent, senderName: msg.senderName });
    }
  });

  const handleToggleAdmin = (targetUserId: string) => {
    if (!isCurrentUserAdmin) {
      showToast('error', 'Seuls les administrateurs du groupe peuvent modifier les rôles.');
      return;
    }
    toggleGroupAdminRole(conversation.id, targetUserId);
  };

  const handleRemoveMember = (targetUserId: string, targetName: string) => {
    if (!isCurrentUserAdmin) {
      showToast('error', 'Seuls les administrateurs du groupe peuvent retirer un membre.');
      return;
    }
    if (window.confirm(`Voulez-vous vraiment retirer ${targetName} de ce groupe ?`)) {
      removeGroupParticipant(conversation.id, targetUserId);
    }
  };

  const handleLeaveGroup = () => {
    if (window.confirm('Êtes-vous sûr de vouloir quitter ce groupe ?')) {
      leaveGroupConversation(conversation.id);
      onClose();
    }
  };

  const handleBlockMember = () => {
    if (!otherParticipant) return;
    if (
      window.confirm(
        `Voulez-vous bloquer ${otherParticipant.userName} ? Vous ne recevrez plus de messages directs de ce membre.`
      )
    ) {
      blockContact(otherParticipant.userId, 'Bloqué depuis la messagerie');
      onClose();
    }
  };

  return (
    <div
      id="conversation-info-drawer"
      className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex justify-end animate-fadeIn select-none"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md h-full bg-white border-l border-stone-200 shadow-2xl flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
          <h3 className="font-bold text-stone-900 text-sm sm:text-base">
            {isGroup ? 'Détails du groupe' : 'Infos du contact'}
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-200/60 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-6">
          {/* Identity & Avatar */}
          <div className="flex flex-col items-center text-center space-y-2">
            <div className="relative">
              {conversation.avatarUrl ? (
                <img
                  src={conversation.avatarUrl}
                  alt="Avatar"
                  className="w-20 h-20 rounded-3xl object-cover shadow-md border-2 border-white ring-2 ring-stone-200"
                />
              ) : (
                <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white flex items-center justify-center text-2xl font-bold font-serif shadow-md">
                  {isGroup ? (
                    <Users className="w-10 h-10" />
                  ) : (
                    otherParticipant?.userName.charAt(0) || 'N'
                  )}
                </div>
              )}

              {conversation.isCouncilGroup && (
                <div
                  className="absolute -bottom-1 -right-1 p-1.5 bg-amber-500 text-stone-950 rounded-xl shadow border border-amber-300"
                  title="Conseil de Famille"
                >
                  <Shield className="w-4 h-4" />
                </div>
              )}
            </div>

            <div>
              <h4 className="text-base sm:text-lg font-bold text-stone-900">
                {MessagingService.getConversationTitle(conversation, currentUser.id)}
              </h4>
              {conversation.description && (
                <p className="text-xs text-stone-500 mt-1 max-w-xs">{conversation.description}</p>
              )}
            </div>

            {/* Badges and tags */}
            <div className="flex flex-wrap items-center justify-center gap-1.5 pt-1">
              {conversation.isCouncilGroup && (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                  ⚖️ Confidentiel • Conseil des Sages
                </span>
              )}
              {conversation.relatedBranchName && (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
                  🌿 {conversation.relatedBranchName}
                </span>
              )}
              {conversation.relatedAlliedFamilyName && (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-800 border border-purple-200">
                  🤝 {conversation.relatedAlliedFamilyName}
                </span>
              )}
            </div>
          </div>

          {/* Group Participants Section */}
          {isGroup && (
            <div className="space-y-3 pt-2 border-t border-stone-200">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-stone-600">
                  Participants ({conversation.participants.length})
                </span>

                {isCurrentUserAdmin && (
                  <button
                    type="button"
                    onClick={onOpenAddMemberModal}
                    className="flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-700 cursor-pointer"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    <span>Ajouter</span>
                  </button>
                )}
              </div>

              <div className="space-y-2">
                {conversation.participants.map((p) => {
                  const isParticipantAdmin = conversation.admins.includes(p.userId);
                  const isMe = p.userId === currentUser.id;

                  return (
                    <div
                      key={p.userId}
                      className="flex items-center justify-between p-2 rounded-xl bg-stone-50 border border-stone-200/80 hover:bg-stone-100 transition"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        {p.userAvatar ? (
                          <img
                            src={p.userAvatar}
                            alt={p.userName}
                            className="w-8 h-8 rounded-full object-cover shrink-0"
                          />
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-blue-600 text-white text-xs font-bold flex items-center justify-center shrink-0">
                            {p.userName.charAt(0)}
                          </div>
                        )}
                        <div className="truncate">
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-bold text-stone-900 truncate">
                              {p.userName} {isMe && '(Vous)'}
                            </span>
                            {isParticipantAdmin && (
                              <span className="flex items-center gap-0.5 px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-100 text-amber-800 border border-amber-300">
                                <Crown className="w-2.5 h-2.5" />
                                Admin
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-stone-500 truncate block">
                            {p.familyName || 'Famille'} {p.branchName ? `• ${p.branchName}` : ''}
                          </span>
                        </div>
                      </div>

                      {/* Admin Controls on participant */}
                      {isCurrentUserAdmin && !isMe && (
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleToggleAdmin(p.userId)}
                            className="p-1 rounded-lg text-stone-400 hover:text-amber-600 hover:bg-stone-200 transition cursor-pointer"
                            title={
                              isParticipantAdmin
                                ? 'Retirer les droits administrateur'
                                : 'Promouvoir administrateur'
                            }
                          >
                            <Crown className={`w-3.5 h-3.5 ${isParticipantAdmin ? 'text-amber-500' : ''}`} />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleRemoveMember(p.userId, p.userName)}
                            className="p-1 rounded-lg text-stone-400 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
                            title="Retirer du groupe"
                          >
                            <UserMinus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Shared Media Tabs */}
          <div className="space-y-3 pt-2 border-t border-stone-200">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-600">
              Médias &amp; Fichiers partagés
            </span>

            {/* Media navigation pills */}
            <div className="flex rounded-xl bg-stone-100 p-1 text-xs font-bold text-stone-600">
              <button
                type="button"
                onClick={() => setActiveMediaTab('PHOTOS')}
                className={`flex-1 py-1.5 rounded-lg transition text-center cursor-pointer ${
                  activeMediaTab === 'PHOTOS' ? 'bg-white text-blue-700 shadow-xs' : 'hover:text-stone-900'
                }`}
              >
                Photos ({sharedImages.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveMediaTab('VIDEOS')}
                className={`flex-1 py-1.5 rounded-lg transition text-center cursor-pointer ${
                  activeMediaTab === 'VIDEOS' ? 'bg-white text-blue-700 shadow-xs' : 'hover:text-stone-900'
                }`}
              >
                Vidéos ({sharedVideos.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveMediaTab('FILES')}
                className={`flex-1 py-1.5 rounded-lg transition text-center cursor-pointer ${
                  activeMediaTab === 'FILES' ? 'bg-white text-blue-700 shadow-xs' : 'hover:text-stone-900'
                }`}
              >
                Docs ({sharedFiles.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveMediaTab('LINKS')}
                className={`flex-1 py-1.5 rounded-lg transition text-center cursor-pointer ${
                  activeMediaTab === 'LINKS' ? 'bg-white text-blue-700 shadow-xs' : 'hover:text-stone-900'
                }`}
              >
                Partages ({sharedPostsAndEvents.length})
              </button>
            </div>

            {/* Tab contents */}
            {activeMediaTab === 'PHOTOS' && (
              sharedImages.length > 0 ? (
                <div className="grid grid-cols-3 gap-1.5">
                  {sharedImages.map((img, idx) => (
                    <div
                      key={img.id || idx}
                      onClick={() => onSelectMediaForLightbox && onSelectMediaForLightbox(sharedImages, idx)}
                      className="aspect-square rounded-xl overflow-hidden bg-stone-900 cursor-pointer group relative"
                    >
                      <img
                        src={img.url}
                        alt="Photo partagée"
                        className="w-full h-full object-cover transition duration-300 group-hover:scale-110"
                      />
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-stone-400 italic text-center py-4">Aucune photo partagée</p>
              )
            )}

            {activeMediaTab === 'VIDEOS' && (
              sharedVideos.length > 0 ? (
                <div className="space-y-2">
                  {sharedVideos.map((vid, idx) => (
                    <div key={idx} className="rounded-xl overflow-hidden bg-black">
                      <video src={vid.url} controls className="w-full max-h-40 object-cover" />
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-stone-400 italic text-center py-4">Aucune vidéo partagée</p>
              )
            )}

            {activeMediaTab === 'FILES' && (
              sharedFiles.length > 0 ? (
                <div className="space-y-1.5">
                  {sharedFiles.map((f, idx) => (
                    <div
                      key={idx}
                      className="p-2 rounded-xl bg-stone-50 border border-stone-200 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2 truncate">
                        <FileText className="w-4 h-4 text-blue-600 shrink-0" />
                        <span className="font-semibold truncate">{f.fileName}</span>
                      </div>
                      <span className="text-[10px] text-stone-400 shrink-0">
                        {MessagingService.formatFileSize(f.fileSize)}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-stone-400 italic text-center py-4">Aucun document partagé</p>
              )
            )}

            {activeMediaTab === 'LINKS' && (
              sharedPostsAndEvents.length > 0 ? (
                <div className="space-y-2">
                  {sharedPostsAndEvents.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-xl bg-stone-50 border border-stone-200 space-y-1 text-xs"
                    >
                      <div className="flex items-center gap-1.5 font-bold text-stone-800">
                        {item.type === 'POST' ? <Sparkles className="w-3.5 h-3.5 text-blue-600" /> : <Calendar className="w-3.5 h-3.5 text-amber-600" />}
                        <span>{item.item.title || 'Contenu partagé'}</span>
                      </div>
                      <p className="text-[11px] text-stone-500 line-clamp-1">
                        Partagé par {item.senderName}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-stone-400 italic text-center py-4">Aucun partage</p>
              )
            )}
          </div>

          {/* Danger & Moderation Actions */}
          <div className="space-y-2 pt-4 border-t border-stone-200">
            {isGroup ? (
              <button
                type="button"
                onClick={handleLeaveGroup}
                className="w-full p-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold border border-rose-200 flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
                <span>Quitter le groupe</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleBlockMember}
                className="w-full p-2.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold border border-stone-300 flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <Ban className="w-4 h-4 text-stone-600" />
                <span>Bloquer ce membre</span>
              </button>
            )}

            <button
              type="button"
              onClick={onOpenReportModal}
              className="w-full p-2.5 rounded-xl text-stone-500 hover:text-rose-600 hover:bg-stone-50 text-xs font-semibold flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <Flag className="w-4 h-4" />
              <span>Signaler un abus ou contenu inapproprié</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
