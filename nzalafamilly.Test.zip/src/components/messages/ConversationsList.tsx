/**
 * NzalaFamilly - Liste Latérale des Conversations & Filtres
 */

import React, { useState } from 'react';
import {
  Search,
  Plus,
  Pin,
  Archive,
  CheckCheck,
  Users,
  MessageSquare,
  Shield,
  MoreVertical,
  Camera,
  Video,
  Mic,
  FileText,
  Sparkles,
  Calendar,
  Trash2,
} from 'lucide-react';
import { FamilyConversation } from '../../types/messaging';
import { useFamily } from '../../context/FamilyContext';
import { MessagingService } from '../../services/messagingService';

export type ConversationFilterTab = 'TOUS' | 'NON_LUS' | 'EPINGLES' | 'GROUPES' | 'DIRECTS' | 'ARCHIVES';

interface ConversationsListProps {
  conversations: FamilyConversation[];
  activeConversationId: string | null;
  onSelectConversation: (id: string) => void;
  onOpenNewConversationModal: () => void;
}

export const ConversationsList: React.FC<ConversationsListProps> = ({
  conversations,
  activeConversationId,
  onSelectConversation,
  onOpenNewConversationModal,
}) => {
  const {
    currentUser,
    blockedContacts,
    presences,
    togglePinConversation,
    toggleArchiveConversation,
    markConversationAsRead,
    deleteConversation,
    totalUnreadMessagesCount,
  } = useFamily();

  const [activeTab, setActiveTab] = useState<ConversationFilterTab>('TOUS');
  const [searchQuery, setSearchQuery] = useState('');
  const [openDropdownId, setOpenDropdownId] = useState<string | null>(null);

  // Filter conversations
  const visibleConversations = MessagingService.getVisibleConversations(
    currentUser,
    conversations,
    blockedContacts
  );

  const filteredConversations = visibleConversations.filter((conv) => {
    const unreadCount = conv.participants.find((p) => p.userId === currentUser.id)?.unreadCount || 0;
    const title = MessagingService.getConversationTitle(conv, currentUser.id);

    // Tab filter
    if (activeTab === 'NON_LUS' && unreadCount === 0) return false;
    if (activeTab === 'EPINGLES' && !conv.isPinned) return false;
    if (activeTab === 'GROUPES' && conv.type !== 'GROUP') return false;
    if (activeTab === 'DIRECTS' && conv.type !== 'DIRECT') return false;
    if (activeTab === 'ARCHIVES' && !conv.isArchived) return false;
    if (activeTab !== 'ARCHIVES' && conv.isArchived) return false;

    // Search query filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const inTitle = title.toLowerCase().includes(q);
      const inLastMsg = conv.lastMessage?.content?.toLowerCase().includes(q);
      return inTitle || inLastMsg;
    }

    return true;
  });

  // Helper to render last message preview icon
  const renderMediaTypeIcon = (type?: string) => {
    switch (type) {
      case 'IMAGE':
        return <Camera className="w-3.5 h-3.5 text-blue-500 shrink-0 inline mr-1" />;
      case 'VIDEO':
        return <Video className="w-3.5 h-3.5 text-indigo-500 shrink-0 inline mr-1" />;
      case 'AUDIO':
        return <Mic className="w-3.5 h-3.5 text-amber-500 shrink-0 inline mr-1" />;
      case 'FILE':
        return <FileText className="w-3.5 h-3.5 text-stone-500 shrink-0 inline mr-1" />;
      case 'POST':
        return <Sparkles className="w-3.5 h-3.5 text-purple-500 shrink-0 inline mr-1" />;
      case 'EVENT':
        return <Calendar className="w-3.5 h-3.5 text-emerald-500 shrink-0 inline mr-1" />;
      default:
        return null;
    }
  };

  return (
    <div className="w-full h-full flex flex-col bg-white border-r border-stone-200 select-none">
      {/* Top Header */}
      <div className="p-3 sm:p-4 border-b border-stone-200 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-bold font-serif text-stone-900">Nzala Messages</h2>
            {totalUnreadMessagesCount > 0 && (
              <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-amber-500 text-stone-950 shadow-xs">
                {totalUnreadMessagesCount}
              </span>
            )}
          </div>

          <button
            type="button"
            onClick={onOpenNewConversationModal}
            className="p-2 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white shadow-md transition active:scale-95 flex items-center gap-1.5 text-xs font-bold cursor-pointer"
            title="Nouvelle discussion"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Nouveau</span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher une discussion..."
            className="w-full pl-9 pr-4 py-2 rounded-2xl bg-stone-100 border border-stone-200 text-xs sm:text-sm text-stone-900 placeholder:text-stone-400 outline-none focus:bg-white focus:border-blue-500 transition"
          />
        </div>

        {/* Filter Navigation Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 no-scrollbar text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('TOUS')}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition cursor-pointer ${
              activeTab === 'TOUS'
                ? 'bg-stone-900 text-white shadow-xs'
                : 'text-stone-600 hover:bg-stone-100'
            }`}
          >
            Tous
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('NON_LUS')}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1 ${
              activeTab === 'NON_LUS'
                ? 'bg-stone-900 text-white shadow-xs'
                : 'text-stone-600 hover:bg-stone-100'
            }`}
          >
            <span>Non lus</span>
            {totalUnreadMessagesCount > 0 && (
              <span className="w-2 h-2 rounded-full bg-amber-500" />
            )}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('EPINGLES')}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition cursor-pointer ${
              activeTab === 'EPINGLES'
                ? 'bg-stone-900 text-white shadow-xs'
                : 'text-stone-600 hover:bg-stone-100'
            }`}
          >
            Épinglés
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('GROUPES')}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition cursor-pointer ${
              activeTab === 'GROUPES'
                ? 'bg-stone-900 text-white shadow-xs'
                : 'text-stone-600 hover:bg-stone-100'
            }`}
          >
            Groupes
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('DIRECTS')}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition cursor-pointer ${
              activeTab === 'DIRECTS'
                ? 'bg-stone-900 text-white shadow-xs'
                : 'text-stone-600 hover:bg-stone-100'
            }`}
          >
            Directs
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('ARCHIVES')}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition cursor-pointer ${
              activeTab === 'ARCHIVES'
                ? 'bg-stone-900 text-white shadow-xs'
                : 'text-stone-600 hover:bg-stone-100'
            }`}
          >
            Archivés
          </button>
        </div>
      </div>

      {/* Conversations Scrollable List */}
      <div className="flex-1 overflow-y-auto divide-y divide-stone-100">
        {filteredConversations.length > 0 ? (
          filteredConversations.map((conv) => {
            const isSelected = conv.id === activeConversationId;
            const isPinned = !!conv.isPinned;
            const isArchived = !!conv.isArchived;
            const unreadCount =
              conv.participants.find((p) => p.userId === currentUser.id)?.unreadCount || 0;
            const title = MessagingService.getConversationTitle(conv, currentUser.id);
            const avatar = MessagingService.getConversationAvatar(conv, currentUser.id);
            const isOnline = MessagingService.isConversationOnline(conv, currentUser.id, presences);
            const lastMsgDate = conv.lastMessage?.createdAt || conv.updatedAt;

            return (
              <div
                key={conv.id}
                onClick={() => {
                  onSelectConversation(conv.id);
                  if (unreadCount > 0) {
                    markConversationAsRead(conv.id);
                  }
                }}
                className={`p-3 sm:p-3.5 transition-all flex items-start gap-3 cursor-pointer relative group ${
                  isSelected
                    ? 'bg-blue-50/80 border-l-4 border-blue-600'
                    : 'hover:bg-stone-50/80 border-l-4 border-transparent'
                }`}
              >
                {/* Avatar with Online/Shield indicator */}
                <div className="relative shrink-0">
                  {avatar ? (
                    <img
                      src={avatar}
                      alt={title}
                      className="w-12 h-12 rounded-2xl object-cover shadow-xs border border-stone-200"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white flex items-center justify-center text-lg font-bold font-serif shadow-xs">
                      {conv.type === 'GROUP' ? <Users className="w-6 h-6" /> : title.charAt(0)}
                    </div>
                  )}

                  {/* Online dot for Directs */}
                  {conv.type === 'DIRECT' && isOnline && (
                    <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white" />
                  )}

                  {/* Council of Family badge */}
                  {conv.isCouncilGroup && (
                    <span
                      className="absolute -bottom-1 -right-1 p-0.5 bg-amber-500 text-stone-950 rounded-lg shadow border border-amber-300"
                      title="Conseil de Famille"
                    >
                      <Shield className="w-3 h-3" />
                    </span>
                  )}
                </div>

                {/* Conversation Details */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-0.5">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <h4
                        className={`text-xs sm:text-sm font-bold truncate ${
                          isSelected ? 'text-blue-900' : 'text-stone-900'
                        }`}
                      >
                        {title}
                      </h4>
                      {isPinned && <Pin className="w-3 h-3 text-amber-600 shrink-0 fill-current" />}
                    </div>

                    <span
                      className={`text-[10px] whitespace-nowrap ml-1 ${
                        unreadCount > 0 ? 'font-bold text-blue-600' : 'text-stone-400'
                      }`}
                    >
                      {lastMsgDate ? MessagingService.formatRelativeTime(lastMsgDate) : ''}
                    </span>
                  </div>

                  {/* Last Message preview */}
                  <div className="flex items-center justify-between gap-1">
                    <p
                      className={`text-xs truncate ${
                        unreadCount > 0
                          ? 'font-bold text-stone-900'
                          : 'text-stone-500 font-normal'
                      }`}
                    >
                      {renderMediaTypeIcon(conv.lastMessage?.mediaType)}
                      {conv.lastMessage?.content || 'Aucun message'}
                    </p>

                    {/* Badges / Unread counter */}
                    {unreadCount > 0 && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-600 text-white shrink-0 shadow-xs">
                        {unreadCount}
                      </span>
                    )}
                  </div>
                </div>

                {/* Hover Quick Actions Menu */}
                <div className="relative shrink-0">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setOpenDropdownId(openDropdownId === conv.id ? null : conv.id);
                    }}
                    className="p-1 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-200/60 opacity-0 group-hover:opacity-100 transition cursor-pointer"
                  >
                    <MoreVertical className="w-4 h-4" />
                  </button>

                  {openDropdownId === conv.id && (
                    <>
                      <div
                        className="fixed inset-0 z-30"
                        onClick={(e) => {
                          e.stopPropagation();
                          setOpenDropdownId(null);
                        }}
                      />
                      <div
                        className="absolute right-0 top-full mt-1 w-44 bg-white border border-stone-200 rounded-2xl shadow-xl p-1 z-40 text-xs text-stone-800 space-y-0.5 animate-fadeIn"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <button
                          type="button"
                          onClick={() => {
                            togglePinConversation(conv.id);
                            setOpenDropdownId(null);
                          }}
                          className="w-full px-2.5 py-1.5 rounded-xl hover:bg-stone-100 text-left flex items-center gap-2 transition cursor-pointer"
                        >
                          <Pin className="w-3.5 h-3.5 text-stone-500" />
                          <span>{isPinned ? 'Désépingler' : 'Épingler'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            toggleArchiveConversation(conv.id);
                            setOpenDropdownId(null);
                          }}
                          className="w-full px-2.5 py-1.5 rounded-xl hover:bg-stone-100 text-left flex items-center gap-2 transition cursor-pointer"
                        >
                          <Archive className="w-3.5 h-3.5 text-stone-500" />
                          <span>{isArchived ? 'Désarchiver' : 'Archiver'}</span>
                        </button>

                        {unreadCount > 0 ? (
                          <button
                            type="button"
                            onClick={() => {
                              markConversationAsRead(conv.id);
                              setOpenDropdownId(null);
                            }}
                            className="w-full px-2.5 py-1.5 rounded-xl hover:bg-stone-100 text-left flex items-center gap-2 transition cursor-pointer"
                          >
                            <CheckCheck className="w-3.5 h-3.5 text-blue-600" />
                            <span>Marquer comme lu</span>
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => {
                              // mark as unread
                              setOpenDropdownId(null);
                            }}
                            className="w-full px-2.5 py-1.5 rounded-xl hover:bg-stone-100 text-left flex items-center gap-2 transition cursor-pointer"
                          >
                            <MessageSquare className="w-3.5 h-3.5 text-stone-500" />
                            <span>Marquer comme non lu</span>
                          </button>
                        )}

                        <div className="pt-1 border-t border-stone-100">
                          <button
                            type="button"
                            onClick={() => {
                              if (window.confirm('Voulez-vous supprimer cette conversation ?')) {
                                deleteConversation(conv.id);
                              }
                              setOpenDropdownId(null);
                            }}
                            className="w-full px-2.5 py-1.5 rounded-xl hover:bg-rose-50 text-rose-600 text-left flex items-center gap-2 transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Supprimer</span>
                          </button>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            );
          })
        ) : (
          <div className="p-8 text-center space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-stone-100 text-stone-400 mx-auto flex items-center justify-center">
              <MessageSquare className="w-6 h-6" />
            </div>
            <p className="text-xs sm:text-sm font-semibold text-stone-600">Aucune discussion trouvée</p>
            <p className="text-[11px] text-stone-400">
              {searchQuery
                ? 'Essayez un autre mot-clé ou filtre.'
                : 'Commencez une nouvelle conversation familiale.'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
