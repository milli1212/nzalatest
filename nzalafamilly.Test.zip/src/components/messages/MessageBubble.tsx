/**
 * NzalaFamilly - Bulle de Message Élégante et Multifonction
 */

import React, { useState } from 'react';
import {
  Check,
  CheckCheck,
  Clock,
  AlertCircle,
  CornerUpLeft,
  Smile,
  MoreVertical,
  Edit2,
  Trash2,
  Copy,
  Flag,
  FileText,
  Download,
  Calendar,
  Newspaper,
  ExternalLink,
  Play,
  Languages,
  Eye,
  EyeOff,
  Lock,
  Sparkles,
  ShieldCheck,
  Ban,
} from 'lucide-react';
import { FamilyMessage, MessageReaction, MessageAttachment } from '../../types/messaging';
import { useFamily } from '../../context/FamilyContext';
import { MessagingService } from '../../services/messagingService';
import { TranslationService, SUPPORTED_LANGUAGES } from '../../services/translationService';
import { AudioMessagePlayer } from './AudioMessagePlayer';
import { ViewOnceModal } from './ViewOnceModal';
import { VerifiedBadge } from '../common/VerifiedBadge';
import { BlockUserModal } from '../common/BlockUserModal';
import { IssueReportModal } from '../common/IssueReportModal';
import { MediaItem } from '../../types';

interface MessageBubbleProps {
  message: FamilyMessage;
  isGroup?: boolean;
  onReply: (message: FamilyMessage) => void;
  onEdit: (message: FamilyMessage) => void;
  onDelete: (messageId: string) => void;
  onReport: (message: FamilyMessage) => void;
  onSelectMediaForLightbox?: (mediaList: MediaItem[], initialIndex: number) => void;
  onScrollToMessage?: (messageId: string) => void;
}

const POPULAR_REACTIONS = ['❤️', '😂', '🙏', '👏', '🎉', '🕊️', '👍'];

export const MessageBubble: React.FC<MessageBubbleProps> = ({
  message,
  isGroup = false,
  onReply,
  onEdit,
  onDelete,
  onReport,
  onSelectMediaForLightbox,
  onScrollToMessage,
}) => {
  const { currentUser, toggleMessageReaction, showToast, setActiveTab, setSelectedEvent } = useFamily();
  const [showReactionPicker, setShowReactionPicker] = useState(false);
  const [showActionsMenu, setShowActionsMenu] = useState(false);
  const [showLangSelector, setShowLangSelector] = useState(false);
  const [translatedText, setTranslatedText] = useState<string | null>(message.translatedContent || null);
  const [translatedLang, setTranslatedLang] = useState<string | null>(message.translatedLanguage || null);
  const [isTranslating, setIsTranslating] = useState(false);
  const [isViewOnceModalOpen, setIsViewOnceModalOpen] = useState(false);
  const [activeViewOnceAttachment, setActiveViewOnceAttachment] = useState<MessageAttachment | undefined>(undefined);
  const [viewOnceLocalState, setViewOnceLocalState] = useState<'UNOPENED' | 'VIEWED'>(
    message.viewOnceState === 'VIEWED' ? 'VIEWED' : 'UNOPENED'
  );
  const [isBlockModalOpen, setIsBlockModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);

  const handleTranslate = async (targetLang: string) => {
    if (!message.content) return;
    setIsTranslating(true);
    try {
      const result = await TranslationService.translateMessage(message.content, targetLang as any);
      setTranslatedText(result.translatedText);
      setTranslatedLang(result.targetLanguage);
      const langInfo = TranslationService.getLanguageInfo(result.targetLanguage);
      showToast('info', `Message traduit en ${langInfo.name}.`);
    } catch {
      showToast('error', 'Échec de la traduction.');
    } finally {
      setIsTranslating(false);
      setShowLangSelector(false);
      setShowActionsMenu(false);
    }
  };

  const handleOpenViewOnce = (attachment?: MessageAttachment) => {
    if (viewOnceLocalState === 'VIEWED' && !isSentByMe) {
      showToast('warning', 'Ce média à vue unique a déjà été consulté.');
      return;
    }
    setActiveViewOnceAttachment(attachment);
    setIsViewOnceModalOpen(true);
  };

  const handleMarkAsViewed = () => {
    setViewOnceLocalState('VIEWED');
  };

  const isSentByMe = message.senderId === currentUser.id;

  // Render status icon
  const renderStatusIcon = () => {
    if (!isSentByMe) return null;

    switch (message.status) {
      case 'ENVOI':
        return (
          <span title="En cours d’envoi">
            <Clock className="w-3 h-3 text-blue-200 animate-pulse" />
          </span>
        );
      case 'ENVOYE':
        return (
          <span title="Envoyé">
            <Check className="w-3 h-3 text-blue-200" />
          </span>
        );
      case 'LIVRE':
        return (
          <span title="Délivré">
            <CheckCheck className="w-3.5 h-3.5 text-blue-200" />
          </span>
        );
      case 'LU':
        return (
          <span title="Lu">
            <CheckCheck className="w-3.5 h-3.5 text-amber-300" />
          </span>
        );
      case 'ERREUR':
        return (
          <span title="Erreur d’envoi">
            <AlertCircle className="w-3 h-3 text-rose-300" />
          </span>
        );
      default:
        return <CheckCheck className="w-3.5 h-3.5 text-blue-200" />;
    }
  };

  const handleCopyText = () => {
    if (message.content) {
      navigator.clipboard.writeText(message.content);
      showToast('success', 'Message copié dans le presse-papier.');
    }
  };

  const handleReactionClick = (emoji: string) => {
    toggleMessageReaction(message.id, emoji);
    setShowReactionPicker(false);
  };

  // Regroup reactions by emoji
  const groupedReactions = message.reactions?.reduce<Record<string, { count: number; users: string[]; hasReacted: boolean }>>(
    (acc, r) => {
      if (!acc[r.emoji]) {
        acc[r.emoji] = { count: 0, users: [], hasReacted: false };
      }
      acc[r.emoji].count += 1;
      acc[r.emoji].users.push(r.userName);
      if (r.userId === currentUser.id) {
        acc[r.emoji].hasReacted = true;
      }
      return acc;
    },
    {}
  ) || {};

  // Formatter text with mentions & links
  const renderFormattedText = (text: string) => {
    if (!text) return null;

    // Pattern for URLs and @Mentions
    const parts = text.split(/(@[\w\-_]+|https?:\/\/[^\s]+)/g);

    return parts.map((part, i) => {
      if (part.startsWith('@')) {
        return (
          <span
            key={i}
            className={`font-bold px-1 py-0.5 rounded ${
              isSentByMe ? 'bg-blue-800 text-amber-300' : 'bg-blue-100 text-blue-800'
            }`}
          >
            {part}
          </span>
        );
      }
      if (part.match(/^https?:\/\//)) {
        return (
          <a
            key={i}
            href={part}
            target="_blank"
            rel="noopener noreferrer"
            className={`underline break-all ${isSentByMe ? 'text-amber-200 hover:text-white' : 'text-blue-600 hover:text-blue-800'}`}
          >
            {part}
          </a>
        );
      }
      return part;
    });
  };

  // Image attachments
  const imageAttachments = message.attachments?.filter((a) => a.type === 'IMAGE') || [];
  const videoAttachments = message.attachments?.filter((a) => a.type === 'VIDEO') || [];
  const audioAttachments = message.attachments?.filter((a) => a.type === 'AUDIO') || [];
  const fileAttachments = message.attachments?.filter((a) => a.type === 'FILE') || [];

  return (
    <div
      id={`message-${message.id}`}
      className={`group relative flex flex-col mb-3 transition-colors rounded-2xl ${
        isSentByMe ? 'items-end' : 'items-start'
      }`}
    >
      {/* Sender name for group chats if received */}
      {!isSentByMe && isGroup && (
        <div className="flex items-center gap-2 mb-1 px-1 flex-wrap">
          <span className="text-xs font-bold text-stone-700">{message.senderName}</span>
          <VerifiedBadge
            role={message.senderRole as any}
            isVerified={message.isSenderVerified || message.senderRole === 'SUPER_ADMIN' || message.senderRole === 'ADMIN_FAMILIAL'}
          />
          {message.senderRole && (
            <span className="text-[10px] text-stone-600 bg-stone-100 px-1.5 py-0.5 rounded border border-stone-200">
              {message.senderRole.replace('_', ' ')}
            </span>
          )}
        </div>
      )}

      {/* Main Bubble Container with Actions Toolbar on Hover */}
      <div className={`relative max-w-[85%] sm:max-w-[70%] flex flex-col ${isSentByMe ? 'items-end' : 'items-start'}`}>
        {/* Floating Quick Actions Bar (Hover) */}
        <div
          className={`absolute -top-7 z-20 hidden group-hover:flex items-center gap-1 p-1 bg-stone-900/90 backdrop-blur-sm border border-stone-700 rounded-full shadow-lg text-stone-200 text-xs transition-opacity ${
            isSentByMe ? 'right-0' : 'left-0'
          }`}
        >
          {/* Reaction Picker Button */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowReactionPicker(!showReactionPicker)}
              className="p-1 hover:bg-stone-800 rounded-full transition text-amber-400 cursor-pointer"
              title="Ajouter une réaction"
            >
              <Smile className="w-3.5 h-3.5" />
            </button>

            {/* Quick Emoji Dropdown */}
            {showReactionPicker && (
              <div
                className="absolute bottom-full mb-2 left-0 bg-stone-900 border border-stone-700 rounded-2xl p-1.5 shadow-2xl flex items-center gap-1 z-30 animate-fadeIn"
                onClick={(e) => e.stopPropagation()}
              >
                {POPULAR_REACTIONS.map((emoji) => (
                  <button
                    key={emoji}
                    type="button"
                    onClick={() => handleReactionClick(emoji)}
                    className="w-7 h-7 flex items-center justify-center hover:bg-stone-800 rounded-xl text-base transition hover:scale-125 cursor-pointer"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Reply */}
          <button
            type="button"
            onClick={() => onReply(message)}
            className="p-1 hover:bg-stone-800 rounded-full transition cursor-pointer"
            title="Répondre au message"
          >
            <CornerUpLeft className="w-3.5 h-3.5" />
          </button>

          {/* More Options */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowActionsMenu(!showActionsMenu)}
              className="p-1 hover:bg-stone-800 rounded-full transition cursor-pointer"
              title="Plus d'options"
            >
              <MoreVertical className="w-3.5 h-3.5" />
            </button>

            {showActionsMenu && (
              <>
                <div className="fixed inset-0 z-30" onClick={() => setShowActionsMenu(false)} />
                <div className="absolute right-0 top-full mt-1 w-44 bg-stone-900 border border-stone-700 rounded-xl shadow-2xl p-1 z-40 text-stone-200 text-xs divide-y divide-stone-800">
                  <div className="py-0.5">
                    <button
                      type="button"
                      onClick={() => {
                        handleCopyText();
                        setShowActionsMenu(false);
                      }}
                      className="w-full px-2.5 py-1.5 flex items-center gap-2 hover:bg-stone-800 rounded-lg text-left transition cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5 text-stone-400" />
                      <span>Copier le texte</span>
                    </button>

                    {message.content && (
                      <button
                        type="button"
                        onClick={() => setShowLangSelector(!showLangSelector)}
                        className="w-full px-2.5 py-1.5 flex items-center gap-2 hover:bg-stone-800 rounded-lg text-left transition cursor-pointer text-amber-300"
                      >
                        <Languages className="w-3.5 h-3.5" />
                        <span>Traduire le message...</span>
                      </button>
                    )}
                  </div>

                  {/* Language selection sub-list */}
                  {showLangSelector && (
                    <div className="p-1 bg-stone-950 rounded-lg space-y-0.5 max-h-40 overflow-y-auto">
                      <p className="text-[10px] text-stone-400 px-2 py-0.5 font-bold uppercase">Choisir la langue :</p>
                      {SUPPORTED_LANGUAGES.map((l) => (
                        <button
                          key={l.code}
                          type="button"
                          onClick={() => handleTranslate(l.code)}
                          disabled={isTranslating}
                          className="w-full px-2 py-1 flex items-center justify-between text-[11px] hover:bg-stone-800 rounded text-left text-stone-200 transition cursor-pointer"
                        >
                          <span>{l.name}</span>
                          <span className="text-[10px] text-stone-500 font-mono">{l.code}</span>
                        </button>
                      ))}
                    </div>
                  )}

                  {isSentByMe ? (
                    <div className="py-0.5 space-y-0.5">
                      <button
                        type="button"
                        onClick={() => {
                          onEdit(message);
                          setShowActionsMenu(false);
                        }}
                        className="w-full px-2.5 py-1.5 flex items-center gap-2 hover:bg-stone-800 rounded-lg text-left transition cursor-pointer"
                      >
                        <Edit2 className="w-3.5 h-3.5 text-stone-400" />
                        <span>Modifier</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onDelete(message.id);
                          setShowActionsMenu(false);
                        }}
                        className="w-full px-2.5 py-1.5 flex items-center gap-2 hover:bg-rose-950/40 text-rose-400 rounded-lg text-left transition cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Supprimer</span>
                      </button>
                    </div>
                  ) : (
                    <div className="py-0.5 space-y-0.5">
                      <button
                        type="button"
                        onClick={() => {
                          setIsReportModalOpen(true);
                          setShowActionsMenu(false);
                        }}
                        className="w-full px-2.5 py-1.5 flex items-center gap-2 hover:bg-stone-800 text-stone-300 rounded-lg text-left transition cursor-pointer"
                      >
                        <Flag className="w-3.5 h-3.5 text-amber-400" />
                        <span>Signaler le message</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setIsBlockModalOpen(true);
                          setShowActionsMenu(false);
                        }}
                        className="w-full px-2.5 py-1.5 flex items-center gap-2 hover:bg-rose-950/40 text-rose-400 rounded-lg text-left transition cursor-pointer"
                      >
                        <Ban className="w-3.5 h-3.5" />
                        <span>Bloquer l'expéditeur</span>
                      </button>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        </div>

        {/* Message Bubble Content */}
        <div
          className={`rounded-2xl p-3 sm:p-3.5 shadow-sm space-y-2 relative transition-all ${
            isSentByMe
              ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-tr-xs'
              : 'bg-white text-stone-900 border border-stone-200/80 rounded-tl-xs'
          }`}
        >
          {/* Quoted Message (Reply) */}
          {message.quotedMessage && (
            <div
              onClick={() => onScrollToMessage && onScrollToMessage(message.quotedMessage!.id)}
              className={`p-2 rounded-xl text-xs border-l-4 cursor-pointer transition hover:opacity-90 ${
                isSentByMe
                  ? 'bg-blue-800/60 border-amber-400 text-blue-100'
                  : 'bg-stone-100 border-blue-600 text-stone-700'
              }`}
            >
              <div className="flex items-center gap-1 font-bold text-[11px]">
                <CornerUpLeft className="w-3 h-3" />
                <span>{message.quotedMessage.senderName}</span>
              </div>
              <p className="line-clamp-1 italic mt-0.5">{message.quotedMessage.content}</p>
            </div>
          )}

          {/* View Once Attachment Handler */}
          {(message.isViewOnce || message.attachments?.some((a) => a.isViewOnce)) && (
            <div className="my-1">
              {viewOnceLocalState === 'UNOPENED' ? (
                <button
                  type="button"
                  onClick={() => handleOpenViewOnce(message.attachments?.[0])}
                  className={`w-full flex items-center gap-2.5 p-3 rounded-xl border text-left font-medium transition cursor-pointer ${
                    isSentByMe
                      ? 'bg-blue-700/80 border-blue-400 text-white hover:bg-blue-700'
                      : 'bg-stone-100 border-amber-300 text-stone-900 hover:bg-amber-50'
                  }`}
                >
                  <div className="w-8 h-8 rounded-full bg-amber-500 text-white flex items-center justify-center shrink-0">
                    <Lock className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-xs font-bold flex items-center gap-1.5">
                      <span>{message.mediaType === 'VIDEO' ? '🎥 Vidéo' : '📸 Photo'} à vue unique</span>
                      <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded font-semibold">1x</span>
                    </p>
                    <p className="text-[11px] opacity-80">Cliquer pour ouvrir de façon éphémère</p>
                  </div>
                </button>
              ) : (
                <div className={`flex items-center gap-2 p-2.5 rounded-xl text-xs italic ${
                  isSentByMe ? 'text-blue-200 bg-blue-800/40' : 'text-stone-500 bg-stone-100'
                }`}>
                  <EyeOff className="w-4 h-4 text-stone-400 shrink-0" />
                  <span>Média à vue unique ouvert & détruit</span>
                </div>
              )}
            </div>
          )}

          {/* Photo Gallery / Images (Non View Once) */}
          {!message.isViewOnce && imageAttachments.filter((a) => !a.isViewOnce).length > 0 && (
            <div
              className={`grid gap-1.5 rounded-xl overflow-hidden ${
                imageAttachments.filter((a) => !a.isViewOnce).length === 1
                  ? 'grid-cols-1'
                  : imageAttachments.filter((a) => !a.isViewOnce).length === 2
                  ? 'grid-cols-2'
                  : 'grid-cols-2 sm:grid-cols-3'
              }`}
            >
              {imageAttachments.filter((a) => !a.isViewOnce).map((img, idx) => (
                <div
                  key={img.id || idx}
                  onClick={() => {
                    if (onSelectMediaForLightbox) {
                      const mediaList: MediaItem[] = imageAttachments.map((att) => ({
                        id: att.id,
                        type: 'IMAGE',
                        url: att.url,
                        caption: att.caption,
                      }));
                      onSelectMediaForLightbox(mediaList, idx);
                    }
                  }}
                  className="relative group/img cursor-pointer overflow-hidden rounded-lg max-h-60 bg-stone-900"
                >
                  <img
                    src={img.url}
                    alt={img.caption || 'Photo'}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover/img:scale-105"
                  />
                  {img.caption && (
                    <div className="absolute bottom-0 inset-x-0 p-1.5 bg-gradient-to-t from-stone-950/80 to-transparent text-[11px] text-white truncate">
                      {img.caption}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Video Attachment (Non View Once) */}
          {!message.isViewOnce && videoAttachments.filter((a) => !a.isViewOnce).length > 0 && (
            <div className="space-y-1.5">
              {videoAttachments.filter((a) => !a.isViewOnce).map((vid, idx) => (
                <div key={vid.id || idx} className="rounded-xl overflow-hidden bg-black border border-stone-700">
                  <video
                    src={vid.url}
                    controls
                    preload="metadata"
                    className="w-full max-h-64 object-contain"
                  />
                  {vid.caption && (
                    <div className="p-2 text-xs text-stone-300 bg-stone-950/90">{vid.caption}</div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Audio Message Player */}
          {audioAttachments.length > 0 && (
            <div className="space-y-1">
              {audioAttachments.map((aud, idx) => (
                <AudioMessagePlayer
                  key={aud.id || idx}
                  audioUrl={aud.url}
                  durationSec={aud.durationSec}
                  isSentByMe={isSentByMe}
                />
              ))}
            </div>
          )}

          {/* File Attachments */}
          {fileAttachments.length > 0 && (
            <div className="space-y-1.5">
              {fileAttachments.map((file, idx) => (
                <div
                  key={file.id || idx}
                  className={`flex items-center justify-between gap-3 p-2.5 rounded-xl border ${
                    isSentByMe
                      ? 'bg-blue-700/60 border-blue-400/40 text-white'
                      : 'bg-stone-50 border-stone-200 text-stone-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div
                      className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                        isSentByMe ? 'bg-white/20 text-white' : 'bg-blue-100 text-blue-700'
                      }`}
                    >
                      <FileText className="w-5 h-5" />
                    </div>
                    <div className="truncate">
                      <p className="text-xs font-bold truncate">{file.fileName || 'Document'}</p>
                      <p className={`text-[10px] ${isSentByMe ? 'text-blue-200' : 'text-stone-500'}`}>
                        {MessagingService.formatFileSize(file.fileSize)}
                      </p>
                    </div>
                  </div>

                  <a
                    href={file.url}
                    download={file.fileName}
                    className={`p-2 rounded-lg transition shrink-0 ${
                      isSentByMe
                        ? 'bg-white/20 hover:bg-white/30 text-white'
                        : 'bg-stone-200 hover:bg-stone-300 text-stone-700'
                    }`}
                    title="Télécharger le fichier"
                  >
                    <Download className="w-4 h-4" />
                  </a>
                </div>
              ))}
            </div>
          )}

          {/* Shared Post Card */}
          {message.sharedPost && (
            <div
              onClick={() => setActiveTab('announcements')}
              className={`p-3 rounded-xl border space-y-2 cursor-pointer transition hover:opacity-95 ${
                isSentByMe
                  ? 'bg-blue-800/80 border-blue-400/40 text-white'
                  : 'bg-stone-50 border-stone-200 text-stone-900'
              }`}
            >
              <div className="flex items-center justify-between text-[11px] font-bold">
                <div className="flex items-center gap-1.5">
                  <Newspaper className="w-3.5 h-3.5 text-amber-400" />
                  <span>Publication partagée du Fil Familial</span>
                </div>
                <ExternalLink className="w-3 h-3 opacity-70" />
              </div>

              {message.sharedPost.firstImageUrl && (
                <img
                  src={message.sharedPost.firstImageUrl}
                  alt="Aperçu"
                  className="w-full h-32 object-cover rounded-lg"
                />
              )}

              <div>
                <p className="text-xs font-bold">{message.sharedPost.authorName}</p>
                {message.sharedPost.title && (
                  <p className="text-xs font-semibold mt-0.5 line-clamp-1">{message.sharedPost.title}</p>
                )}
                <p className="text-xs opacity-85 line-clamp-2 mt-0.5">{message.sharedPost.content}</p>
              </div>
            </div>
          )}

          {/* Shared Event Card */}
          {message.sharedEvent && (
            <div
              onClick={() => setActiveTab('events')}
              className={`p-3 rounded-xl border space-y-2 cursor-pointer transition hover:opacity-95 ${
                isSentByMe
                  ? 'bg-blue-800/80 border-blue-400/40 text-white'
                  : 'bg-stone-50 border-stone-200 text-stone-900'
              }`}
            >
              <div className="flex items-center justify-between text-[11px] font-bold">
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-amber-400" />
                  <span>Événement Familial partagé</span>
                </div>
                <ExternalLink className="w-3 h-3 opacity-70" />
              </div>

              <div>
                <p className="text-xs font-bold">{message.sharedEvent.title}</p>
                <p className="text-[11px] opacity-85 mt-0.5">
                  📅 {message.sharedEvent.startDate} • 📍 {message.sharedEvent.location}
                </p>
              </div>
            </div>
          )}

          {/* Main Text Content */}
          {message.content && (
            <div className="text-xs sm:text-sm whitespace-pre-wrap leading-relaxed break-words">
              {renderFormattedText(message.content)}
            </div>
          )}

          {/* Translated Content Section */}
          {translatedText && (
            <div
              className={`mt-2 pt-2 border-t text-xs space-y-1 ${
                isSentByMe
                  ? 'border-blue-400/40 text-blue-50 bg-blue-900/40 -mx-1 p-2 rounded-lg'
                  : 'border-stone-200 text-stone-800 bg-amber-50/70 -mx-1 p-2 rounded-lg'
              }`}
            >
              <div className="flex items-center justify-between text-[10px] opacity-80 font-bold">
                <span className="flex items-center gap-1 text-amber-500">
                  <Languages className="w-3 h-3" />
                  Traduit en {translatedLang}
                </span>
                <button
                  type="button"
                  onClick={() => setTranslatedText(null)}
                  className="hover:underline cursor-pointer opacity-70 hover:opacity-100"
                >
                  Masquer
                </button>
              </div>
              <div className="whitespace-pre-wrap leading-relaxed font-sans">
                {renderFormattedText(translatedText)}
              </div>
            </div>
          )}

          {/* Footer: Time + Edited + Status */}
          <div
            className={`flex items-center justify-end gap-1.5 text-[10px] select-none pt-0.5 ${
              isSentByMe ? 'text-blue-100' : 'text-stone-600'
            }`}
          >
            {message.isEdited && <span className="italic">(modifié)</span>}
            <span>{MessagingService.formatMessageTime(message.createdAt)}</span>
            {renderStatusIcon()}
          </div>
        </div>

        {/* Reaction Badges below the bubble */}
        {Object.keys(groupedReactions).length > 0 && (
          <div className="flex flex-wrap gap-1 mt-1 px-1">
            {Object.entries(groupedReactions).map(([emoji, data]) => (
              <button
                key={emoji}
                type="button"
                onClick={() => handleReactionClick(emoji)}
                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold shadow-xs border transition active:scale-95 cursor-pointer ${
                  data.hasReacted
                    ? 'bg-blue-100 text-blue-900 border-blue-400'
                    : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                }`}
                title={`Réactions : ${data.users.join(', ')}`}
              >
                <span>{emoji}</span>
                <span className="text-[10px] font-bold">{data.count}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* View Once Security Modal */}
      {isViewOnceModalOpen && (
        <ViewOnceModal
          isOpen={isViewOnceModalOpen}
          message={message}
          attachment={activeViewOnceAttachment}
          onClose={() => setIsViewOnceModalOpen(false)}
          onMarkAsViewed={handleMarkAsViewed}
        />
      )}

      {/* Block User Modal */}
      {isBlockModalOpen && (
        <BlockUserModal
          isOpen={isBlockModalOpen}
          targetUserId={message.senderId}
          targetUserName={message.senderName}
          onClose={() => setIsBlockModalOpen(false)}
        />
      )}

      {/* Issue Report Modal */}
      {isReportModalOpen && (
        <IssueReportModal
          isOpen={isReportModalOpen}
          defaultCategory="MESSAGERIE"
          onClose={() => setIsReportModalOpen(false)}
        />
      )}
    </div>
  );
};
