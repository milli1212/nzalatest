/**
 * NzalaFamilly - Zone de Saisie & Composition de Message Multifonction
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Smile,
  Image,
  Video,
  Paperclip,
  Mic,
  X,
  CornerUpLeft,
  FileText,
  AlertCircle,
  EyeOff,
  Lock,
} from 'lucide-react';
import {
  FamilyMessage,
  MessageAttachment,
  QuotedMessage,
  MessageMediaType,
  ConversationParticipant,
} from '../../types/messaging';
import { MessagingService } from '../../services/messagingService';
import { VoiceRecorder } from './VoiceRecorder';
import { useFamily } from '../../context/FamilyContext';

interface MessageComposerProps {
  conversationId: string;
  participants: ConversationParticipant[];
  quotedMessage: FamilyMessage | null;
  editingMessage: FamilyMessage | null;
  onClearQuote: () => void;
  onClearEdit: () => void;
  onSendMessage: (data: {
    content: string;
    mediaType?: MessageMediaType;
    attachments?: MessageAttachment[];
    quotedMessage?: QuotedMessage;
    mentions?: string[];
    isViewOnce?: boolean;
  }) => void;
  onSaveEdit: (messageId: string, content: string) => void;
}

const POPULAR_EMOJIS = [
  '😊', '😂', '❤️', '🙏', '👏', '🎉', '🔥', '✨', '🤝', '🕊️', '💐', '👑',
  '👍', '😍', '🥳', '🙌', '💪', '🌱', '☀️', '🌟', '🇨🇩', '🇫🇷', '💡', '📖'
];

export const MessageComposer: React.FC<MessageComposerProps> = ({
  conversationId,
  participants,
  quotedMessage,
  editingMessage,
  onClearQuote,
  onClearEdit,
  onSendMessage,
  onSaveEdit,
}) => {
  const { members, showToast } = useFamily();
  const [content, setContent] = useState('');
  const [attachments, setAttachments] = useState<MessageAttachment[]>([]);
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [isViewOnce, setIsViewOnce] = useState(false);

  // Mentions autocomplete state
  const [mentionQuery, setMentionQuery] = useState<string | null>(null);
  const [mentionPosition, setMentionPosition] = useState<number>(0);

  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const photoInputRef = useRef<HTMLInputElement | null>(null);
  const videoInputRef = useRef<HTMLInputElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Synchroniser avec editingMessage
  useEffect(() => {
    if (editingMessage) {
      setContent(editingMessage.content);
      if (textareaRef.current) {
        textareaRef.current.focus();
      }
    }
  }, [editingMessage]);

  // Handle textarea autosize & mention detection
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setContent(val);

    // Auto resize textarea height smoothly up to max 150px
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const newHeight = Math.min(Math.max(textareaRef.current.scrollHeight, 24), 150);
      textareaRef.current.style.height = `${newHeight}px`;
    }

    // Check for @mention trigger
    const cursorPos = e.target.selectionStart || 0;
    const textBeforeCursor = val.slice(0, cursorPos);
    const lastAtIndex = textBeforeCursor.lastIndexOf('@');

    if (lastAtIndex !== -1 && (lastAtIndex === 0 || /\s/.test(textBeforeCursor[lastAtIndex - 1]))) {
      const query = textBeforeCursor.slice(lastAtIndex + 1);
      if (!query.includes(' ') && query.length <= 20) {
        setMentionQuery(query);
        setMentionPosition(lastAtIndex);
        return;
      }
    }
    setMentionQuery(null);
  };

  const handleSelectMention = (name: string) => {
    if (mentionPosition === null) return;
    const formattedName = `@${name.replace(/\s+/g, '_')} `;
    const beforeMention = content.slice(0, mentionPosition);
    const afterMention = content.slice(mentionPosition + (mentionQuery ? mentionQuery.length + 1 : 1));
    const newContent = `${beforeMention}${formattedName}${afterMention}`;
    setContent(newContent);
    setMentionQuery(null);
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const validation = MessagingService.validateFileAttachment(file);
      if (!validation.valid) {
        showToast('error', validation.error || 'Fichier non valide.');
        return;
      }

      const reader = new FileReader();
      reader.onload = (loadEvt) => {
        if (loadEvt.target?.result) {
          const newAtt: MessageAttachment = {
            id: `att-img-${Date.now()}-${Math.random()}`,
            type: 'IMAGE',
            url: loadEvt.target.result as string,
            fileName: file.name,
            fileSize: file.size,
            mimeType: file.type,
          };
          setAttachments((prev) => [...prev, newAtt]);
        }
      };
      reader.readAsDataURL(file);
    });

    if (photoInputRef.current) photoInputRef.current.value = '';
  };

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const validation = MessagingService.validateFileAttachment(file);
    if (!validation.valid) {
      showToast('error', validation.error || 'Vidéo non valide.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (loadEvt) => {
      if (loadEvt.target?.result) {
        const newAtt: MessageAttachment = {
          id: `att-vid-${Date.now()}`,
          type: 'VIDEO',
          url: loadEvt.target.result as string,
          fileName: file.name,
          fileSize: file.size,
          mimeType: file.type,
        };
        setAttachments((prev) => [...prev, newAtt]);
      }
    };
    reader.readAsDataURL(file);
    if (videoInputRef.current) videoInputRef.current.value = '';
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const validation = MessagingService.validateFileAttachment(file);
    if (!validation.valid) {
      showToast('error', validation.error || 'Fichier non valide.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (loadEvt) => {
      if (loadEvt.target?.result) {
        const newAtt: MessageAttachment = {
          id: `att-file-${Date.now()}`,
          type: 'FILE',
          url: loadEvt.target.result as string,
          fileName: file.name,
          fileSize: file.size,
          mimeType: file.type,
        };
        setAttachments((prev) => [...prev, newAtt]);
      }
    };
    reader.readAsDataURL(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleRemoveAttachment = (id: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  };

  const handleInsertEmoji = (emoji: string) => {
    setContent((prev) => prev + emoji);
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    if (editingMessage) {
      if (!content.trim()) return;
      onSaveEdit(editingMessage.id, content.trim());
      setContent('');
      onClearEdit();
      return;
    }

    if (!content.trim() && attachments.length === 0) return;

    // Detect mediaType
    let mediaType: MessageMediaType = 'NONE';
    if (attachments.some((a) => a.type === 'IMAGE')) mediaType = 'IMAGE';
    else if (attachments.some((a) => a.type === 'VIDEO')) mediaType = 'VIDEO';
    else if (attachments.some((a) => a.type === 'AUDIO')) mediaType = 'AUDIO';
    else if (attachments.some((a) => a.type === 'FILE')) mediaType = 'FILE';

    // Build quoted message
    let quote: QuotedMessage | undefined = undefined;
    if (quotedMessage) {
      quote = {
        id: quotedMessage.id,
        senderId: quotedMessage.senderId,
        senderName: quotedMessage.senderName,
        content: quotedMessage.content || 'Média partagé',
        mediaType: quotedMessage.mediaType,
      };
    }

    // Extract mentions
    const mentionsMatches = content.match(/@[\w\-_]+/g) || [];
    const mentions = mentionsMatches.map((m) => m.slice(1).replace(/_/g, ' '));

    const finalAttachments = attachments.map((a) => (isViewOnce ? { ...a, isViewOnce: true } : a));

    onSendMessage({
      content: content.trim(),
      mediaType,
      attachments: finalAttachments.length > 0 ? finalAttachments : undefined,
      quotedMessage: quote,
      mentions: mentions.length > 0 ? mentions : undefined,
      isViewOnce: isViewOnce && finalAttachments.length > 0,
    });

    setContent('');
    setAttachments([]);
    setIsViewOnce(false);
    onClearQuote();
    setShowEmojiPicker(false);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  // Filter mention candidates from participants or members
  const mentionCandidates = participants
    .filter((p) =>
      mentionQuery ? p.userName.toLowerCase().includes(mentionQuery.toLowerCase()) : true
    )
    .slice(0, 5);

  return (
    <div className="border-t border-stone-200 bg-white p-2.5 sm:p-4 space-y-2 relative">
      {/* Hidden file inputs */}
      <input
        ref={photoInputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={handlePhotoUpload}
      />
      <input
        ref={videoInputRef}
        type="file"
        accept="video/*"
        className="hidden"
        onChange={handleVideoUpload}
      />
      <input
        ref={fileInputRef}
        type="file"
        accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt"
        className="hidden"
        onChange={handleFileUpload}
      />

      {/* Reply Banner */}
      {quotedMessage && (
        <div className="flex items-center justify-between p-2.5 rounded-2xl bg-blue-50 border border-blue-200 text-xs animate-fadeIn">
          <div className="flex items-center gap-2 min-w-0">
            <CornerUpLeft className="w-4 h-4 text-blue-600 shrink-0" />
            <div className="truncate">
              <span className="font-bold text-blue-900">Réponse à {quotedMessage.senderName} : </span>
              <span className="text-blue-700 truncate">{quotedMessage.content || 'Média'}</span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClearQuote}
            className="p-1 text-stone-400 hover:text-stone-700 rounded-full hover:bg-stone-200/60 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Edit Banner */}
      {editingMessage && (
        <div className="flex items-center justify-between p-2.5 rounded-2xl bg-amber-50 border border-amber-200 text-xs animate-fadeIn">
          <span className="font-bold text-amber-900">Modification de votre message</span>
          <button
            type="button"
            onClick={onClearEdit}
            className="p-1 text-stone-400 hover:text-stone-700 rounded-full hover:bg-amber-200/60 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Attachments Queue Preview */}
      {attachments.length > 0 && (
        <div className="flex flex-wrap gap-2 p-2 rounded-2xl bg-stone-50 border border-stone-200">
          {attachments.map((att) => (
            <div key={att.id} className="relative group/att rounded-xl overflow-hidden border border-stone-300 bg-white p-1">
              {att.type === 'IMAGE' ? (
                <img src={att.url} alt="Aperçu" className="w-16 h-16 object-cover rounded-lg" />
              ) : att.type === 'VIDEO' ? (
                <div className="w-20 h-16 bg-stone-900 rounded-lg flex items-center justify-center text-white text-xs">
                  Vidéo
                </div>
              ) : (
                <div className="flex items-center gap-1.5 p-2 text-xs text-stone-700">
                  <FileText className="w-4 h-4 text-blue-600" />
                  <span className="truncate max-w-[100px]">{att.fileName}</span>
                </div>
              )}

              <button
                type="button"
                onClick={() => handleRemoveAttachment(att.id)}
                className="absolute -top-1 -right-1 w-5 h-5 bg-rose-600 text-white rounded-full flex items-center justify-center shadow-md cursor-pointer hover:bg-rose-700"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Mentions Autocompletion Dropdown */}
      {mentionQuery !== null && mentionCandidates.length > 0 && (
        <div className="absolute bottom-full mb-2 left-4 w-64 bg-white border border-stone-200 rounded-2xl shadow-2xl p-1.5 z-40 animate-fadeIn">
          <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-stone-400">
            Mentionner un membre
          </div>
          {mentionCandidates.map((c) => (
            <button
              key={c.userId}
              type="button"
              onClick={() => handleSelectMention(c.userName)}
              className="w-full px-2.5 py-1.5 rounded-xl hover:bg-blue-50 text-left text-xs flex items-center gap-2 text-stone-800 transition cursor-pointer"
            >
              <div className="w-6 h-6 rounded-full bg-amber-600 text-white text-[10px] font-bold flex items-center justify-center">
                {c.userName.charAt(0)}
              </div>
              <span className="font-bold truncate">{c.userName}</span>
            </button>
          ))}
        </div>
      )}

      {/* Voice Recorder Overlay */}
      {isRecordingVoice ? (
        <VoiceRecorder
          onSendVoice={(voiceAtt) => {
            setIsRecordingVoice(false);
            onSendMessage({
              content: content.trim(),
              mediaType: 'AUDIO',
              attachments: [voiceAtt],
              quotedMessage: quotedMessage
                ? {
                    id: quotedMessage.id,
                    senderId: quotedMessage.senderId,
                    senderName: quotedMessage.senderName,
                    content: quotedMessage.content || 'Média',
                    mediaType: quotedMessage.mediaType,
                  }
                : undefined,
            });
            setContent('');
            onClearQuote();
          }}
          onCancel={() => setIsRecordingVoice(false)}
        />
      ) : (
        /* Main Input Bar */
        <div className="flex items-end gap-1.5 sm:gap-2">
          {/* Action buttons (left) */}
          <div className="flex items-center gap-0.5 sm:gap-1 text-stone-500 pb-1">
            {/* Emoji Trigger */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                className="p-2 rounded-xl hover:text-amber-600 hover:bg-stone-100 transition cursor-pointer"
                title="Ajouter un emoji"
              >
                <Smile className="w-5 h-5" />
              </button>

              {/* Emoji Picker Popup */}
              {showEmojiPicker && (
                <>
                  <div className="fixed inset-0 z-30" onClick={() => setShowEmojiPicker(false)} />
                  <div className="absolute bottom-full mb-2 left-0 w-64 p-3 bg-white border border-stone-200 rounded-2xl shadow-2xl z-40 grid grid-cols-6 gap-1 animate-fadeIn">
                    {POPULAR_EMOJIS.map((emoji) => (
                      <button
                        key={emoji}
                        type="button"
                        onClick={() => handleInsertEmoji(emoji)}
                        className="w-8 h-8 flex items-center justify-center text-lg hover:bg-stone-100 rounded-lg transition hover:scale-125 cursor-pointer"
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>

            {/* Photo Button */}
            <button
              type="button"
              onClick={() => photoInputRef.current?.click()}
              className="p-2 rounded-xl hover:text-blue-600 hover:bg-stone-100 transition cursor-pointer"
              title="Envoyer des photos"
            >
              <Image className="w-5 h-5" />
            </button>

            {/* Video Button */}
            <button
              type="button"
              onClick={() => videoInputRef.current?.click()}
              className="p-2 rounded-xl hover:text-indigo-600 hover:bg-stone-100 transition cursor-pointer hidden sm:inline-flex"
              title="Envoyer une vidéo"
            >
              <Video className="w-5 h-5" />
            </button>

            {/* File Attachment Button */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-2 rounded-xl hover:text-stone-800 hover:bg-stone-100 transition cursor-pointer"
              title="Envoyer un fichier ou document"
            >
              <Paperclip className="w-5 h-5" />
            </button>

            {/* View Once Toggle Button */}
            <button
              type="button"
              onClick={() => {
                const next = !isViewOnce;
                setIsViewOnce(next);
                if (next) {
                  showToast('info', 'Mode vue unique activé pour les photos/vidéos.');
                }
              }}
              className={`p-2 rounded-xl transition cursor-pointer flex items-center gap-1 ${
                isViewOnce
                  ? 'bg-amber-500 text-white font-bold shadow-xs'
                  : 'hover:text-amber-600 hover:bg-stone-100 text-stone-500'
              }`}
              title={isViewOnce ? 'Vue unique activée (Cliquer pour désactiver)' : 'Activer la vue unique (1x)'}
            >
              <Lock className="w-4 h-4" />
              <span className="text-[10px] font-bold">1x</span>
            </button>
          </div>

          {/* Text Area */}
          <div className="flex-1 bg-stone-100 rounded-2xl border border-stone-200 focus-within:border-blue-500 focus-within:bg-white transition-all px-3 py-2 flex items-center min-h-[44px]">
            <textarea
              ref={textareaRef}
              value={content}
              onChange={handleTextChange}
              onKeyDown={handleKeyDown}
              placeholder="Écrire un message... (@ pour mentionner)"
              rows={1}
              className="w-full bg-transparent text-xs sm:text-sm text-stone-900 placeholder:text-stone-400 outline-none resize-none max-h-32"
            />
          </div>

          {/* Voice Record / Send Button */}
          {content.trim() || attachments.length > 0 || editingMessage ? (
            <button
              type="button"
              onClick={() => handleSubmit()}
              className="p-2.5 sm:px-4 sm:py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95 flex items-center gap-1.5 shrink-0 cursor-pointer"
              title="Envoyer le message (Entrée)"
            >
              <Send className="w-4 h-4" />
              <span className="hidden sm:inline">Envoyer</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => setIsRecordingVoice(true)}
              className="p-2.5 rounded-2xl bg-stone-800 hover:bg-stone-900 text-white shadow transition-all active:scale-95 shrink-0 cursor-pointer"
              title="Enregistrer un message vocal"
            >
              <Mic className="w-4 h-4 text-amber-400" />
            </button>
          )}
        </div>
      )}
    </div>
  );
};
