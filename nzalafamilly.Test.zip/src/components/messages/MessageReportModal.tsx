/**
 * NzalaFamilly - Modale de Signalement de Message ou de Conversation
 */

import React, { useState } from 'react';
import { X, Flag, AlertTriangle, Send } from 'lucide-react';
import { MessageReportReason, FamilyMessage } from '../../types/messaging';
import { useFamily } from '../../context/FamilyContext';

interface MessageReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  conversationId: string;
  message?: FamilyMessage | null;
}

export const MessageReportModal: React.FC<MessageReportModalProps> = ({
  isOpen,
  onClose,
  conversationId,
  message,
}) => {
  const { currentUser, reportConversationOrMessage, showToast } = useFamily();
  const [reason, setReason] = useState<MessageReportReason>('CONTENU_INAPPROPRIE');
  const [details, setDetails] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    reportConversationOrMessage({
      conversationId,
      messageId: message?.id,
      reportedUserId: message?.senderId || 'usr-unknown',
      reason,
      details: details.trim() || undefined,
    });

    onClose();
  };

  return (
    <div
      id="message-report-modal"
      className="fixed inset-0 z-50 bg-stone-950/80 backdrop-blur-xs flex items-center justify-center p-4 select-none animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md bg-white rounded-3xl border border-stone-200 shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-stone-100 bg-stone-50 flex items-center justify-between">
          <div className="flex items-center gap-2 text-rose-600">
            <Flag className="w-5 h-5" />
            <h3 className="text-base font-bold text-stone-900">Signaler un contenu</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 rounded-xl hover:bg-stone-200/60 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <span>
              Les signalements sont traités en toute confidentialité par les administrateurs et le Conseil de Modération.
            </span>
          </div>

          {message && (
            <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200 text-xs space-y-1">
              <span className="font-bold text-stone-700">Message concerné ({message.senderName}) :</span>
              <p className="italic text-stone-600 line-clamp-2">{message.content || 'Média joint'}</p>
            </div>
          )}

          {/* Reason Selector */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Motif du signalement *
            </label>
            <select
              value={reason}
              onChange={(e) => setReason(e.target.value as MessageReportReason)}
              className="w-full px-3 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs sm:text-sm text-stone-900 outline-none focus:border-blue-500"
            >
              <option value="CONTENU_INAPPROPRIE">Contenu inapproprié ou offensant</option>
              <option value="HARCELEMENT">Harcèlement ou propos haineux</option>
              <option value="SPAM">Spam ou sollicitation non désirée</option>
              <option value="USURPATION">Usurpation d'identité familiale</option>
              <option value="AUTRE">Autre motif</option>
            </select>
          </div>

          {/* Details */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Précisions complémentaires (facultatif)
            </label>
            <textarea
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              rows={3}
              placeholder="Expliquez en quelques mots pourquoi ce contenu pose problème..."
              className="w-full px-3 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs sm:text-sm text-stone-900 outline-none focus:border-blue-500 resize-none"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-stone-600 hover:bg-stone-100 text-xs font-semibold transition cursor-pointer"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs sm:text-sm font-bold shadow flex items-center gap-1.5 transition cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>Transmettre au Conseil</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
