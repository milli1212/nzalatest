/**
 * NzalaFamilly - Vue Principale de Messagerie Privée (Nzala Messages)
 */

import React, { useState } from 'react';
import {
  MessageSquare,
  Shield,
  Users,
  Plus,
  Lock,
  Sparkles,
  Search,
  Phone,
} from 'lucide-react';
import { useFamily } from '../../context/FamilyContext';
import { ConversationsList } from './ConversationsList';
import { ChatArea } from './ChatArea';
import { NewConversationModal } from './NewConversationModal';
import { AddMemberToGroupModal } from './AddMemberToGroupModal';
import { CallHistoryTab } from '../calls/CallHistoryTab';

export const MessagesView: React.FC = () => {
  const {
    conversations,
    activeConversationId,
    setActiveConversationId,
    currentUser,
    callHistory,
    startCall,
    simulateIncomingCall,
    clearCallHistory,
  } = useFamily();

  const [subTab, setSubTab] = useState<'MESSAGES' | 'CALLS'>('MESSAGES');
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [isAddMemberModalOpen, setIsAddMemberModalOpen] = useState(false);

  // Active conversation object
  const activeConversation = conversations.find((c) => c.id === activeConversationId);

  const missedCallsCount = callHistory.filter((c) => c.status === 'MISSED').length;

  return (
    <div
      id="nzala-messages-view"
      className="w-full h-[calc(100vh-4.5rem)] sm:h-[calc(100vh-5.5rem)] bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden flex flex-col relative animate-fadeIn"
    >
      {/* Top Section Switcher (Messages vs Calls) */}
      <div className="px-4 py-2.5 bg-stone-900 border-b border-stone-800 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setSubTab('MESSAGES')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
              subTab === 'MESSAGES'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-stone-300 hover:bg-stone-800'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Discussions ({conversations.length})</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setSubTab('CALLS');
              setActiveConversationId(null);
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
              subTab === 'CALLS'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-stone-300 hover:bg-stone-800'
            }`}
          >
            <Phone className="w-3.5 h-3.5" />
            <span>Appels &amp; Visio</span>
            {missedCallsCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-rose-500 text-white text-[10px] font-black animate-pulse">
                {missedCallsCount}
              </span>
            )}
          </button>
        </div>

        <div className="hidden sm:flex items-center gap-2 text-[11px] text-stone-400">
          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
          <span>Réseau Sécurisé Nzala Connect</span>
        </div>
      </div>

      {subTab === 'CALLS' ? (
        /* CALL HISTORY VIEW */
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-stone-50">
          <CallHistoryTab
            callHistory={callHistory}
            currentUserId={currentUser.id}
            onInitiateCall={(target, type) => startCall(target, type)}
            onSimulateIncomingCall={() => simulateIncomingCall()}
            onClearHistory={clearCallHistory}
          />
        </div>
      ) : (
        /* MESSAGING SPLIT VIEW */
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          {/* Left Column: Conversations List */}
          <div
            className={`w-full md:w-80 lg:w-96 h-full shrink-0 ${
              activeConversationId ? 'hidden md:flex' : 'flex'
            } flex-col`}
          >
            <ConversationsList
              conversations={conversations}
              activeConversationId={activeConversationId}
              onSelectConversation={(id) => setActiveConversationId(id)}
              onOpenNewConversationModal={() => setIsNewModalOpen(true)}
            />
          </div>

          {/* Right Column: Chat Area or Empty State */}
          <div
            className={`flex-1 h-full ${
              !activeConversationId ? 'hidden md:flex' : 'flex'
            } flex-col bg-stone-50/50`}
          >
            {activeConversation ? (
              <ChatArea
                conversation={activeConversation}
                onBackMobile={() => setActiveConversationId(null)}
                onOpenAddMemberModal={() => setIsAddMemberModalOpen(true)}
              />
            ) : (
              /* Empty selection state on desktop */
              <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center space-y-4 select-none">
                <div className="w-20 h-20 rounded-3xl bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center shadow-inner">
                  <MessageSquare className="w-10 h-10" />
                </div>

                <div className="max-w-md space-y-1.5">
                  <h3 className="text-xl font-bold font-serif text-stone-900">
                    Messagerie Familiale Privée
                  </h3>
                  <p className="text-xs sm:text-sm text-stone-500 leading-relaxed">
                    Sélectionnez une discussion à gauche ou démarrez un nouvel échange direct ou de groupe avec vos proches.
                  </p>
                </div>

                <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsNewModalOpen(true)}
                    className="px-5 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95 flex items-center gap-2 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Nouvelle discussion</span>
                  </button>
                </div>

                <div className="pt-6 border-t border-stone-200/80 flex items-center gap-4 text-stone-400 text-xs">
                  <div className="flex items-center gap-1">
                    <Lock className="w-3.5 h-3.5 text-amber-500" />
                    <span>Chiffré &amp; Privé</span>
                  </div>
                  <span>•</span>
                  <div className="flex items-center gap-1">
                    <Shield className="w-3.5 h-3.5 text-blue-500" />
                    <span>Conseil des Sages</span>
                  </div>
                  <span>•</span>
                  <div className="flex items-center gap-1">
                    <Users className="w-3.5 h-3.5 text-indigo-500" />
                    <span>Groupes de branches</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* New Conversation Modal */}
      <NewConversationModal
        isOpen={isNewModalOpen}
        onClose={() => setIsNewModalOpen(false)}
      />

      {/* Add Member Modal (when inside a group) */}
      {activeConversation && (
        <AddMemberToGroupModal
          conversation={activeConversation}
          isOpen={isAddMemberModalOpen}
          onClose={() => setIsAddMemberModalOpen(false)}
        />
      )}
    </div>
  );
};
