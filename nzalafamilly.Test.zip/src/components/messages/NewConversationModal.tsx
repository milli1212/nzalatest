/**
 * NzalaFamilly - Modale de Création de Conversation Directe ou Groupe
 */

import React, { useState } from 'react';
import {
  X,
  MessageSquare,
  Users,
  Search,
  Check,
  Plus,
  Shield,
  HeartHandshake,
  GitFork,
  Image,
} from 'lucide-react';
import { useFamily } from '../../context/FamilyContext';

interface NewConversationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NewConversationModal: React.FC<NewConversationModalProps> = ({ isOpen, onClose }) => {
  const {
    currentUser,
    userAccounts,
    branches,
    alliedFamilies,
    alliances,
    createDirectConversation,
    createGroupConversation,
    setActiveConversationId,
  } = useFamily();

  const [activeTab, setActiveTab] = useState<'DIRECT' | 'GROUP'>('DIRECT');
  const [searchQuery, setSearchQuery] = useState('');

  // Group Form state
  const [groupTitle, setGroupTitle] = useState('');
  const [groupDescription, setGroupDescription] = useState('');
  const [groupAvatarUrl, setGroupAvatarUrl] = useState('');
  const [selectedBranchId, setSelectedBranchId] = useState('');
  const [selectedAlliedFamilyId, setSelectedAlliedFamilyId] = useState('');
  const [selectedAllianceId, setSelectedAllianceId] = useState('');
  const [isCouncilGroup, setIsCouncilGroup] = useState(false);
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);

  if (!isOpen) return null;

  const isUserAdmin = currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL';

  // Available users to message (exclude current user)
  const availableUsers = userAccounts.filter((u) => u.id !== currentUser.id && u.role !== 'VISITEUR');

  const filteredUsers = availableUsers.filter((u) => {
    const q = searchQuery.toLowerCase();
    const fullName = `${u.firstName || ''} ${u.lastName || ''}`.trim();
    const matchesName = fullName.toLowerCase().includes(q) || u.email.toLowerCase().includes(q);
    const matchesFamily = u.primaryFamilyName?.toLowerCase().includes(q);
    return matchesName || matchesFamily;
  });

  const handleStartDirect = (targetUserId: string) => {
    const res = createDirectConversation(targetUserId);
    if (res.success && res.conversation) {
      setActiveConversationId(res.conversation.id);
      onClose();
    }
  };

  const toggleUserSelection = (userId: string) => {
    if (selectedUserIds.includes(userId)) {
      setSelectedUserIds((prev) => prev.filter((id) => id !== userId));
    } else {
      setSelectedUserIds((prev) => [...prev, userId]);
    }
  };

  const handleCreateGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupTitle.trim()) return;

    // Resolve branch and family names
    const branch = branches.find((b) => b.id === selectedBranchId);
    const alliedFamily = alliedFamilies.find((f) => f.id === selectedAlliedFamilyId);
    const alliance = alliances.find((a) => a.id === selectedAllianceId);

    const res = createGroupConversation({
      title: groupTitle.trim(),
      description: groupDescription.trim() || undefined,
      avatarUrl: groupAvatarUrl.trim() || undefined,
      participantIds: selectedUserIds,
      relatedBranchId: selectedBranchId || undefined,
      relatedBranchName: branch?.name,
      relatedAlliedFamilyId: selectedAlliedFamilyId || undefined,
      relatedAlliedFamilyName: alliedFamily?.name,
      relatedAllianceId: selectedAllianceId || undefined,
      relatedAllianceName: alliance?.title,
      isCouncilGroup: isCouncilGroup && isUserAdmin,
    });

    if (res.success && res.conversation) {
      setActiveConversationId(res.conversation.id);
      onClose();
    }
  };

  return (
    <div
      id="new-conversation-modal"
      className="fixed inset-0 z-50 bg-stone-950/80 backdrop-blur-xs flex items-center justify-center p-3 select-none animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg bg-white rounded-3xl border border-stone-200 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-stone-100 bg-stone-50 flex items-center justify-between">
          <div>
            <h3 className="text-base sm:text-lg font-bold text-stone-900">Nouvelle discussion</h3>
            <p className="text-xs text-stone-500">Nzala Messages</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 rounded-xl hover:bg-stone-200/60 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-stone-200 bg-stone-50 px-4 pt-2">
          <button
            type="button"
            onClick={() => setActiveTab('DIRECT')}
            className={`flex-1 py-2.5 text-xs font-bold flex items-center justify-center gap-2 border-b-2 transition cursor-pointer ${
              activeTab === 'DIRECT'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>Message Direct</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('GROUP')}
            className={`flex-1 py-2.5 text-xs font-bold flex items-center justify-center gap-2 border-b-2 transition cursor-pointer ${
              activeTab === 'GROUP'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Nouveau Groupe</span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* TAB 1: DIRECT CONVERSATION */}
          {activeTab === 'DIRECT' && (
            <div className="space-y-3">
              {/* Search Bar */}
              <div className="relative">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Rechercher un membre par nom ou famille..."
                  className="w-full pl-9 pr-4 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs sm:text-sm text-stone-900 outline-none focus:border-blue-500"
                />
              </div>

              {/* Members List */}
              <div className="space-y-1.5 max-h-80 overflow-y-auto">
                {filteredUsers.length > 0 ? (
                  filteredUsers.map((u) => {
                    const fullName = `${u.firstName || ''} ${u.lastName || ''}`.trim() || u.email;
                    const familyLabel = u.primaryFamilyName || 'Famille Nzala';
                    return (
                      <button
                        key={u.id}
                        type="button"
                        onClick={() => handleStartDirect(u.id)}
                        className="w-full p-2.5 rounded-2xl bg-stone-50 hover:bg-blue-50/70 border border-stone-200/80 hover:border-blue-300 transition flex items-center justify-between text-left cursor-pointer group"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-10 h-10 rounded-2xl bg-blue-600 text-white font-bold flex items-center justify-center font-serif text-sm shrink-0">
                            {fullName.charAt(0)}
                          </div>
                          <div className="truncate">
                            <p className="text-xs sm:text-sm font-bold text-stone-900 group-hover:text-blue-900 truncate">
                              {fullName}
                            </p>
                            <p className="text-[11px] text-stone-500 truncate">
                              {familyLabel} • {u.role.replace('_', ' ')}
                            </p>
                          </div>
                        </div>

                        <span className="px-3 py-1 rounded-xl bg-white border border-stone-200 text-xs font-bold text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition">
                          Discuter
                        </span>
                      </button>
                    );
                  })
                ) : (
                  <p className="text-xs text-stone-400 italic text-center py-6">
                    Aucun membre correspondant trouvé.
                  </p>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: GROUP CONVERSATION */}
          {activeTab === 'GROUP' && (
            <form onSubmit={handleCreateGroup} className="space-y-4">
              {/* Group Title */}
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Nom du groupe *
                </label>
                <input
                  type="text"
                  required
                  value={groupTitle}
                  onChange={(e) => setGroupTitle(e.target.value)}
                  placeholder="Ex : Famille Nzala — Branche Matadi"
                  className="w-full px-3 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs sm:text-sm text-stone-900 outline-none focus:border-blue-500"
                />
              </div>

              {/* Group Description */}
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Description ou objectif du groupe
                </label>
                <textarea
                  value={groupDescription}
                  onChange={(e) => setGroupDescription(e.target.value)}
                  placeholder="Ex : Coordination des préparatifs et projets..."
                  rows={2}
                  className="w-full px-3 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs sm:text-sm text-stone-900 outline-none focus:border-blue-500 resize-none"
                />
              </div>

              {/* Group Avatar URL */}
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  URL de la photo du groupe (facultatif)
                </label>
                <input
                  type="url"
                  value={groupAvatarUrl}
                  onChange={(e) => setGroupAvatarUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-3 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs sm:text-sm text-stone-900 outline-none focus:border-blue-500"
                />
              </div>

              {/* Association Options */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Lier à une branche
                  </label>
                  <select
                    value={selectedBranchId}
                    onChange={(e) => setSelectedBranchId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs text-stone-900 outline-none focus:border-blue-500"
                  >
                    <option value="">Aucune branche spécifique</option>
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Lier à une famille alliée
                  </label>
                  <select
                    value={selectedAlliedFamilyId}
                    onChange={(e) => setSelectedAlliedFamilyId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs text-stone-900 outline-none focus:border-blue-500"
                  >
                    <option value="">Aucune famille alliée</option>
                    {alliedFamilies.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Special Council Group Flag (Only for Admins) */}
              {isUserAdmin && (
                <div className="p-3 rounded-2xl bg-amber-50 border border-amber-300 flex items-start gap-2.5">
                  <input
                    type="checkbox"
                    id="council-checkbox"
                    checked={isCouncilGroup}
                    onChange={(e) => setIsCouncilGroup(e.target.checked)}
                    className="mt-1 rounded text-amber-600 focus:ring-amber-500 cursor-pointer"
                  />
                  <label htmlFor="council-checkbox" className="text-xs text-amber-950 cursor-pointer">
                    <strong className="block font-bold">Groupe Strict Conseil de Famille</strong>
                    Ce groupe sera strictement masqué et protégé. Seuls les administrateurs et sages pourront le voir.
                  </label>
                </div>
              )}

              {/* Participants Selector */}
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  Sélectionner les participants ({selectedUserIds.length} sélectionnés)
                </label>

                <div className="space-y-1.5 max-h-48 overflow-y-auto border border-stone-200 rounded-2xl p-2 bg-stone-50">
                  {availableUsers.map((u) => {
                    const isSelected = selectedUserIds.includes(u.id);
                    const fullName = `${u.firstName || ''} ${u.lastName || ''}`.trim() || u.email;
                    const familyLabel = u.primaryFamilyName || 'Famille Nzala';
                    return (
                      <div
                        key={u.id}
                        onClick={() => toggleUserSelection(u.id)}
                        className={`p-2 rounded-xl border flex items-center justify-between cursor-pointer transition ${
                          isSelected
                            ? 'bg-blue-100/70 border-blue-400 text-blue-950'
                            : 'bg-white border-stone-200 text-stone-800 hover:bg-stone-100'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-7 h-7 rounded-lg bg-blue-600 text-white text-xs font-bold flex items-center justify-center shrink-0">
                            {fullName.charAt(0)}
                          </div>
                          <div className="truncate">
                            <p className="text-xs font-bold truncate">{fullName}</p>
                            <p className="text-[10px] text-stone-500 truncate">{familyLabel}</p>
                          </div>
                        </div>

                        <div
                          className={`w-5 h-5 rounded-lg border flex items-center justify-center ${
                            isSelected ? 'bg-blue-600 border-blue-600 text-white' : 'border-stone-300'
                          }`}
                        >
                          {isSelected && <Check className="w-3.5 h-3.5" />}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Submit */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-100">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl text-stone-600 hover:bg-stone-100 text-xs font-semibold transition cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={!groupTitle.trim()}
                  className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs sm:text-sm font-bold shadow flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Users className="w-4 h-4" />
                  <span>Créer le groupe</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
