/**
 * NzalaFamilly - Visualiseur Sécurisé de Messages à Vue Unique (View Once)
 * Fournit une protection anti-capture d'écran, filigrane dynamique et destruction immédiate après fermeture.
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Eye,
  EyeOff,
  Shield,
  ShieldAlert,
  AlertTriangle,
  X,
  Lock,
  Clock,
  Play,
  Pause,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { FamilyMessage, MessageAttachment } from '../../types/messaging';
import { useFamily } from '../../context/FamilyContext';

interface ViewOnceModalProps {
  isOpen: boolean;
  message: FamilyMessage;
  attachment?: MessageAttachment;
  onClose: () => void;
  onMarkAsViewed: (messageId: string, attachmentId?: string) => void;
}

export const ViewOnceModal: React.FC<ViewOnceModalProps> = ({
  isOpen,
  message,
  attachment,
  onClose,
  onMarkAsViewed,
}) => {
  const { currentUser, showToast } = useFamily();
  const [screenshotAttempt, setScreenshotAttempt] = useState(false);
  const [secondsRemaining, setSecondsRemaining] = useState<number | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [isAudioMuted, setIsAudioMuted] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const activeMedia = attachment || message.attachments?.[0];
  const mediaType = activeMedia?.type || message.mediaType;
  const mediaUrl = activeMedia?.url || '';

  // Heuristique de détection de capture d'écran & protection clavier
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      // PrintScreen, Windows+Shift+S, Mac Cmd+Shift+3/4/5, Ctrl+P
      if (
        e.key === 'PrintScreen' ||
        (e.ctrlKey && e.key === 'p') ||
        (e.metaKey && e.shiftKey && ['3', '4', '5'].includes(e.key))
      ) {
        e.preventDefault();
        setScreenshotAttempt(true);
        showToast('warning', 'Tentative de capture d\'écran détectée ! Les médias à vue unique sont confidentiels.');
      }
    };

    const handleVisibilityChange = () => {
      if (document.hidden) {
        // Fenêtre passée en arrière-plan (possible enregistreur d'écran ou capture externe)
        setScreenshotAttempt(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [isOpen, showToast]);

  // Minuteur automatique si vidéo ou audio
  useEffect(() => {
    if (!isOpen) return;

    // Définir un timer par défaut pour les photos (30s)
    if (mediaType === 'IMAGE') {
      setSecondsRemaining(30);
      const interval = setInterval(() => {
        setSecondsRemaining((prev) => {
          if (prev === null || prev <= 1) {
            clearInterval(interval);
            handleCloseAndView();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [isOpen, mediaType]);

  const handleCloseAndView = () => {
    if (activeMedia) {
      onMarkAsViewed(message.id, activeMedia.id);
    } else {
      onMarkAsViewed(message.id);
    }
    onClose();
  };

  if (!isOpen) return null;

  const currentFormattedTime = new Date().toLocaleTimeString('fr-FR', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  return (
    <div
      id="view-once-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md select-none"
      onContextMenu={(e) => e.preventDefault()}
      style={{ userSelect: 'none', WebkitUserSelect: 'none' }}
    >
      {/* Watermark overlay dynamically rendered across the screen */}
      <div className="absolute inset-0 pointer-events-none z-20 flex flex-col justify-between p-8 opacity-15 text-white font-mono text-xs overflow-hidden">
        <div className="flex justify-between">
          <span>{currentUser.name} • {currentUser.id}</span>
          <span>{currentFormattedTime}</span>
        </div>
        <div className="flex justify-around text-center rotate-[-20deg] text-sm">
          <span>CONFIDENTIEL NZALAFAMILLY • VUE UNIQUE</span>
        </div>
        <div className="flex justify-between">
          <span>Expéditeur : {message.senderName}</span>
          <span>Nzala Security System</span>
        </div>
      </div>

      {/* Top Header Bar */}
      <div className="absolute top-0 inset-x-0 p-4 sm:p-6 flex items-center justify-between z-30 bg-gradient-to-b from-black/80 to-transparent">
        <div className="flex items-center gap-3 text-white">
          <div className="w-10 h-10 rounded-full bg-blue-600/30 border border-blue-500/50 flex items-center justify-center text-blue-400">
            <EyeOff className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm sm:text-base">Média à Vue Unique</span>
              <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] px-2 py-0.5 rounded-full font-bold">
                Éphémère
              </span>
            </div>
            <p className="text-xs text-stone-400">
              De {message.senderName} • Ce média sera définitivement effacé dès la fermeture
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {secondsRemaining !== null && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-stone-800/80 border border-stone-700 text-stone-200 text-xs font-mono">
              <Clock className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>{secondsRemaining}s</span>
            </div>
          )}

          <button
            type="button"
            onClick={handleCloseAndView}
            className="px-3 sm:px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center gap-1.5 transition active:scale-95 cursor-pointer shadow-lg"
          >
            <X className="w-4 h-4" />
            <span className="hidden sm:inline">Fermer & Supprimer</span>
          </button>
        </div>
      </div>

      {/* Main Media Content */}
      <div className="relative max-w-4xl max-h-[80vh] w-full p-4 flex flex-col items-center justify-center z-10">
        {mediaType === 'IMAGE' && (
          <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-stone-800 bg-stone-950 flex items-center justify-center">
            <img
              src={mediaUrl}
              alt="Média confidentiel"
              className="max-h-[70vh] max-w-full object-contain pointer-events-none"
              draggable={false}
            />
          </div>
        )}

        {mediaType === 'VIDEO' && (
          <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-stone-800 bg-black w-full max-w-2xl">
            <video
              ref={videoRef}
              src={mediaUrl}
              autoPlay
              controls
              controlsList="nodownload noplaybackrate"
              disablePictureInPicture
              onEnded={handleCloseAndView}
              className="w-full max-h-[70vh] object-contain"
            />
          </div>
        )}

        {mediaType === 'AUDIO' && (
          <div className="w-full max-w-md p-6 rounded-3xl bg-stone-900 border border-stone-800 text-white space-y-5 shadow-2xl">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-600 to-amber-400 flex items-center justify-center text-white text-2xl shadow-lg">
                🎵
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-bold text-base text-stone-100">Message Vocal Éphémère</h4>
                <p className="text-xs text-stone-400">Lecture unique autorisée</p>
              </div>
            </div>

            <audio
              ref={audioRef}
              src={mediaUrl}
              autoPlay
              muted={isAudioMuted}
              onPlay={() => setIsPlayingAudio(true)}
              onPause={() => setIsPlayingAudio(false)}
              onEnded={handleCloseAndView}
              className="hidden"
            />

            <div className="flex items-center justify-center gap-4 pt-2">
              <button
                type="button"
                onClick={() => {
                  if (audioRef.current) {
                    if (isPlayingAudio) audioRef.current.pause();
                    else audioRef.current.play();
                  }
                }}
                className="w-14 h-14 rounded-full bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center text-xl shadow-lg transition active:scale-95 cursor-pointer"
              >
                {isPlayingAudio ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-0.5" />}
              </button>

              <button
                type="button"
                onClick={() => setIsAudioMuted(!isAudioMuted)}
                className="p-3 rounded-full bg-stone-800 hover:bg-stone-700 text-stone-300 transition cursor-pointer"
              >
                {isAudioMuted ? <VolumeX className="w-5 h-5 text-rose-400" /> : <Volume2 className="w-5 h-5" />}
              </button>
            </div>
          </div>
        )}

        {/* Caption if present */}
        {activeMedia?.caption && (
          <div className="mt-4 px-4 py-2 rounded-xl bg-stone-900/80 border border-stone-800 text-stone-200 text-xs sm:text-sm max-w-lg text-center">
            {activeMedia.caption}
          </div>
        )}
      </div>

      {/* Bottom Safety Notice Bar */}
      <div className="absolute bottom-4 inset-x-4 max-w-xl mx-auto z-30">
        <div className="p-3 rounded-2xl bg-stone-900/90 border border-stone-800 backdrop-blur-md flex items-center gap-3 text-xs text-stone-400 shadow-xl">
          <Shield className="w-4 h-4 text-emerald-400 shrink-0" />
          <p className="leading-tight text-[11px]">
            <strong className="text-stone-200">Sécurité & Confidentialité Nzala :</strong> Le contenu est verrouillé en session active. Note : Bien que les protections logicielles soient appliquées, veillez à toujours respecter la confiance de vos proches.
          </p>
        </div>
      </div>
    </div>
  );
};
