/**
 * NzalaFamilly - Enregistreur de message vocal haute fidélité
 * Utilise l'API native MediaRecorder et getUserMedia avec négociation de codecs
 * et pré-écoute interactive complète avant transmission.
 */

import React, { useState, useEffect, useRef } from 'react';
import { Mic, Square, Trash2, Send, Play, Pause, AlertCircle, RefreshCw, Volume2 } from 'lucide-react';
import { MessagingService } from '../../services/messagingService';
import { MessageAttachment } from '../../types/messaging';

interface VoiceRecorderProps {
  onSendVoice: (attachment: MessageAttachment) => void;
  onCancel: () => void;
}

export const VoiceRecorder: React.FC<VoiceRecorderProps> = ({ onSendVoice, onCancel }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordDuration, setRecordDuration] = useState(0);
  const [audioBlobUrl, setAudioBlobUrl] = useState<string | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [isPlayingPreview, setIsPlayingPreview] = useState(false);
  const [previewCurrentTime, setPreviewCurrentTime] = useState(0);
  const [previewDuration, setPreviewDuration] = useState(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isStarting, setIsStarting] = useState(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const startTimeRef = useRef<number>(0);
  const timerIntervalRef = useRef<number | null>(null);
  const previewAudioRef = useRef<HTMLAudioElement | null>(null);

  // Détecter le meilleur format MIME supporté
  const getSupportedMimeType = (): string => {
    if (typeof MediaRecorder === 'undefined') return '';
    const candidates = [
      'audio/webm;codecs=opus',
      'audio/webm',
      'audio/ogg;codecs=opus',
      'audio/ogg',
      'audio/mp4',
      'audio/aac',
    ];
    for (const mime of candidates) {
      if (MediaRecorder.isTypeSupported(mime)) {
        return mime;
      }
    }
    return '';
  };

  const cleanupStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
  };

  const stopTimer = () => {
    if (timerIntervalRef.current !== null) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
  };

  const startTimer = () => {
    stopTimer();
    startTimeRef.current = Date.now();
    setRecordDuration(0);
    timerIntervalRef.current = window.setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTimeRef.current) / 1000);
      setRecordDuration(elapsed);
    }, 200);
  };

  const startRecording = async () => {
    setErrorMessage(null);
    setIsStarting(true);
    audioChunksRef.current = [];

    // Revoke previous blob url
    if (audioBlobUrl) {
      URL.revokeObjectURL(audioBlobUrl);
      setAudioBlobUrl(null);
      setAudioBlob(null);
    }

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Votre navigateur ne prend pas en charge l\'enregistrement audio.');
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      streamRef.current = stream;
      const mimeType = getSupportedMimeType();
      const options = mimeType ? { mimeType } : undefined;
      const mediaRecorder = new MediaRecorder(stream, options);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const actualMime = mimeType || mediaRecorder.mimeType || 'audio/webm';
        const blob = new Blob(audioChunksRef.current, { type: actualMime });
        const url = URL.createObjectURL(blob);
        const finalSec = Math.max(1, Math.round((Date.now() - startTimeRef.current) / 1000));
        
        setAudioBlob(blob);
        setAudioBlobUrl(url);
        setPreviewDuration(finalSec);
        cleanupStream();
      };

      mediaRecorder.start(100);
      setIsRecording(true);
      startTimer();
    } catch (err: any) {
      console.warn('Microphone error:', err);
      let message = 'Impossible d\'accéder au microphone.';
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        message = 'Accès au microphone refusé. Veuillez autoriser le microphone dans les paramètres de votre navigateur.';
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        message = 'Aucun microphone n\'a été détecté sur votre appareil.';
      } else if (err.message) {
        message = err.message;
      }
      setErrorMessage(message);
    } finally {
      setIsStarting(false);
    }
  };

  const stopRecording = () => {
    stopTimer();
    setIsRecording(false);
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      try {
        mediaRecorderRef.current.stop();
      } catch (err) {
        console.error('Error stopping media recorder:', err);
      }
    }
  };

  // Démarrer automatiquement l'enregistrement à l'ouverture
  useEffect(() => {
    startRecording();
    return () => {
      stopTimer();
      cleanupStream();
      if (audioBlobUrl) {
        URL.revokeObjectURL(audioBlobUrl);
      }
    };
  }, []);

  // Synchronisation audio preview
  useEffect(() => {
    const audio = previewAudioRef.current;
    if (!audio) return;

    const onTimeUpdate = () => setPreviewCurrentTime(audio.currentTime);
    const onEnded = () => {
      setIsPlayingPreview(false);
      setPreviewCurrentTime(0);
    };
    const onLoadedMetadata = () => {
      if (audio.duration && !isNaN(audio.duration) && isFinite(audio.duration)) {
        setPreviewDuration(Math.round(audio.duration));
      }
    };

    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('ended', onEnded);
    audio.addEventListener('loadedmetadata', onLoadedMetadata);

    return () => {
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('ended', onEnded);
      audio.removeEventListener('loadedmetadata', onLoadedMetadata);
    };
  }, [audioBlobUrl]);

  const togglePreviewPlay = () => {
    const audio = previewAudioRef.current;
    if (!audio) return;

    if (isPlayingPreview) {
      audio.pause();
      setIsPlayingPreview(false);
    } else {
      audio.play().then(() => {
        setIsPlayingPreview(true);
      }).catch((err) => {
        console.warn('Playback error:', err);
        setIsPlayingPreview(false);
      });
    }
  };

  const handleSend = () => {
    if (!audioBlobUrl) return;

    const finalDuration = previewDuration > 0 ? previewDuration : Math.max(1, recordDuration);
    const dateStr = new Date().toISOString().slice(0, 10);

    const attachment: MessageAttachment = {
      id: `att-voice-${Date.now()}`,
      type: 'AUDIO',
      url: audioBlobUrl,
      durationSec: finalDuration,
      fileName: `Vocal_Nzala_${dateStr}.webm`,
      caption: `Message vocal (${MessagingService.formatDuration(finalDuration)})`,
    };

    onSendVoice(attachment);
  };

  const handleDiscard = () => {
    stopRecording();
    cleanupStream();
    if (audioBlobUrl) {
      URL.revokeObjectURL(audioBlobUrl);
      setAudioBlobUrl(null);
      setAudioBlob(null);
    }
    onCancel();
  };

  const animatedBars = [35, 65, 45, 90, 60, 100, 80, 50, 95, 70, 85, 40, 75, 90, 55, 65, 80, 45, 95, 60, 40, 70, 85, 50];

  return (
    <div className="p-3 sm:p-4 rounded-2xl bg-slate-900 text-white border border-slate-800 shadow-xl space-y-3 animate-fadeIn">
      {errorMessage && (
        <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-800 text-xs text-rose-200 flex items-start justify-between gap-2">
          <div className="flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
          <button
            type="button"
            onClick={startRecording}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-800 hover:bg-rose-700 text-white font-semibold text-[11px] transition shrink-0 cursor-pointer"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Réessayer</span>
          </button>
        </div>
      )}

      {/* Recording in progress */}
      {isRecording && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3 w-full sm:w-auto">
            {/* Blinking recording indicator */}
            <div className="relative flex items-center justify-center shrink-0">
              <span className="w-3.5 h-3.5 rounded-full bg-rose-500 animate-ping absolute" />
              <span className="w-3.5 h-3.5 rounded-full bg-rose-600 relative" />
            </div>

            {/* Live timer */}
            <div className="font-mono text-sm sm:text-base font-bold text-white tracking-wider">
              {MessagingService.formatDuration(recordDuration)}
            </div>

            {/* Live pulsating waveform */}
            <div className="flex items-center gap-1 h-5 px-2">
              {animatedBars.slice(0, 14).map((h, i) => (
                <div
                  key={i}
                  className="w-1 bg-rose-500 rounded-full animate-pulse"
                  style={{
                    height: `${Math.max(20, (h * ((i % 3) + 1)) % 100)}%`,
                    animationDelay: `${i * 70}ms`,
                    animationDuration: '600ms',
                  }}
                />
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={handleDiscard}
              className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition cursor-pointer"
              title="Annuler le message vocal"
            >
              <Trash2 className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={stopRecording}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition shadow cursor-pointer"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
              <span>Terminer</span>
            </button>
          </div>
        </div>
      )}

      {/* Recording finished - Preview mode */}
      {!isRecording && audioBlobUrl && (
        <div className="space-y-2.5">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={togglePreviewPlay}
                className="w-8 h-8 rounded-full bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center shadow transition cursor-pointer shrink-0"
                title={isPlayingPreview ? 'Mettre en pause' : 'Écouter l\'enregistrement'}
              >
                {isPlayingPreview ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
              </button>

              <div className="flex flex-col">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Volume2 className="w-3.5 h-3.5 text-blue-400" />
                  <span>Aperçu du vocal</span>
                </span>
                <span className="font-mono text-[11px] text-slate-400">
                  {MessagingService.formatDuration(previewCurrentTime > 0 ? previewCurrentTime : previewDuration)} / {MessagingService.formatDuration(previewDuration)}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleDiscard}
                className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition cursor-pointer"
                title="Supprimer"
              >
                <Trash2 className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={startRecording}
                className="p-2 rounded-xl text-slate-400 hover:text-blue-400 hover:bg-slate-800 transition cursor-pointer"
                title="Réenregistrer"
              >
                <RefreshCw className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={handleSend}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md transition cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Envoyer</span>
              </button>
            </div>
          </div>

          {/* Scrubbable waveform preview */}
          <div className="flex items-center gap-1 h-6 px-1 bg-slate-950/60 rounded-xl p-1">
            {animatedBars.map((height, idx) => {
              const progress = (idx / animatedBars.length) * 100;
              const currentProgress = previewDuration > 0 ? (previewCurrentTime / previewDuration) * 100 : 0;
              const isPlayed = progress <= currentProgress;

              return (
                <div
                  key={idx}
                  onClick={() => {
                    if (previewAudioRef.current && previewDuration > 0) {
                      const seekTime = (idx / animatedBars.length) * previewDuration;
                      previewAudioRef.current.currentTime = seekTime;
                      setPreviewCurrentTime(seekTime);
                    }
                  }}
                  className={`flex-1 rounded-full cursor-pointer transition-all duration-150 ${
                    isPlayed ? 'bg-blue-400' : 'bg-slate-700 hover:bg-slate-600'
                  }`}
                  style={{ height: `${height}%` }}
                />
              );
            })}
          </div>

          <audio ref={previewAudioRef} src={audioBlobUrl} preload="auto" className="hidden" />
        </div>
      )}

      {/* Idle or Error with no audio */}
      {!isRecording && !audioBlobUrl && !isStarting && (
        <div className="flex items-center justify-between">
          <span className="text-xs text-slate-400">Prêt à enregistrer</span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onCancel}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
            >
              Annuler
            </button>
            <button
              type="button"
              onClick={startRecording}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
            >
              <Mic className="w-3.5 h-3.5" />
              <span>Démarrer</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
