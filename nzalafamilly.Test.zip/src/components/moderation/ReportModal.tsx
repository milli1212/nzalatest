/**
 * NzalaFamilly - Modale de Signalement Unifiée (NZALA SOCIAL REPORT MODAL)
 * Permet de signaler de manière confidentielle un membre, un message, une story, un post ou un groupe
 */

import React, { useState } from 'react';
import {
  AlertTriangle,
  X,
  Shield,
  Flag,
  CheckCircle,
  HelpCircle,
} from 'lucide-react';
import { ReportCategory, ReportTargetType } from '../../types/moderation';
import { ModerationService } from '../../services/moderation/ModerationService';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetType: ReportTargetType;
  targetId: string;
  targetTitle?: string;
  reportedUserId?: string;
  reportedUserName?: string;
  onSubmit: (data: {
    targetType: ReportTargetType;
    targetId: string;
    targetTitle?: string;
    reportedUserId?: string;
    reportedUserName?: string;
    category: ReportCategory;
    description: string;
  }) => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  isOpen,
  onClose,
  targetType,
  targetId,
  targetTitle,
  reportedUserId,
  reportedUserName,
  onSubmit,
}) => {
  const [category, setCategory] = useState<ReportCategory>('COMPORTEMENT_ABUSIF');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const categories: { value: ReportCategory; label: string; desc: string }[] = [
    {
      value: 'COMPORTEMENT_ABUSIF',
      label: 'Comportement abusif / Harcèlement',
      desc: 'Propos insultants, menaces ou harcèlement répété',
    },
    {
      value: 'CONTENU_INAPPROPRIE',
      label: 'Contenu inapproprié',
      desc: 'Contenu offensant, violent ou contraire aux valeurs familiales',
    },
    {
      value: 'SPAM',
      label: 'Spam / Sollicitation commerciale',
      desc: 'Publicités non autorisées ou messages indésirables',
    },
    {
      value: 'USURPATION',
      label: 'Usurpation d’identité',
      desc: 'Compte se faisant passer pour un autre membre de la famille',
    },
    {
      value: 'AUTRE',
      label: 'Autre motif',
      desc: 'Autre problème nécessitant l’intervention d’un modérateur',
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;

    setIsSubmitting(true);
    onSubmit({
      targetType,
      targetId,
      targetTitle,
      reportedUserId,
      reportedUserName,
      category,
      description: description.trim(),
    });
    setIsSubmitting(false);
    onClose();
  };

  return (
    <div
      id="report-modal-overlay"
      className="fixed inset-0 z-50 bg-stone-950/60 backdrop-blur-xs flex items-center justify-center p-4 select-none animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[85vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 bg-stone-50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-rose-100 text-rose-700">
              <Flag className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-stone-900 text-base">Signaler un contenu ou membre</h3>
              <p className="text-xs text-stone-500">
                {ModerationService.getTargetTypeLabel(targetType)}
                {targetTitle ? ` : ${targetTitle}` : ''}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-200 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          <div className="p-3 rounded-2xl bg-amber-50/70 border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
            <Shield className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              Ce signalement est <strong>confidentiel</strong>. Il sera examiné par les administrateurs et modérateurs autorisés dans le respect des règles de gouvernance.
            </p>
          </div>

          {/* Categories Radio List */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-stone-900 block">
              Quel est le motif du signalement ?
            </label>
            <div className="space-y-2">
              {categories.map((cat) => (
                <label
                  key={cat.value}
                  className={`flex items-start gap-3 p-3 rounded-2xl border transition cursor-pointer ${
                    category === cat.value
                      ? 'bg-amber-50/60 border-amber-500 shadow-xs'
                      : 'border-stone-200 hover:bg-stone-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="report_category"
                    value={cat.value}
                    checked={category === cat.value}
                    onChange={() => setCategory(cat.value)}
                    className="mt-1 text-amber-600 focus:ring-amber-500 accent-amber-600 cursor-pointer"
                  />
                  <div>
                    <div className="text-xs font-bold text-stone-900">{cat.label}</div>
                    <div className="text-[11px] text-stone-500">{cat.desc}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Details textarea */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-stone-900 block">
              Précisions pour les modérateurs *
            </label>
            <textarea
              id="report-input-details"
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Expliquez brièvement le contexte du problème..."
              className="w-full p-3 rounded-2xl border border-stone-200 text-xs text-stone-800 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 bg-stone-50"
              required
            />
          </div>

          {/* Footer buttons */}
          <div className="pt-3 border-t border-stone-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-600 hover:bg-stone-100 transition cursor-pointer"
            >
              Annuler
            </button>
            <button
              id="btn-submit-report"
              type="submit"
              disabled={isSubmitting || !description.trim()}
              className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-xs transition cursor-pointer disabled:opacity-50"
            >
              Envoyer le signalement
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
