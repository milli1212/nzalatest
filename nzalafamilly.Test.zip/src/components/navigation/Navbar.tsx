import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { RoleBadge } from '../common/Badges';
import { NzalaLogo } from '../common/NzalaLogo';
import { GlobalSearchBar } from '../search/GlobalSearchBar';
import {
  Menu,
  X,
  Sparkles,
  ChevronDown,
  RotateCcw,
  FileCheck2,
  LogIn,
  UserPlus,
  User,
  LogOut,
  MessageSquare,
  Bell,
  Compass,
} from 'lucide-react';

interface NavbarProps {
  onMobileMenuToggle: () => void;
  isMobileMenuOpen: boolean;
  onOpenAuth: (mode: 'LOGIN' | 'REGISTER') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onMobileMenuToggle,
  isMobileMenuOpen,
  onOpenAuth,
}) => {
  const {
    currentUser,
    switchProfile,
    availableProfiles,
    verificationRequests,
    totalUnreadMessagesCount,
    notifications,
    setIsNotificationDrawerOpen,
    activeTab,
    setActiveTab,
    resetToDefaults,
    logout,
  } = useFamily();

  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);

  const unreadNotificationsCount = notifications.filter((n) => !n.read && !n.isRead).length;

  const pendingCount = verificationRequests.filter(
    (r) => r.status === 'EN_ATTENTE' || r.status === 'EN_VERIFICATION'
  ).length;

  const isVisitor = currentUser.role === 'VISITEUR';

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 text-slate-800 shadow-xs">
      <div className="max-w-7xl mx-auto px-2.5 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-2 sm:gap-4 h-15 sm:h-18">
          {/* Brand Logo & Name */}
          <div
            className="flex items-center cursor-pointer transition hover:opacity-90 shrink-0"
            onClick={() => setActiveTab('landing')}
          >
            <NzalaLogo variant="full" size="sm" className="sm:hidden" />
            <NzalaLogo variant="full" size="md" className="hidden sm:flex" />
          </div>

          {/* Central Global Search Bar (Desktop & Tablet) */}
          <div className="flex-1 max-w-xl mx-auto hidden md:flex items-center justify-center px-2">
            <GlobalSearchBar className="w-full" />
          </div>

          {/* Right Action buttons */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* --- DESKTOP ONLY ACTIONS (Hidden on Mobile) --- */}
            
            {/* Desktop Discovery Hub shortcut */}
            <button
              id="nav-btn-discovery"
              onClick={() => setActiveTab('discovery')}
              className={`hidden md:flex items-center gap-1.5 px-2.5 sm:px-3 py-2 rounded-xl text-xs font-semibold border transition cursor-pointer min-h-[40px] ${
                activeTab === 'discovery'
                  ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                  : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
              }`}
              title="Découverte & Exploration"
            >
              <Compass className={`w-4 h-4 ${activeTab === 'discovery' ? 'text-white' : 'text-blue-600'}`} />
              <span className="hidden xl:inline">Découvrir</span>
            </button>

            {/* Desktop Notifications Drawer trigger */}
            <button
              id="nav-btn-notifications-desktop"
              onClick={() => setIsNotificationDrawerOpen(true)}
              className="hidden md:flex relative p-2 sm:p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 hover:text-blue-600 transition cursor-pointer min-h-[40px] min-w-[40px] items-center justify-center"
              title="Centre de notifications"
              aria-label="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute -top-1 -right-1 px-1.5 py-0.2 rounded-full bg-rose-500 text-white text-[10px] font-black shadow-xs">
                  {unreadNotificationsCount}
                </span>
              )}
            </button>

            {/* Desktop Direct affiliation shortcut */}
            <button
              id="nav-btn-affiliation"
              onClick={() => setActiveTab('affiliation')}
              className={`hidden lg:flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition cursor-pointer min-h-[40px] ${
                activeTab === 'affiliation'
                  ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                  : 'bg-blue-50/60 text-blue-700 hover:bg-blue-100/70 border-blue-200'
              }`}
            >
              <FileCheck2 className="w-4 h-4 text-blue-600" />
              <span>Affiliation</span>
            </button>

            {/* Desktop Pending Verifications Badge */}
            {(currentUser.role === 'SUPER_ADMIN' ||
              currentUser.role === 'ADMIN_FAMILIAL' ||
              currentUser.role === 'VALIDATEUR') && pendingCount > 0 && (
              <button
                onClick={() => setActiveTab('verifications')}
                className="hidden xl:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100 transition cursor-pointer min-h-[40px]"
                title={`${pendingCount} demandes en attente de vérification`}
              >
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
                <span>{pendingCount} à vérifier</span>
              </button>
            )}

            {/* --- 1. MESSAGES BUTTON (Visible both Mobile & Desktop) --- */}
            <button
              id="nav-btn-messages"
              onClick={() => setActiveTab('messages')}
              className={`relative flex items-center justify-center gap-1.5 p-2 sm:px-3 sm:py-2 rounded-xl text-xs font-semibold border transition cursor-pointer min-h-[40px] min-w-[40px] ${
                activeTab === 'messages'
                  ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                  : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
              }`}
              title="Messagerie Privée"
              aria-label="Messages"
            >
              <MessageSquare className={`w-4.5 h-4.5 ${activeTab === 'messages' ? 'text-white' : 'text-blue-600'}`} />
              <span className="hidden lg:inline">Messages</span>
              {totalUnreadMessagesCount > 0 && (
                <span className="absolute -top-1 -right-1 px-1.5 py-0.5 rounded-full bg-blue-600 text-white text-[10px] font-bold shadow-xs">
                  {totalUnreadMessagesCount}
                </span>
              )}
            </button>

            {/* --- 2. CONNEXION / PROFIL BUTTON (Mobile: Profile Circle or Login / Desktop: Pill + Dropdown) --- */}
            {isVisitor ? (
              <button
                id="nav-btn-login"
                onClick={() => onOpenAuth('LOGIN')}
                className="flex items-center gap-1.5 px-2.5 sm:px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 transition cursor-pointer min-h-[40px]"
              >
                <LogIn className="w-4 h-4 text-blue-600" />
                <span>Connexion</span>
              </button>
            ) : (
              <div className="relative">
                {/* Mobile: Clean Circle Avatar directly opening Profile or quick menu */}
                <button
                  id="user-account-mobile-btn"
                  onClick={() => setActiveTab('profile')}
                  className="md:hidden flex items-center justify-center w-9 h-9 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-bold text-xs ring-2 ring-blue-500/20 shadow-xs cursor-pointer overflow-hidden"
                  title="Mon Profil"
                  aria-label="Mon Profil"
                >
                  {(currentUser.avatarUrl || currentUser.avatar) ? (
                    <img src={currentUser.avatarUrl || currentUser.avatar} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <span>{currentUser.firstName ? currentUser.firstName.charAt(0) : currentUser.name.charAt(0)}</span>
                  )}
                </button>

                {/* Desktop: Rich Profile Button with Dropdown */}
                <button
                  id="user-account-btn"
                  onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                  className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-left transition cursor-pointer min-h-[40px]"
                >
                  <div className="w-7 h-7 rounded-lg bg-blue-600 text-white flex items-center justify-center text-xs font-bold shadow-xs shrink-0 overflow-hidden">
                    {(currentUser.avatarUrl || currentUser.avatar) ? (
                      <img src={currentUser.avatarUrl || currentUser.avatar} alt="" className="w-full h-full object-cover" />
                    ) : (
                      currentUser.firstName ? currentUser.firstName.charAt(0) : currentUser.name.charAt(0)
                    )}
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-slate-900 leading-none truncate max-w-[120px]">
                      {currentUser.name}
                    </div>
                    <div className="text-[10px] text-blue-600 font-medium mt-0.5 flex items-center gap-1">
                      <span className="truncate max-w-[80px]">{currentUser.familyName || 'Famille Nzala'}</span>
                      <span>•</span>
                      <span className="text-slate-500">{currentUser.role.replace('_', ' ')}</span>
                    </div>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                </button>

                {/* Dropdown Menu (Desktop) */}
                {isProfileMenuOpen && (
                  <>
                    <div
                      className="fixed inset-0 z-40"
                      onClick={() => setIsProfileMenuOpen(false)}
                    />
                    <div className="absolute right-0 mt-2 w-[min(20rem,calc(100vw-1rem))] bg-white border border-slate-200 rounded-2xl shadow-xl z-50 p-2 text-slate-800 divide-y divide-slate-100">
                      {/* User Profile Header */}
                      <div className="p-3 space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-900 truncate pr-2">{currentUser.name}</span>
                          <RoleBadge role={currentUser.role} />
                        </div>
                        <p className="text-[11px] text-slate-500 truncate">{currentUser.email}</p>

                        <div className="pt-1 flex items-center gap-2">
                          <button
                            onClick={() => {
                              setActiveTab('profile');
                              setIsProfileMenuOpen(false);
                            }}
                            className="flex-1 py-2 px-2.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-xs font-semibold text-blue-700 border border-blue-200 transition flex items-center justify-center gap-1.5 cursor-pointer min-h-[38px]"
                          >
                            <User className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                            <span className="truncate">Mon Profil</span>
                          </button>
                          <button
                            onClick={() => {
                              logout();
                              setIsProfileMenuOpen(false);
                            }}
                            className="py-2 px-2.5 rounded-xl bg-slate-50 hover:bg-rose-50 text-slate-600 hover:text-rose-700 border border-slate-200 hover:border-rose-200 transition text-xs flex items-center justify-center cursor-pointer min-h-[38px] min-w-[38px]"
                            title="Déconnexion"
                          >
                            <LogOut className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Quick Demo Switcher */}
                      <div className="p-2 space-y-1.5">
                        <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-blue-700 flex items-center gap-1.5">
                          <Sparkles className="w-3 h-3 text-blue-600 shrink-0" />
                          <span>Changer de rôle (Comptes Démo)</span>
                        </div>

                        <div className="space-y-1 max-h-52 overflow-y-auto pr-1">
                          {availableProfiles.map((p, idx) => {
                            const isCurrent = currentUser.id === p.user.id;
                            return (
                              <button
                                key={p.user.id}
                                onClick={() => {
                                  switchProfile(idx);
                                  setIsProfileMenuOpen(false);
                                }}
                                className={`w-full text-left p-2 rounded-xl text-xs flex flex-col gap-0.5 transition cursor-pointer ${
                                  isCurrent
                                    ? 'bg-blue-50 text-blue-900 border border-blue-200 font-medium'
                                    : 'hover:bg-slate-50 text-slate-700'
                                }`}
                              >
                                <div className="flex items-center justify-between">
                                  <span className="font-semibold text-[11px] truncate text-slate-900">{p.user.name}</span>
                                  <RoleBadge role={p.user.role} />
                                </div>
                                <span className="text-[10px] text-slate-500 truncate">{p.label}</span>
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Reset button */}
                      <div className="p-2">
                        <button
                          onClick={() => {
                            resetToDefaults();
                            setIsProfileMenuOpen(false);
                          }}
                          className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition cursor-pointer min-h-[38px]"
                        >
                          <RotateCcw className="w-3 h-3 text-slate-500 shrink-0" />
                          <span>Réinitialiser les données de démo</span>
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}

            {/* --- 3. MENU (HAMBURGER) BUTTON (Mobile only) --- */}
            <button
              id="mobile-menu-toggle"
              onClick={onMobileMenuToggle}
              className="md:hidden p-2 rounded-xl bg-slate-100 text-slate-700 hover:text-slate-900 hover:bg-slate-200 cursor-pointer min-h-[40px] min-w-[40px] flex items-center justify-center shrink-0"
              aria-label="Menu Principal"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
