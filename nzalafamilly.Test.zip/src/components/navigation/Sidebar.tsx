import React from 'react';
import { useFamily } from '../../context/FamilyContext';
import {
  LayoutDashboard,
  Users,
  HeartHandshake,
  FileCheck,
  GitFork,
  Calendar,
  ShieldCheck,
  Sparkles,
  Home,
  User,
  FileCheck2,
  Newspaper,
  MessageSquare,
  Bell,
  Info,
  Compass,
  PhoneCall,
} from 'lucide-react';

interface SidebarProps {
  isMobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isMobileOpen, onCloseMobile }) => {
  const {
    activeTab,
    setActiveTab,
    verificationRequests,
    posts,
    totalUnreadMessagesCount,
    notifications,
    setIsNotificationDrawerOpen,
    currentUser,
    can,
  } = useFamily();

  const unreadNotificationsCount = notifications.filter((n) => !n.read && !n.isRead).length;

  const pendingVerifications = verificationRequests.filter(
    (r) => r.status === 'EN_ATTENTE' || r.status === 'EN_VERIFICATION'
  ).length;

  const pendingPostModeration = posts.filter(
    (p) => p.moderationStatus === 'EN_ATTENTE_MODERATION'
  ).length;

  const canModerate =
    currentUser.role === 'SUPER_ADMIN' ||
    currentUser.role === 'ADMIN_FAMILIAL' ||
    currentUser.role === 'VALIDATEUR';

  const navigationItems = [
    {
      id: 'landing',
      label: 'Accueil & Présentation',
      icon: Home,
      description: 'Découvrir NzalaFamilly',
    },
    {
      id: 'discovery',
      label: 'Découverte Familiale',
      icon: Compass,
      description: 'Nouveautés & alliances',
    },
    {
      id: 'dashboard',
      label: 'Tableau de bord',
      icon: LayoutDashboard,
      description: 'Synthèses & activités',
      permission: 'VIEW_DASHBOARD',
    },
    {
      id: 'profile',
      label: 'Mon Profil & Sécurité',
      icon: User,
      description: 'Identité & paramètres',
    },
    {
      id: 'affiliation',
      label: 'Mon Affiliation',
      icon: FileCheck2,
      description: 'Déclaration & statut',
    },
    {
      id: 'members',
      label: 'Annuaire des Membres',
      icon: Users,
      description: 'Nzala & Membres Alliés',
      permission: 'VIEW_MEMBERS',
    },
    {
      id: 'alliances',
      label: 'Familles & Alliances',
      icon: HeartHandshake,
      description: 'Pactes & lignées alliées',
      permission: 'VIEW_ALLIED_FAMILIES',
    },
    {
      id: 'verifications',
      label: 'Centre de Vérification',
      icon: FileCheck,
      description: 'Examen des affiliations',
      badge:
        pendingVerifications > 0 && can('PROCESS_VERIFICATION')
          ? pendingVerifications
          : undefined,
    },
    {
      id: 'genealogy',
      label: 'Arbre Généalogique',
      icon: GitFork,
      description: 'Branches & générations',
      permission: 'VIEW_GENEALOGY',
    },
    {
      id: 'memoire',
      label: 'Mémoire & Archives',
      icon: Sparkles,
      description: 'Récits, ancêtres & photos',
    },
    {
      id: 'events',
      label: 'Événements & Calendrier',
      icon: Calendar,
      description: 'Anniversaires & rencontres',
      permission: 'VIEW_EVENTS',
    },
    {
      id: 'announcements',
      label: 'Fil Familial & Annonces',
      icon: Newspaper,
      description: 'Publications, réactions & fil',
      badge: pendingPostModeration > 0 && canModerate ? pendingPostModeration : undefined,
    },
    {
      id: 'messages',
      label: 'Messagerie Privée',
      icon: MessageSquare,
      description: 'Discussions directes & groupes',
      badge: totalUnreadMessagesCount > 0 ? totalUnreadMessagesCount : undefined,
    },
    {
      id: 'calls',
      label: 'Appels Audio & Vidéo',
      icon: PhoneCall,
      description: 'Appels chiffrés HD familiaux',
    },
    {
      id: 'notifications',
      label: 'Notifications',
      icon: Bell,
      description: 'Alertes & interactions',
      badge: unreadNotificationsCount > 0 ? unreadNotificationsCount : undefined,
      isAction: true,
      onClick: () => setIsNotificationDrawerOpen(true),
    },
    {
      id: 'admin',
      label: 'Administration & Audit',
      icon: ShieldCheck,
      description: 'Rôles, logs & gouvernance',
      requiresAdmin: true,
    },
  ];

  const handleNavClick = (item: any) => {
    if (item.isAction && item.onClick) {
      item.onClick();
    } else {
      setActiveTab(item.id);
    }
    if (isMobileOpen) {
      onCloseMobile();
    }
  };

  const isUserAdmin =
    currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL';

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-xs md:hidden"
          onClick={onCloseMobile}
        />
      )}

      <aside
        id="app-sidebar"
        className={`fixed md:sticky top-16 sm:top-18 z-40 md:z-20 h-[calc(100vh-4rem)] sm:h-[calc(100vh-4.5rem)] w-72 bg-white border-r border-slate-200 flex flex-col justify-between transition-transform duration-300 ease-in-out shrink-0 shadow-xs ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div className="p-3.5 space-y-1 overflow-y-auto">
          {/* Section: Navigation Principale */}
          <div className="px-3 py-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Espaces &amp; Modules
          </div>

          <nav className="space-y-1">
            {navigationItems.map((item) => {
              if (item.requiresAdmin && !isUserAdmin) return null;

              const isActive = activeTab === item.id;
              const Icon = item.icon;

              return (
                <button
                  key={item.id}
                  id={`nav-item-${item.id}`}
                  onClick={() => handleNavClick(item)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-left transition cursor-pointer group ${
                    isActive
                      ? 'bg-blue-600 text-white font-semibold shadow-xs'
                      : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Icon
                      className={`w-4 h-4 shrink-0 transition ${
                        isActive ? 'text-white' : 'text-slate-500 group-hover:text-blue-600'
                      }`}
                    />
                    <div className="truncate">
                      <div className="text-xs font-semibold leading-tight truncate">{item.label}</div>
                      <div
                        className={`text-[10px] truncate ${
                          isActive ? 'text-blue-100 font-medium' : 'text-slate-400'
                        }`}
                      >
                        {item.description}
                      </div>
                    </div>
                  </div>

                  {item.badge !== undefined && (
                    <span
                      className={`shrink-0 ml-2 px-1.5 py-0.5 text-[10px] font-bold rounded-full ${
                        isActive
                          ? 'bg-white text-blue-700'
                          : 'bg-blue-100 text-blue-700'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Quick Notice about Nzala vs Alliés */}
          <div className="pt-3 mt-2 border-t border-slate-100 px-1">
            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1">
              <div className="flex items-center gap-1.5 font-semibold text-blue-700 text-[11px]">
                <Info className="w-3.5 h-3.5 text-blue-600" />
                <span>Gouvernance &amp; Confidentialité</span>
              </div>
              <p className="text-[10px] text-slate-500 leading-relaxed">
                Les droits d’accès aux arbres privés et fiches membres sont régis par le Conseil de famille.
              </p>
            </div>
          </div>
        </div>

        {/* Footer info in sidebar */}
        <div className="p-3 border-t border-slate-100 bg-slate-50/70">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="font-semibold text-slate-700">NzalaFamilly</span>
            <span className="px-2 py-0.5 bg-slate-200/80 rounded-md text-[10px] text-slate-600 font-medium">v2.0 UI</span>
          </div>
        </div>
      </aside>
    </>
  );
};
