/**
 * NzalaFamilly - Centre de Notifications Centralisé & Intelligent (NZALA NOTIFICATION CENTER)
 * Tiroir latéral & vue complète avec filtrage par catégorie, statut de lecture, regroupement intelligent et actions rapides
 */

import React, { useState, useMemo } from 'react';
import {
  Bell,
  CheckCheck,
  X,
  Phone,
  PhoneMissed,
  MessageSquare,
  Calendar,
  Sparkles,
  Newspaper,
  Shield,
  Clock,
  Settings,
  ChevronRight,
  Filter,
  Check,
  Ban,
  Trash2,
  Megaphone,
  AlertTriangle,
  Radio,
  Lock,
  UserCheck,
  Share2,
  Heart,
  Users,
  Eye,
} from 'lucide-react';
import {
  FamilyNotification,
  NotificationCategory,
  NotificationType,
} from '../../types/notifications';
import {
  NotificationService,
  GroupedNotification,
} from '../../services/notifications/NotificationService';
import { useFamily } from '../../context/FamilyContext';
import { OfficialNotificationModal } from './OfficialNotificationModal';

interface NotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: FamilyNotification[];
  onMarkAsRead: (id: string) => void;
  onMarkAllAsRead: () => void;
  onNavigateToTarget: (linkTab?: string, targetId?: string) => void;
  onOpenSettings: () => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkAsRead,
  onMarkAllAsRead,
  onNavigateToTarget,
  onOpenSettings,
}) => {
  const {
    currentUser,
    notificationPreferences,
    deleteNotification,
    clearReadNotifications,
    handleNotificationQuickAction,
  } = useFamily();

  const [activeCategory, setActiveCategory] = useState<NotificationCategory>('ALL');
  const [isOfficialModalOpen, setIsOfficialModalOpen] = useState(false);

  const isUserAdmin =
    currentUser.role === 'SUPER_ADMIN' ||
    currentUser.role === 'ADMIN_FAMILIAL' ||
    currentUser.role === 'VALIDATEUR';

  // Filtrage selon les préférences et la catégorie
  const filteredNotifications = useMemo(() => {
    return NotificationService.filterNotifications(
      notifications,
      activeCategory,
      currentUser.role,
      notificationPreferences
    );
  }, [notifications, activeCategory, currentUser.role, notificationPreferences]);

  // Regroupement intelligent des notifications
  const groupedNotifications = useMemo(() => {
    return NotificationService.groupSimilarNotifications(filteredNotifications);
  }, [filteredNotifications]);

  const unreadCount = useMemo(() => {
    return notifications.filter((n) => !n.read && !n.isRead).length;
  }, [notifications]);

  if (!isOpen) return null;

  const categoriesConfig: { id: NotificationCategory; label: string; count?: number }[] = [
    { id: 'ALL', label: 'Toutes' },
    { id: 'UNREAD', label: `Non lues`, count: unreadCount },
    { id: 'SOCIAL', label: 'Social' },
    { id: 'MESSAGES', label: 'Messages' },
    { id: 'STORIES', label: 'Stories' },
    { id: 'EVENTS', label: 'Événements' },
    { id: 'FAMILY', label: 'Famille' },
    { id: 'LIVE', label: '🔴 Live' },
    { id: 'SECURITY', label: 'Sécurité' },
    ...(isUserAdmin ? [{ id: 'ADMIN' as NotificationCategory, label: 'Administration' }] : []),
    { id: 'SYSTEM', label: 'Système' },
  ];

  const renderIcon = (notif: GroupedNotification) => {
    switch (notif.type) {
      case 'LIVE_EN_COURS':
      case 'LIVE_BIENTOT':
      case 'LIVE_PROGRAMME':
        return <Radio className="w-4 h-4 text-rose-600 animate-pulse" />;
      case 'REACTION':
      case 'NEW_REACTION':
        return <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />;
      case 'COMMENTAIRE':
      case 'REPONSE_COMMENTAIRE':
      case 'NEW_COMMENT':
        return <MessageSquare className="w-4 h-4 text-blue-600" />;
      case 'MENTION':
        return <span className="font-black text-xs text-indigo-600">@</span>;
      case 'PARTAGE':
        return <Share2 className="w-4 h-4 text-emerald-600" />;
      case 'STORY_REACTION':
      case 'STORY':
        return <Sparkles className="w-4 h-4 text-amber-500" />;
      case 'MESSAGE':
      case 'MESSAGE_AUDIO':
      case 'MESSAGE_MEDIA':
        return <MessageSquare className="w-4 h-4 text-blue-500" />;
      case 'MESSAGE_VUE_UNIQUE':
        return <Eye className="w-4 h-4 text-purple-600" />;
      case 'APPEL_MANQUE':
        return <PhoneMissed className="w-4 h-4 text-rose-500" />;
      case 'APPEL_ENTRANT':
        return <Phone className="w-4 h-4 text-blue-500" />;
      case 'DEMANDE_ACCES_PROFIL':
      case 'ACCES_PROFIL_ACCEPTE':
        return <UserCheck className="w-4 h-4 text-teal-600" />;
      case 'AFFILIATION_APPROUVEE':
      case 'ADMIN_NOUVELLE_AFFILIATION':
      case 'ADMIN_DOSSIER_EXAMEN':
      case 'AFFILIATION':
        return <Shield className="w-4 h-4 text-purple-600" />;
      case 'EVENEMENT':
      case 'EVENEMENT_INVITATION':
      case 'EVENEMENT_RAPPEL':
        return <Calendar className="w-4 h-4 text-emerald-600" />;
      case 'ANNIVERSAIRE_JOUR':
      case 'ANNIVERSAIRE':
        return <span className="text-sm">🎂</span>;
      case 'SECURITE_CONNEXION':
      case 'SECURITE_ALERTE':
      case 'SECURITE_2FA':
        return <Lock className="w-4 h-4 text-stone-700" />;
      case 'SYSTEME_COMMUNIQUE':
      case 'OFFICIAL_COMMUNIQUE':
        return <Megaphone className="w-4 h-4 text-blue-600" />;
      case 'ADMIN_SIGNALEMENT':
      case 'MODERATION_UPDATE':
        return <AlertTriangle className="w-4 h-4 text-amber-600" />;
      default:
        return <Newspaper className="w-4 h-4 text-blue-600" />;
    }
  };

  const handleCardClick = (notif: GroupedNotification) => {
    // Marquer comme lues toutes les notifications brutes du groupe
    notif.rawNotifications.forEach((raw) => {
      if (!raw.read && !raw.isRead) {
        onMarkAsRead(raw.id);
      }
    });

    if (notif.linkTab) {
      onNavigateToTarget(notif.linkTab, notif.targetId);
      onClose();
    }
  };

  return (
    <>
      <div
        id="notification-drawer-overlay"
        className="fixed inset-0 z-50 bg-stone-950/60 backdrop-blur-xs flex justify-end animate-fadeIn"
        onClick={onClose}
      >
        <div
          className="w-full max-w-lg h-full bg-white shadow-2xl flex flex-col justify-between overflow-hidden animate-slideInRight"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="p-4 border-b border-stone-200 bg-stone-50/90 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-blue-50 text-blue-700 border border-blue-200 shadow-xs">
                <Bell className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-stone-900 text-base">Notifications</h3>
                  {unreadCount > 0 && (
                    <span className="px-2 py-0.5 rounded-full bg-blue-600 text-white text-[11px] font-black shadow-xs">
                      {unreadCount > 99 ? '99+' : unreadCount}
                    </span>
                  )}
                </div>
                <p className="text-xs text-stone-500">Mises à jour, interactions et gouvernance</p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              {isUserAdmin && (
                <button
                  id="notif-btn-broadcast-official"
                  onClick={() => setIsOfficialModalOpen(true)}
                  className="p-2 rounded-xl text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 transition cursor-pointer"
                  title="Diffuser un communiqué officiel"
                >
                  <Megaphone className="w-4 h-4" />
                </button>
              )}
              <button
                id="notif-btn-settings"
                onClick={onOpenSettings}
                className="p-2 rounded-xl text-stone-500 hover:text-stone-900 hover:bg-stone-200 transition cursor-pointer"
                title="Préférences de notifications"
              >
                <Settings className="w-4 h-4" />
              </button>
              <button
                id="notif-btn-close"
                onClick={onClose}
                className="p-2 rounded-xl text-stone-500 hover:text-stone-900 hover:bg-stone-200 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Categories / Filter Tabs */}
          <div className="px-3 py-2 border-b border-stone-200 bg-white flex items-center gap-1.5 overflow-x-auto text-xs no-scrollbar">
            {categoriesConfig.map((tab) => {
              const isSelected = activeCategory === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveCategory(tab.id)}
                  className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 text-xs ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-stone-600 bg-stone-50 hover:bg-stone-100 border border-stone-200/60'
                  }`}
                >
                  <span>{tab.label}</span>
                  {tab.count !== undefined && tab.count > 0 && (
                    <span
                      className={`px-1.5 py-0.2 rounded-full text-[10px] font-black ${
                        isSelected ? 'bg-white/30 text-white' : 'bg-blue-100 text-blue-700'
                      }`}
                    >
                      {tab.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Action toolbar (Tout lire / Effacer lues) */}
          <div className="px-4 py-2 bg-stone-50 border-b border-stone-200 flex items-center justify-between text-xs text-stone-500">
            <span className="text-[11px] font-medium">
              {groupedNotifications.length} notification{groupedNotifications.length > 1 ? 's' : ''}
            </span>
            <div className="flex items-center gap-3">
              {unreadCount > 0 && (
                <button
                  id="notif-btn-mark-all-read"
                  onClick={onMarkAllAsRead}
                  className="flex items-center gap-1 text-[11px] font-bold text-blue-700 hover:text-blue-800 transition cursor-pointer"
                >
                  <CheckCheck className="w-3.5 h-3.5" />
                  <span>Tout marquer comme lu</span>
                </button>
              )}
              <button
                id="notif-btn-clear-read"
                onClick={clearReadNotifications}
                className="flex items-center gap-1 text-[11px] font-semibold text-stone-500 hover:text-rose-600 transition cursor-pointer"
              >
                <Trash2 className="w-3 h-3" />
                <span>Effacer lues</span>
              </button>
            </div>
          </div>

          {/* Notifications Feed */}
          <div className="flex-1 overflow-y-auto p-3.5 space-y-2.5">
            {groupedNotifications.length > 0 ? (
              groupedNotifications.map((notif) => {
                const isUnread = !notif.read;
                const hasPendingQuickAction =
                  notif.type === 'DEMANDE_ACCES_PROFIL' &&
                  notif.metadata?.quickActionState === 'PENDING';

                return (
                  <div
                    key={notif.id}
                    id={`notification-card-${notif.id}`}
                    onClick={() => handleCardClick(notif)}
                    className={`p-3.5 rounded-2xl border transition cursor-pointer group relative flex flex-col gap-2 ${
                      isUnread
                        ? 'bg-blue-50/50 border-blue-200/90 shadow-xs hover:bg-blue-50/80'
                        : 'bg-white border-stone-200/80 hover:bg-stone-50 hover:border-stone-300'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      {/* Avatar or Icon */}
                      <div className="relative shrink-0 mt-0.5">
                        {notif.senderAvatar ? (
                          <img
                            src={notif.senderAvatar}
                            alt={notif.senderName || 'Expéditeur'}
                            className="w-10 h-10 rounded-xl object-cover border border-stone-200"
                          />
                        ) : (
                          <div
                            className={`w-10 h-10 rounded-xl flex items-center justify-center border ${
                              isUnread
                                ? 'bg-white border-blue-200 text-blue-600 shadow-xs'
                                : 'bg-stone-100 border-stone-200 text-stone-600'
                            }`}
                          >
                            {renderIcon(notif)}
                          </div>
                        )}

                        {/* Small corner badge if avatar is present */}
                        {notif.senderAvatar && (
                          <div className="absolute -bottom-1 -right-1 p-0.5 rounded-full bg-white shadow-xs border border-stone-200">
                            {renderIcon(notif)}
                          </div>
                        )}
                      </div>

                      {/* Content details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-1">
                          <div className="flex items-center gap-1.5 flex-wrap min-w-0">
                            <h4
                              className={`text-xs leading-snug truncate ${
                                isUnread ? 'font-bold text-stone-900' : 'font-semibold text-stone-700'
                              }`}
                            >
                              {notif.title}
                            </h4>
                            {notif.senderVerifiedBadge && (
                              <span className="px-1.5 py-0.2 rounded-md bg-stone-100 border border-stone-200 text-[10px] font-semibold text-stone-600 shrink-0">
                                {notif.senderVerifiedBadge}
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-stone-400 shrink-0 whitespace-nowrap">
                            {formatRelativeDate(notif.createdAt)}
                          </span>
                        </div>

                        <p className="text-xs text-stone-600 mt-1 leading-relaxed line-clamp-2">
                          {notif.body}
                        </p>

                        {/* Grouped badge count */}
                        {notif.itemsCount > 1 && (
                          <div className="mt-1.5 inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-bold">
                            <Users className="w-3 h-3" />
                            <span>{notif.itemsCount} éléments regroupés</span>
                          </div>
                        )}

                        {/* Quick action buttons for Profile Access Requests */}
                        {hasPendingQuickAction && (
                          <div
                            className="flex items-center gap-2 mt-2.5 pt-2 border-t border-stone-200/60"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <button
                              id={`btn-accept-access-${notif.id}`}
                              onClick={() =>
                                handleNotificationQuickAction(notif.rawNotifications[0].id, 'ACCEPT')
                              }
                              className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-xs cursor-pointer"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>Accepter l'accès</span>
                            </button>
                            <button
                              id={`btn-reject-access-${notif.id}`}
                              onClick={() =>
                                handleNotificationQuickAction(notif.rawNotifications[0].id, 'REJECT')
                              }
                              className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold transition cursor-pointer"
                            >
                              <Ban className="w-3.5 h-3.5" />
                              <span>Refuser</span>
                            </button>
                          </div>
                        )}

                        {/* Action result status badge if resolved */}
                        {notif.metadata?.quickActionState === 'ACCEPTED' && (
                          <div className="mt-2 text-[11px] font-bold text-emerald-700 flex items-center gap-1">
                            <Check className="w-3.5 h-3.5" />
                            <span>Demande acceptée</span>
                          </div>
                        )}
                        {notif.metadata?.quickActionState === 'REJECTED' && (
                          <div className="mt-2 text-[11px] font-bold text-rose-700 flex items-center gap-1">
                            <Ban className="w-3.5 h-3.5" />
                            <span>Demande refusée</span>
                          </div>
                        )}

                        {/* Direct link label */}
                        {notif.linkTab && !hasPendingQuickAction && (
                          <div className="flex items-center gap-1 text-[11px] font-bold text-blue-700 mt-2 group-hover:translate-x-0.5 transition-transform">
                            <span>Consulter</span>
                            <ChevronRight className="w-3 h-3" />
                          </div>
                        )}
                      </div>

                      {/* Right actions: Delete & Unread indicator */}
                      <div className="flex flex-col items-end gap-2 shrink-0">
                        {isUnread && (
                          <span className="w-2.5 h-2.5 rounded-full bg-blue-600 shadow-xs animate-pulse" />
                        )}
                        <button
                          id={`btn-delete-notif-${notif.id}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            notif.rawNotifications.forEach((raw) => deleteNotification(raw.id));
                          }}
                          className="opacity-0 group-hover:opacity-100 p-1 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-stone-100 transition cursor-pointer"
                          title="Supprimer cette notification"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="py-24 text-center text-stone-400">
                <Bell className="w-12 h-12 mx-auto mb-3 opacity-25 text-stone-500" />
                <h4 className="text-sm font-bold text-stone-700">Aucune notification</h4>
                <p className="text-xs text-stone-500 mt-1 max-w-xs mx-auto">
                  Toutes vos notifications sont à jour pour cette catégorie.
                </p>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="p-3.5 border-t border-stone-200 bg-stone-50/80 flex items-center justify-between">
            <button
              onClick={onOpenSettings}
              className="text-xs text-stone-600 hover:text-blue-700 font-semibold cursor-pointer flex items-center gap-1.5"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Gérer mes alertes</span>
            </button>
            <span className="text-[11px] text-stone-400 font-medium">
              Nzala Notification Center v2.0
            </span>
          </div>
        </div>
      </div>

      {/* Admin Broadcast Modal */}
      <OfficialNotificationModal
        isOpen={isOfficialModalOpen}
        onClose={() => setIsOfficialModalOpen(false)}
      />
    </>
  );
};

function formatRelativeDate(isoDate: string): string {
  try {
    const date = new Date(isoDate);
    const now = new Date();
    const diffMins = Math.floor((now.getTime() - date.getTime()) / 60000);

    if (diffMins < 1) return "À l'instant";
    if (diffMins < 60) return `Il y a ${diffMins} min`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `Il y a ${diffHours} h`;
    const diffDays = Math.floor(diffHours / 24);
    if (diffDays === 1) return 'Hier';
    if (diffDays < 7) return `Il y a ${diffDays} j`;

    return date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
  } catch {
    return '';
  }
}
