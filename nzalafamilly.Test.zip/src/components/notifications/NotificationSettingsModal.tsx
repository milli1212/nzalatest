/**
 * NzalaFamilly - Modale des Préférences de Notifications (NZALA NOTIFICATION SETTINGS)
 * Permet d'activer/désactiver par catégorie et de préparer le Web Push
 */

import React, { useState } from 'react';
import {
  X,
  Bell,
  MessageSquare,
  Sparkles,
  Newspaper,
  Calendar,
  Phone,
  Shield,
  Volume2,
  Lock,
  Megaphone,
  Radio,
  AlertCircle,
  Cake,
} from 'lucide-react';
import { NotificationPreferences } from '../../types/notifications';
import { NotificationService } from '../../services/notifications/NotificationService';

interface NotificationSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  preferences: NotificationPreferences;
  onUpdatePreferences: (prefs: Partial<NotificationPreferences>) => void;
}

export const NotificationSettingsModal: React.FC<NotificationSettingsModalProps> = ({
  isOpen,
  onClose,
  preferences,
  onUpdatePreferences,
}) => {
  const [pushStatus, setPushStatus] = useState<string>('DEFAULT');

  if (!isOpen) return null;

  const handleTogglePush = async () => {
    if (!preferences.pushEnabled) {
      const res = await NotificationService.requestPushPermission();
      if (res.granted) {
        onUpdatePreferences({ pushEnabled: true });
        setPushStatus('GRANTED');
      } else {
        setPushStatus('DENIED');
      }
    } else {
      onUpdatePreferences({ pushEnabled: false });
    }
  };

  const categories = [
    {
      key: 'messages',
      label: 'Messages privés & Groupes',
      desc: 'Nouveaux messages, vocaux, photos éphémères et partages',
      icon: MessageSquare,
      color: 'text-blue-600 bg-blue-50',
    },
    {
      key: 'calls',
      label: 'Appels audio & vidéo',
      desc: 'Appels entrants et notifications d’appels manqués',
      icon: Phone,
      color: 'text-emerald-600 bg-emerald-50',
    },
    {
      key: 'publications',
      label: 'Publications & Fil Social',
      desc: 'Nouvelles annonces, réactions ❤️ et commentaires',
      icon: Newspaper,
      color: 'text-indigo-600 bg-indigo-50',
    },
    {
      key: 'stories',
      label: 'Stories familiales',
      desc: 'Nouvelles stories partagées et réactions des membres',
      icon: Sparkles,
      color: 'text-amber-600 bg-amber-50',
    },
    {
      key: 'events',
      label: 'Événements & Réunions',
      desc: 'Invitations, rappels d’agenda et confirmations RSVP',
      icon: Calendar,
      color: 'text-purple-600 bg-purple-50',
    },
    {
      key: 'birthdays',
      label: 'Anniversaires des membres',
      desc: 'Alertes et célébrations le jour des anniversaires',
      icon: Cake,
      color: 'text-pink-600 bg-pink-50',
    },
    {
      key: 'governance',
      label: 'Gouvernance, Profils & Affiliations',
      desc: 'Demandes d’accès profils, décisions du Conseil et dossiers',
      icon: Shield,
      color: 'text-teal-600 bg-teal-50',
    },
    {
      key: 'security',
      label: 'Sécurité & Accès au compte',
      desc: 'Nouvelles connexions, alertes de sécurité et 2FA',
      icon: Lock,
      color: 'text-stone-700 bg-stone-100',
    },
    {
      key: 'system',
      label: 'Système & Communiqués officiels',
      desc: 'Communications générales, maintenance et nouveautés',
      icon: Megaphone,
      color: 'text-blue-700 bg-blue-50',
    },
  ];

  return (
    <div
      id="notif-settings-overlay"
      className="fixed inset-0 z-50 bg-stone-950/60 backdrop-blur-xs flex items-center justify-center p-4 select-none animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[85vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 bg-stone-50/90 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-blue-50 text-blue-700 border border-blue-200">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-stone-900 text-base">Préférences de Notifications</h3>
              <p className="text-xs text-stone-500">Contrôlez les alertes et notifications que vous recevez</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-200 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {/* Push Web Notification Section */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-50/50 via-white to-stone-50 border border-blue-200/80 space-y-2">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <Radio className="w-5 h-5 text-blue-600" />
                <div>
                  <h4 className="text-xs font-bold text-stone-900">Notifications Push Navigateur</h4>
                  <p className="text-[11px] text-stone-600">
                    Recevoir les alertes même lorsque l’onglet n’est pas actif
                  </p>
                </div>
              </div>
              <button
                id="btn-toggle-push-notifications"
                onClick={handleTogglePush}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                  preferences.pushEnabled
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                }`}
              >
                {preferences.pushEnabled ? 'Activé' : 'Activer'}
              </button>
            </div>
            {pushStatus === 'DENIED' && (
              <p className="text-[11px] text-rose-600 flex items-center gap-1 mt-1 font-medium">
                <AlertCircle className="w-3.5 h-3.5" />
                L’autorisation a été bloquée dans votre navigateur.
              </p>
            )}
            <p className="text-[10px] text-stone-400 italic">
              Compatible avec Web Push API &amp; Firebase Cloud Messaging.
            </p>
          </div>

          {/* Sound toggle */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-stone-50 border border-stone-200">
            <div className="flex items-center gap-2.5">
              <Volume2 className="w-4 h-4 text-stone-600" />
              <div>
                <h4 className="text-xs font-bold text-stone-900">Effets sonores &amp; Tonalités</h4>
                <p className="text-[11px] text-stone-500">Jouer un son lors des nouveaux messages et alertes</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={preferences.soundEnabled}
              onChange={(e) => onUpdatePreferences({ soundEnabled: e.target.checked })}
              className="w-4 h-4 text-blue-600 rounded cursor-pointer accent-blue-600"
            />
          </div>

          {/* Category List */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-400 px-1 pt-1">
              Canaux d'alertes &amp; Catégories
            </h4>
            {categories.map((cat) => {
              const Icon = cat.icon;
              const isChecked = (preferences as any)[cat.key] ?? true;

              return (
                <label
                  key={cat.key}
                  className="flex items-center justify-between p-3 rounded-2xl border border-stone-200/80 hover:border-stone-300 hover:bg-stone-50/70 transition cursor-pointer"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`p-2 rounded-xl shrink-0 ${cat.color}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-stone-900">{cat.label}</div>
                      <div className="text-[11px] text-stone-500 truncate">{cat.desc}</div>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={isChecked}
                    onChange={(e) => onUpdatePreferences({ [cat.key]: e.target.checked } as any)}
                    className="w-4 h-4 text-blue-600 rounded cursor-pointer accent-blue-600 ml-3"
                  />
                </label>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-stone-200 bg-stone-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-blue-600 text-white text-xs font-bold hover:bg-blue-700 transition shadow-xs cursor-pointer"
          >
            Enregistrer les préférences
          </button>
        </div>
      </div>
    </div>
  );
};
