/**
 * NzalaFamilly - Modale de Diffusion de Notification Officielle (NZALA BROADCAST MODAL)
 * Réservée aux Administrateurs et au Conseil des Sages
 */

import React, { useState } from 'react';
import { X, Send, Megaphone, AlertTriangle, ShieldCheck, Info } from 'lucide-react';
import { useFamily } from '../../context/FamilyContext';

interface OfficialNotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const OfficialNotificationModal: React.FC<OfficialNotificationModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { createOfficialNotification, currentUser } = useFamily();
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [priority, setPriority] = useState<'NORMALE' | 'HAUTE' | 'URGENTE'>('NORMALE');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) return;

    setIsSubmitting(true);
    createOfficialNotification(title.trim(), body.trim(), priority);
    setIsSubmitting(false);
    setTitle('');
    setBody('');
    setPriority('NORMALE');
    onClose();
  };

  return (
    <div
      id="official-notif-modal-overlay"
      className="fixed inset-0 z-50 bg-stone-950/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 bg-stone-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-50 text-blue-700 border border-blue-200">
              <Megaphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-stone-900 text-base">Diffuser une Notification Officielle</h3>
              <p className="text-xs text-stone-500">
                Alerte adressée à l'ensemble de la communauté Nzala
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-200 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-4">
          <div className="flex items-center gap-2 p-3 bg-blue-50/70 border border-blue-100 rounded-2xl text-xs text-blue-900">
            <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
            <span>
              Diffusé en tant que <strong>{currentUser.name}</strong> ({currentUser.role}). Cette annonce apparaîtra dans le centre de notifications de tous les membres.
            </span>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1.5">
              Titre du communiqué *
            </label>
            <input
              type="text"
              required
              placeholder="Ex: Assemblée Générale Extraordinaire du Conseil..."
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-blue-500 text-stone-900 text-xs font-semibold"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1.5">
              Message détaillé *
            </label>
            <textarea
              required
              rows={4}
              placeholder="Rédigez ici les détails de la communication officielle..."
              value={body}
              onChange={(e) => setBody(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-blue-500 text-stone-900 text-xs leading-relaxed"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1.5">
              Niveau d'Urgence / Priorité
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'NORMALE', label: 'Normale', icon: Info, color: 'border-stone-200 text-stone-700' },
                { id: 'HAUTE', label: 'Haute', icon: AlertTriangle, color: 'border-amber-300 text-amber-800 bg-amber-50/50' },
                { id: 'URGENTE', label: 'Urgente', icon: Megaphone, color: 'border-rose-300 text-rose-800 bg-rose-50/50' },
              ].map((p) => {
                const Icon = p.icon;
                const isSelected = priority === p.id;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setPriority(p.id as any)}
                    className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl border text-xs font-bold transition cursor-pointer ${
                      isSelected
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : `${p.color} hover:bg-stone-50`
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{p.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Footer actions */}
          <div className="pt-3 border-t border-stone-100 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-600 hover:bg-stone-100 transition cursor-pointer"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !title.trim() || !body.trim()}
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-xs transition disabled:opacity-50 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Diffuser maintenant</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
