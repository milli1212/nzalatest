/**
 * NzalaFamilly - Modale de personnalisation d'avatar & profil vidéo 5 secondes
 * Supporte :
 * 1. Téléversement de photo depuis l'appareil
 * 2. Galerie d'avatars prédéfinis (Sages, Patriarches, Jeunesse, Héritage)
 * 3. Profil vidéo animé court (5 secondes max en boucle continue)
 */

import React, { useState, useRef } from 'react';
import { useFamily } from '../../context/FamilyContext';
import {
  X,
  Upload,
  Camera,
  Video,
  Sparkles,
  Check,
  Play,
  RotateCcw,
  Film,
  User,
  AlertCircle,
  Clock,
} from 'lucide-react';
import { MediaStorage } from '../../services/mediaStorage';

interface AvatarEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// Avatars prédéfinis représentatifs
export const PRESET_AVATARS = [
  {
    id: 'av-1',
    name: 'Patriarche Aîné',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
    category: 'Sages',
  },
  {
    id: 'av-2',
    name: 'Mère de Famille',
    url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&auto=format&fit=crop&q=80',
    category: 'Mères',
  },
  {
    id: 'av-3',
    name: 'Jeune Leader',
    url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80',
    category: 'Jeunesse',
  },
  {
    id: 'av-4',
    name: 'Cadre & Ingénieur',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
    category: 'Jeunesse',
  },
  {
    id: 'av-5',
    name: 'Doyenne Vénérée',
    url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300&auto=format&fit=crop&q=80',
    category: 'Sages',
  },
  {
    id: 'av-6',
    name: 'Membre de la Diaspora',
    url: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&auto=format&fit=crop&q=80',
    category: 'Diaspora',
  },
  {
    id: 'av-7',
    name: 'Conseillère Familiale',
    url: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=300&auto=format&fit=crop&q=80',
    category: 'Mères',
  },
  {
    id: 'av-8',
    name: 'Étudiant & Relève',
    url: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=300&auto=format&fit=crop&q=80',
    category: 'Jeunesse',
  },
];

// Vidéos d'exemples de profil court 5s
export const PRESET_PROFILE_VIDEOS = [
  {
    id: 'vid-av-1',
    name: 'Sourire chaleureux',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-young-man-smiling-happily-41121-large.mp4',
    duration: '5s',
  },
  {
    id: 'vid-av-2',
    name: 'Salutation familiale',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-african-woman-smiling-at-the-camera-41120-large.mp4',
    duration: '4s',
  },
];

export const AvatarEditorModal: React.FC<AvatarEditorModalProps> = ({ isOpen, onClose }) => {
  const { currentUser, updateUserProfile, setCurrentUser, showToast } = useFamily();

  const [activeTab, setActiveTab] = useState<'PHOTO' | 'PRESETS' | 'VIDEO'>('PHOTO');
  const [selectedAvatarUrl, setSelectedAvatarUrl] = useState<string>(currentUser.avatarUrl || '');
  const [selectedVideoUrl, setSelectedVideoUrl] = useState<string>(currentUser.avatarVideoUrl || '');
  const [isVideoAvatarActive, setIsVideoAvatarActive] = useState<boolean>(Boolean(currentUser.avatarVideoUrl));
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const videoPreviewRef = useRef<HTMLVideoElement>(null);

  if (!isOpen) return null;

  const handlePhotoUpload = async (file: File) => {
    setError(null);
    setIsProcessing(true);
    try {
      const validation = MediaStorage.validateFile(file);
      if (!validation.isValid) {
        setError(validation.error || 'Photo invalide.');
        return;
      }
      const media = await MediaStorage.uploadFile(file);
      setSelectedAvatarUrl(media.url);
      setIsVideoAvatarActive(false);
      showToast('success', 'Photo chargée avec succès !');
    } catch {
      setError('Impossible de charger la photo.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleVideoUpload = async (file: File) => {
    setError(null);
    setIsProcessing(true);
    try {
      const validation = MediaStorage.validateFile(file);
      if (!validation.isValid) {
        setError(validation.error || 'Vidéo invalide.');
        return;
      }
      const media = await MediaStorage.uploadFile(file);
      setSelectedVideoUrl(media.url);
      setIsVideoAvatarActive(true);
      showToast('success', 'Vidéo de profil 5 secondes chargée !');
    } catch {
      setError('Impossible de charger la vidéo.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSave = () => {
    const finalAvatar = selectedAvatarUrl || currentUser.avatarUrl;
    const finalVideo = isVideoAvatarActive ? selectedVideoUrl : undefined;

    updateUserProfile(currentUser.id, {
      avatarUrl: finalAvatar,
      avatarVideoUrl: finalVideo,
    });

    setCurrentUser({
      ...currentUser,
      avatarUrl: finalAvatar,
      avatarVideoUrl: finalVideo,
    });

    showToast('success', 'Photo et profil vidéo mis à jour avec succès !');
    onClose();
  };

  return (
    <div
      id="avatar-editor-modal"
      className="fixed inset-0 z-50 bg-stone-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-stone-900 font-serif">
                Photo & Vidéo de Profil
              </h2>
              <p className="text-xs text-stone-500">
                Personnalisez votre identité visuelle au sein de la famille
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-stone-200 bg-stone-50/70 p-1.5 gap-1.5">
          <button
            type="button"
            onClick={() => setActiveTab('PHOTO')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'PHOTO'
                ? 'bg-white text-blue-600 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Ma Photo</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('PRESETS')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'PRESETS'
                ? 'bg-white text-blue-600 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Galerie Prédéfinie</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('VIDEO')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'VIDEO'
                ? 'bg-white text-blue-600 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Video className="w-3.5 h-3.5" />
            <span>Vidéo 5s</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1">
          {error && (
            <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-xs font-semibold text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Current Live Preview */}
          <div className="flex flex-col items-center justify-center py-2">
            <div className="relative group">
              <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl overflow-hidden border-4 border-white shadow-xl bg-slate-900 flex items-center justify-center">
                {isVideoAvatarActive && selectedVideoUrl ? (
                  <video
                    ref={videoPreviewRef}
                    src={selectedVideoUrl}
                    autoPlay
                    loop
                    muted
                    playsInline
                    className="w-full h-full object-cover"
                  />
                ) : selectedAvatarUrl ? (
                  <img src={selectedAvatarUrl} alt="" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center text-3xl font-bold font-serif">
                    {currentUser.firstName?.charAt(0) || currentUser.name.charAt(0)}
                  </div>
                )}
              </div>

              {isVideoAvatarActive && (
                <div className="absolute -bottom-2 inset-x-0 flex justify-center">
                  <span className="px-2.5 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-bold shadow flex items-center gap-1">
                    <Film className="w-2.5 h-2.5" /> Vidéo active
                  </span>
                </div>
              )}
            </div>

            <p className="text-xs text-stone-500 mt-3 text-center">
              Aperçu en temps réel de votre profil visible par toute la famille
            </p>
          </div>

          {/* TAB 1: Photo Upload */}
          {activeTab === 'PHOTO' && (
            <div className="space-y-4">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handlePhotoUpload(e.target.files[0]);
                  }
                }}
              />

              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-stone-300 hover:border-blue-500 rounded-3xl p-6 text-center cursor-pointer transition bg-stone-50/50 hover:bg-blue-50/30 flex flex-col items-center justify-center gap-2"
              >
                <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center">
                  <Camera className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs sm:text-sm font-bold text-stone-800">
                    Cliquez ou glissez une photo ici
                  </p>
                  <p className="text-[11px] text-stone-500 mt-0.5">
                    Formats acceptés : JPG, PNG, WEBP (Max 15 Mo)
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Presets Gallery */}
          {activeTab === 'PRESETS' && (
            <div className="space-y-3">
              <span className="text-xs font-bold text-stone-700 block">
                Sélectionnez un avatar illustratif :
              </span>

              <div className="grid grid-cols-4 gap-2.5">
                {PRESET_AVATARS.map((preset) => {
                  const isSelected = !isVideoAvatarActive && selectedAvatarUrl === preset.url;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => {
                        setSelectedAvatarUrl(preset.url);
                        setIsVideoAvatarActive(false);
                      }}
                      className={`relative aspect-square rounded-2xl overflow-hidden border-2 transition hover:scale-105 cursor-pointer ${
                        isSelected ? 'border-blue-600 ring-2 ring-blue-400' : 'border-stone-200'
                      }`}
                    >
                      <img src={preset.url} alt={preset.name} className="w-full h-full object-cover" />
                      {isSelected && (
                        <div className="absolute inset-0 bg-blue-600/40 flex items-center justify-center">
                          <Check className="w-6 h-6 text-white" />
                        </div>
                      )}
                      <span className="absolute bottom-0 inset-x-0 bg-stone-900/70 text-white text-[9px] truncate px-1 text-center">
                        {preset.name}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: 5-Second Video Profile */}
          {activeTab === 'VIDEO' && (
            <div className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-indigo-50 border border-indigo-200 flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                <div className="text-xs text-indigo-950">
                  <strong className="block font-bold mb-0.5">Profil Vidéo Dynamique (5 secondes max)</strong>
                  Votre vidéo tourne en boucle fluide sur votre profil et vos cartes de contact.
                </div>
              </div>

              <input
                ref={videoInputRef}
                type="file"
                accept="video/*"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleVideoUpload(e.target.files[0]);
                  }
                }}
              />

              <div
                onClick={() => videoInputRef.current?.click()}
                className="border-2 border-dashed border-indigo-300 hover:border-indigo-500 rounded-3xl p-6 text-center cursor-pointer transition bg-indigo-50/30 hover:bg-indigo-50/70 flex flex-col items-center justify-center gap-2"
              >
                <div className="w-12 h-12 rounded-2xl bg-indigo-100 text-indigo-600 flex items-center justify-center">
                  <Video className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs sm:text-sm font-bold text-stone-800">
                    Importer une vidéo de 5 secondes
                  </p>
                  <p className="text-[11px] text-stone-500 mt-0.5">
                    Formats acceptés : MP4, WEBM (Max 100 Mo)
                  </p>
                </div>
              </div>

              {/* Exemples de vidéos de profil */}
              <div className="space-y-2 pt-2">
                <span className="text-xs font-bold text-stone-700 block">Ou choisir un modèle de test :</span>
                <div className="grid grid-cols-2 gap-2">
                  {PRESET_PROFILE_VIDEOS.map((vid) => (
                    <button
                      key={vid.id}
                      type="button"
                      onClick={() => {
                        setSelectedVideoUrl(vid.url);
                        setIsVideoAvatarActive(true);
                      }}
                      className="p-2.5 rounded-2xl bg-stone-100 hover:bg-stone-200 border border-stone-200 flex items-center gap-2.5 text-left transition cursor-pointer"
                    >
                      <div className="w-8 h-8 rounded-xl bg-slate-900 text-white flex items-center justify-center shrink-0">
                        <Play className="w-4 h-4 ml-0.5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-bold text-stone-800 truncate">{vid.name}</p>
                        <span className="text-[10px] text-stone-500">{vid.duration}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 border-t border-stone-200 bg-stone-50 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-stone-600 hover:bg-stone-200 text-xs font-semibold transition cursor-pointer"
          >
            Annuler
          </button>

          <button
            type="button"
            disabled={isProcessing}
            onClick={handleSave}
            className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-xs sm:text-sm shadow-md transition flex items-center gap-1.5 cursor-pointer"
          >
            <Check className="w-4 h-4" />
            <span>Enregistrer le profil</span>
          </button>
        </div>
      </div>
    </div>
  );
};
