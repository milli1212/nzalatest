/**
 * NzalaFamilly - Section des Paramètres de Confidentialité (NZALA PRIVACY SETTINGS)
 * Permet de définir les audiences pour les appels, messages, statut en ligne et publications
 */

import React from 'react';
import {
  Shield,
  Lock,
  Eye,
  Phone,
  MessageSquare,
  Sparkles,
  Users,
  CheckCircle,
  AtSign,
  Search,
  CheckSquare,
} from 'lucide-react';
import { UserPrivacySettings, PrivacyAudience } from '../../types/notifications';
import { SearchVisibilitySettings, DEFAULT_SEARCH_VISIBILITY_SETTINGS } from '../../types/search';

interface PrivacySettingsSectionProps {
  settings: UserPrivacySettings;
  onUpdateSettings: (newSettings: Partial<UserPrivacySettings>) => void;
}

export const PrivacySettingsSection: React.FC<PrivacySettingsSectionProps> = ({
  settings,
  onUpdateSettings,
}) => {
  const searchVis: SearchVisibilitySettings = settings.searchVisibility || DEFAULT_SEARCH_VISIBILITY_SETTINGS;

  const handleUpdateSearchVis = (updates: Partial<SearchVisibilitySettings>) => {
    onUpdateSettings({
      searchVisibility: {
        ...searchVis,
        ...updates,
      },
    });
  };

  const audienceOptions: { value: PrivacyAudience; label: string; description: string }[] = [
    {
      value: 'TOUS_AUTORISES',
      label: 'Tout membre autorisé',
      description: 'Membres vérifiés Nzala et des familles alliées',
    },
    {
      value: 'FAMILLE_SEULEMENT',
      label: 'Membres de ma famille uniquement',
      description: 'Uniquement les personnes de votre famille principale',
    },
    {
      value: 'FAMILLES_ALLIEES',
      label: 'Famille & Familles Alliées',
      description: 'Lignées directes et alliances reconnues',
    },
    {
      value: 'RELATIONS_AUTORISEES',
      label: 'Relations directes & Branche',
      description: 'Personnes partageant votre branche généalogique',
    },
    {
      value: 'PERSONNE',
      label: 'Personne (Privé strict)',
      description: 'Désactive cette interaction pour tous',
    },
  ];

  return (
    <div className="bg-white rounded-3xl border border-stone-200 p-6 sm:p-8 space-y-6 shadow-xs">
      {/* Header */}
      <div className="flex items-center gap-3 pb-4 border-b border-stone-200">
        <div className="p-2.5 rounded-2xl bg-amber-100 text-amber-900 border border-amber-200">
          <Shield className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-lg font-bold text-stone-900">Confidentialité &amp; Permissions Sociales</h3>
          <p className="text-xs text-stone-500">
            Contrôlez qui peut vous contacter, vous appeler ou consulter vos activités
          </p>
        </div>
      </div>

      {/* Toggles: Presence & Read receipts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <label className="p-4 rounded-2xl border border-stone-200 bg-stone-50/50 hover:bg-stone-50 transition cursor-pointer flex items-start justify-between gap-3">
          <div className="space-y-1">
            <div className="text-xs font-bold text-stone-900 flex items-center gap-1.5">
              <Eye className="w-4 h-4 text-emerald-600" />
              <span>Afficher mon statut en ligne</span>
            </div>
            <p className="text-[11px] text-stone-500 leading-relaxed">
              Permet aux membres autorisés de voir quand vous êtes connecté
            </p>
          </div>
          <input
            type="checkbox"
            checked={settings.showOnlineStatus}
            onChange={(e) => onUpdateSettings({ showOnlineStatus: e.target.checked })}
            className="w-4 h-4 text-amber-600 rounded cursor-pointer accent-amber-600 mt-1"
          />
        </label>

        <label className="p-4 rounded-2xl border border-stone-200 bg-stone-50/50 hover:bg-stone-50 transition cursor-pointer flex items-start justify-between gap-3">
          <div className="space-y-1">
            <div className="text-xs font-bold text-stone-900 flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-blue-600" />
              <span>Accusés de lecture (Vu)</span>
            </div>
            <p className="text-[11px] text-stone-500 leading-relaxed">
              Indique lorsque vous avez lu les messages privés
            </p>
          </div>
          <input
            type="checkbox"
            checked={settings.showReadReceipts}
            onChange={(e) => onUpdateSettings({ showReadReceipts: e.target.checked })}
            className="w-4 h-4 text-amber-600 rounded cursor-pointer accent-amber-600 mt-1"
          />
        </label>
      </div>

      {/* Section Visibilité dans la Recherche Globale */}
      <div className="p-5 rounded-2xl border border-blue-200 bg-blue-50/40 space-y-4">
        <div className="flex items-start justify-between gap-3 pb-3 border-b border-blue-200/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-blue-100 text-blue-700">
              <Search className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                Visibilité dans la Recherche Globale &amp; Découverte
              </h4>
              <p className="text-[11px] text-slate-500">
                Déterminez si et comment votre profil apparaît lors des recherches de membres
              </p>
            </div>
          </div>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={searchVis.showInSearch}
              onChange={(e) => handleUpdateSearchVis({ showInSearch: e.target.checked })}
              className="w-4 h-4 text-blue-600 rounded cursor-pointer accent-blue-600"
            />
            <span className="text-xs font-bold text-slate-800">Actif</span>
          </label>
        </div>

        {searchVis.showInSearch && (
          <div className="space-y-2.5 pt-1">
            <p className="text-[11px] font-bold text-slate-700 uppercase tracking-wide">
              Attributs visibles dans les résultats de recherche :
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
              {[
                { key: 'showNameInSearch', label: 'Nom et prénom' },
                { key: 'showPhotoInSearch', label: 'Photo de profil' },
                { key: 'showFamilyInSearch', label: 'Nom de la famille' },
                { key: 'showBranchInSearch', label: 'Branche généalogique' },
                { key: 'showGenerationInSearch', label: 'Niveau de génération' },
                { key: 'showBioInSearch', label: 'Biographie & Titre' },
                { key: 'showBirthdayInSearch', label: 'Date d’anniversaire' },
                { key: 'showLocationInSearch', label: 'Localisation géographique' },
                { key: 'showContactInSearch', label: 'Coordonnées de contact' },
              ].map((item) => (
                <label
                  key={item.key}
                  className="flex items-center gap-2 p-2 rounded-xl bg-white border border-slate-200/80 text-xs font-medium text-slate-800 hover:bg-slate-50 transition cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={(searchVis as any)[item.key]}
                    onChange={(e) => handleUpdateSearchVis({ [item.key]: e.target.checked })}
                    className="w-3.5 h-3.5 text-blue-600 rounded cursor-pointer accent-blue-600"
                  />
                  <span>{item.label}</span>
                </label>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Selectors */}
      <div className="space-y-5 pt-2">
        {/* 1. Who can call me */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-stone-900 flex items-center gap-2">
            <Phone className="w-4 h-4 text-emerald-600" />
            <span>Qui peut m'appeler en Audio / Vidéo ?</span>
          </label>
          <select
            id="privacy-select-calls"
            value={settings.whoCanCallMe}
            onChange={(e) => onUpdateSettings({ whoCanCallMe: e.target.value as PrivacyAudience })}
            className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 text-xs font-medium text-stone-800 bg-stone-50 hover:bg-white focus:bg-white focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition"
          >
            {audienceOptions.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label} — {opt.description}
              </option>
            ))}
          </select>
        </div>

        {/* 2. Who can message me */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-stone-900 flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-blue-600" />
            <span>Qui peut m'envoyer un message privé direct ?</span>
          </label>
          <select
            id="privacy-select-messages"
            value={settings.whoCanMessageMe}
            onChange={(e) => onUpdateSettings({ whoCanMessageMe: e.target.value as PrivacyAudience })}
            className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 text-xs font-medium text-stone-800 bg-stone-50 hover:bg-white focus:bg-white focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition"
          >
            {audienceOptions.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label} — {opt.description}
              </option>
            ))}
          </select>
        </div>

        {/* 3. Who can see online status */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-stone-900 flex items-center gap-2">
            <Eye className="w-4 h-4 text-amber-600" />
            <span>Qui peut voir mon statut de présence ?</span>
          </label>
          <select
            id="privacy-select-status"
            value={settings.whoCanSeeOnlineStatus}
            onChange={(e) =>
              onUpdateSettings({ whoCanSeeOnlineStatus: e.target.value as PrivacyAudience })
            }
            className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 text-xs font-medium text-stone-800 bg-stone-50 hover:bg-white focus:bg-white focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition"
          >
            {audienceOptions.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label} — {opt.description}
              </option>
            ))}
          </select>
        </div>

        {/* 4. Who can see stories */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-stone-900 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-rose-600" />
            <span>Qui peut voir mes stories familiales ?</span>
          </label>
          <select
            id="privacy-select-stories"
            value={settings.whoCanSeeStories}
            onChange={(e) => onUpdateSettings({ whoCanSeeStories: e.target.value as PrivacyAudience })}
            className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 text-xs font-medium text-stone-800 bg-stone-50 hover:bg-white focus:bg-white focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition"
          >
            {audienceOptions.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label} — {opt.description}
              </option>
            ))}
          </select>
        </div>

        {/* 5. Who can mention me */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-stone-900 flex items-center gap-2">
            <AtSign className="w-4 h-4 text-purple-600" />
            <span>Qui peut me mentionner (@nom) ?</span>
          </label>
          <select
            id="privacy-select-mentions"
            value={settings.whoCanMentionMe}
            onChange={(e) => onUpdateSettings({ whoCanMentionMe: e.target.value as PrivacyAudience })}
            className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 text-xs font-medium text-stone-800 bg-stone-50 hover:bg-white focus:bg-white focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition"
          >
            {audienceOptions.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label} — {opt.description}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
};
