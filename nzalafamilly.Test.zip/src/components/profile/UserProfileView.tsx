import React, { useState, useMemo } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { RoleBadge, AffiliationStatusBadge, AccountStatusBadge } from '../common/Badges';
import { checkPasswordStrength } from '../../services/authService';
import {
  User,
  Mail,
  Phone,
  ShieldCheck,
  Lock,
  KeyRound,
  History,
  Building2,
  Crown,
  Edit3,
  Check,
  AlertTriangle,
  FileCheck2,
  Smartphone,
  Calendar,
  Sparkles,
  ExternalLink,
  MessageSquare,
  Image as ImageIcon,
  Video,
  HeartHandshake,
  Grid,
  Camera,
  Layers,
  Clock,
  Info,
  Users,
  Eye,
  Send,
  Plus,
  ArrowLeft,
  Share2,
  Trash2,
  Radio,
} from 'lucide-react';
import { PostCard } from '../feed/PostCard';
import { LightboxModal } from '../social/LightboxModal';
import { PrivacySettingsSection } from './PrivacySettingsSection';
import { AvatarEditorModal } from './AvatarEditorModal';
import { VerifiedBadge } from '../common/VerifiedBadge';
import { MediaItem, Member } from '../../types';
import { getStoryHoursRemaining } from '../../services/socialService';

type ProfileTab = 'POSTS' | 'PHOTOS' | 'VIDEOS' | 'STORIES' | 'INFOS' | 'RELATIONS';

interface DisplayProfileUser {
  id: string;
  name: string;
  firstName?: string;
  lastName?: string;
  email: string;
  phone?: string;
  role: any;
  accountStatus?: any;
  avatarUrl?: string;
  avatarVideoUrl?: string;
  coverPhotoUrl?: string;
  bio?: string;
  memberId?: string;
  familyName?: string;
  branchName?: string;
  isVerified?: boolean;
  isPrivateProfile?: boolean;
  verifiedBadge?: string;
}

export const UserProfileView: React.FC = () => {
  const {
    currentUser,
    userAccounts,
    members,
    families,
    posts,
    stories,
    verificationRequests,
    updateUserProfile,
    changePassword,
    toggleTwoFactor,
    setActiveTab,
    setSelectedMember,
    auditLogs,
    showToast,
    userPrivacySettings,
    updatePrivacySettings,
    viewingUserId,
    setViewingUserId,
    startCall,
    createDirectConversation,
    openUserProfile,
  } = useFamily();

  // Active Social Profile Tab (6 Instagram-inspired tabs)
  const [activeProfileTab, setActiveProfileTab] = useState<ProfileTab>('POSTS');

  // Modals
  const [showAvatarModal, setShowAvatarModal] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);

  // Profile Edit State
  const [isEditing, setIsEditing] = useState(false);
  const [phone, setPhone] = useState(currentUser.phone || '');
  const [bio, setBio] = useState(currentUser.bio || '');

  // Password Change State
  const [showPasswordChange, setShowPasswordChange] = useState(false);
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState<string | null>(null);

  // Lightbox state for Photos / Videos
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxMedia, setLightboxMedia] = useState<MediaItem[]>([]);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  // Access request state when visiting private profile
  const [accessRequested, setAccessRequested] = useState(false);

  // Determine user to display: currentUser or viewingUserId
  const isSelf = !viewingUserId || viewingUserId === currentUser.id;

  const targetUser: DisplayProfileUser = useMemo(() => {
    if (isSelf) {
      return {
        id: currentUser.id,
        name: currentUser.name || `${currentUser.firstName || ''} ${currentUser.lastName || ''}`.trim() || 'Membre Nzala',
        firstName: currentUser.firstName,
        lastName: currentUser.lastName,
        email: currentUser.email || '',
        phone: currentUser.phone,
        role: currentUser.role,
        accountStatus: currentUser.accountStatus || 'ACTIF',
        avatarUrl: currentUser.avatarUrl,
        avatarVideoUrl: currentUser.avatarVideoUrl,
        coverPhotoUrl: (currentUser as any).coverPhotoUrl,
        bio: currentUser.bio,
        memberId: currentUser.memberId,
        familyName: currentUser.familyName,
        branchName: currentUser.branchName,
        isVerified: true,
        verifiedBadge: currentUser.verifiedBadge,
        isPrivateProfile: false,
      };
    }

    const account = userAccounts.find((u) => u.id === viewingUserId);
    if (account) {
      return {
        id: account.id,
        name: `${account.firstName} ${account.lastName}`.trim() || account.email.split('@')[0],
        firstName: account.firstName,
        lastName: account.lastName,
        email: account.email,
        phone: account.phone,
        role: account.role,
        accountStatus: account.accountStatus || 'ACTIF',
        avatarUrl: account.avatarUrl,
        avatarVideoUrl: account.avatarVideoUrl,
        bio: account.bio,
        memberId: account.memberId,
        familyName: account.primaryFamilyName || 'Famille Nzala',
        branchName: account.branchName,
        isVerified: account.isVerified ?? true,
        isPrivateProfile: (account as any).isPrivateProfile || false,
      };
    }

    const member = members.find((m) => m.id === viewingUserId || m.userId === viewingUserId);
    if (member) {
      return {
        id: member.userId || member.id,
        name: `${member.firstName} ${member.lastName}`,
        firstName: member.firstName,
        lastName: member.lastName,
        email: member.email || '',
        phone: member.phone,
        role: (member.userId ? 'MEMBRE_NZALA' : 'VISITEUR') as any,
        accountStatus: 'ACTIF' as any,
        avatarUrl: member.avatarUrl,
        bio: member.bio,
        memberId: member.id,
        familyName: member.primaryFamilyName,
        branchName: member.branchName,
        isVerified: true,
      };
    }

    return {
      id: currentUser.id,
      name: currentUser.name,
      email: currentUser.email || '',
      role: currentUser.role,
      avatarUrl: currentUser.avatarUrl,
    };
  }, [isSelf, viewingUserId, currentUser, userAccounts, members]);

  // Find linked member record
  const targetMember: Member | undefined = useMemo(() => {
    if (targetUser.memberId) {
      return members.find((m) => m.id === targetUser.memberId);
    }
    return members.find(
      (m) =>
        (targetUser.email && m.email && m.email.toLowerCase() === targetUser.email.toLowerCase()) ||
        m.id === targetUser.id
    );
  }, [targetUser, members]);

  // Compute profile username handle (e.g. @jean_pierre_nzala)
  const usernameHandle = useMemo(() => {
    const rawName = targetUser.name || `${targetUser.firstName || ''} ${targetUser.lastName || ''}`;
    return `@${rawName.trim().toLowerCase().replace(/\s+/g, '_')}`;
  }, [targetUser]);

  // Privacy determination
  const isTargetPrivate = !isSelf && targetUser.isPrivateProfile;

  // Filter posts created by target user
  const userPosts = useMemo(() => {
    return posts.filter(
      (p) =>
        p.authorId === targetUser.id ||
        (targetUser.memberId && p.relatedMemberId === targetUser.memberId) ||
        (targetMember && p.authorId === targetMember.id)
    );
  }, [posts, targetUser, targetMember]);

  // Filter active and archived stories for target user
  const userStories = useMemo(() => {
    return stories.filter(
      (s) => s.authorId === targetUser.id || (targetMember && s.memberId === targetMember.id)
    );
  }, [stories, targetUser, targetMember]);

  // Extract photos from user's posts
  const userPhotos = useMemo(() => {
    const items: MediaItem[] = [];
    userPosts.forEach((p) => {
      if (p.media && p.media.length > 0) {
        p.media.forEach((m) => {
          if (m.type === 'IMAGE') items.push(m);
        });
      } else if (p.imageUrl) {
        items.push({
          id: `img-${p.id}`,
          url: p.imageUrl,
          type: 'IMAGE',
          caption: p.mediaCaption || p.title,
        });
      }
    });
    return items;
  }, [userPosts]);

  // Extract videos from user's posts
  const userVideos = useMemo(() => {
    const items: MediaItem[] = [];
    userPosts.forEach((p) => {
      if (p.media && p.media.length > 0) {
        p.media.forEach((m) => {
          if (m.type === 'VIDEO') items.push(m);
        });
      }
    });
    return items;
  }, [userPosts]);

  // Relatives calculation
  const targetRelatives = useMemo(() => {
    if (!targetMember) return [];
    return members.filter(
      (m) =>
        m.id !== targetMember.id &&
        (m.primaryFamilyId === targetMember.primaryFamilyId ||
          m.branchId === targetMember.branchId ||
          m.originFamilyName === targetMember.primaryFamilyName)
    ).slice(0, 12);
  }, [targetMember, members]);

  const passwordStrength = checkPasswordStrength(newPassword);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile(currentUser.id, {
      phone,
      bio,
    });
    setIsEditing(false);
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError(null);

    if (!oldPassword || !newPassword) {
      setPasswordError('Veuillez remplir tous les champs.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setPasswordError('Les nouveaux mots de passe ne correspondent pas.');
      return;
    }

    if (passwordStrength.score < 2) {
      setPasswordError('Le nouveau mot de passe doit comporter au moins 8 caractères et plusieurs types de caractères.');
      return;
    }

    const res = changePassword(oldPassword, newPassword);
    if (!res.success) {
      setPasswordError(res.error || 'Erreur lors du changement de mot de passe.');
    } else {
      setShowPasswordChange(false);
      setOldPassword('');
      setNewPassword('');
      setConfirmPassword('');
      showToast('success', 'Mot de passe modifié avec succès.');
    }
  };

  const handleRequestAccess = () => {
    setAccessRequested(true);
    showToast('info', `Demande d'accès envoyée à ${targetUser.name}. Vous serez notifié dès acceptation.`);
  };

  const openMediaInLightbox = (mediaList: MediaItem[], index: number) => {
    setLightboxMedia(mediaList);
    setLightboxIndex(index);
    setLightboxOpen(true);
  };

  return (
    <div id="user-profile-view" className="space-y-6 pb-16 max-w-5xl mx-auto animate-fadeIn">
      {/* Return button if viewing someone else */}
      {!isSelf && (
        <button
          type="button"
          onClick={() => setViewingUserId(null)}
          className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 text-xs font-bold transition cursor-pointer shadow-xs"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Retour à mon profil</span>
        </button>
      )}

      {/* Main Profile Header Card (Instagram / Modern Social Inspired) */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        {/* Cover Banner */}
        <div className="relative h-44 sm:h-56 bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-950 overflow-hidden">
          {targetUser.coverPhotoUrl ? (
            <img
              src={targetUser.coverPhotoUrl}
              alt=""
              className="w-full h-full object-cover opacity-85"
            />
          ) : (
            <div className="w-full h-full bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-blue-900/60 via-slate-900 to-slate-950 flex items-center justify-center">
              <div className="text-center opacity-40">
                <span className="font-serif font-black text-6xl text-white tracking-widest">NZALA</span>
              </div>
            </div>
          )}

          {/* Cover Action Button (For Self) */}
          {isSelf && (
            <div className="absolute top-4 right-4 flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowAvatarModal(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-black/40 hover:bg-black/60 text-white backdrop-blur-md text-xs font-semibold border border-white/20 transition cursor-pointer shadow-md"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>Modifier la couverture</span>
              </button>
            </div>
          )}
        </div>

        {/* Profile Info Header Content */}
        <div className="px-5 sm:px-8 pb-6 pt-0 relative">
          {/* Avatar and Action Controls Row */}
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 -mt-16 sm:-mt-20 mb-5">
            {/* Circular Avatar / 5s Video with Ring */}
            <div className="relative shrink-0">
              <div
                onClick={() => isSelf && setShowAvatarModal(true)}
                className={`relative group ${isSelf ? 'cursor-pointer' : ''}`}
                title={isSelf ? 'Modifier photo ou vidéo de profil' : ''}
              >
                <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-full p-1 bg-gradient-to-tr from-blue-600 via-indigo-600 to-amber-500 shadow-xl">
                  <div className="w-full h-full rounded-full overflow-hidden bg-slate-900 border-4 border-white flex items-center justify-center text-white font-serif font-bold text-3xl sm:text-4xl">
                    {targetUser.avatarVideoUrl ? (
                      <video
                        src={targetUser.avatarVideoUrl}
                        autoPlay
                        loop
                        muted
                        playsInline
                        className="w-full h-full object-cover"
                      />
                    ) : targetUser.avatarUrl ? (
                      <img
                        src={targetUser.avatarUrl}
                        alt={targetUser.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <span>
                        {targetUser.firstName ? targetUser.firstName.charAt(0) : targetUser.name.charAt(0)}
                      </span>
                    )}
                  </div>
                </div>

                {/* Badge Indicator for Video Profile */}
                {targetUser.avatarVideoUrl && (
                  <div className="absolute top-1 right-1 p-1.5 rounded-full bg-rose-600 text-white shadow-md border-2 border-white" title="Profil vidéo 5s actif">
                    <Video className="w-3 h-3" />
                  </div>
                )}

                {/* Camera Icon Overlay (For Self) */}
                {isSelf && (
                  <div className="absolute bottom-1 right-1 p-2 rounded-full bg-blue-600 text-white shadow-lg border-2 border-white group-hover:scale-110 transition">
                    <Camera className="w-3.5 h-3.5" />
                  </div>
                )}
              </div>
            </div>

            {/* Action Buttons Row */}
            <div className="flex flex-wrap items-center gap-2">
              {isSelf ? (
                <>
                  <button
                    type="button"
                    onClick={() => setIsEditing(!isEditing)}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs sm:text-sm font-bold border border-slate-200 transition cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>{isEditing ? 'Annuler' : 'Modifier le profil'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowPrivacyModal(true)}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs sm:text-sm font-bold border border-blue-200 transition cursor-pointer"
                  >
                    <Lock className="w-3.5 h-3.5 text-blue-600" />
                    <span>Confidentialité</span>
                  </button>
                </>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      createDirectConversation(targetUser.id);
                      setActiveTab('messages');
                    }}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-bold shadow-md transition cursor-pointer"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Message</span>
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      startCall({
                        id: targetUser.id,
                        name: targetUser.name,
                        avatarUrl: targetUser.avatarUrl,
                        role: targetUser.role,
                        familyName: targetUser.familyName,
                      }, 'AUDIO')
                    }
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs sm:text-sm font-bold border border-slate-200 transition cursor-pointer"
                    title="Appel Audio"
                  >
                    <Phone className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Appel</span>
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      startCall({
                        id: targetUser.id,
                        name: targetUser.name,
                        avatarUrl: targetUser.avatarUrl,
                        role: targetUser.role,
                        familyName: targetUser.familyName,
                      }, 'VIDEO')
                    }
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs sm:text-sm font-bold border border-slate-200 transition cursor-pointer"
                    title="Appel Vidéo HD"
                  >
                    <Video className="w-3.5 h-3.5 text-blue-600" />
                    <span>Vidéo HD</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {/* User Details & Identity */}
          <div className="space-y-3">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-2xl sm:text-3xl font-serif font-black text-slate-900 tracking-tight">
                  {targetUser.name}
                </h1>
                <VerifiedBadge
                  role={targetUser.role}
                  isVerified={targetUser.isVerified ?? true}
                  badgeLabel={targetUser.verifiedBadge}
                  size="md"
                />
                <RoleBadge role={targetUser.role} />
              </div>
              <p className="text-xs sm:text-sm font-semibold text-blue-600 mt-0.5">
                {usernameHandle}
              </p>
            </div>

            {/* Family affiliation & Branch tags */}
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="px-2.5 py-1 rounded-full bg-blue-50 text-blue-800 font-bold border border-blue-200">
                {targetUser.familyName || 'Famille Nzala'}
              </span>
              {targetUser.branchName && (
                <span className="px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-800 font-semibold border border-indigo-200">
                  {targetUser.branchName}
                </span>
              )}
              {targetMember?.generationLevel && (
                <span className="px-2.5 py-1 rounded-full bg-amber-50 text-amber-900 font-semibold border border-amber-200">
                  Génération {targetMember.generationLevel}
                </span>
              )}
            </div>

            {/* Bio */}
            {targetUser.bio && (
              <p className="text-xs sm:text-sm text-slate-700 max-w-2xl leading-relaxed whitespace-pre-line pt-1">
                {targetUser.bio}
              </p>
            )}

            {/* Statistics Bar (Instagram Style) */}
            <div className="flex items-center gap-6 sm:gap-10 pt-4 border-t border-slate-100">
              <div className="text-left">
                <span className="block text-base sm:text-lg font-black text-slate-900">
                  {userPosts.length}
                </span>
                <span className="text-[11px] sm:text-xs text-slate-500 font-medium">Publications</span>
              </div>
              <div className="text-left">
                <span className="block text-base sm:text-lg font-black text-slate-900">
                  {userPhotos.length}
                </span>
                <span className="text-[11px] sm:text-xs text-slate-500 font-medium">Photos</span>
              </div>
              <div className="text-left">
                <span className="block text-base sm:text-lg font-black text-slate-900">
                  {userVideos.length}
                </span>
                <span className="text-[11px] sm:text-xs text-slate-500 font-medium">Vidéos</span>
              </div>
              <div className="text-left">
                <span className="block text-base sm:text-lg font-black text-slate-900">
                  {targetRelatives.length}
                </span>
                <span className="text-[11px] sm:text-xs text-slate-500 font-medium">Relations</span>
              </div>
            </div>
          </div>

          {/* Quick Edit Form for Self */}
          {isEditing && (
            <form onSubmit={handleSaveProfile} className="mt-5 p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Modifier mes informations
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Téléphone</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+243 ..."
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Biographie</label>
                  <input
                    type="text"
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    placeholder="Quelques mots sur vous..."
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-3 py-1.5 rounded-xl border border-slate-300 text-slate-600 text-xs cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-blue-600 text-white font-bold text-xs cursor-pointer shadow-xs"
                >
                  Enregistrer
                </button>
              </div>
            </form>
          )}
        </div>
      </div>

      {/* Private Profile Notice (If visiting private profile without access) */}
      {isTargetPrivate && !accessRequested ? (
        <div className="p-8 bg-white rounded-3xl border border-slate-200 text-center space-y-4 shadow-sm">
          <div className="w-14 h-14 rounded-2xl bg-slate-100 text-slate-600 mx-auto flex items-center justify-center">
            <Lock className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900">Ce profil est privé</h3>
            <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto mt-1">
              {targetUser.name} a limité la visibilité de ses publications, photos et relations familiales.
            </p>
          </div>
          <button
            type="button"
            onClick={handleRequestAccess}
            className="px-5 py-2.5 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-bold shadow-md transition cursor-pointer"
          >
            Demander l’accès
          </button>
        </div>
      ) : isTargetPrivate && accessRequested ? (
        <div className="p-8 bg-blue-50 rounded-3xl border border-blue-200 text-center space-y-3 shadow-xs">
          <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white mx-auto flex items-center justify-center">
            <Check className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-blue-950">Demande d’accès transmise</h3>
          <p className="text-xs text-blue-800 max-w-sm mx-auto">
            Une notification sécurisée a été envoyée au titulaire du compte. Vous aurez accès dès validation.
          </p>
        </div>
      ) : (
        /* 6 Tabbed Navigation System */
        <div className="space-y-4">
          {/* Tabs Bar */}
          <div className="flex items-center gap-1 sm:gap-2 border-b border-slate-200 bg-white p-1.5 rounded-2xl shadow-xs overflow-x-auto">
            {[
              { id: 'POSTS', label: 'Publications', icon: Grid, count: userPosts.length },
              { id: 'PHOTOS', label: 'Photos', icon: ImageIcon, count: userPhotos.length },
              { id: 'VIDEOS', label: 'Vidéos', icon: Video, count: userVideos.length },
              { id: 'STORIES', label: 'Stories / Archives', icon: Clock, count: userStories.length },
              { id: 'INFOS', label: 'Informations', icon: Info },
              { id: 'RELATIONS', label: 'Relations', icon: Users, count: targetRelatives.length },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveProfileTab(tab.id as any)}
                  className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                    activeProfileTab === tab.id
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                  {tab.count !== undefined && (
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                        activeProfileTab === tab.id
                          ? 'bg-white/20 text-white'
                          : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      {tab.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* TAB 1: Publications */}
          {activeProfileTab === 'POSTS' && (
            <div className="space-y-4">
              {userPosts.length > 0 ? (
                userPosts.map((post) => (
                  <PostCard key={post.id} post={post} />
                ))
              ) : (
                <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 space-y-2">
                  <Grid className="w-10 h-10 text-slate-300 mx-auto" />
                  <p className="text-sm font-bold text-slate-700">Aucune publication pour le moment</p>
                  <p className="text-xs text-slate-400">
                    {isSelf ? 'Partagez une nouvelle, un souvenir ou une photo sur le fil familial.' : 'Ce membre n’a pas encore publié de message.'}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: Photos (Instagram Grid 3x3) */}
          {activeProfileTab === 'PHOTOS' && (
            <div>
              {userPhotos.length > 0 ? (
                <div className="grid grid-cols-3 gap-1.5 sm:gap-2.5">
                  {userPhotos.map((photo, idx) => (
                    <div
                      key={photo.id || idx}
                      onClick={() => openMediaInLightbox(userPhotos, idx)}
                      className="group relative aspect-square bg-slate-100 rounded-2xl overflow-hidden cursor-pointer shadow-xs border border-slate-200/60"
                    >
                      <img
                        src={photo.url}
                        alt=""
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition flex items-center justify-center opacity-0 group-hover:opacity-100 text-white">
                        <Eye className="w-6 h-6 drop-shadow-md" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 space-y-2">
                  <ImageIcon className="w-10 h-10 text-slate-300 mx-auto" />
                  <p className="text-sm font-bold text-slate-700">Aucune photo dans la galerie</p>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: Vidéos (Reels Grid) */}
          {activeProfileTab === 'VIDEOS' && (
            <div>
              {userVideos.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {userVideos.map((video, idx) => (
                    <div
                      key={video.id || idx}
                      onClick={() => openMediaInLightbox(userVideos, idx)}
                      className="group relative aspect-[9/14] bg-slate-900 rounded-2xl overflow-hidden cursor-pointer shadow-md border border-slate-800"
                    >
                      <video
                        src={video.url}
                        className="w-full h-full object-cover opacity-85 group-hover:opacity-100 transition"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-11 h-11 rounded-full bg-blue-600/90 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition">
                          <Video className="w-5 h-5" />
                        </div>
                      </div>
                      {video.caption && (
                        <p className="absolute bottom-2 left-2 right-2 text-white text-xs font-semibold truncate drop-shadow">
                          {video.caption}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 space-y-2">
                  <Video className="w-10 h-10 text-slate-300 mx-auto" />
                  <p className="text-sm font-bold text-slate-700">Aucune vidéo enregistrée</p>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: Stories & Archives */}
          {activeProfileTab === 'STORIES' && (
            <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm sm:text-base font-bold text-slate-900 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-blue-600" />
                  <span>Stories & Archives Familiales</span>
                </h3>
                <span className="text-xs text-slate-400 font-medium">Conservation sécurisée</span>
              </div>

              {userStories.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {userStories.map((story) => {
                    const firstSlide = story.slides[0];
                    const hoursLeft = getStoryHoursRemaining(story);
                    const isExpired = hoursLeft <= 0;

                    return (
                      <div
                        key={story.id}
                        className="relative aspect-[9/14] bg-slate-900 rounded-2xl overflow-hidden p-3 flex flex-col justify-between border border-slate-200 shadow-xs"
                      >
                        {firstSlide?.contentUrl && (
                          <img
                            src={firstSlide.contentUrl}
                            alt=""
                            className="absolute inset-0 w-full h-full object-cover opacity-75"
                          />
                        )}
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-slate-950/40" />

                        <div className="relative z-10">
                          <span
                            className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                              isExpired ? 'bg-slate-700 text-slate-200' : 'bg-blue-600 text-white'
                            }`}
                          >
                            {isExpired ? 'Archivée' : `${hoursLeft}h restantes`}
                          </span>
                        </div>

                        <div className="relative z-10 text-white">
                          <p className="text-xs font-bold truncate">{firstSlide?.caption || 'Story'}</p>
                          <p className="text-[10px] text-slate-300">
                            {new Date(story.createdAt).toLocaleDateString('fr-FR')}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-500">
                  Aucune story active ou archivée.
                </div>
              )}
            </div>
          )}

          {/* TAB 5: Informations */}
          {activeProfileTab === 'INFOS' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Coordonnées */}
              <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-2.5">
                  <Mail className="w-4 h-4 text-blue-600" /> Coordonnées & Contact
                </h3>
                <div className="space-y-3 text-xs sm:text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Email :</span>
                    <span className="font-semibold text-slate-900">{targetUser.email}</span>
                  </div>
                  {targetUser.phone && (
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Téléphone :</span>
                      <span className="font-semibold text-slate-900">{targetUser.phone}</span>
                    </div>
                  )}
                  {targetMember?.location && (
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Localisation :</span>
                      <span className="font-semibold text-slate-900">{targetMember.location}</span>
                    </div>
                  )}
                  {targetMember?.profession && (
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Profession :</span>
                      <span className="font-semibold text-slate-900">{targetMember.profession}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Généalogie & Rôle */}
              <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-2.5">
                  <Building2 className="w-4 h-4 text-indigo-600" /> Appartenance & Rôle Familial
                </h3>
                <div className="space-y-3 text-xs sm:text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Famille principale :</span>
                    <span className="font-bold text-blue-700">{targetUser.familyName || 'Famille Nzala'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Branche :</span>
                    <span className="font-semibold text-slate-900">{targetUser.branchName || 'Kinshasa (Aînée)'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Génération :</span>
                    <span className="font-bold text-amber-700">Niveau {targetMember?.generationLevel || 3}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Statut de compte :</span>
                    <AccountStatusBadge status={targetUser.accountStatus || 'ACTIF'} />
                  </div>
                </div>
              </div>

              {/* Security card (for Self) */}
              {isSelf && (
                <div className="md:col-span-2 bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" /> Sécurité & Mot de Passe
                    </h3>
                    <button
                      type="button"
                      onClick={() => setShowPasswordChange(!showPasswordChange)}
                      className="text-xs font-bold text-blue-600 hover:text-blue-700 cursor-pointer"
                    >
                      {showPasswordChange ? 'Fermer' : 'Changer mon mot de passe'}
                    </button>
                  </div>

                  {showPasswordChange && (
                    <form onSubmit={handlePasswordSubmit} className="space-y-3 p-4 rounded-2xl bg-slate-50 border border-slate-200">
                      {passwordError && (
                        <p className="text-xs font-bold text-rose-600">{passwordError}</p>
                      )}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <input
                          type="password"
                          value={oldPassword}
                          onChange={(e) => setOldPassword(e.target.value)}
                          placeholder="Mot de passe actuel"
                          className="px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs outline-none focus:border-blue-500"
                        />
                        <input
                          type="password"
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          placeholder="Nouveau mot de passe"
                          className="px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs outline-none focus:border-blue-500"
                        />
                        <input
                          type="password"
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          placeholder="Confirmer mot de passe"
                          className="px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs outline-none focus:border-blue-500"
                        />
                      </div>
                      <div className="flex justify-end">
                        <button
                          type="submit"
                          className="px-4 py-2 rounded-xl bg-blue-600 text-white font-bold text-xs shadow-xs cursor-pointer"
                        >
                          Mettre à jour
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}
            </div>
          )}

          {/* TAB 6: Relations familiales */}
          {activeProfileTab === 'RELATIONS' && (
            <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm sm:text-base font-bold text-slate-900 flex items-center gap-2">
                  <Users className="w-4 h-4 text-blue-600" />
                  <span>Liens & Relations Familiales</span>
                </h3>
                <span className="text-xs text-slate-500 font-medium">
                  {targetRelatives.length} parents directs identifiés
                </span>
              </div>

              {targetRelatives.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {targetRelatives.map((rel) => (
                    <div
                      key={rel.id}
                      onClick={() => openUserProfile(rel.userId || rel.id)}
                      className="p-3 rounded-2xl border border-slate-200 bg-slate-50/70 hover:bg-white hover:border-blue-300 hover:shadow-md transition flex items-center justify-between gap-3 cursor-pointer group"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-10 h-10 rounded-full overflow-hidden bg-slate-200 border border-slate-200 shrink-0 flex items-center justify-center font-bold text-xs text-slate-700">
                          {rel.avatarUrl ? (
                            <img src={rel.avatarUrl} alt="" className="w-full h-full object-cover" />
                          ) : (
                            rel.firstName.charAt(0)
                          )}
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-slate-900 group-hover:text-blue-600 truncate">
                            {rel.firstName} {rel.lastName}
                          </p>
                          <p className="text-[10px] text-slate-500 truncate">
                            {rel.branchName || rel.primaryFamilyName}
                          </p>
                        </div>
                      </div>

                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">
                        Gén. {rel.generationLevel}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-500">
                  Aucune relation familiale directe renseignée.
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Modals */}
      <AvatarEditorModal
        isOpen={showAvatarModal}
        onClose={() => setShowAvatarModal(false)}
      />

      {showPrivacyModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
          <div className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-900">Paramètres de Confidentialité</h2>
              <button
                type="button"
                onClick={() => setShowPrivacyModal(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                ✕
              </button>
            </div>
            <div className="p-4 sm:p-6 overflow-y-auto flex-1">
              <PrivacySettingsSection
                settings={userPrivacySettings}
                onUpdateSettings={updatePrivacySettings}
              />
            </div>
          </div>
        </div>
      )}

      {/* Lightbox for Photos & Videos */}
      <LightboxModal
        isOpen={lightboxOpen}
        mediaList={lightboxMedia}
        initialIndex={lightboxIndex}
        onClose={() => setLightboxOpen(false)}
      />
    </div>
  );
};
