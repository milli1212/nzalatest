import React, { useState, useEffect } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { RelationshipType, Member } from '../../types';
import {
  validateRelationship,
  getRelationshipLabel,
  isSymmetricRelationship,
} from '../../services/relationshipEngine';
import {
  X,
  Link2,
  AlertTriangle,
  CheckCircle2,
  Info,
  Heart,
  Users,
  ShieldCheck,
  Calendar,
  Sparkles,
} from 'lucide-react';

interface AddRelationshipModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMemberAId?: string;
  initialMemberBId?: string;
  initialType?: RelationshipType;
}

export const AddRelationshipModal: React.FC<AddRelationshipModalProps> = ({
  isOpen,
  onClose,
  initialMemberAId,
  initialMemberBId,
  initialType = 'PARENT_ENFANT',
}) => {
  const { members, relationships, currentUser, addRelationship, showToast } = useFamily();

  const [memberAId, setMemberAId] = useState(initialMemberAId || '');
  const [memberBId, setMemberBId] = useState(initialMemberBId || '');
  const [relationshipType, setRelationshipType] = useState<RelationshipType>(initialType);
  const [startDate, setStartDate] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [warning, setWarning] = useState<string | null>(null);

  const isAdminOrValidator =
    currentUser.role === 'SUPER_ADMIN' ||
    currentUser.role === 'ADMIN_FAMILIAL' ||
    currentUser.role === 'VALIDATEUR';

  useEffect(() => {
    if (initialMemberAId) setMemberAId(initialMemberAId);
    if (initialMemberBId) setMemberBId(initialMemberBId);
  }, [initialMemberAId, initialMemberBId]);

  // Run live validation whenever inputs change
  useEffect(() => {
    if (memberAId && memberBId) {
      const result = validateRelationship(
        memberAId,
        memberBId,
        relationshipType,
        relationships,
        members
      );
      if (!result.isValid) {
        setError(result.error || null);
        setWarning(null);
      } else {
        setError(null);
        setWarning(result.warning || null);
      }
    } else {
      setError(null);
      setWarning(null);
    }
  }, [memberAId, memberBId, relationshipType, relationships, members]);

  if (!isOpen) return null;

  const memberA = members.find((m) => m.id === memberAId);
  const memberB = members.find((m) => m.id === memberBId);

  const previewLabels =
    memberA && memberB
      ? getRelationshipLabel(relationshipType, memberA, memberB)
      : null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!memberAId || !memberBId) {
      setError('Veuillez sélectionner les deux membres concernés.');
      return;
    }

    const res = addRelationship({
      memberAId,
      memberBId,
      relationshipType,
      startDate: startDate || undefined,
      notes: notes.trim() || undefined,
    });

    if (!res.success) {
      setError(res.error || 'Erreur lors de l\'enregistrement de la relation.');
    } else {
      onClose();
      setNotes('');
      setStartDate('');
    }
  };

  const relationshipOptions: { type: RelationshipType; label: string; desc: string }[] = [
    {
      type: 'PARENT_ENFANT',
      label: 'Parent ↔ Enfant (Filiation directe)',
      desc: 'Définit une filiation directe entre un parent (Membre A) et son enfant (Membre B).',
    },
    {
      type: 'CONJOINT',
      label: 'Conjoint(e) / Époux (Alliance matrimoniale)',
      desc: 'Lie deux personnes par le mariage civil ou coutumier.',
    },
    {
      type: 'FRERE_SOEUR',
      label: 'Frère ↔ Sœur (Fratrie germaine ou consanguine)',
      desc: 'Lie deux membres partageant les mêmes parents ou une même souche.',
    },
    {
      type: 'GRAND_PARENT_PETIT_ENFANT',
      label: 'Grand-parent ↔ Petit-enfant',
      desc: 'Relation directe intergénérationnelle sur deux niveaux.',
    },
    {
      type: 'ONCLE_TANTE_NEVEU_NIECE',
      label: 'Oncle / Tante ↔ Neveu / Nièce',
      desc: 'Relation collatérale entre un aîné et les enfants de sa fratrie.',
    },
    {
      type: 'COUSIN',
      label: 'Cousin(e) germain(e)',
      desc: 'Relation collatérale entre enfants de frères et sœurs.',
    },
    {
      type: 'BEAU_PARENT_BEAU_FILS_FILLE',
      label: 'Beau-parent ↔ Beau-fils / Belle-fille',
      desc: 'Relation acquise par alliance matrimoniale.',
    },
    {
      type: 'PARRAIN_MARRAINE',
      label: 'Parrain / Marraine ↔ Filleul(e)',
      desc: 'Parrainage coutumier, spirituel ou moral reconnu par la famille.',
    },
    {
      type: 'AUTRE',
      label: 'Autre lien familial',
      desc: 'Autre attache spécifique répertoriée par le Conseil.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl max-w-2xl w-full border border-stone-200 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-6 bg-stone-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <Link2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif font-bold text-lg text-amber-100">
                {isAdminOrValidator
                  ? 'Formaliser une relation familiale'
                  : 'Proposer un lien familial au Conseil'}
              </h2>
              <p className="text-xs text-stone-300">
                {isAdminOrValidator
                  ? 'Enregistrement direct dans le registre généalogique officiel.'
                  : 'Votre proposition sera examinée et validée par les administrateurs familiaux.'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-white hover:bg-stone-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5">
          {/* Member A & Member B Selection */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Member A */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-stone-800 flex items-center justify-between">
                <span>Membre A (Source / Référence)</span>
                {memberA && (
                  <span className="text-[10px] text-amber-700 font-mono">
                    G{memberA.generationLevel} • {memberA.primaryFamilyName}
                  </span>
                )}
              </label>
              <select
                value={memberAId}
                onChange={(e) => setMemberAId(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 text-stone-900 text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500 transition"
              >
                <option value="">-- Choisir la première personne --</option>
                {members.map((m) => (
                  <option key={`a-${m.id}`} value={m.id}>
                    {m.firstName} {m.lastName} {m.livingStatus === 'DECEDE' ? '(🕊️ Décédé)' : ''} — G{m.generationLevel} ({m.primaryFamilyName})
                  </option>
                ))}
              </select>
            </div>

            {/* Member B */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-stone-800 flex items-center justify-between">
                <span>Membre B (Personne liée)</span>
                {memberB && (
                  <span className="text-[10px] text-amber-700 font-mono">
                    G{memberB.generationLevel} • {memberB.primaryFamilyName}
                  </span>
                )}
              </label>
              <select
                value={memberBId}
                onChange={(e) => setMemberBId(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 text-stone-900 text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500 transition"
              >
                <option value="">-- Choisir la deuxième personne --</option>
                {members
                  .filter((m) => m.id !== memberAId)
                  .map((m) => (
                    <option key={`b-${m.id}`} value={m.id}>
                      {m.firstName} {m.lastName} {m.livingStatus === 'DECEDE' ? '(🕊️ Décédé)' : ''} — G{m.generationLevel} ({m.primaryFamilyName})
                    </option>
                  ))}
              </select>
            </div>
          </div>

          {/* Relationship Type Selection */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-stone-800">
              Type de relation généalogique ou coutumière
            </label>
            <select
              value={relationshipType}
              onChange={(e) => setRelationshipType(e.target.value as RelationshipType)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 text-stone-900 text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500 font-medium transition"
            >
              {relationshipOptions.map((opt) => (
                <option key={opt.type} value={opt.type}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>

          {/* Live Dynamic Preview Card */}
          {previewLabels && (
            <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200/80 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-950">
                <Sparkles className="w-4 h-4 text-amber-600" />
                <span>Interprétation sémantique de la relation :</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 rounded-xl bg-white border border-amber-200 text-stone-800">
                  <span className="text-[10px] uppercase font-bold text-stone-400 block">
                    Dans le sens A → B :
                  </span>
                  <span className="font-bold text-stone-900">{memberA?.firstName} {memberA?.lastName}</span> est le/la <span className="font-semibold text-amber-900">{previewLabels.labelAtoB}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-white border border-amber-200 text-stone-800">
                  <span className="text-[10px] uppercase font-bold text-stone-400 block">
                    Dans le sens B → A :
                  </span>
                  <span className="font-bold text-stone-900">{memberB?.firstName} {memberB?.lastName}</span> est le/la <span className="font-semibold text-amber-900">{previewLabels.labelBtoA}</span>
                </div>
              </div>
            </div>
          )}

          {/* Optional Details (Start date, notes) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-stone-800">
                Date de l'événement fondateur (optionnel)
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 text-stone-900 text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500 transition"
              />
              <span className="text-[10px] text-stone-400">
                Ex : date de mariage, union coutumière ou date d'adoption
              </span>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-stone-800">
                Notes &amp; Précisions pour le Conseil
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Ex: Célébré à Boma, attesté par les aînés..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50 text-stone-900 text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-500 transition"
              />
            </div>
          </div>

          {/* Error / Warning Feedbacks */}
          {error && (
            <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {warning && (
            <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-2.5">
              <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <span>{warning}</span>
            </div>
          )}

          {/* Action buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-stone-100">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold transition cursor-pointer"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={!!error || !memberAId || !memberBId}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-50 disabled:cursor-not-allowed text-stone-950 font-bold text-xs shadow-md shadow-amber-950/20 transition cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>
                {isAdminOrValidator
                  ? 'Enregistrer & Valider la relation'
                  : 'Soumettre la proposition'}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
