/**
 * NzalaFamilly - Modal de Recherche Avancée
 * Permet un filtrage multi-critères granulaire et sécurisé
 */

import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import {
  SearchCategory,
  SearchFilters,
  SearchResult,
} from '../../types/search';
import { executeGlobalSearch } from '../../services/search/searchEngine';
import { SearchResultItem } from './SearchResultItem';
import {
  SlidersHorizontal,
  X,
  Search,
  Users,
  Newspaper,
  Calendar,
  GitFork,
  RotateCcw,
  Sparkles,
  ChevronRight,
  Filter,
} from 'lucide-react';

interface AdvancedSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectResult: (result: SearchResult) => void;
  initialCategory?: SearchCategory;
}

export const AdvancedSearchModal: React.FC<AdvancedSearchModalProps> = ({
  isOpen,
  onClose,
  onSelectResult,
  initialCategory = 'ALL',
}) => {
  const {
    members,
    families,
    branches,
    posts,
    events,
    stories,
    liveStreams,
    memoryAlbums,
    historicalPublications,
    currentUser,
  } = useFamily();

  const [activeCategory, setActiveCategory] = useState<SearchCategory>(initialCategory);
  const [keyword, setKeyword] = useState('');

  // Filters state
  const [selectedFamilyId, setSelectedFamilyId] = useState<string>('ALL');
  const [selectedBranchId, setSelectedBranchId] = useState<string>('ALL');
  const [selectedGen, setSelectedGen] = useState<string>('ALL');
  const [selectedLivingStatus, setSelectedLivingStatus] = useState<string>('ALL');
  const [selectedBelonging, setSelectedBelonging] = useState<string>('ALL');

  const [selectedPostType, setSelectedPostType] = useState<string>('ALL');
  const [selectedPostPeriod, setSelectedPostPeriod] = useState<string>('ALL');

  const [selectedEventType, setSelectedEventType] = useState<string>('ALL');
  const [selectedEventPeriod, setSelectedEventPeriod] = useState<string>('ALL');

  if (!isOpen) return null;

  const currentFilters: SearchFilters = {
    category: activeCategory,
    familyId: selectedFamilyId,
    branchId: selectedBranchId,
    generationLevel: selectedGen === 'ALL' ? undefined : Number(selectedGen),
    livingStatus: selectedLivingStatus as any,
    belongingType: selectedBelonging,
    postType: selectedPostType,
    period: selectedPostPeriod as any,
    eventType: selectedEventType,
    eventPeriod: selectedEventPeriod as any,
  };

  const results = executeGlobalSearch(
    keyword,
    {
      members,
      families,
      branches,
      posts,
      events,
      stories,
      liveStreams,
      memoryAlbums,
      historicalPublications,
      currentUser,
    },
    activeCategory,
    currentFilters
  );

  const resetFilters = () => {
    setKeyword('');
    setSelectedFamilyId('ALL');
    setSelectedBranchId('ALL');
    setSelectedGen('ALL');
    setSelectedLivingStatus('ALL');
    setSelectedBelonging('ALL');
    setSelectedPostType('ALL');
    setSelectedPostPeriod('ALL');
    setSelectedEventType('ALL');
    setSelectedEventPeriod('ALL');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2.5 sm:p-4 animate-in fade-in duration-200">
      <div
        id="advanced-search-modal"
        className="bg-white rounded-3xl max-w-4xl w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Modal Header */}
        <div className="px-5 py-4 sm:px-6 sm:py-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-blue-100/80 text-blue-700 border border-blue-200/80">
              <SlidersHorizontal className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900">
                Recherche Avancée &amp; Filtres Précis
              </h2>
              <p className="text-xs text-slate-500">
                Recherchez précisément dans les membres, familles, filiations, publications et événements autorisés
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition cursor-pointer"
            aria-label="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Tabs */}
        <div className="px-5 sm:px-6 pt-3 pb-2 border-b border-slate-100 bg-white flex items-center gap-2 overflow-x-auto no-scrollbar">
          {[
            { id: 'ALL', label: 'Tous les domaines', icon: Sparkles },
            { id: 'MEMBERS', label: 'Membres', icon: Users },
            { id: 'POSTS', label: 'Publications', icon: Newspaper },
            { id: 'EVENTS', label: 'Événements', icon: Calendar },
            { id: 'GENEALOGY', label: 'Généalogie & Familles', icon: GitFork },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeCategory === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveCategory(tab.id as SearchCategory)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200/80'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Filters Body */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-5">
          {/* Keyword Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              placeholder="Mots-clés, nom, prénom, titre, ville, profession..."
              className="w-full pl-10 pr-4 py-2.5 rounded-2xl border border-slate-200 text-xs sm:text-sm bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
            />
          </div>

          {/* Conditional Filters depending on category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5 p-4 rounded-2xl bg-slate-50 border border-slate-200">
            {/* 1. Famille */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wide">
                Famille
              </label>
              <select
                value={selectedFamilyId}
                onChange={(e) => setSelectedFamilyId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 focus:ring-2 focus:ring-blue-500"
              >
                <option value="ALL">Toutes les familles</option>
                {families.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name} {f.type === 'PRINCIPALE' ? '(Souche)' : '(Alliée)'}
                  </option>
                ))}
              </select>
            </div>

            {/* 2. Branche */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wide">
                Branche
              </label>
              <select
                value={selectedBranchId}
                onChange={(e) => setSelectedBranchId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 focus:ring-2 focus:ring-blue-500"
              >
                <option value="ALL">Toutes les branches</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    Branche {b.name} ({b.familyName})
                  </option>
                ))}
              </select>
            </div>

            {/* 3. Génération (si Membres ou Généalogie) */}
            {(activeCategory === 'ALL' || activeCategory === 'MEMBERS' || activeCategory === 'GENEALOGY') && (
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wide">
                  Génération
                </label>
                <select
                  value={selectedGen}
                  onChange={(e) => setSelectedGen(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 focus:ring-2 focus:ring-blue-500"
                >
                  <option value="ALL">Toutes les générations</option>
                  <option value="1">Génération 1 — Patriarches Fondateurs</option>
                  <option value="2">Génération 2 — Aînés &amp; Pionniers</option>
                  <option value="3">Génération 3 — Descendance &amp; Alliances</option>
                  <option value="4">Génération 4 — Jeunesse</option>
                  <option value="5">Génération 5 — Nouvelle Génération</option>
                </select>
              </div>
            )}

            {/* 4. Statut Vital */}
            {(activeCategory === 'ALL' || activeCategory === 'MEMBERS' || activeCategory === 'GENEALOGY') && (
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wide">
                  Statut Vital
                </label>
                <select
                  value={selectedLivingStatus}
                  onChange={(e) => setSelectedLivingStatus(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 focus:ring-2 focus:ring-blue-500"
                >
                  <option value="ALL">Tous</option>
                  <option value="VIVANT">Membres Vivants</option>
                  <option value="DECEDE">🕊️ Hommages &amp; Ancêtres Décédés</option>
                </select>
              </div>
            )}

            {/* 5. Type d'appartenance */}
            {(activeCategory === 'ALL' || activeCategory === 'MEMBERS') && (
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wide">
                  Lien d'Appartenance
                </label>
                <select
                  value={selectedBelonging}
                  onChange={(e) => setSelectedBelonging(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 focus:ring-2 focus:ring-blue-500"
                >
                  <option value="ALL">Tous les types</option>
                  <option value="APPARTENANCE_DIRECTE">Lignée directe Nzala</option>
                  <option value="ALLIANCE_MARIAGE">Conjoint(e) par mariage</option>
                  <option value="ALLIANCE_DESCENDANCE">Descendance d'alliance</option>
                </select>
              </div>
            )}

            {/* 6. Filtres Publications */}
            {(activeCategory === 'ALL' || activeCategory === 'POSTS') && (
              <>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wide">
                    Type de Publication
                  </label>
                  <select
                    value={selectedPostType}
                    onChange={(e) => setSelectedPostType(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="ALL">Tous les types</option>
                    <option value="ANNONCE">Annonces</option>
                    <option value="COMMUNIQUE_OFFICIEL">Communiqués officiels</option>
                    <option value="ACTUALITE_FAMILIALE">Actualités familiales</option>
                    <option value="NAISSANCE">Naissances</option>
                    <option value="MARIAGE">Mariages</option>
                    <option value="ANNIVERSAIRE">Anniversaires</option>
                    <option value="MEMOIRE_FAMILIALE">Mémoire &amp; Récits</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wide">
                    Période de Publication
                  </label>
                  <select
                    value={selectedPostPeriod}
                    onChange={(e) => setSelectedPostPeriod(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="ALL">Toutes les dates</option>
                    <option value="TODAY">Aujourd'hui</option>
                    <option value="WEEK">7 derniers jours</option>
                    <option value="MONTH">Ce mois-ci</option>
                    <option value="YEAR">Cette année</option>
                  </select>
                </div>
              </>
            )}

            {/* 7. Filtres Événements */}
            {(activeCategory === 'ALL' || activeCategory === 'EVENTS') && (
              <>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wide">
                    Type d'Événement
                  </label>
                  <select
                    value={selectedEventType}
                    onChange={(e) => setSelectedEventType(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="ALL">Tous les événements</option>
                    <option value="ANNIVERSAIRE">Anniversaires</option>
                    <option value="REUNION_FAMILIALE">Réunions de famille</option>
                    <option value="CONSEIL_FAMILLE">Conseils de famille</option>
                    <option value="MARIAGE">Célébrations de mariage</option>
                    <option value="CEREMONIE">Cérémonies traditionnelles</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wide">
                    Période d'Événement
                  </label>
                  <select
                    value={selectedEventPeriod}
                    onChange={(e) => setSelectedEventPeriod(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs text-slate-800 focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="ALL">Tous</option>
                    <option value="UPCOMING">À venir</option>
                    <option value="THIS_WEEK">Cette semaine</option>
                    <option value="THIS_MONTH">Ce mois-ci</option>
                    <option value="PAST">Passés</option>
                  </select>
                </div>
              </>
            )}
          </div>

          {/* Results Header with Count & Reset */}
          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-900">
                Résultats correspondants :
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-xs font-black">
                {results.length}
              </span>
            </div>
            <button
              onClick={resetFilters}
              className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-900 transition cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Réinitialiser les filtres</span>
            </button>
          </div>

          {/* Results List */}
          <div className="space-y-2">
            {results.length > 0 ? (
              results.map((result) => (
                <SearchResultItem
                  key={result.id}
                  result={result}
                  onClick={(r) => {
                    onSelectResult(r);
                    onClose();
                  }}
                />
              ))
            ) : (
              <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-200 text-slate-500 space-y-2">
                <Search className="w-8 h-8 text-slate-400 mx-auto" />
                <p className="text-xs sm:text-sm font-semibold text-slate-700">
                  Aucun résultat accessible ne correspond à ces critères précis.
                </p>
                <p className="text-[11px] text-slate-400">
                  Essayez d'élargir vos filtres ou de modifier vos mots-clés.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3.5 sm:px-6 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2.5">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-bold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 transition cursor-pointer"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
