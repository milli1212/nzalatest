/**
 * NzalaFamilly - Barre de Recherche Globale (Desktop, Tablette & Mobile)
 */

import React, { useState, useEffect, useRef } from 'react';
import { useFamily } from '../../context/FamilyContext';
import {
  SearchResult,
  SearchCategory,
} from '../../types/search';
import {
  executeGlobalSearch,
  groupSearchResults,
  loadSearchHistory,
  saveSearchHistoryItem,
  deleteSearchHistoryItem,
  clearAllSearchHistory,
  getSmartSuggestions,
} from '../../services/search/searchEngine';
import { SearchDropdown } from './SearchDropdown';
import { SearchModalMobile } from './SearchModalMobile';
import { AdvancedSearchModal } from './AdvancedSearchModal';
import {
  Search,
  X,
  SlidersHorizontal,
  Command,
} from 'lucide-react';

interface GlobalSearchBarProps {
  className?: string;
}

export const GlobalSearchBar: React.FC<GlobalSearchBarProps> = ({ className = '' }) => {
  const {
    members,
    families,
    branches,
    posts,
    events,
    stories,
    liveStreams,
    memoryAlbums,
    historicalPublications,
    currentUser,
    setActiveTab,
    setSelectedMember,
    setSelectedPost,
    setSelectedEvent,
    setSelectedFamily,
  } = useFamily();

  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [category, setCategory] = useState<SearchCategory>('ALL');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isMobileModalOpen, setIsMobileModalOpen] = useState(false);
  const [isAdvancedModalOpen, setIsAdvancedModalOpen] = useState(false);
  const [history, setHistory] = useState(loadSearchHistory());

  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Debounce query
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedQuery(query);
    }, 180);
    return () => clearTimeout(handler);
  }, [query]);

  // Click outside to dismiss dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Keyboard shortcut ( / or Ctrl+K / Cmd+K )
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // If user presses '/' outside of an active input/textarea
      if (
        (e.key === '/' || (e.key.toLowerCase() === 'k' && (e.ctrlKey || e.metaKey))) &&
        document.activeElement?.tagName !== 'INPUT' &&
        document.activeElement?.tagName !== 'TEXTAREA'
      ) {
        e.preventDefault();
        inputRef.current?.focus();
        setIsDropdownOpen(true);
      } else if (e.key === 'Escape') {
        setIsDropdownOpen(false);
        inputRef.current?.blur();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Compute search results
  const results = executeGlobalSearch(
    debouncedQuery,
    {
      members,
      families,
      branches,
      posts,
      events,
      stories,
      liveStreams,
      memoryAlbums,
      historicalPublications,
      currentUser,
    },
    category
  );

  const grouped = groupSearchResults(results);
  const suggestions = getSmartSuggestions(currentUser, liveStreams);

  // Handle direct navigation to target
  const handleSelectResult = (res: SearchResult) => {
    if (query.trim().length > 1) {
      const updated = saveSearchHistoryItem(query, category, results.length);
      setHistory(updated);
    }

    setIsDropdownOpen(false);
    setIsMobileModalOpen(false);

    // Direct routing based on type and targetId
    if (res.type === 'MEMBER') {
      const targetMember = members.find((m) => m.id === res.targetId);
      if (targetMember) {
        setSelectedMember(targetMember);
        setActiveTab('members');
      }
    } else if (res.type === 'GENEALOGY_NODE' || res.type === 'BRANCH') {
      const targetMember = members.find((m) => m.id === res.targetId);
      if (targetMember) {
        setSelectedMember(targetMember);
      }
      setActiveTab('genealogy');
    } else if (res.type === 'FAMILY') {
      const targetFam = families.find((f) => f.id === res.targetId);
      if (targetFam) {
        setSelectedFamily(targetFam);
      }
      setActiveTab('alliances');
    } else if (res.type === 'POST') {
      const targetPost = posts.find((p) => p.id === res.targetId);
      if (targetPost) {
        setSelectedPost(targetPost);
      }
      setActiveTab('announcements');
    } else if (res.type === 'EVENT') {
      const targetEvent = events.find((e) => e.id === res.targetId);
      if (targetEvent) {
        setSelectedEvent(targetEvent);
      }
      setActiveTab('events');
    } else if (res.type === 'LIVE' || res.type === 'STORY') {
      setActiveTab('announcements');
    } else if (res.type === 'MEMORY_ALBUM' || res.type === 'HISTORICAL_FIGURE') {
      setActiveTab('memoire');
    } else if (res.linkTab) {
      setActiveTab(res.linkTab);
    }
  };

  const handleSelectHistory = (histQuery: string) => {
    setQuery(histQuery);
    setDebouncedQuery(histQuery);
    setIsDropdownOpen(true);
  };

  const handleDeleteHistory = (id: string) => {
    const updated = deleteSearchHistoryItem(id);
    setHistory(updated);
  };

  const handleClearHistory = () => {
    clearAllSearchHistory();
    setHistory([]);
  };

  return (
    <>
      {/* 1. DESKTOP & TABLET INLINE SEARCH BAR */}
      <div
        ref={containerRef}
        className={`relative hidden md:block w-full max-w-xs lg:max-w-md xl:max-w-lg ${className}`}
      >
        <div className="relative flex items-center">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
          <input
            id="global-search-input"
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setIsDropdownOpen(true);
            }}
            onFocus={() => {
              setHistory(loadSearchHistory());
              setIsDropdownOpen(true);
            }}
            placeholder="Rechercher membre, famille, événement..."
            className="w-full pl-10 pr-20 py-2 rounded-2xl bg-slate-100/90 hover:bg-slate-100 focus:bg-white text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 border border-slate-200/80 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 shadow-2xs transition min-h-[38px]"
          />

          {/* Right Action Icons in Input */}
          <div className="absolute right-2 flex items-center gap-1">
            {query.length > 0 ? (
              <button
                type="button"
                onClick={() => {
                  setQuery('');
                  setDebouncedQuery('');
                  inputRef.current?.focus();
                }}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition cursor-pointer"
                title="Effacer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            ) : (
              <kbd className="hidden lg:inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-md bg-white border border-slate-200 text-[10px] font-semibold text-slate-400 shadow-2xs">
                /
              </kbd>
            )}

            <button
              type="button"
              onClick={() => setIsAdvancedModalOpen(true)}
              className="p-1 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition cursor-pointer"
              title="Recherche avancée &amp; filtres"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Dropdown Popover */}
        <SearchDropdown
          isOpen={isDropdownOpen}
          query={debouncedQuery}
          category={category}
          onSelectCategory={setCategory}
          groupedResults={grouped}
          allResults={results}
          history={history}
          suggestions={suggestions}
          onSelectResult={handleSelectResult}
          onSelectHistory={handleSelectHistory}
          onDeleteHistoryItem={handleDeleteHistory}
          onClearAllHistory={handleClearHistory}
          onOpenAdvancedSearch={() => {
            setIsDropdownOpen(false);
            setIsAdvancedModalOpen(true);
          }}
          onClose={() => setIsDropdownOpen(false)}
        />
      </div>

      {/* 2. MOBILE TRIGGER BUTTON */}
      <div className="md:hidden">
        <button
          id="btn-mobile-search"
          onClick={() => setIsMobileModalOpen(true)}
          className="p-2 sm:p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 hover:text-blue-600 transition cursor-pointer min-h-[40px] min-w-[40px] flex items-center justify-center"
          title="Rechercher"
          aria-label="Rechercher"
        >
          <Search className="w-4 h-4 text-blue-600" />
        </button>
      </div>

      {/* 3. MOBILE FULLSCREEN MODAL */}
      <SearchModalMobile
        isOpen={isMobileModalOpen}
        onClose={() => setIsMobileModalOpen(false)}
        onSelectResult={handleSelectResult}
        onOpenAdvancedSearch={() => setIsAdvancedModalOpen(true)}
      />

      {/* 4. ADVANCED SEARCH MODAL */}
      <AdvancedSearchModal
        isOpen={isAdvancedModalOpen}
        onClose={() => setIsAdvancedModalOpen(false)}
        onSelectResult={handleSelectResult}
        initialCategory={category}
      />
    </>
  );
};
