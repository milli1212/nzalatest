/**
 * NzalaFamilly - Dropdown des Résultats de Recherche Globale
 */

import React from 'react';
import {
  SearchResult,
  SearchCategory,
  SearchCategoryGroup,
  SearchHistoryItem,
  SmartSuggestion,
} from '../../types/search';
import { SearchResultItem } from './SearchResultItem';
import {
  History,
  Trash2,
  SlidersHorizontal,
  ArrowRight,
  Search,
  Sparkles,
  Users,
  HeartHandshake,
  GitFork,
  Newspaper,
  Calendar,
  Radio,
  Crown,
  X,
} from 'lucide-react';

interface SearchDropdownProps {
  isOpen: boolean;
  query: string;
  category: SearchCategory;
  onSelectCategory: (cat: SearchCategory) => void;
  groupedResults: SearchCategoryGroup[];
  allResults: SearchResult[];
  history: SearchHistoryItem[];
  suggestions: SmartSuggestion[];
  onSelectResult: (result: SearchResult) => void;
  onSelectHistory: (query: string) => void;
  onDeleteHistoryItem: (id: string) => void;
  onClearAllHistory: () => void;
  onOpenAdvancedSearch: () => void;
  onViewAllResults?: () => void;
  onClose: () => void;
  selectedIndex?: number;
}

export const SearchDropdown: React.FC<SearchDropdownProps> = ({
  isOpen,
  query,
  category,
  onSelectCategory,
  groupedResults,
  allResults,
  history,
  suggestions,
  onSelectResult,
  onSelectHistory,
  onDeleteHistoryItem,
  onClearAllHistory,
  onOpenAdvancedSearch,
  onViewAllResults,
  onClose,
  selectedIndex = -1,
}) => {
  if (!isOpen) return null;

  const hasQuery = query.trim().length > 0;
  const totalCount = allResults.length;

  const categories: { id: SearchCategory; label: string; icon: any }[] = [
    { id: 'ALL', label: 'Tous', icon: Sparkles },
    { id: 'MEMBERS', label: 'Membres', icon: Users },
    { id: 'FAMILIES', label: 'Familles', icon: HeartHandshake },
    { id: 'GENEALOGY', label: 'Généalogie', icon: GitFork },
    { id: 'POSTS', label: 'Publications', icon: Newspaper },
    { id: 'EVENTS', label: 'Événements', icon: Calendar },
    { id: 'LIVES', label: 'Live', icon: Radio },
    { id: 'STORIES', label: 'Stories', icon: Sparkles },
    { id: 'MEMORY', label: 'Mémoire', icon: Crown },
  ];

  return (
    <div
      id="global-search-dropdown"
      className="absolute top-full left-0 right-0 mt-2 bg-white rounded-3xl border border-slate-200 shadow-2xl overflow-hidden z-50 animate-in fade-in-50 zoom-in-95 duration-150 max-h-[80vh] flex flex-col"
    >
      {/* Category Tabs */}
      <div className="px-3 py-2 bg-slate-50/90 border-b border-slate-200 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
        {categories.map((cat) => {
          const Icon = cat.icon;
          const isActive = category === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer shrink-0 ${
                isActive
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white hover:bg-slate-200/80 text-slate-600 border border-slate-200/80'
              }`}
            >
              <Icon className="w-3 h-3" />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Content Area */}
      <div className="p-3.5 sm:p-4 overflow-y-auto flex-1 space-y-4">
        {/* CASE 1: Query is EMPTY -> Show Recent Searches & Smart Suggestions */}
        {!hasQuery ? (
          <div className="space-y-4">
            {/* Recent Searches */}
            {history.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center justify-between px-1">
                  <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                    <History className="w-3.5 h-3.5 text-slate-400" />
                    <span>Recherches récentes</span>
                  </span>
                  <button
                    onClick={onClearAllHistory}
                    className="text-[11px] text-slate-400 hover:text-rose-600 transition cursor-pointer"
                  >
                    Effacer tout
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {history.map((h) => (
                    <div
                      key={h.id}
                      className="group flex items-center gap-1.5 pl-3 pr-1.5 py-1 rounded-xl bg-slate-100 hover:bg-blue-50 border border-slate-200 hover:border-blue-200 transition text-xs font-medium text-slate-700 hover:text-blue-700"
                    >
                      <span
                        onClick={() => onSelectHistory(h.query)}
                        className="cursor-pointer"
                      >
                        {h.query}
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteHistoryItem(h.id);
                        }}
                        className="p-1 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-slate-200 transition cursor-pointer"
                        title="Supprimer"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Smart Suggestions */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5 px-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>Raccourcis &amp; Suggestions Intelligentes</span>
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {suggestions.map((sug) => (
                  <div
                    key={sug.id}
                    onClick={() => {
                      if (sug.presetQuery) {
                        onSelectHistory(sug.presetQuery);
                      } else if (sug.targetTab) {
                        onSelectResult({
                          id: sug.id,
                          type: 'MEMBER',
                          category: sug.category,
                          title: sug.title,
                          linkTab: sug.targetTab,
                          targetId: sug.targetId || '',
                          relevanceScore: 10,
                        });
                      }
                    }}
                    className="p-3 rounded-2xl bg-slate-50/80 hover:bg-blue-50/60 border border-slate-200/80 hover:border-blue-200 transition cursor-pointer flex items-center justify-between gap-3 group text-left"
                  >
                    <div className="space-y-0.5 min-w-0">
                      <h4 className="text-xs font-bold text-slate-800 group-hover:text-blue-700 truncate">
                        {sug.title}
                      </h4>
                      <p className="text-[11px] text-slate-500 truncate">
                        {sug.subtitle}
                      </p>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-600 transition shrink-0 group-hover:translate-x-0.5" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          /* CASE 2: Query HAS text -> Show categorized results */
          <div className="space-y-4">
            {totalCount > 0 ? (
              groupedResults.map((group) => (
                <div key={group.category} className="space-y-1.5">
                  <div className="flex items-center justify-between px-1 pb-1 border-b border-slate-100">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                      <span>{group.label}</span>
                      <span className="px-1.5 py-0.2 rounded-full bg-slate-100 text-slate-700 text-[10px] font-bold">
                        {group.count}
                      </span>
                    </span>
                  </div>
                  <div className="space-y-1">
                    {group.results.slice(0, 4).map((res) => (
                      <SearchResultItem
                        key={res.id}
                        result={res}
                        onClick={onSelectResult}
                      />
                    ))}
                  </div>
                </div>
              ))
            ) : (
              /* Empty Results State */
              <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <Search className="w-8 h-8 text-slate-400 mx-auto" />
                <p className="text-xs sm:text-sm font-semibold text-slate-700">
                  Aucun résultat accessible pour «&nbsp;{query}&nbsp;»
                </p>
                <p className="text-[11px] text-slate-500 max-w-sm mx-auto">
                  Vérifiez l'orthographe ou utilisez la recherche avancée pour combiner plusieurs critères.
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Dropdown Footer with Quick Actions */}
      <div className="px-4 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-2 flex-wrap text-xs">
        <button
          onClick={onOpenAdvancedSearch}
          className="flex items-center gap-1.5 font-bold text-blue-600 hover:text-blue-800 transition cursor-pointer"
        >
          <SlidersHorizontal className="w-3.5 h-3.5" />
          <span>Recherche avancée avec filtres</span>
        </button>

        {hasQuery && totalCount > 0 && onViewAllResults && (
          <button
            onClick={onViewAllResults}
            className="flex items-center gap-1 font-semibold text-slate-700 hover:text-slate-900 transition cursor-pointer"
          >
            <span>Voir tous les {totalCount} résultats</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
