/**
 * NzalaFamilly - Modal de Recherche Plein Écran pour Mobile
 */

import React, { useState, useEffect, useRef } from 'react';
import { useFamily } from '../../context/FamilyContext';
import {
  SearchResult,
  SearchCategory,
} from '../../types/search';
import {
  executeGlobalSearch,
  groupSearchResults,
  loadSearchHistory,
  saveSearchHistoryItem,
  deleteSearchHistoryItem,
  clearAllSearchHistory,
  getSmartSuggestions,
} from '../../services/search/searchEngine';
import { SearchResultItem } from './SearchResultItem';
import {
  Search,
  X,
  SlidersHorizontal,
  History,
  Sparkles,
  Users,
  HeartHandshake,
  GitFork,
  Newspaper,
  Calendar,
  Radio,
  Crown,
  ArrowLeft,
} from 'lucide-react';

interface SearchModalMobileProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectResult: (result: SearchResult) => void;
  onOpenAdvancedSearch: () => void;
}

export const SearchModalMobile: React.FC<SearchModalMobileProps> = ({
  isOpen,
  onClose,
  onSelectResult,
  onOpenAdvancedSearch,
}) => {
  const {
    members,
    families,
    branches,
    posts,
    events,
    stories,
    liveStreams,
    memoryAlbums,
    historicalPublications,
    currentUser,
  } = useFamily();

  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [category, setCategory] = useState<SearchCategory>('ALL');
  const [history, setHistory] = useState(loadSearchHistory());
  const inputRef = useRef<HTMLInputElement>(null);

  // Debounce query
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedQuery(query);
    }, 200);
    return () => clearTimeout(handler);
  }, [query]);

  // Focus input on open
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
      setHistory(loadSearchHistory());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const suggestions = getSmartSuggestions(currentUser, liveStreams);

  const results = executeGlobalSearch(
    debouncedQuery,
    {
      members,
      families,
      branches,
      posts,
      events,
      stories,
      liveStreams,
      memoryAlbums,
      historicalPublications,
      currentUser,
    },
    category
  );

  const grouped = groupSearchResults(results);

  const handleResultClick = (res: SearchResult) => {
    if (query.trim().length > 1) {
      saveSearchHistoryItem(query, category, results.length);
    }
    onSelectResult(res);
    onClose();
  };

  const handleHistoryClick = (histQuery: string) => {
    setQuery(histQuery);
    setDebouncedQuery(histQuery);
  };

  const categories: { id: SearchCategory; label: string; icon: any }[] = [
    { id: 'ALL', label: 'Tous', icon: Sparkles },
    { id: 'MEMBERS', label: 'Membres', icon: Users },
    { id: 'FAMILIES', label: 'Familles', icon: HeartHandshake },
    { id: 'GENEALOGY', label: 'Généalogie', icon: GitFork },
    { id: 'POSTS', label: 'Fil', icon: Newspaper },
    { id: 'EVENTS', label: 'Événements', icon: Calendar },
    { id: 'LIVES', label: 'Live', icon: Radio },
    { id: 'STORIES', label: 'Stories', icon: Sparkles },
    { id: 'MEMORY', label: 'Mémoire', icon: Crown },
  ];

  return (
    <div
      id="mobile-search-modal"
      className="fixed inset-0 z-50 bg-white flex flex-col animate-in fade-in duration-150"
    >
      {/* Top Search Header */}
      <div className="p-3 border-b border-slate-200 bg-white/95 backdrop-blur-md flex items-center gap-2">
        <button
          onClick={onClose}
          className="p-2 rounded-xl text-slate-600 hover:bg-slate-100 transition cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center"
          aria-label="Retour"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        {/* Input Bar */}
        <div className="flex-1 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Rechercher dans NzalaFamilly..."
            className="w-full pl-9 pr-8 py-2.5 rounded-2xl bg-slate-100 text-slate-900 placeholder:text-slate-400 text-sm focus:bg-white focus:ring-2 focus:ring-blue-500 border border-transparent focus:border-blue-500 transition min-h-[44px]"
          />
          {query.length > 0 && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-full text-slate-400 hover:text-slate-700 absolute right-2.5 top-1/2 -translate-y-1/2 min-h-[32px] min-w-[32px] flex items-center justify-center cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter Button */}
        <button
          onClick={() => {
            onOpenAdvancedSearch();
            onClose();
          }}
          className="p-2 rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200 transition cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center"
          title="Filtres avancés"
        >
          <SlidersHorizontal className="w-5 h-5 text-blue-600" />
        </button>
      </div>

      {/* Category Pills Bar */}
      <div className="px-3 py-2 border-b border-slate-100 bg-slate-50 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
        {categories.map((cat) => {
          const Icon = cat.icon;
          const isActive = category === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setCategory(cat.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer shrink-0 min-h-[36px] ${
                isActive
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-700 border border-slate-200'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Results / Suggestions Scrollable Body */}
      <div className="flex-1 overflow-y-auto p-3 space-y-4">
        {query.trim().length === 0 ? (
          <div className="space-y-4">
            {/* Recent Searches */}
            {history.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center justify-between px-1">
                  <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                    <History className="w-3.5 h-3.5 text-slate-400" />
                    <span>Recherches récentes</span>
                  </span>
                  <button
                    onClick={() => {
                      clearAllSearchHistory();
                      setHistory([]);
                    }}
                    className="text-[11px] text-slate-400 hover:text-rose-600 transition"
                  >
                    Effacer tout
                  </button>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {history.map((h) => (
                    <div
                      key={h.id}
                      className="flex items-center gap-1.5 pl-3 pr-1.5 py-1 rounded-xl bg-slate-100 border border-slate-200 text-xs font-medium text-slate-700"
                    >
                      <span onClick={() => handleHistoryClick(h.query)} className="cursor-pointer">
                        {h.query}
                      </span>
                      <button
                        onClick={() => {
                          const updated = deleteSearchHistoryItem(h.id);
                          setHistory(updated);
                        }}
                        className="p-1 text-slate-400 hover:text-rose-500"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Smart Suggestions */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5 px-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>Suggestions Intelligentes</span>
              </span>
              <div className="space-y-1.5">
                {suggestions.map((sug) => (
                  <div
                    key={sug.id}
                    onClick={() => {
                      if (sug.presetQuery) {
                        handleHistoryClick(sug.presetQuery);
                      } else if (sug.targetTab) {
                        handleResultClick({
                          id: sug.id,
                          type: 'MEMBER',
                          category: sug.category,
                          title: sug.title,
                          linkTab: sug.targetTab,
                          targetId: sug.targetId || '',
                          relevanceScore: 10,
                        });
                      }
                    }}
                    className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 transition cursor-pointer flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <h4 className="text-xs font-bold text-slate-800 truncate">
                        {sug.title}
                      </h4>
                      <p className="text-[11px] text-slate-500 truncate">
                        {sug.subtitle}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          /* Grouped Results */
          <div className="space-y-4">
            {results.length > 0 ? (
              grouped.map((group) => (
                <div key={group.category} className="space-y-1.5">
                  <div className="flex items-center justify-between px-1 pb-1 border-b border-slate-100">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                      <span>{group.label}</span>
                      <span className="px-1.5 py-0.2 rounded-full bg-slate-100 text-slate-700 text-[10px] font-bold">
                        {group.count}
                      </span>
                    </span>
                  </div>
                  <div className="space-y-1">
                    {group.results.map((res) => (
                      <SearchResultItem
                        key={res.id}
                        result={res}
                        onClick={handleResultClick}
                      />
                    ))}
                  </div>
                </div>
              ))
            ) : (
              <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <Search className="w-8 h-8 text-slate-400 mx-auto" />
                <p className="text-xs sm:text-sm font-semibold text-slate-700">
                  Aucun résultat accessible pour «&nbsp;{query}&nbsp;»
                </p>
                <p className="text-[11px] text-slate-500">
                  Vérifiez vos termes de recherche ou essayez la recherche avancée.
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
