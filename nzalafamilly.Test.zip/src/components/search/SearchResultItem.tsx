/**
 * NzalaFamilly - Composant pour un Résultat de Recherche
 */

import React from 'react';
import { SearchResult } from '../../types/search';
import {
  Users,
  HeartHandshake,
  GitFork,
  Newspaper,
  Calendar,
  Radio,
  Sparkles,
  Crown,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';

interface SearchResultItemProps {
  result: SearchResult;
  onClick: (result: SearchResult) => void;
  isSelected?: boolean;
}

export const SearchResultItem: React.FC<SearchResultItemProps> = ({
  result,
  onClick,
  isSelected = false,
}) => {
  const getCategoryIcon = () => {
    switch (result.type) {
      case 'MEMBER':
        return <Users className="w-4 h-4 text-blue-600" />;
      case 'FAMILY':
        return <HeartHandshake className="w-4 h-4 text-emerald-600" />;
      case 'BRANCH':
      case 'GENEALOGY_NODE':
        return <GitFork className="w-4 h-4 text-amber-600" />;
      case 'POST':
        return <Newspaper className="w-4 h-4 text-blue-600" />;
      case 'EVENT':
        return <Calendar className="w-4 h-4 text-rose-600" />;
      case 'LIVE':
        return <Radio className="w-4 h-4 text-rose-600 animate-pulse" />;
      case 'STORY':
        return <Sparkles className="w-4 h-4 text-purple-600" />;
      case 'MEMORY_ALBUM':
      case 'HISTORICAL_FIGURE':
        return <Crown className="w-4 h-4 text-amber-700" />;
      default:
        return <Users className="w-4 h-4 text-blue-600" />;
    }
  };

  const getBadgeClasses = () => {
    switch (result.badgeColor) {
      case 'blue':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'emerald':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'amber':
        return 'bg-amber-50 text-amber-800 border-amber-200';
      case 'purple':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'rose':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      case 'slate':
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div
      id={`search-result-${result.id}`}
      onClick={() => onClick(result)}
      className={`group px-3.5 py-2.5 rounded-2xl flex items-center justify-between gap-3 transition cursor-pointer text-left border ${
        isSelected
          ? 'bg-blue-50/90 border-blue-200 shadow-xs'
          : 'bg-white hover:bg-slate-50/90 border-transparent hover:border-slate-200/80'
      }`}
    >
      {/* Left Icon / Avatar */}
      <div className="relative shrink-0 flex items-center justify-center">
        {result.avatarUrl ? (
          <img
            src={result.avatarUrl}
            alt={result.title}
            referrerPolicy="no-referrer"
            className="w-10 h-10 rounded-xl object-cover border border-slate-200 shadow-2xs"
          />
        ) : result.thumbnailUrl ? (
          <img
            src={result.thumbnailUrl}
            alt={result.title}
            referrerPolicy="no-referrer"
            className="w-10 h-10 rounded-xl object-cover border border-slate-200 shadow-2xs"
          />
        ) : (
          <div className="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center">
            {getCategoryIcon()}
          </div>
        )}

        {/* Mini live indicator if active */}
        {result.isLive && (
          <span className="absolute -top-1 -right-1 flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500"></span>
          </span>
        )}
      </div>

      {/* Main Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 flex-wrap">
          <h4 className="text-xs sm:text-sm font-bold text-slate-900 truncate group-hover:text-blue-600 transition">
            {result.title}
          </h4>
          {result.isVerified && (
            <span title="Membre vérifié">
              <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 inline-block shrink-0" />
            </span>
          )}
          {result.isOfficial && (
            <span title="Publication officielle">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-600 inline-block shrink-0" />
            </span>
          )}
          {result.badge && (
            <span
              className={`px-2 py-0.5 rounded-full text-[10px] font-semibold border ${getBadgeClasses()}`}
            >
              {result.badge}
            </span>
          )}
        </div>

        {result.subtitle && (
          <p className="text-[11px] sm:text-xs text-slate-500 truncate mt-0.5">
            {result.subtitle}
          </p>
        )}

        {result.description && (
          <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
            {result.description}
          </p>
        )}
      </div>

      {/* Right chevron action */}
      <div className="shrink-0 text-slate-300 group-hover:text-blue-600 transition group-hover:translate-x-0.5">
        <ChevronRight className="w-4 h-4" />
      </div>
    </div>
  );
};
