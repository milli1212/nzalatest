import React, { useState, useEffect, useCallback } from 'react';
import { MediaItem } from '../../types';
import { X, ChevronLeft, ChevronRight, Download, Maximize2 } from 'lucide-react';

interface LightboxModalProps {
  mediaList?: MediaItem[];
  media?: MediaItem[];
  initialIndex?: number;
  isOpen: boolean;
  onClose: () => void;
}

export const LightboxModal: React.FC<LightboxModalProps> = ({
  mediaList: propMediaList,
  media: propMedia,
  initialIndex = 0,
  isOpen,
  onClose,
}) => {
  const mediaList = propMediaList || propMedia || [];
  const [currentIndex, setCurrentIndex] = useState(initialIndex);

  useEffect(() => {
    setCurrentIndex(initialIndex);
  }, [initialIndex]);

  const handlePrev = useCallback(() => {
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : mediaList.length - 1));
  }, [mediaList.length]);

  const handleNext = useCallback(() => {
    setCurrentIndex((prev) => (prev < mediaList.length - 1 ? prev + 1 : 0));
  }, [mediaList.length]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft') handlePrev();
      if (e.key === 'ArrowRight') handleNext();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose, handlePrev, handleNext]);

  if (!isOpen || mediaList.length === 0) return null;

  const currentMedia = mediaList[currentIndex];

  return (
    <div
      id="lightbox-modal"
      className="fixed inset-0 z-50 bg-stone-950/95 backdrop-blur-md flex flex-col justify-between select-none animate-fadeIn"
      onClick={onClose}
    >
      {/* Top Header */}
      <div
        className="flex items-center justify-between p-4 text-white z-10 bg-gradient-to-b from-stone-950/80 to-transparent"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3">
          <span className="px-2.5 py-1 rounded-full bg-stone-800/80 border border-stone-700 text-xs font-semibold text-stone-300">
            {currentIndex + 1} / {mediaList.length}
          </span>
          {currentMedia.caption && (
            <p className="text-sm font-medium text-stone-200 line-clamp-1 max-w-md hidden sm:block">
              {currentMedia.caption}
            </p>
          )}
        </div>

        <div className="flex items-center gap-2">
          {currentMedia.url && (
            <a
              href={currentMedia.url}
              download={currentMedia.fileName || 'media-nzalafamilly'}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-xl bg-stone-800/70 hover:bg-stone-700 text-stone-300 hover:text-white transition"
              title="Télécharger l'original"
            >
              <Download className="w-4 h-4" />
            </a>
          )}
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-stone-800/70 hover:bg-rose-600/80 text-stone-300 hover:text-white transition cursor-pointer"
            title="Fermer (Échap)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Media Display */}
      <div
        className="relative flex-1 flex items-center justify-center p-2 sm:p-6 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {mediaList.length > 1 && (
          <button
            onClick={handlePrev}
            className="absolute left-2 sm:left-6 z-20 p-3 rounded-2xl bg-stone-900/80 hover:bg-stone-800 border border-stone-700 text-white transition shadow-lg hover:scale-105 cursor-pointer"
            title="Précédent"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        )}

        <div className="max-w-5xl max-h-[80vh] flex flex-col items-center justify-center">
          {currentMedia.type === 'VIDEO' ? (
            <video
              src={currentMedia.url}
              controls
              autoPlay
              className="max-h-[75vh] max-w-full rounded-2xl shadow-2xl border border-stone-800 object-contain"
            />
          ) : (
            <img
              src={currentMedia.url}
              alt={currentMedia.caption || 'Média familial'}
              className="max-h-[75vh] max-w-full rounded-2xl shadow-2xl border border-stone-800 object-contain"
            />
          )}

          {currentMedia.caption && (
            <div className="mt-3 text-center px-4 py-2 rounded-xl bg-stone-900/80 border border-stone-800/60 max-w-2xl">
              <p className="text-xs sm:text-sm text-stone-300 leading-relaxed font-sans">
                {currentMedia.caption}
              </p>
            </div>
          )}
        </div>

        {mediaList.length > 1 && (
          <button
            onClick={handleNext}
            className="absolute right-2 sm:right-6 z-20 p-3 rounded-2xl bg-stone-900/80 hover:bg-stone-800 border border-stone-700 text-white transition shadow-lg hover:scale-105 cursor-pointer"
            title="Suivant"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        )}
      </div>

      {/* Bottom Thumbnails */}
      {mediaList.length > 1 && (
        <div
          className="p-3 flex items-center justify-center gap-2 overflow-x-auto bg-gradient-to-t from-stone-950/90 to-transparent"
          onClick={(e) => e.stopPropagation()}
        >
          {mediaList.map((media, idx) => (
            <button
              key={media.id || idx}
              onClick={() => setCurrentIndex(idx)}
              className={`w-12 h-12 rounded-xl overflow-hidden shrink-0 border-2 transition cursor-pointer ${
                idx === currentIndex
                  ? 'border-amber-500 scale-105 shadow-md shadow-amber-500/20'
                  : 'border-stone-800 opacity-60 hover:opacity-100'
              }`}
            >
              {media.type === 'VIDEO' ? (
                <div className="w-full h-full bg-stone-800 flex items-center justify-center text-xs text-amber-400">
                  ▶
                </div>
              ) : (
                <img
                  src={media.thumbnailUrl || media.url}
                  alt=""
                  className="w-full h-full object-cover"
                />
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
