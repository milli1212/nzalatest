import React from 'react';
import { LinkPreview } from '../../types';
import { ExternalLink, Globe } from 'lucide-react';

interface LinkPreviewCardProps {
  preview: LinkPreview;
}

export const LinkPreviewCard: React.FC<LinkPreviewCardProps> = ({ preview }) => {
  if (!preview || !preview.url) return null;

  return (
    <a
      href={preview.url}
      target="_blank"
      rel="noopener noreferrer"
      className="mt-3 block overflow-hidden rounded-2xl border border-stone-200 bg-stone-50 hover:bg-stone-100/90 transition shadow-sm group"
      id="link-preview-card"
    >
      {preview.imageUrl && (
        <div className="w-full h-44 sm:h-52 overflow-hidden bg-stone-200">
          <img
            src={preview.imageUrl}
            alt={preview.title}
            className="w-full h-full object-cover group-hover:scale-102 transition duration-300"
            loading="lazy"
          />
        </div>
      )}
      <div className="p-3.5 sm:p-4">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-700 uppercase tracking-wider mb-1">
          <Globe className="w-3.5 h-3.5" />
          <span>{preview.domain}</span>
          <ExternalLink className="w-3 h-3 ml-auto text-stone-400 group-hover:text-amber-700 transition" />
        </div>
        <h4 className="text-sm sm:text-base font-bold text-stone-900 line-clamp-1 group-hover:text-blue-600 transition">
          {preview.title}
        </h4>
        {preview.description && (
          <p className="text-xs text-stone-600 line-clamp-2 mt-1 leading-relaxed">
            {preview.description}
          </p>
        )}
      </div>
    </a>
  );
};
