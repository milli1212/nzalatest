import React, { useState } from 'react';
import { MediaItem } from '../../types';
import { Play, Eye, Image as ImageIcon } from 'lucide-react';
import { LightboxModal } from './LightboxModal';

interface MediaGridProps {
  media?: MediaItem[];
  fallbackImageUrl?: string;
  mediaCaption?: string;
}

export const MediaGrid: React.FC<MediaGridProps> = ({
  media = [],
  fallbackImageUrl,
  mediaCaption,
}) => {
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [activeMediaIndex, setActiveMediaIndex] = useState(0);

  // Normalisation : si on n'a pas de tableau `media` mais qu'on a `fallbackImageUrl`
  const mediaList: MediaItem[] =
    media && media.length > 0
      ? media
      : fallbackImageUrl
      ? [
          {
            id: 'legacy-media-img',
            type: 'IMAGE',
            url: fallbackImageUrl,
            caption: mediaCaption,
          },
        ]
      : [];

  if (mediaList.length === 0) return null;

  const openLightbox = (index: number) => {
    setActiveMediaIndex(index);
    setLightboxOpen(true);
  };

  const count = mediaList.length;

  return (
    <>
      <div id="media-grid-container" className="mt-3 overflow-hidden rounded-2xl border border-stone-200 bg-stone-900 shadow-sm">
        {/* CAS 1 : Média Unique */}
        {count === 1 && (
          <div className="relative group cursor-pointer overflow-hidden max-h-[520px] flex items-center justify-center bg-stone-950">
            {mediaList[0].type === 'VIDEO' ? (
              <div className="relative w-full aspect-video flex items-center justify-center bg-stone-950" onClick={() => openLightbox(0)}>
                <video
                  src={mediaList[0].url}
                  className="w-full h-full object-contain"
                  preload="metadata"
                />
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center group-hover:bg-black/40 transition">
                  <div className="w-16 h-16 rounded-full bg-amber-600/90 text-white flex items-center justify-center shadow-lg transform group-hover:scale-110 transition">
                    <Play className="w-8 h-8 ml-1 fill-white" />
                  </div>
                </div>
              </div>
            ) : (
              <div className="w-full flex items-center justify-center bg-stone-950" onClick={() => openLightbox(0)}>
                <img
                  src={mediaList[0].url}
                  alt={mediaList[0].caption || 'Média familial'}
                  className="w-full max-h-[500px] object-cover group-hover:scale-101 transition duration-300"
                  loading="lazy"
                />
              </div>
            )}
            {mediaList[0].caption && (
              <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-stone-950/80 via-stone-950/40 to-transparent p-3 text-xs text-stone-200">
                {mediaList[0].caption}
              </div>
            )}
          </div>
        )}

        {/* CAS 2 : Deux Médias */}
        {count === 2 && (
          <div className="grid grid-cols-2 gap-1 h-72 sm:h-80">
            {mediaList.map((item, idx) => (
              <div
                key={item.id || idx}
                className="relative group cursor-pointer overflow-hidden bg-stone-950"
                onClick={() => openLightbox(idx)}
              >
                {item.type === 'VIDEO' ? (
                  <div className="w-full h-full relative flex items-center justify-center">
                    <video src={item.url} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                      <div className="w-10 h-10 rounded-full bg-amber-600/90 text-white flex items-center justify-center shadow">
                        <Play className="w-5 h-5 ml-0.5 fill-white" />
                      </div>
                    </div>
                  </div>
                ) : (
                  <img
                    src={item.url}
                    alt={item.caption || ''}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    loading="lazy"
                  />
                )}
              </div>
            ))}
          </div>
        )}

        {/* CAS 3 : Trois Médias */}
        {count === 3 && (
          <div className="grid grid-cols-3 gap-1 h-72 sm:h-80">
            <div
              className="col-span-2 relative group cursor-pointer overflow-hidden bg-stone-950"
              onClick={() => openLightbox(0)}
            >
              {mediaList[0].type === 'VIDEO' ? (
                <div className="w-full h-full relative flex items-center justify-center">
                  <video src={mediaList[0].url} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                    <div className="w-12 h-12 rounded-full bg-amber-600/90 text-white flex items-center justify-center shadow">
                      <Play className="w-6 h-6 ml-0.5 fill-white" />
                    </div>
                  </div>
                </div>
              ) : (
                <img
                  src={mediaList[0].url}
                  alt=""
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  loading="lazy"
                />
              )}
            </div>
            <div className="grid grid-rows-2 gap-1">
              {mediaList.slice(1, 3).map((item, idx) => (
                <div
                  key={item.id || idx}
                  className="relative group cursor-pointer overflow-hidden bg-stone-950"
                  onClick={() => openLightbox(idx + 1)}
                >
                  {item.type === 'VIDEO' ? (
                    <div className="w-full h-full relative flex items-center justify-center">
                      <video src={item.url} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                        <Play className="w-5 h-5 text-white fill-white" />
                      </div>
                    </div>
                  ) : (
                    <img
                      src={item.url}
                      alt=""
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                      loading="lazy"
                    />
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* CAS 4+ : Quatre Médias ou Plus */}
        {count >= 4 && (
          <div className="grid grid-cols-2 gap-1 h-72 sm:h-96">
            {mediaList.slice(0, 4).map((item, idx) => {
              const isFourth = idx === 3;
              const extraCount = count - 4;

              return (
                <div
                  key={item.id || idx}
                  className="relative group cursor-pointer overflow-hidden bg-stone-950"
                  onClick={() => openLightbox(idx)}
                >
                  {item.type === 'VIDEO' ? (
                    <div className="w-full h-full relative flex items-center justify-center">
                      <video src={item.url} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                        <Play className="w-6 h-6 text-white fill-white" />
                      </div>
                    </div>
                  ) : (
                    <img
                      src={item.url}
                      alt=""
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                      loading="lazy"
                    />
                  )}

                  {isFourth && extraCount > 0 && (
                    <div className="absolute inset-0 bg-stone-950/70 backdrop-blur-xs flex flex-col items-center justify-center text-white font-bold group-hover:bg-stone-950/60 transition">
                      <span className="text-2xl sm:text-3xl">+{extraCount}</span>
                      <span className="text-xs font-normal text-stone-300 mt-1 flex items-center gap-1">
                        <ImageIcon className="w-3.5 h-3.5" /> Voir tout
                      </span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      <LightboxModal
        isOpen={lightboxOpen}
        mediaList={mediaList}
        initialIndex={activeMediaIndex}
        onClose={() => setLightboxOpen(false)}
      />
    </>
  );
};
