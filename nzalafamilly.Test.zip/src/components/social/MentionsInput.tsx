import React, { useState, useRef } from 'react';
import { Member, MemberMention } from '../../types';
import { AtSign, Users } from 'lucide-react';

interface MentionsInputProps {
  value: string;
  onChange: (value: string) => void;
  members: Member[];
  onMentionsChange?: (mentions: MemberMention[]) => void;
  placeholder?: string;
  rows?: number;
  id?: string;
  className?: string;
}

export const MentionsInput: React.FC<MentionsInputProps> = ({
  value,
  onChange,
  members = [],
  onMentionsChange,
  placeholder = 'Rédigez votre message... Tapez @ pour identifier un membre',
  rows = 3,
  id = 'mentions-input-textarea',
  className = '',
}) => {
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [filterText, setFilterText] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Filtrage des membres disponibles
  const matchingMembers = members
    .filter((m) => {
      if (!filterText) return true;
      const q = filterText.toLowerCase();
      return (
        m.firstName.toLowerCase().includes(q) ||
        m.lastName.toLowerCase().includes(q) ||
        m.branchId?.toLowerCase().includes(q)
      );
    })
    .slice(0, 5);

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    onChange(val);

    const cursorPos = e.target.selectionStart;
    const textBeforeCursor = val.slice(0, cursorPos);
    const lastAtIndex = textBeforeCursor.lastIndexOf('@');

    if (lastAtIndex !== -1 && lastAtIndex === textBeforeCursor.length - 1) {
      setShowSuggestions(true);
      setFilterText('');
    } else if (lastAtIndex !== -1 && !textBeforeCursor.slice(lastAtIndex).includes(' ')) {
      setShowSuggestions(true);
      setFilterText(textBeforeCursor.slice(lastAtIndex + 1));
    } else {
      setShowSuggestions(false);
    }
  };

  const handleSelectMember = (member: Member) => {
    if (!textareaRef.current) return;
    const cursorPos = textareaRef.current.selectionStart;
    const textBeforeCursor = value.slice(0, cursorPos);
    const lastAtIndex = textBeforeCursor.lastIndexOf('@');
    const textAfterCursor = value.slice(cursorPos);

    const memberTag = `@${member.firstName}_${member.lastName} `;
    const newText = value.slice(0, lastAtIndex) + memberTag + textAfterCursor;

    onChange(newText);
    setShowSuggestions(false);

    if (onMentionsChange) {
      // Re-scan mentions
      const mention: MemberMention = {
        memberId: member.id,
        memberName: `${member.firstName} ${member.lastName}`,
        memberAvatar: member.avatarUrl,
        startIndex: lastAtIndex,
        endIndex: lastAtIndex + memberTag.length,
      };
      onMentionsChange([mention]);
    }

    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        const newCursorPos = lastAtIndex + memberTag.length;
        textareaRef.current.setSelectionRange(newCursorPos, newCursorPos);
      }
    }, 50);
  };

  return (
    <div className="relative w-full">
      <textarea
        ref={textareaRef}
        id={id}
        rows={rows}
        value={value}
        onChange={handleTextChange}
        placeholder={placeholder}
        className={`w-full rounded-2xl border border-stone-200 bg-white p-3.5 text-stone-900 placeholder:text-stone-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 text-sm sm:text-base resize-none transition outline-none ${className}`}
      />

      {showSuggestions && matchingMembers.length > 0 && (
        <div
          id="mentions-suggestions-popup"
          className="absolute left-0 right-0 top-full mt-1 z-30 max-h-48 overflow-y-auto rounded-2xl border border-stone-200 bg-white shadow-xl p-1.5 animate-fadeIn"
        >
          <div className="px-2.5 py-1 text-[11px] font-semibold text-stone-400 uppercase tracking-wider flex items-center gap-1">
            <AtSign className="w-3 h-3 text-blue-500" /> Mentionner un membre de la famille
          </div>
          {matchingMembers.map((member) => (
            <button
              key={member.id}
              type="button"
              onClick={() => handleSelectMember(member)}
              className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left hover:bg-blue-50/80 transition group cursor-pointer"
            >
              <div className="w-7 h-7 rounded-full overflow-hidden bg-stone-200 shrink-0 border border-stone-200 flex items-center justify-center font-bold text-xs text-stone-600">
                {member.avatarUrl ? (
                  <img src={member.avatarUrl} alt="" className="w-full h-full object-cover" />
                ) : (
                  member.firstName.charAt(0)
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs sm:text-sm font-semibold text-stone-900 group-hover:text-blue-600 truncate">
                  {member.firstName} {member.lastName}
                </p>
                <p className="text-[11px] text-stone-500 truncate">
                  Génération {member.generationLevel || 1} • {member.branchName || member.primaryFamilyName || 'Famille'}
                </p>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
