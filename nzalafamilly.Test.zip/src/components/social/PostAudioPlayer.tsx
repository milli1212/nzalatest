/**
 * NzalaFamilly - Lecteur Audio Intégré aux Publications (Bande-son / Musique)
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Music2,
  Disc3,
  Sparkles,
} from 'lucide-react';
import { FamilyAudioTrack } from '../../types/socialFeatures';

interface PostAudioPlayerProps {
  audioTrack: FamilyAudioTrack;
}

export const PostAudioPlayer: React.FC<PostAudioPlayerProps> = ({ audioTrack }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(audioTrack.durationSec || 0);

  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => setCurrentTime(audio.currentTime);
    const handleLoadedMetadata = () => {
      if (audio.duration && !isNaN(audio.duration)) {
        setDuration(Math.floor(audio.duration));
      }
    };
    const handleEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('ended', handleEnded);
    };
  }, []);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().catch(() => {});
      setIsPlaying(true);
    }
  };

  const toggleMute = () => {
    if (!audioRef.current) return;
    audioRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = Number(e.target.value);
    setCurrentTime(time);
    if (audioRef.current) {
      audioRef.current.currentTime = time;
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="my-3 p-3.5 rounded-2xl bg-gradient-to-r from-amber-950/90 via-slate-900 to-indigo-950 text-white shadow-md border border-amber-800/30 select-none">
      <audio ref={audioRef} src={audioTrack.url} preload="metadata" />

      <div className="flex items-center justify-between gap-3">
        {/* Vinyl / Cover Art */}
        <div className="flex items-center gap-3 min-w-0">
          <div
            onClick={togglePlay}
            className={`w-11 h-11 rounded-full bg-gradient-to-tr from-amber-600 to-yellow-400 flex items-center justify-center text-white shrink-0 shadow-lg cursor-pointer transition ${
              isPlaying ? 'animate-spin' : 'hover:scale-105'
            }`}
            style={{ animationDuration: '4s' }}
          >
            <Disc3 className="w-6 h-6" />
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded font-bold uppercase tracking-wider">
                Bande-son
              </span>
              <span className="text-xs font-bold text-white truncate">
                {audioTrack.title}
              </span>
            </div>
            <p className="text-[11px] text-stone-300 truncate">
              {audioTrack.artistOrTradition || 'Patrimoine familial Nzala'}
            </p>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={togglePlay}
            className="w-9 h-9 rounded-full bg-amber-500 hover:bg-amber-400 text-stone-950 flex items-center justify-center font-bold shadow-md transition active:scale-95 cursor-pointer"
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
          </button>

          <button
            type="button"
            onClick={toggleMute}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-stone-200 transition cursor-pointer"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Progress slider & time */}
      <div className="mt-2.5 flex items-center gap-2 text-[10px] text-stone-400 font-mono">
        <span>{formatTime(currentTime)}</span>
        <input
          type="range"
          min={0}
          max={duration || 100}
          value={currentTime}
          onChange={handleSeek}
          className="flex-1 h-1 bg-stone-700 rounded-lg appearance-none cursor-pointer accent-amber-400"
        />
        <span>{formatTime(duration)}</span>
      </div>
    </div>
  );
};
