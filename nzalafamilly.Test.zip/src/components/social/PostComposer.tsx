import React, { useState, useRef } from 'react';
import { useFamily } from '../../context/FamilyContext';
import {
  PostType,
  PostScope,
  MediaItem,
  LinkPreview,
  MemberMention,
} from '../../types';
import {
  Image as ImageIcon,
  Video,
  Link2,
  Send,
  Lock,
  Globe,
  Users,
  Sparkles,
  X,
  Plus,
  Smile,
  Film,
  AlertCircle,
  Loader2,
} from 'lucide-react';
import { MentionsInput } from './MentionsInput';
import { MediaStorage, CURATED_FAMILY_MEDIA } from '../../services/mediaStorage';
import { parseMentionsFromText } from '../../services/socialService';

interface PostComposerProps {
  onPostCreated?: () => void;
  defaultScope?: PostScope;
  placeholder?: string;
  isCompact?: boolean;
}

const COMMON_EMOJIS = ['❤️', '🙏', '🎉', '😊', '👏', '🕊️', '✨', '🎂', '🔥', '👑', '💪', '🤝', '🌿', '🦁', '🌟'];

export const PostComposer: React.FC<PostComposerProps> = ({
  onPostCreated,
  defaultScope = 'NZALA_INTERNE',
  placeholder = 'Quoi de neuf dans la famille ? Partagez une nouvelle, un souvenir, une photo...',
  isCompact = false,
}) => {
  const { currentUser, members, events, alliedFamilies, addPost } = useFamily();

  const [isExpanded, setIsExpanded] = useState(!isCompact);
  const [content, setContent] = useState('');
  const [title, setTitle] = useState('');
  const [postType, setPostType] = useState<PostType>('ACTUALITE_FAMILIALE');
  const [scope, setScope] = useState<PostScope>(defaultScope);
  const [targetAlliedFamilyId, setTargetAlliedFamilyId] = useState('');
  const [targetBranchId, setTargetBranchId] = useState('');
  const [relatedEventId, setRelatedEventId] = useState('');
  const [relatedMemberId, setRelatedMemberId] = useState('');
  const [isOfficial, setIsOfficial] = useState(false);

  // Médias
  const [mediaList, setMediaList] = useState<MediaItem[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [showPresetPicker, setShowPresetPicker] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  // Lien
  const [linkInput, setLinkInput] = useState('');
  const [linkPreview, setLinkPreview] = useState<LinkPreview | null>(null);
  const [showLinkInput, setShowLinkInput] = useState(false);
  const [isGeneratingLink, setIsGeneratingLink] = useState(false);

  // Erreurs
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const isCouncilOrAdmin =
    currentUser.role === 'SUPER_ADMIN' ||
    currentUser.role === 'ADMIN_FAMILIAL' ||
    currentUser.role === 'VALIDATEUR';

  // Gestion de l'upload de photos / vidéos
  const handleFileUpload = async (files: FileList | null, type: 'IMAGE' | 'VIDEO') => {
    if (!files || files.length === 0) return;
    setIsUploading(true);
    setError(null);

    try {
      const newItems: MediaItem[] = [];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const validation = MediaStorage.validateFile(file);
        if (!validation.isValid) {
          setError(validation.error || 'Fichier non valide.');
          continue;
        }
        const uploaded = await MediaStorage.uploadFile(file);
        newItems.push(uploaded);
      }
      setMediaList((prev) => [...prev, ...newItems]);
    } catch {
      setError('Erreur lors du traitement des fichiers.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemoveMedia = (index: number) => {
    setMediaList((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleAddPresetMedia = (item: MediaItem) => {
    setMediaList((prev) => [...prev, item]);
    setShowPresetPicker(false);
  };

  const handleInsertEmoji = (emoji: string) => {
    setContent((prev) => prev + (prev.endsWith(' ') || prev.length === 0 ? emoji : ` ${emoji}`));
  };

  // Génération de l'aperçu de lien
  const handleAttachLink = async () => {
    if (!linkInput.trim()) return;
    setIsGeneratingLink(true);
    setError(null);
    try {
      const preview = await MediaStorage.generateLinkPreview(linkInput.trim());
      setLinkPreview(preview);
      setShowLinkInput(false);
      setLinkInput('');
    } catch {
      setError('Impossible de générer l\'aperçu pour ce lien.');
    } finally {
      setIsGeneratingLink(false);
    }
  };

  // Soumission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!content.trim() && mediaList.length === 0 && !linkPreview) {
      setError('Veuillez rédiger un texte ou ajouter un média pour publier.');
      return;
    }

    if (scope === 'FAMILLE_ALLIEE' && !targetAlliedFamilyId) {
      setError('Veuillez sélectionner la famille alliée ciblée.');
      return;
    }

    if (scope === 'INTER_FAMILLES' && !targetAlliedFamilyId) {
      setError('Veuillez indiquer la famille alliée partenaire pour le partage Inter-Familles.');
      return;
    }

    const mentions: MemberMention[] = parseMentionsFromText(content, members);

    const resolvedTitle =
      title.trim() ||
      (content.trim().length > 60
        ? content.trim().substring(0, 57) + '...'
        : postType === 'COMMUNIQUE_OFFICIEL'
        ? 'Communiqué Officiel du Conseil'
        : 'Actualité Familiale');

    const alliedFamily = alliedFamilies.find((f) => f.id === targetAlliedFamilyId);
    const relatedEvent = events.find((ev) => ev.id === relatedEventId);
    const relatedMember = members.find((m) => m.id === relatedMemberId);

    addPost({
      title: resolvedTitle,
      content: content.trim(),
      postType,
      scope,
      status: 'PUBLIE',
      moderationStatus: 'APPROUVE',
      authorId: currentUser.id || 'usr-default',
      authorName: currentUser.name || 'Membre Nzala',
      authorRole: currentUser.role,
      authorAvatar: currentUser.avatarUrl,
      authorType: isOfficial && isCouncilOrAdmin ? 'CONSEIL_FAMILLE' : 'MEMBRE',
      authorFamilyId: currentUser.familyId,
      authorFamilyName: currentUser.familyName,
      targetAlliedFamilyId: targetAlliedFamilyId || undefined,
      targetAlliedFamilyName: alliedFamily?.name,
      targetBranchId: targetBranchId || undefined,
      relatedEventId: relatedEventId || undefined,
      relatedEventTitle: relatedEvent?.title,
      relatedMemberId: relatedMemberId || undefined,
      relatedMemberName: relatedMember ? `${relatedMember.firstName} ${relatedMember.lastName}` : undefined,
      imageUrl: mediaList.length > 0 ? mediaList[0].url : undefined,
      media: mediaList.length > 0 ? mediaList : undefined,
      linkPreview: linkPreview || undefined,
      mentions: mentions.length > 0 ? mentions : undefined,
      isOfficial: Boolean(isOfficial && isCouncilOrAdmin),
      isPinned: false,
    });

    // Reset
    setContent('');
    setTitle('');
    setMediaList([]);
    setLinkPreview(null);
    setShowEmojiPicker(false);
    setSuccess(true);
    if (isCompact) setIsExpanded(false);

    setTimeout(() => {
      setSuccess(false);
      if (onPostCreated) onPostCreated();
    }, 1200);
  };

  return (
    <div
      id="post-composer-container"
      className="overflow-hidden rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-5 shadow-xs transition"
    >
      {/* Header / Avatar & Quick input */}
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-blue-600 text-white font-bold flex items-center justify-center shrink-0 shadow-xs text-sm overflow-hidden">
          {currentUser.avatarUrl ? (
            <img src={currentUser.avatarUrl} alt={currentUser.name} className="w-full h-full object-cover" />
          ) : (
            currentUser.firstName?.charAt(0) || currentUser.name?.charAt(0) || 'N'
          )}
        </div>

        <div className="flex-1 min-w-0">
          {!isExpanded ? (
            <button
              type="button"
              onClick={() => setIsExpanded(true)}
              className="w-full text-left px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200/70 text-slate-500 text-xs sm:text-sm font-medium transition cursor-pointer min-h-[44px] flex items-center"
            >
              {placeholder}
            </button>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3">
              {/* Type de publication & Visibilité */}
              <div className="flex flex-wrap items-center gap-2 pb-2 border-b border-slate-100">
                <select
                  value={postType}
                  onChange={(e) => setPostType(e.target.value as PostType)}
                  className="px-2.5 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-800 outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="ACTUALITE_FAMILIALE">📰 Actualité Familiale</option>
                  <option value="FELICITATION">🎉 Félicitation</option>
                  <option value="NAISSANCE">👶 Naissance</option>
                  <option value="MARIAGE">💍 Mariage & Dot</option>
                  <option value="ANNONCE">📢 Annonce</option>
                  <option value="ANNIVERSAIRE">🎂 Anniversaire</option>
                  <option value="MEMOIRE_FAMILIALE">🕊️ Mémoire & Transmission</option>
                  {isCouncilOrAdmin && (
                    <option value="COMMUNIQUE_OFFICIEL">📜 Communiqué Officiel (Conseil)</option>
                  )}
                </select>

                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-blue-50 border border-blue-200 text-xs font-semibold text-blue-900">
                  {scope === 'PUBLIC' && <Globe className="w-3.5 h-3.5 text-blue-600" />}
                  {scope === 'NZALA_INTERNE' && <Users className="w-3.5 h-3.5 text-blue-600" />}
                  {scope === 'INTER_FAMILLES' && <Users className="w-3.5 h-3.5 text-indigo-600" />}
                  {scope === 'PRIVE' && <Lock className="w-3.5 h-3.5 text-slate-600" />}

                  <select
                    value={scope}
                    onChange={(e) => setScope(e.target.value as PostScope)}
                    className="bg-transparent border-none outline-none font-bold cursor-pointer text-slate-800"
                  >
                    <option value="NZALA_INTERNE">Famille Nzala (Interne)</option>
                    <option value="PUBLIC">Public (Ouvert)</option>
                    <option value="INTER_FAMILLES">Inter-Familles (Nzala + Alliée)</option>
                    <option value="FAMILLE_ALLIEE">Famille Alliée Spécifique</option>
                    <option value="BRANCHE">Branche Spécifique</option>
                    <option value="PRIVE">Cercle Privé</option>
                  </select>
                </div>

                {isCouncilOrAdmin && postType === 'COMMUNIQUE_OFFICIEL' && (
                  <label className="flex items-center gap-1.5 text-xs font-semibold text-blue-800 bg-blue-50 px-2.5 py-1 rounded-xl border border-blue-200 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isOfficial}
                      onChange={(e) => setIsOfficial(e.target.checked)}
                      className="rounded text-blue-600"
                    />
                    Sceau Officiel du Conseil
                  </label>
                )}
              </div>

              {/* Sélecteur de famille alliée si inter-famille */}
              {(scope === 'INTER_FAMILLES' || scope === 'FAMILLE_ALLIEE') && (
                <div className="p-2.5 rounded-xl bg-indigo-50/70 border border-indigo-200 flex flex-col sm:flex-row sm:items-center gap-2 text-xs">
                  <span className="font-semibold text-indigo-900">Famille alliée partenaire :</span>
                  <select
                    value={targetAlliedFamilyId}
                    onChange={(e) => setTargetAlliedFamilyId(e.target.value)}
                    className="px-2 py-1 rounded-lg bg-white border border-indigo-300 font-medium text-slate-800 outline-none"
                    required
                  >
                    <option value="">-- Choisir la famille alliée --</option>
                    {alliedFamilies.map((fam) => (
                      <option key={fam.id} value={fam.id}>
                        {fam.name} ({fam.originLocation})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Titre facultatif */}
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Titre de la publication (facultatif)"
                className="w-full text-xs sm:text-sm font-semibold text-slate-900 placeholder:text-slate-400 bg-transparent border-b border-slate-100 pb-1.5 outline-none focus:border-blue-500"
              />

              {/* Champ texte principal avec autocomplétion des mentions */}
              <MentionsInput
                value={content}
                onChange={setContent}
                members={members}
                placeholder={placeholder}
                rows={3}
              />

              {/* Emoji quick bar picker */}
              {showEmojiPicker && (
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex flex-wrap items-center gap-1.5 animate-fadeIn">
                  <span className="text-[11px] font-bold text-slate-500 mr-1">Émojis :</span>
                  {COMMON_EMOJIS.map((em) => (
                    <button
                      key={em}
                      type="button"
                      onClick={() => handleInsertEmoji(em)}
                      className="w-8 h-8 rounded-lg hover:bg-slate-200 flex items-center justify-center text-base transition hover:scale-115 active:scale-95 cursor-pointer"
                    >
                      {em}
                    </button>
                  ))}
                </div>
              )}

              {/* Prévisualisation des Médias attachés avec vidéos et photos */}
              {mediaList.length > 0 && (
                <div className="space-y-2 pt-2">
                  <div className="flex items-center justify-between text-xs text-slate-500 font-semibold">
                    <span>Médias attachés ({mediaList.length})</span>
                    <span className="text-[11px] text-slate-400">Photos & Vidéos prêtes à être partagées</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                    {mediaList.map((media, idx) => (
                      <div
                        key={media.id || idx}
                        className="relative group rounded-xl overflow-hidden border border-slate-200 aspect-video bg-slate-950 flex items-center justify-center"
                      >
                        {media.type === 'VIDEO' ? (
                          <div className="relative w-full h-full">
                            <video src={media.url} controls className="w-full h-full object-cover" />
                            <span className="absolute top-1 left-1 bg-black/70 text-white text-[9px] font-bold px-1.5 py-0.5 rounded flex items-center gap-1">
                              <Film className="w-3 h-3 text-rose-400" /> Vidéo
                            </span>
                          </div>
                        ) : (
                          <img src={media.url} alt="" className="w-full h-full object-cover" />
                        )}
                        <button
                          type="button"
                          onClick={() => handleRemoveMedia(idx)}
                          className="absolute top-1 right-1 p-1 rounded-full bg-slate-950/80 text-white hover:bg-rose-600 transition cursor-pointer z-10"
                          title="Supprimer ce média"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Upload en cours spinner */}
              {isUploading && (
                <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-xs font-semibold text-blue-800 flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin text-blue-600 shrink-0" />
                  <span>Traitement et optimisation des fichiers multimédias en cours...</span>
                </div>
              )}

              {/* Prévisualisation du Lien attaché */}
              {linkPreview && (
                <div className="relative">
                  <div className="p-3 rounded-xl border border-slate-200 bg-slate-50 flex items-center gap-3">
                    {linkPreview.imageUrl && (
                      <img src={linkPreview.imageUrl} alt="" className="w-14 h-14 rounded-lg object-cover shrink-0" />
                    )}
                    <div className="flex-1 min-w-0">
                      <span className="text-[11px] font-bold text-blue-700 uppercase">{linkPreview.domain}</span>
                      <p className="text-xs font-semibold text-slate-900 truncate">{linkPreview.title}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setLinkPreview(null)}
                      className="p-1 rounded-full hover:bg-slate-200 text-slate-500 cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* Input d'ajout de lien rapide */}
              {showLinkInput && !linkPreview && (
                <div className="p-3 rounded-xl bg-blue-50/60 border border-blue-200 flex items-center gap-2 animate-fadeIn">
                  <Link2 className="w-4 h-4 text-blue-600 shrink-0" />
                  <input
                    type="url"
                    value={linkInput}
                    onChange={(e) => setLinkInput(e.target.value)}
                    placeholder="Collez l'adresse URL du lien..."
                    className="flex-1 text-xs sm:text-sm bg-white px-2.5 py-1.5 rounded-lg border border-blue-300 outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleAttachLink}
                    disabled={isGeneratingLink || !linkInput.trim()}
                    className="px-3 py-1.5 rounded-lg bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 disabled:opacity-50 transition cursor-pointer"
                  >
                    {isGeneratingLink ? 'Extraction...' : 'Ajouter'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowLinkInput(false)}
                    className="p-1 text-slate-500 hover:text-slate-700 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* Galerie prédéfinie pour démo */}
              {showPresetPicker && (
                <div className="p-3 rounded-xl bg-blue-50/60 border border-blue-200 animate-fadeIn">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-blue-900 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-blue-600" /> Galerie Familiale de Démonstration
                    </span>
                    <button type="button" onClick={() => setShowPresetPicker(false)} className="text-xs text-slate-500 cursor-pointer">
                      Fermer
                    </button>
                  </div>
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                    {[...CURATED_FAMILY_MEDIA.reunions, ...CURATED_FAMILY_MEDIA.ceremonies].map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => handleAddPresetMedia(item)}
                        className="aspect-square rounded-lg overflow-hidden border border-blue-300 hover:scale-105 transition cursor-pointer"
                      >
                        <img src={item.url} alt="" className="w-full h-full object-cover" />
                      </button>
                    ))}
                    {CURATED_FAMILY_MEDIA.videoArchives.map((vid) => (
                      <button
                        key={vid.id}
                        type="button"
                        onClick={() => handleAddPresetMedia(vid)}
                        className="aspect-square rounded-lg overflow-hidden border border-blue-300 bg-slate-900 relative flex items-center justify-center hover:scale-105 transition cursor-pointer"
                      >
                        <Video className="w-6 h-6 text-blue-400" />
                        <span className="absolute bottom-1 text-[9px] text-white font-bold bg-black/60 px-1 rounded">Vidéo</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Messages d'erreur & succès */}
              {error && (
                <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-xs font-semibold text-rose-800 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {success && (
                <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-semibold text-emerald-800 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 shrink-0" />
                  <span>Votre publication a été partagée avec succès dans la famille !</span>
                </div>
              )}

              {/* Barre d'outils inférieure & Bouton Publier */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
                {/* Boutons d'insertion */}
                <div className="flex items-center gap-1 sm:gap-2">
                  {/* Photos */}
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    className="hidden"
                    onChange={(e) => handleFileUpload(e.target.files, 'IMAGE')}
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="p-2 rounded-xl text-emerald-700 bg-emerald-50 hover:bg-emerald-100 transition flex items-center gap-1.5 text-xs font-semibold cursor-pointer min-h-[38px]"
                    title="Ajouter une photo"
                  >
                    <ImageIcon className="w-4 h-4 text-emerald-600" />
                    <span className="hidden sm:inline">Photo</span>
                  </button>

                  {/* Vidéos */}
                  <input
                    ref={videoInputRef}
                    type="file"
                    accept="video/*"
                    multiple
                    className="hidden"
                    onChange={(e) => handleFileUpload(e.target.files, 'VIDEO')}
                  />
                  <button
                    type="button"
                    onClick={() => videoInputRef.current?.click()}
                    className="p-2 rounded-xl text-rose-700 bg-rose-50 hover:bg-rose-100 transition flex items-center gap-1.5 text-xs font-semibold cursor-pointer min-h-[38px]"
                    title="Ajouter une ou plusieurs vidéos"
                  >
                    <Video className="w-4 h-4 text-rose-600" />
                    <span className="hidden sm:inline">Vidéo</span>
                  </button>

                  {/* Émojis */}
                  <button
                    type="button"
                    onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                    className="p-2 rounded-xl text-amber-700 bg-amber-50 hover:bg-amber-100 transition flex items-center gap-1.5 text-xs font-semibold cursor-pointer min-h-[38px]"
                    title="Insérer un émoji"
                  >
                    <Smile className="w-4 h-4 text-amber-600" />
                    <span className="hidden sm:inline">Émoji</span>
                  </button>

                  {/* Liens */}
                  <button
                    type="button"
                    onClick={() => setShowLinkInput(!showLinkInput)}
                    className="p-2 rounded-xl text-blue-700 bg-blue-50 hover:bg-blue-100 transition flex items-center gap-1.5 text-xs font-semibold cursor-pointer min-h-[38px]"
                    title="Partager un lien web"
                  >
                    <Link2 className="w-4 h-4 text-blue-600" />
                    <span className="hidden sm:inline">Lien</span>
                  </button>

                  {/* Galerie Preset */}
                  <button
                    type="button"
                    onClick={() => setShowPresetPicker(!showPresetPicker)}
                    className="p-2 rounded-xl text-blue-800 bg-blue-50 hover:bg-blue-100 transition flex items-center gap-1.5 text-xs font-semibold cursor-pointer min-h-[38px]"
                    title="Médias d'archives suggérés"
                  >
                    <Sparkles className="w-4 h-4 text-blue-600" />
                    <span className="hidden sm:inline">Archives</span>
                  </button>
                </div>

                {/* Actions : Annuler & Publier */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setIsExpanded(false);
                      setContent('');
                      setMediaList([]);
                      setLinkPreview(null);
                      setShowEmojiPicker(false);
                    }}
                    className="px-3 py-2 rounded-xl text-slate-500 hover:bg-slate-100 text-xs font-semibold transition cursor-pointer min-h-[38px]"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    disabled={isUploading || isGeneratingLink || (!content.trim() && mediaList.length === 0 && !linkPreview)}
                    className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-bold shadow-xs hover:shadow flex items-center gap-1.5 disabled:opacity-50 transition cursor-pointer min-h-[38px]"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Publier</span>
                  </button>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
