import React, { useState } from 'react';
import { FamilyPost, PostScope } from '../../types';
import { useFamily } from '../../context/FamilyContext';
import {
  X,
  Share2,
  Copy,
  Check,
  Send,
  Lock,
  Globe,
  Users,
  AlertTriangle,
} from 'lucide-react';

interface PostShareModalProps {
  post: FamilyPost;
  isOpen: boolean;
  onClose: () => void;
}

export const PostShareModal: React.FC<PostShareModalProps> = ({ post, isOpen, onClose }) => {
  const { currentUser, addPost } = useFamily();
  const [commentary, setCommentary] = useState('');
  const [copied, setCopied] = useState(false);
  const [scope, setScope] = useState<PostScope>(post.scope);

  if (!isOpen || !post) return null;

  const isPrivatePost = post.scope === 'PRIVE';

  const handleRepost = (e: React.FormEvent) => {
    e.preventDefault();

    addPost({
      title: `Partage de : ${post.title || post.authorName}`,
      content: commentary.trim() || 'A partagé cette publication.',
      postType: post.postType,
      // La portée ne peut pas être plus large que la portée d'origine
      scope: isPrivatePost ? 'PRIVE' : scope,
      status: 'PUBLIE',
      moderationStatus: 'APPROUVE',
      authorId: currentUser.id || 'usr-default',
      authorName: currentUser.name || 'Membre Nzala',
      authorRole: currentUser.role,
      authorFamilyId: currentUser.familyId,
      authorFamilyName: currentUser.familyName,
      sharedPostId: post.id,
      sharedPost: post,
      quoteComment: commentary.trim() || undefined,
      isOfficial: false,
      isPinned: false,
    });

    onClose();
  };

  const handleCopyLink = () => {
    const postUrl = `${window.location.origin}/#post-${post.id}`;
    navigator.clipboard.writeText(postUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      id="post-share-modal"
      className="fixed inset-0 z-50 bg-stone-950/80 backdrop-blur-sm flex items-center justify-center p-3 select-none"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-3xl bg-white shadow-2xl border border-stone-200 overflow-hidden animate-fadeIn"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-stone-100 bg-stone-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center font-bold text-xs">
              <Share2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-stone-900">
                Partager la publication
              </h3>
              <p className="text-[11px] text-stone-500">Fil familial NzalaFamilly</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-200/60 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleRepost} className="p-4 sm:p-5 space-y-4">
          {/* Avertissement de sécurité si contenu privé */}
          {isPrivatePost && (
            <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-800 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
              <span>
                <strong>Confidentialité garantie :</strong> Cette publication d'origine a une visibilité privée. Le partage restera strictement cantonné au cercle privé d'origine.
              </span>
            </div>
          )}

          {/* Commentaire de republication */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Votre commentaire (facultatif)
            </label>
            <textarea
              value={commentary}
              onChange={(e) => setCommentary(e.target.value)}
              placeholder="Ajoutez un message personnel..."
              rows={2}
              className="w-full px-3 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs sm:text-sm text-stone-900 outline-none focus:border-blue-500 resize-none"
            />
          </div>

          {/* Carte miniature de la publication d'origine */}
          <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200 space-y-1.5">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-amber-600 text-white text-xs font-bold flex items-center justify-center">
                {post.authorName.charAt(0)}
              </div>
              <span className="text-xs font-bold text-stone-900">{post.authorName}</span>
              <span className="text-[11px] text-stone-500">• {post.postType}</span>
            </div>
            {post.title && <p className="text-xs font-bold text-stone-800">{post.title}</p>}
            <p className="text-xs text-stone-600 line-clamp-2">{post.content}</p>
          </div>

          {/* Bouton copier le lien */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-blue-50/60 border border-blue-200">
            <div className="text-xs text-blue-900">
              <p className="font-bold">Lien direct interne</p>
              <p className="text-[11px] text-blue-700">Accessible uniquement aux membres autorisés</p>
            </div>
            <button
              type="button"
              onClick={handleCopyLink}
              className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copié !' : 'Copier le lien'}</span>
            </button>
          </div>

          {/* Footer actions */}
          <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-stone-600 hover:bg-stone-100 text-xs font-semibold transition cursor-pointer"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-bold shadow flex items-center gap-1.5 transition cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>Republier sur mon fil</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
