import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { PostScope, ReactionType } from '../../types';
import {
  Smile,
  Plus,
  Send,
  X,
  Lock,
  Globe,
  Users,
  Sparkles,
  Trash2,
} from 'lucide-react';
import { STATUS_MOOD_PRESETS, canUserViewStatus } from '../../services/socialService';

export const StatusTray: React.FC = () => {
  const { statuses = [], currentUser, addStatus, deleteStatus, reactToStatus } = useFamily();

  const [isEditing, setIsEditing] = useState(false);
  const [statusText, setStatusText] = useState('');
  const [selectedMood, setSelectedMood] = useState(STATUS_MOOD_PRESETS[0]);
  const [scope, setScope] = useState<PostScope>('NZALA_INTERNE');

  // Filtrer les statuts visibles pour l'utilisateur
  const visibleStatuses = statuses.filter((s) => canUserViewStatus(s, currentUser));

  // Statut actuel de l'utilisateur
  const myStatus = visibleStatuses.find(
    (s) => s.authorId === currentUser.id || (currentUser.memberId && s.memberId === currentUser.memberId)
  );

  const handleSaveStatus = (e: React.FormEvent) => {
    e.preventDefault();
    if (!statusText.trim() && !selectedMood) return;

    addStatus({
      authorId: currentUser.id || 'usr-default',
      authorName: currentUser.name || 'Membre Nzala',
      authorAvatar: undefined,
      authorRole: currentUser.role,
      authorFamilyName: currentUser.familyName,
      memberId: currentUser.memberId,
      text: statusText.trim(),
      moodEmoji: selectedMood.emoji,
      moodLabel: selectedMood.label,
      scope,
    });

    setStatusText('');
    setIsEditing(false);
  };

  return (
    <div
      id="status-tray-container"
      className="w-full overflow-hidden rounded-2xl border border-stone-200 bg-white p-3.5 sm:p-4 shadow-sm"
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center text-xs font-bold">
            <Smile className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-bold text-stone-800 uppercase tracking-wider">
            Statuts & Humeurs du Jour
          </span>
        </div>

        {!isEditing && (
          <button
            type="button"
            onClick={() => setIsEditing(true)}
            className="px-2.5 py-1 rounded-xl bg-blue-50 text-blue-700 hover:bg-blue-100 text-xs font-semibold flex items-center gap-1 transition cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{myStatus ? 'Modifier mon statut' : 'Définir mon statut'}</span>
          </button>
        )}
      </div>

      {/* Formulaire d'édition de Mon Statut */}
      {isEditing && (
        <form onSubmit={handleSaveStatus} className="mb-3 p-3.5 rounded-2xl bg-stone-50 border border-stone-200 space-y-3 animate-fadeIn">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-stone-700">Votre statut pour aujourd'hui :</span>
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="text-stone-400 hover:text-stone-700 text-xs"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Choix d'humeur rapide */}
          <div className="flex flex-wrap gap-1.5">
            {STATUS_MOOD_PRESETS.map((preset) => (
              <button
                key={preset.label}
                type="button"
                onClick={() => setSelectedMood(preset)}
                className={`px-2.5 py-1 rounded-xl text-xs flex items-center gap-1 transition cursor-pointer ${
                  selectedMood.label === preset.label
                    ? 'bg-amber-500 text-white font-bold shadow-sm'
                    : 'bg-white border border-stone-200 text-stone-700 hover:bg-stone-100'
                }`}
              >
                <span>{preset.emoji}</span>
                <span className="text-[11px]">{preset.label}</span>
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              value={statusText}
              onChange={(e) => setStatusText(e.target.value)}
              placeholder="Ex: De passage à Boma pour saluer les aînés..."
              className="flex-1 px-3 py-2 rounded-xl bg-white border border-stone-200 text-xs sm:text-sm text-stone-900 outline-none focus:border-blue-500"
            />
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1 transition cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Enregistrer</span>
            </button>
          </div>
        </form>
      )}

      {/* Affichage des statuts actifs de la famille */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
        {visibleStatuses.map((item) => {
          const isMine = item.authorId === currentUser.id;
          return (
            <div
              key={item.id}
              className={`p-3 rounded-2xl border transition flex items-start justify-between gap-2.5 ${
                isMine ? 'bg-amber-50/70 border-amber-200' : 'bg-stone-50/70 border-stone-200 hover:bg-stone-100/60'
              }`}
            >
              <div className="flex items-start gap-2.5 min-w-0">
                <div className="relative">
                  <div className="w-8 h-8 rounded-full overflow-hidden bg-stone-200 flex items-center justify-center font-bold text-xs text-stone-700 shrink-0">
                    {item.authorAvatar ? (
                      <img src={item.authorAvatar} alt="" className="w-full h-full object-cover" />
                    ) : (
                      item.authorName.charAt(0)
                    )}
                  </div>
                  {item.moodEmoji && (
                    <span className="absolute -bottom-1 -right-1 text-xs">{item.moodEmoji}</span>
                  )}
                </div>

                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs font-bold text-stone-900 truncate">
                      {isMine ? 'Moi' : item.authorName}
                    </p>
                    {item.moodLabel && (
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-100 text-amber-800 font-semibold truncate">
                        {item.moodLabel}
                      </span>
                    )}
                  </div>
                  {item.text && (
                    <p className="text-xs text-stone-700 mt-0.5 leading-tight font-sans line-clamp-2">
                      {item.text}
                    </p>
                  )}
                </div>
              </div>

              {isMine && (
                <button
                  type="button"
                  onClick={() => deleteStatus(item.id)}
                  className="p-1 rounded-lg text-stone-400 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
                  title="Supprimer mon statut"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
