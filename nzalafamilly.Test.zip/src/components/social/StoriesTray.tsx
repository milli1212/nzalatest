import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { Plus, Sparkles } from 'lucide-react';
import { StoryViewerModal } from './StoryViewerModal';
import { StoryCreatorModal } from './StoryCreatorModal';
import { filterVisibleActiveStories } from '../../services/socialService';

export const StoriesTray: React.FC = () => {
  const { stories = [], currentUser } = useFamily();

  const [viewerOpen, setViewerOpen] = useState(false);
  const [activeStoryIndex, setActiveStoryIndex] = useState(0);
  const [creatorOpen, setCreatorOpen] = useState(false);

  // Filter visible & active stories
  const visibleStories = filterVisibleActiveStories(stories, currentUser);

  // User's active story index if present
  const userStoryIndex = visibleStories.findIndex((s) => s.authorId === currentUser.id);
  const hasUserStory = userStoryIndex !== -1;

  const handleOpenViewer = (index: number) => {
    setActiveStoryIndex(index);
    setViewerOpen(true);
  };

  return (
    <>
      <div
        id="stories-tray-container"
        className="w-full overflow-hidden rounded-2xl border border-slate-200/80 bg-white p-3 sm:p-4 shadow-2xs mb-4"
      >
        {/* Header Label */}
        <div className="flex items-center justify-between mb-2.5 px-0.5">
          <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5 uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" /> Stories Familiales
          </span>
          <span className="text-[11px] text-slate-400 font-medium">Éphémère 24h</span>
        </div>

        {/* Horizontal Scrollable Circular Avatars Tray */}
        <div className="flex items-center gap-3.5 overflow-x-auto pb-1 pt-0.5 scrollbar-none no-scrollbar">
          {/* 1. Bouton Créer / Votre Story */}
          <div className="flex flex-col items-center shrink-0 group cursor-pointer">
            <button
              type="button"
              onClick={() => {
                if (hasUserStory) {
                  handleOpenViewer(userStoryIndex);
                } else {
                  setCreatorOpen(true);
                }
              }}
              className="relative focus:outline-none"
              aria-label={hasUserStory ? 'Voir ma story' : 'Créer une story'}
            >
              <div
                className={`p-0.5 rounded-full transition duration-200 group-hover:scale-105 ${
                  hasUserStory
                    ? 'bg-gradient-to-tr from-amber-400 via-rose-500 to-blue-600 ring-2 ring-blue-500/20'
                    : 'border-2 border-dashed border-slate-300 hover:border-blue-500'
                }`}
              >
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full overflow-hidden bg-slate-100 border-2 border-white flex items-center justify-center font-bold text-xs text-slate-700">
                  {(currentUser.avatarUrl || currentUser.avatar) ? (
                    <img
                      src={currentUser.avatarUrl || currentUser.avatar}
                      alt={currentUser.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span>{currentUser.firstName ? currentUser.firstName.charAt(0) : currentUser.name.charAt(0)}</span>
                  )}
                </div>
              </div>

              {/* Plus Badge Icon on bottom-right of avatar */}
              <div
                onClick={(e) => {
                  e.stopPropagation();
                  setCreatorOpen(true);
                }}
                className="absolute -bottom-0.5 -right-0.5 w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center border-2 border-white shadow-xs group-hover:bg-blue-700 group-hover:scale-110 transition"
                title="Ajouter une story"
              >
                <Plus className="w-3.5 h-3.5 stroke-[3]" />
              </div>
            </button>

            <span className="text-[11px] font-medium text-slate-700 text-center max-w-[68px] truncate mt-1.5 leading-tight">
              {hasUserStory ? 'Votre story' : 'Ajouter'}
            </span>
          </div>

          {/* 2. Liste des Stories des autres membres */}
          {visibleStories
            .map((story, index) => ({ story, originalIndex: index }))
            .filter(({ story }) => story.authorId !== currentUser.id)
            .map(({ story, originalIndex }) => {
              const isSeen = story.viewedByUserIds?.includes(currentUser.id || '');

              return (
                <div
                  key={story.id}
                  onClick={() => handleOpenViewer(originalIndex)}
                  className="flex flex-col items-center shrink-0 group cursor-pointer"
                >
                  <div
                    className={`p-[2.5px] rounded-full transition duration-200 group-hover:scale-105 ${
                      isSeen
                        ? 'bg-slate-300'
                        : 'bg-gradient-to-tr from-amber-400 via-rose-500 to-blue-600 shadow-xs'
                    }`}
                  >
                    <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full overflow-hidden bg-slate-200 border-2 border-white flex items-center justify-center font-bold text-xs text-slate-800">
                      {story.authorAvatar ? (
                        <img
                          src={story.authorAvatar}
                          alt={story.authorName}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        story.authorName.charAt(0)
                      )}
                    </div>
                  </div>

                  <span className="text-[11px] font-medium text-slate-700 text-center max-w-[68px] truncate mt-1.5 leading-tight">
                    {story.authorName.split(' ')[0]}
                  </span>
                </div>
              );
            })}
        </div>
      </div>

      <StoryViewerModal
        isOpen={viewerOpen}
        stories={visibleStories}
        initialStoryIndex={activeStoryIndex}
        onClose={() => setViewerOpen(false)}
      />

      <StoryCreatorModal
        isOpen={creatorOpen}
        onClose={() => setCreatorOpen(false)}
      />
    </>
  );
};
