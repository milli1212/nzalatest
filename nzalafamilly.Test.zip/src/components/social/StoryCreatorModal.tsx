import React, { useState, useRef } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { PostScope, StorySlide, StorySlideType } from '../../types';
import {
  X,
  Image as ImageIcon,
  Video,
  Type,
  Sparkles,
  Send,
  Lock,
  Globe,
  Users,
  AlertCircle,
} from 'lucide-react';
import { MediaStorage, CURATED_FAMILY_MEDIA } from '../../services/mediaStorage';

interface StoryCreatorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const GRADIENT_PRESETS = [
  'linear-gradient(135deg, #1877F2, #7c3aed)',
  'linear-gradient(135deg, #d97706, #dc2626)',
  'linear-gradient(135deg, #059669, #0284c7)',
  'linear-gradient(135deg, #4f46e5, #ec4899)',
  'linear-gradient(135deg, #1e293b, #0f172a)',
];

export const StoryCreatorModal: React.FC<StoryCreatorModalProps> = ({ isOpen, onClose }) => {
  const { currentUser, addStory, alliedFamilies } = useFamily();

  const [slideType, setSlideType] = useState<StorySlideType>('IMAGE');
  const [contentUrl, setContentUrl] = useState('');
  const [textContent, setTextContent] = useState('');
  const [selectedGradient, setSelectedGradient] = useState(GRADIENT_PRESETS[0]);
  const [caption, setCaption] = useState('');
  const [scope, setScope] = useState<PostScope>('NZALA_INTERNE');
  const [targetAlliedFamilyId, setTargetAlliedFamilyId] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setError(null);
    try {
      const validation = MediaStorage.validateFile(file);
      if (!validation.isValid) {
        setError(validation.error || 'Fichier invalide.');
        return;
      }
      const uploaded = await MediaStorage.uploadFile(file);
      setContentUrl(uploaded.url);
      setSlideType(uploaded.type === 'VIDEO' ? 'VIDEO' : 'IMAGE');
    } catch {
      setError('Erreur lors du chargement du fichier.');
    } finally {
      setIsUploading(false);
    }
  };

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (slideType === 'TEXT' && !textContent.trim()) {
      setError('Veuillez saisir le texte de votre story.');
      return;
    }

    if ((slideType === 'IMAGE' || slideType === 'VIDEO') && !contentUrl) {
      setError('Veuillez sélectionner ou charger une photo/vidéo.');
      return;
    }

    const slide: StorySlide = {
      id: `slide-${Date.now()}`,
      type: slideType,
      contentUrl: slideType !== 'TEXT' ? contentUrl : undefined,
      textContent: slideType === 'TEXT' ? textContent.trim() : undefined,
      backgroundColor: slideType === 'TEXT' ? selectedGradient : undefined,
      caption: caption.trim() || undefined,
      durationSeconds: slideType === 'VIDEO' ? 15 : 6,
      createdAt: new Date().toISOString(),
    };

    addStory({
      authorId: currentUser.id || 'usr-default',
      authorName: currentUser.name || 'Membre Nzala',
      authorAvatar: undefined,
      authorRole: currentUser.role,
      authorFamilyName: currentUser.familyName,
      memberId: currentUser.memberId,
      slides: [slide],
      scope,
      targetFamilyId: targetAlliedFamilyId || undefined,
    });

    onClose();
  };

  return (
    <div
      id="story-creator-modal"
      className="fixed inset-0 z-50 bg-stone-950/80 backdrop-blur-sm flex items-center justify-center p-3 select-none"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-3xl bg-white shadow-2xl border border-stone-200 overflow-hidden animate-fadeIn"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-stone-100 bg-stone-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-bold text-xs shadow-sm">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-stone-900">
                Créer une Story NzalaFamilly
              </h3>
              <p className="text-[11px] text-stone-500">Visible pendant 24 heures par la famille</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-200/60 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Choix du mode : Image / Vidéo / Texte */}
        <div className="p-4 sm:p-5 space-y-4 max-h-[75vh] overflow-y-auto">
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => {
                setSlideType('IMAGE');
                if (!contentUrl) {
                  setContentUrl(CURATED_FAMILY_MEDIA.reunions[0].url);
                }
              }}
              className={`p-3 rounded-2xl border text-xs font-bold flex flex-col items-center gap-1.5 transition cursor-pointer ${
                slideType === 'IMAGE'
                  ? 'bg-blue-50 border-blue-500 text-blue-800'
                  : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'
              }`}
            >
              <ImageIcon className="w-5 h-5 text-emerald-600" />
              <span>Photo</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setSlideType('VIDEO');
                if (!contentUrl) {
                  setContentUrl(CURATED_FAMILY_MEDIA.videoArchives[0].url);
                }
              }}
              className={`p-3 rounded-2xl border text-xs font-bold flex flex-col items-center gap-1.5 transition cursor-pointer ${
                slideType === 'VIDEO'
                  ? 'bg-rose-50 border-rose-500 text-rose-800'
                  : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'
              }`}
            >
              <Video className="w-5 h-5 text-rose-600" />
              <span>Vidéo</span>
            </button>

            <button
              type="button"
              onClick={() => setSlideType('TEXT')}
              className={`p-3 rounded-2xl border text-xs font-bold flex flex-col items-center gap-1.5 transition cursor-pointer ${
                slideType === 'TEXT'
                  ? 'bg-amber-50 border-amber-500 text-amber-800'
                  : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'
              }`}
            >
              <Type className="w-5 h-5 text-amber-600" />
              <span>Texte coloré</span>
            </button>
          </div>

          {/* Mode Média (Photo / Vidéo) */}
          {(slideType === 'IMAGE' || slideType === 'VIDEO') && (
            <div className="space-y-3">
              <input
                ref={fileInputRef}
                type="file"
                accept={slideType === 'IMAGE' ? 'image/*' : 'video/*'}
                className="hidden"
                onChange={handleFileUpload}
              />

              <div className="relative aspect-[9/16] max-h-64 sm:max-h-72 mx-auto rounded-2xl overflow-hidden bg-stone-900 border border-stone-200 flex items-center justify-center">
                {contentUrl ? (
                  slideType === 'VIDEO' ? (
                    <video src={contentUrl} className="w-full h-full object-cover" autoPlay muted loop />
                  ) : (
                    <img src={contentUrl} alt="" className="w-full h-full object-cover" />
                  )
                ) : (
                  <p className="text-xs text-stone-400">Aucun média sélectionné</p>
                )}

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute bottom-3 px-3 py-1.5 rounded-xl bg-stone-950/80 text-white text-xs font-semibold hover:bg-black transition cursor-pointer"
                >
                  {isUploading ? 'Chargement...' : 'Téléverser un fichier'}
                </button>
              </div>

              {/* Suggestions rapides de médias démo */}
              <div>
                <span className="text-[11px] font-semibold text-stone-500">Ou choisir une photo d'exemple :</span>
                <div className="flex gap-2 overflow-x-auto py-1.5">
                  {CURATED_FAMILY_MEDIA.reunions.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setContentUrl(item.url);
                        setSlideType('IMAGE');
                      }}
                      className="w-12 h-16 rounded-xl overflow-hidden shrink-0 border border-stone-300 hover:scale-105 transition cursor-pointer"
                    >
                      <img src={item.url} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                  {CURATED_FAMILY_MEDIA.videoArchives.map((vid) => (
                    <button
                      key={vid.id}
                      type="button"
                      onClick={() => {
                        setContentUrl(vid.url);
                        setSlideType('VIDEO');
                      }}
                      className="w-12 h-16 rounded-xl overflow-hidden shrink-0 bg-stone-800 border border-stone-300 flex items-center justify-center text-white text-xs hover:scale-105 transition cursor-pointer"
                    >
                      ▶
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Mode Texte */}
          {slideType === 'TEXT' && (
            <div className="space-y-3">
              <div
                className="aspect-[9/16] max-h-64 sm:max-h-72 mx-auto rounded-2xl p-6 flex items-center justify-center text-center shadow-inner"
                style={{ background: selectedGradient }}
              >
                <textarea
                  value={textContent}
                  onChange={(e) => setTextContent(e.target.value)}
                  placeholder="Tapez votre message ici..."
                  rows={4}
                  className="w-full bg-transparent text-white font-serif font-bold text-lg text-center placeholder:text-white/60 resize-none outline-none"
                />
              </div>

              <div>
                <span className="text-[11px] font-semibold text-stone-500">Couleurs d'ambiance :</span>
                <div className="flex gap-2 mt-1">
                  {GRADIENT_PRESETS.map((grad, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSelectedGradient(grad)}
                      className={`w-8 h-8 rounded-full border-2 transition cursor-pointer ${
                        selectedGradient === grad ? 'border-white ring-2 ring-blue-500 scale-110' : 'border-transparent'
                      }`}
                      style={{ background: grad }}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Légende facultative */}
          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Légende / Message (facultatif)
            </label>
            <input
              type="text"
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              placeholder="Ajoutez une courte description..."
              className="w-full px-3 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs sm:text-sm text-stone-900 outline-none focus:border-blue-500"
            />
          </div>

          {/* Périmètre de visibilité */}
          <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-stone-700">
              <Lock className="w-4 h-4 text-amber-600" />
              <span>Visibilité :</span>
            </div>
            <select
              value={scope}
              onChange={(e) => setScope(e.target.value as PostScope)}
              className="px-2.5 py-1.5 rounded-xl bg-white border border-stone-300 text-xs font-bold text-stone-800 outline-none"
            >
              <option value="NZALA_INTERNE">Famille Nzala (Interne)</option>
              <option value="PUBLIC">Public</option>
              <option value="INTER_FAMILLES">Inter-Familles</option>
              <option value="FAMILLE_ALLIEE">Famille Alliée</option>
              <option value="BRANCHE">Ma Branche</option>
              <option value="PRIVE">Cercle Privé</option>
            </select>
          </div>

          {error && (
            <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-xs font-semibold text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-stone-100 bg-stone-50 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-stone-600 hover:bg-stone-200/70 text-xs font-semibold transition cursor-pointer"
          >
            Annuler
          </button>
          <button
            type="button"
            onClick={handlePublish}
            disabled={isUploading}
            className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-bold shadow flex items-center gap-1.5 transition cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>Partager dans la story</span>
          </button>
        </div>
      </div>
    </div>
  );
};
