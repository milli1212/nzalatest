import React, { useState, useEffect, useCallback, useRef } from 'react';
import { FamilyStory, StoryViewer, StoryReaction } from '../../types';
import { useFamily } from '../../context/FamilyContext';
import {
  X,
  ChevronLeft,
  ChevronRight,
  Heart,
  Sparkles,
  Lock,
  Globe,
  Users,
  Trash2,
  Volume2,
  VolumeX,
  Eye,
  Smile,
  Send,
} from 'lucide-react';
import { formatStoryTimeRemaining } from '../../services/socialService';
import { VerifiedBadge } from '../common/VerifiedBadge';

interface StoryViewerModalProps {
  stories: FamilyStory[];
  initialStoryIndex?: number;
  isOpen: boolean;
  onClose: () => void;
}

interface FloatingReaction {
  id: string;
  emoji: string;
  x: number;
}

export const StoryViewerModal: React.FC<StoryViewerModalProps> = ({
  stories,
  initialStoryIndex = 0,
  isOpen,
  onClose,
}) => {
  const { currentUser, deleteStory, viewStory, addStoryReaction } = useFamily();

  const [storyIndex, setStoryIndex] = useState(initialStoryIndex);
  const [slideIndex, setSlideIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [progress, setProgress] = useState(0);
  const [showViewersDrawer, setShowViewersDrawer] = useState(false);
  const [floatingReactions, setFloatingReactions] = useState<FloatingReaction[]>([]);
  const [replyText, setReplyText] = useState('');

  const videoRef = useRef<HTMLVideoElement>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    setStoryIndex(initialStoryIndex);
    setSlideIndex(0);
    setProgress(0);
    setShowViewersDrawer(false);
  }, [initialStoryIndex]);

  const currentStory = stories[storyIndex];
  const currentSlide = currentStory?.slides[slideIndex];

  // Marquer la story comme vue
  useEffect(() => {
    if (isOpen && currentStory && viewStory) {
      viewStory(currentStory.id);
    }
  }, [isOpen, currentStory, viewStory]);

  const handleNextSlide = useCallback(() => {
    if (!currentStory) return;
    if (slideIndex < currentStory.slides.length - 1) {
      setSlideIndex((prev) => prev + 1);
      setProgress(0);
    } else if (storyIndex < stories.length - 1) {
      setStoryIndex((prev) => prev + 1);
      setSlideIndex(0);
      setProgress(0);
    } else {
      onClose();
    }
  }, [currentStory, slideIndex, storyIndex, stories.length, onClose]);

  const handlePrevSlide = useCallback(() => {
    if (slideIndex > 0) {
      setSlideIndex((prev) => prev - 1);
      setProgress(0);
    } else if (storyIndex > 0) {
      const prevStory = stories[storyIndex - 1];
      setStoryIndex((prev) => prev - 1);
      setSlideIndex(prevStory.slides.length - 1);
      setProgress(0);
    }
  }, [slideIndex, storyIndex, stories]);

  // Horloge de progression
  useEffect(() => {
    if (!isOpen || !currentSlide || isPaused || showViewersDrawer) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    const durationSeconds = currentSlide.durationSeconds || (currentSlide.type === 'VIDEO' ? 15 : 6);
    const intervalMs = 50;
    const step = 100 / ((durationSeconds * 1000) / intervalMs);

    timerRef.current = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          handleNextSlide();
          return 0;
        }
        return prev + step;
      });
    }, intervalMs);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isOpen, currentSlide, isPaused, showViewersDrawer, handleNextSlide]);

  // Raccourcis clavier
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight' || e.key === ' ') handleNextSlide();
      if (e.key === 'ArrowLeft') handlePrevSlide();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose, handleNextSlide, handlePrevSlide]);

  if (!isOpen || !currentStory || !currentSlide) return null;

  const timeRemainingText = formatStoryTimeRemaining(currentStory);
  const isAuthor =
    currentStory.authorId === currentUser.id ||
    (currentUser.memberId && currentStory.memberId === currentUser.memberId);
  const canModerate = currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL';

  const handleDelete = () => {
    deleteStory(currentStory.id);
    onClose();
  };

  const handleSendReaction = (emoji: string) => {
    addStoryReaction(currentStory.id, emoji);
    const newFloat: FloatingReaction = {
      id: `float-${Date.now()}-${Math.random()}`,
      emoji,
      x: 30 + Math.random() * 40,
    };
    setFloatingReactions((prev) => [...prev, newFloat]);

    setTimeout(() => {
      setFloatingReactions((prev) => prev.filter((f) => f.id !== newFloat.id));
    }, 1800);
  };

  // Liste des vues réelles & complétées
  const viewsList: StoryViewer[] = currentStory.views && currentStory.views.length > 0
    ? currentStory.views
    : currentStory.viewedByUserIds.map((uid) => ({
        userId: uid,
        userName: uid === currentUser.id ? currentUser.name : 'Membre de la famille',
        userAvatar: uid === currentUser.id ? currentUser.avatarUrl : undefined,
        viewedAt: currentStory.createdAt,
      }));

  const reactionsList: StoryReaction[] = currentStory.reactions || [];

  return (
    <div
      id="story-viewer-modal"
      className="fixed inset-0 z-50 bg-stone-950 flex items-center justify-center select-none"
      onClick={onClose}
    >
      {/* Container vertical type Story mobile centré */}
      <div
        className="relative w-full max-w-md h-full sm:h-[90vh] sm:max-h-[820px] sm:rounded-3xl overflow-hidden bg-stone-900 shadow-2xl flex flex-col justify-between"
        onClick={(e) => e.stopPropagation()}
        onMouseDown={() => !showViewersDrawer && setIsPaused(true)}
        onMouseUp={() => !showViewersDrawer && setIsPaused(false)}
        onTouchStart={() => !showViewersDrawer && setIsPaused(true)}
        onTouchEnd={() => !showViewersDrawer && setIsPaused(false)}
      >
        {/* Barres de progression des slides */}
        <div className="absolute top-3 inset-x-3 z-30 flex items-center gap-1.5">
          {currentStory.slides.map((_, idx) => {
            let widthPercent = 0;
            if (idx < slideIndex) widthPercent = 100;
            else if (idx === slideIndex) widthPercent = progress;

            return (
              <div key={idx} className="h-1 flex-1 bg-white/30 rounded-full overflow-hidden">
                <div
                  className="h-full bg-white transition-all duration-75 ease-linear rounded-full"
                  style={{ width: `${widthPercent}%` }}
                />
              </div>
            );
          })}
        </div>

        {/* Header Auteur & Options */}
        <div className="absolute top-7 inset-x-3 z-30 flex items-center justify-between text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full overflow-hidden bg-blue-600 border border-white/60 flex items-center justify-center font-bold text-sm shadow">
              {currentStory.authorAvatar ? (
                <img src={currentStory.authorAvatar} alt="" className="w-full h-full object-cover" />
              ) : (
                currentStory.authorName.charAt(0)
              )}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <p className="text-xs sm:text-sm font-bold leading-tight drop-shadow-md">
                  {currentStory.authorName}
                </p>
                <VerifiedBadge
                  role={currentStory.authorRole}
                  isVerified={currentStory.isAuthorVerified ?? true}
                  size="sm"
                />
              </div>
              <div className="flex items-center gap-1.5 text-[11px] text-white/80">
                <span>{timeRemainingText}</span>
                <span>•</span>
                <span className="flex items-center gap-0.5">
                  {currentStory.scope === 'PUBLIC' && <Globe className="w-3 h-3" />}
                  {currentStory.scope === 'NZALA_INTERNE' && <Users className="w-3 h-3 text-amber-300" />}
                  {currentStory.scope === 'PRIVE' && <Lock className="w-3 h-3 text-rose-300" />}
                  {currentStory.scope}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {currentSlide.type === 'VIDEO' && (
              <button
                type="button"
                onClick={() => setIsMuted(!isMuted)}
                className="p-1.5 rounded-full bg-stone-900/60 hover:bg-stone-800 text-white transition cursor-pointer"
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
            )}

            {(isAuthor || canModerate) && (
              <button
                type="button"
                onClick={handleDelete}
                className="p-1.5 rounded-full bg-stone-900/60 hover:bg-rose-600 text-white transition cursor-pointer"
                title="Supprimer la story"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-full bg-stone-900/60 hover:bg-stone-800 text-white transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Zones de navigation gauche / droite */}
        <div className="absolute inset-0 z-20 flex">
          <div className="w-1/3 h-full cursor-pointer" onClick={handlePrevSlide} />
          <div className="w-2/3 h-full cursor-pointer" onClick={handleNextSlide} />
        </div>

        {/* Contenu principal de la Slide */}
        <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
          {currentSlide.type === 'IMAGE' && currentSlide.contentUrl && (
            <img
              src={currentSlide.contentUrl}
              alt=""
              className="w-full h-full object-cover animate-fadeIn"
            />
          )}

          {currentSlide.type === 'VIDEO' && currentSlide.contentUrl && (
            <video
              ref={videoRef}
              src={currentSlide.contentUrl}
              autoPlay
              muted={isMuted}
              playsInline
              className="w-full h-full object-cover"
            />
          )}

          {currentSlide.type === 'TEXT' && (
            <div
              className="w-full h-full p-8 flex flex-col items-center justify-center text-center animate-fadeIn"
              style={{
                background: currentSlide.backgroundColor || 'linear-gradient(135deg, #1877F2, #8b5cf6)',
                color: currentSlide.textColor || '#ffffff',
              }}
            >
              <p className="text-xl sm:text-2xl font-bold font-serif leading-relaxed max-w-xs drop-shadow-md">
                "{currentSlide.textContent}"
              </p>
            </div>
          )}

          {/* Floating animated reactions */}
          {floatingReactions.map((f) => (
            <div
              key={f.id}
              className="absolute bottom-20 z-40 text-4xl animate-bounce pointer-events-none transition-all duration-1000"
              style={{ left: `${f.x}%` }}
            >
              {f.emoji}
            </div>
          ))}

          {/* Caption & Lien en bas */}
          {(currentSlide.caption || currentSlide.linkUrl) && (
            <div className="absolute bottom-16 inset-x-4 z-30 p-3 rounded-2xl bg-stone-950/70 backdrop-blur-md text-white border border-white/10 text-center">
              {currentSlide.caption && (
                <p className="text-xs sm:text-sm leading-relaxed">{currentSlide.caption}</p>
              )}
              {currentSlide.linkUrl && (
                <a
                  href={currentSlide.linkUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-2 inline-flex items-center gap-1 text-xs font-bold text-blue-400 hover:underline"
                >
                  {currentSlide.linkText || 'Voir le lien'} →
                </a>
              )}
            </div>
          )}
        </div>

        {/* Barre inférieure pour réactions ou vues */}
        <div className="absolute bottom-3 inset-x-3 z-30 flex items-center justify-between gap-2">
          {isAuthor ? (
            <button
              type="button"
              onClick={() => {
                setIsPaused(true);
                setShowViewersDrawer(true);
              }}
              className="w-full py-2.5 px-4 rounded-2xl bg-stone-900/80 hover:bg-stone-800 backdrop-blur-md border border-white/10 text-white flex items-center justify-between transition cursor-pointer shadow-lg"
            >
              <div className="flex items-center gap-2 text-xs font-bold">
                <Eye className="w-4 h-4 text-blue-400" />
                <span>{viewsList.length} vues</span>
                {reactionsList.length > 0 && (
                  <span className="flex items-center gap-1 text-slate-300 font-normal">
                    • {reactionsList.length} réaction{reactionsList.length > 1 ? 's' : ''}
                  </span>
                )}
              </div>
              <span className="text-[11px] text-blue-400 font-semibold">Qui a vu ma story ? ↑</span>
            </button>
          ) : (
            <div className="flex items-center justify-between gap-2 w-full">
              <div className="flex-1 px-3 py-2 rounded-full bg-stone-900/70 backdrop-blur-md border border-white/10 text-xs text-white/70">
                Répondre à {currentStory.authorName}...
              </div>
              <div className="flex items-center gap-1 text-lg">
                {['❤️', '👏', '🙏', '🎉', '😂', '😮'].map((emoji) => (
                  <button
                    key={emoji}
                    type="button"
                    onClick={() => handleSendReaction(emoji)}
                    className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-stone-900/70 backdrop-blur-md flex items-center justify-center hover:scale-125 active:scale-95 transition cursor-pointer"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Drawer des vues pour l'auteur */}
        {showViewersDrawer && (
          <div className="absolute inset-0 z-40 bg-stone-950/95 backdrop-blur-md p-4 flex flex-col justify-between animate-fadeIn">
            <div className="flex items-center justify-between pb-3 border-b border-stone-800">
              <div className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-blue-400" />
                <h4 className="text-sm font-bold text-white">Spectateurs & Réactions ({viewsList.length})</h4>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowViewersDrawer(false);
                  setIsPaused(false);
                }}
                className="p-1 rounded-full bg-stone-800 text-stone-300 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Reactions list */}
            {reactionsList.length > 0 && (
              <div className="py-2.5 border-b border-stone-800">
                <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block mb-1.5">
                  Réactions reçues
                </span>
                <div className="flex flex-wrap gap-2">
                  {reactionsList.map((r) => (
                    <div
                      key={r.id}
                      className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-stone-800 text-xs text-white"
                    >
                      <span>{r.reaction}</span>
                      <span className="font-medium text-stone-300">{r.userName}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Views list */}
            <div className="flex-1 overflow-y-auto py-3 space-y-2.5">
              {viewsList.length === 0 ? (
                <div className="text-center py-8 text-xs text-stone-400">
                  Aucun membre n'a encore vu cette story.
                </div>
              ) : (
                viewsList.map((viewer, idx) => (
                  <div key={viewer.userId + idx} className="flex items-center justify-between p-2 rounded-xl bg-stone-900/60">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs overflow-hidden">
                        {viewer.userAvatar ? (
                          <img src={viewer.userAvatar} alt="" className="w-full h-full object-cover" />
                        ) : (
                          viewer.userName.charAt(0)
                        )}
                      </div>
                      <span className="text-xs font-semibold text-white">{viewer.userName}</span>
                    </div>
                    <span className="text-[11px] text-stone-400">Vu</span>
                  </div>
                ))
              )}
            </div>

            <button
              type="button"
              onClick={() => {
                setShowViewersDrawer(false);
                setIsPaused(false);
              }}
              className="w-full py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-xs font-bold text-white transition"
            >
              Reprendre la lecture
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
