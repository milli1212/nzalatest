import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { VerificationRelationNature } from '../../types';
import {
  FileCheck2,
  ShieldCheck,
  Building2,
  Info,
  CheckCircle2,
  Lock,
  User,
  Mail,
  Phone
} from 'lucide-react';

export const SubmitVerificationForm: React.FC<{ onSuccess?: () => void }> = ({ onSuccess }) => {
  const { families, members, submitVerificationRequest, showToast } = useFamily();

  const nzalaMembers = members.filter((m) => m.familyType === 'NZALA_DIRECT');
  const alliedFamilies = families.filter((f) => f.type === 'ALLIEE');

  const [applicantName, setApplicantName] = useState('');
  const [applicantEmail, setApplicantEmail] = useState('');
  const [applicantPhone, setApplicantPhone] = useState('');
  const [claimedFamilyType, setClaimedFamilyType] = useState<'NZALA_DIRECT' | 'FAMILLE_ALLIEE'>('FAMILLE_ALLIEE');
  const [originFamilyName, setOriginFamilyName] = useState('Famille Mavungu');
  const [isCustomFamily, setIsCustomFamily] = useState(false);
  const [customFamilyName, setCustomFamilyName] = useState('');
  const [targetNzalaMemberId, setTargetNzalaMemberId] = useState(nzalaMembers[0]?.id || '');
  const [relationshipNature, setRelationshipNature] = useState<VerificationRelationNature>('CONJOINT');
  const [explanation, setExplanation] = useState('');
  const [references, setReferences] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!applicantName.trim() || !applicantEmail.trim() || !explanation.trim()) {
      showToast('error', 'Veuillez renseigner votre nom, email et les détails de votre lien familial.');
      return;
    }

    const finalOriginFamily =
      claimedFamilyType === 'NZALA_DIRECT'
        ? 'Famille Nzala'
        : isCustomFamily
        ? customFamilyName.trim() || 'Famille Alliée'
        : originFamilyName;

    const targetMember = nzalaMembers.find((m) => m.id === targetNzalaMemberId);

    submitVerificationRequest({
      applicantName: applicantName.trim(),
      applicantEmail: applicantEmail.trim(),
      applicantPhone: applicantPhone.trim(),
      originFamilyName: finalOriginFamily,
      claimedFamilyType,
      targetNzalaMemberId: targetMember?.id,
      targetNzalaMemberName: targetMember ? `${targetMember.firstName} ${targetMember.lastName}` : undefined,
      relationshipNature,
      explanation: explanation.trim(),
      references: references.trim() || undefined,
    });

    setSubmitted(true);
    if (onSuccess) {
      setTimeout(onSuccess, 2000);
    }
  };

  if (submitted) {
    return (
      <div className="p-8 rounded-3xl bg-white border border-stone-200 text-center space-y-4 max-w-xl mx-auto shadow-xs">
        <div className="w-14 h-14 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto border border-emerald-200">
          <CheckCircle2 className="w-8 h-8" />
        </div>

        <h3 className="text-xl font-serif font-bold text-stone-900">
          Demande d'Affiliation Déposée
        </h3>

        <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
          Votre demande a été transmise aux <strong>Administrateurs et au Conseil de Famille</strong>. Vous serez contacté(e) après examen des informations fournies.
        </p>

        <div className="p-3.5 rounded-xl bg-stone-50 border border-stone-200 text-xs text-stone-500 text-left space-y-1">
          <p><strong>Statut initial :</strong> <span className="text-amber-700 font-semibold">EN ATTENTE DE VÉRIFICATION</span></p>
          <p><strong>Principe :</strong> Minimisation des données &amp; validation par les aînés référents.</p>
        </div>

        <button
          onClick={() => setSubmitted(false)}
          className="px-5 py-2.5 rounded-xl bg-stone-900 text-stone-100 text-xs font-semibold hover:bg-stone-800 transition"
        >
          Déposer une autre demande
        </button>
      </div>
    );
  }

  return (
    <div className="p-6 sm:p-8 rounded-3xl bg-white border border-stone-200 shadow-xs max-w-2xl mx-auto space-y-6">
      <div className="space-y-1 border-b border-stone-100 pb-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-800 flex items-center justify-center border border-amber-500/30">
            <FileCheck2 className="w-4 h-4" />
          </div>
          <h2 className="text-lg sm:text-xl font-serif font-bold text-stone-900">
            Procédure d'Adhésion &amp; Vérification
          </h2>
        </div>
        <p className="text-xs text-stone-500">
          Une personne ne peut pas s'auto-déclarer membre sans examen préalable. Remplissez ce formulaire pour soumettre votre affiliation.
        </p>
      </div>

      {/* Privacy Notice Card */}
      <div className="p-3.5 rounded-2xl bg-amber-50/80 border border-amber-200 text-xs text-amber-900 flex items-start gap-3">
        <Lock className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
        <div>
          <strong className="block font-semibold">Respect de la vie privée &amp; minimisation des données :</strong>
          <span>
            Aucun document d'identité sensible inutile n'est exigé en ligne. La validation s'appuie sur la mémoire familiale, les témoins et l'attestation des doyens.
          </span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4 text-xs">
        {/* Identity */}
        <div className="space-y-3">
          <h3 className="font-bold uppercase tracking-wider text-stone-400 text-[11px]">
            1. Votre Identité
          </h3>

          <div>
            <label className="block font-semibold text-stone-700 mb-1">
              Nom complet (Prénom et Nom) <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={applicantName}
              onChange={(e) => setApplicantName(e.target.value)}
              placeholder="Ex: Christian Mavungu, Dorcas Nzala..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:outline-hidden focus:border-amber-500 text-xs"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">
                Adresse Email <span className="text-rose-500">*</span>
              </label>
              <input
                type="email"
                required
                value={applicantEmail}
                onChange={(e) => setApplicantEmail(e.target.value)}
                placeholder="Ex: contact@exemple.cd"
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:outline-hidden focus:border-amber-500 text-xs"
              />
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">
                Téléphone (WhatsApp de préférence)
              </label>
              <input
                type="tel"
                value={applicantPhone}
                onChange={(e) => setApplicantPhone(e.target.value)}
                placeholder="Ex: +243 81 000 0000"
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:outline-hidden focus:border-amber-500 text-xs"
              />
            </div>
          </div>
        </div>

        {/* Claimed Affiliation */}
        <div className="space-y-3 pt-3 border-t border-stone-100">
          <h3 className="font-bold uppercase tracking-wider text-stone-400 text-[11px]">
            2. Déclaration d'Appartenance ou d'Alliance
          </h3>

          <div>
            <label className="block font-semibold text-stone-700 mb-2">
              Type de statut familial revendiqué <span className="text-rose-500">*</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label
                className={`p-3 rounded-2xl border flex items-start gap-3 cursor-pointer transition ${
                  claimedFamilyType === 'NZALA_DIRECT'
                    ? 'bg-amber-50 border-amber-400 text-amber-950 font-semibold'
                    : 'bg-stone-50 border-stone-200 text-stone-700'
                }`}
              >
                <input
                  type="radio"
                  name="claimedType"
                  value="NZALA_DIRECT"
                  checked={claimedFamilyType === 'NZALA_DIRECT'}
                  onChange={() => setClaimedFamilyType('NZALA_DIRECT')}
                  className="mt-0.5 text-amber-600"
                />
                <div>
                  <span className="block font-bold">Membre Direct Famille Nzala</span>
                  <span className="text-[11px] text-stone-500 font-normal">
                    Lignée biologique directe du patriarche fondateur
                  </span>
                </div>
              </label>

              <label
                className={`p-3 rounded-2xl border flex items-start gap-3 cursor-pointer transition ${
                  claimedFamilyType === 'FAMILLE_ALLIEE'
                    ? 'bg-sky-50 border-sky-400 text-sky-950 font-semibold'
                    : 'bg-stone-50 border-stone-200 text-stone-700'
                }`}
              >
                <input
                  type="radio"
                  name="claimedType"
                  value="FAMILLE_ALLIEE"
                  checked={claimedFamilyType === 'FAMILLE_ALLIEE'}
                  onChange={() => setClaimedFamilyType('FAMILLE_ALLIEE')}
                  className="mt-0.5 text-sky-600"
                />
                <div>
                  <span className="block font-bold">Membre d'une Famille Alliée</span>
                  <span className="text-[11px] text-stone-500 font-normal">
                    Lié à la famille Nzala par mariage ou descendance
                  </span>
                </div>
              </label>
            </div>
          </div>

          {/* Family selection if Allied */}
          {claimedFamilyType === 'FAMILLE_ALLIEE' && (
            <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 space-y-2">
              <label className="block font-semibold text-stone-700">
                Votre Famille d'Origine
              </label>

              {!isCustomFamily ? (
                <div className="flex gap-2">
                  <select
                    value={originFamilyName}
                    onChange={(e) => setOriginFamilyName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
                  >
                    {alliedFamilies.map((f) => (
                      <option key={f.id} value={f.name}>
                        {f.name} ({f.originLocation})
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    onClick={() => setIsCustomFamily(true)}
                    className="px-3 py-2 rounded-xl bg-stone-200 hover:bg-stone-300 text-stone-700 font-medium shrink-0"
                  >
                    Autre famille...
                  </button>
                </div>
              ) : (
                <div className="flex gap-2">
                  <input
                    type="text"
                    required
                    value={customFamilyName}
                    onChange={(e) => setCustomFamilyName(e.target.value)}
                    placeholder="Nom de votre famille d'origine..."
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white"
                  />
                  <button
                    type="button"
                    onClick={() => setIsCustomFamily(false)}
                    className="px-3 py-2 rounded-xl bg-stone-200 hover:bg-stone-300 text-stone-700 font-medium shrink-0"
                  >
                    Choisir existante
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Relationship nature & Nzala member link */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">
                Nature exacte du lien <span className="text-rose-500">*</span>
              </label>
              <select
                value={relationshipNature}
                onChange={(e) => setRelationshipNature(e.target.value as VerificationRelationNature)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-white"
              >
                <option value="MEMBRE_DIRECT">Membre Direct (Fils/Fille de sang)</option>
                <option value="ENFANT">Enfant d'un membre Nzala</option>
                <option value="CONJOINT">Conjoint(e) d'un membre Nzala</option>
                <option value="PARENT">Parent d'un membre Nzala</option>
                <option value="FRERE_SOEUR">Frère / Sœur d'un membre allié</option>
                <option value="DESCENDANT_ALLIANCE">Descendant d'une alliance passée</option>
                <option value="FAMILLE_ALLIEE">Représentant d'une famille alliée</option>
                <option value="AUTRE">Autre relation familiale reconnue</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">
                Personne Nzala avec laquelle vous êtes lié(e)
              </label>
              <select
                value={targetNzalaMemberId}
                onChange={(e) => setTargetNzalaMemberId(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-white"
              >
                {nzalaMembers.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.firstName} {m.lastName} ({m.branchName || 'Branche Nzala'})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Detailed Explanation & Witnesses */}
        <div className="space-y-3 pt-3 border-t border-stone-100">
          <h3 className="font-bold uppercase tracking-wider text-stone-400 text-[11px]">
            3. Explications &amp; Éléments de Preuve Familiale
          </h3>

          <div>
            <label className="block font-semibold text-stone-700 mb-1">
              Explication détaillée du lien familial <span className="text-rose-500">*</span>
            </label>
            <textarea
              required
              rows={3}
              value={explanation}
              onChange={(e) => setExplanation(e.target.value)}
              placeholder="Expliquez comment vous êtes rattaché(e) à la famille, votre ville/village, le mariage ou la branche concernée..."
              className="w-full p-3 rounded-xl border border-stone-300 focus:outline-hidden focus:border-amber-500"
            />
          </div>

          <div>
            <label className="block font-semibold text-stone-700 mb-1">
              Témoins et Références Familiales (Aînés qui vous connaissent)
            </label>
            <input
              type="text"
              value={references}
              onChange={(e) => setReferences(e.target.value)}
              placeholder="Ex: Papa Gabriel Nzala à Boma, Maman Claudine Mavungu, etc."
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300"
            />
          </div>
        </div>

        <div className="pt-4 border-t border-stone-200 flex items-center justify-end">
          <button
            type="submit"
            className="w-full sm:w-auto px-6 py-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs transition shadow-lg shadow-amber-950/20 cursor-pointer"
          >
            Soumettre ma demande pour vérification
          </button>
        </div>
      </form>
    </div>
  );
};
