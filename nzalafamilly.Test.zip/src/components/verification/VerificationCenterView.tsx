import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { VerificationRequest, VerificationStatus } from '../../types';
import { StatusBadge } from '../common/Badges';
import { VerificationDetailModal } from './VerificationDetailModal';
import { SubmitVerificationForm } from './SubmitVerificationForm';
import {
  FileCheck2,
  ShieldCheck,
  PlusCircle,
  Clock,
  CheckCircle2,
  XCircle,
  PauseCircle,
  Search,
  Filter,
  Info,
  ChevronRight,
  Sparkles
} from 'lucide-react';

export const VerificationCenterView: React.FC = () => {
  const {
    verificationRequests,
    currentUser,
    can,
  } = useFamily();

  const [activeTab, setActiveTab] = useState<'QUEUE' | 'SUBMIT'>(
    currentUser.role === 'VISITEUR' ? 'SUBMIT' : 'QUEUE'
  );
  const [statusFilter, setStatusFilter] = useState<'ALL' | VerificationStatus>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRequest, setSelectedRequest] = useState<VerificationRequest | null>(null);

  const filteredRequests = verificationRequests.filter((req) => {
    if (statusFilter !== 'ALL' && req.status !== statusFilter) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        req.applicantName.toLowerCase().includes(q) ||
        req.originFamilyName.toLowerCase().includes(q) ||
        req.applicantEmail.toLowerCase().includes(q) ||
        (req.targetNzalaMemberName && req.targetNzalaMemberName.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const pendingCount = verificationRequests.filter((r) => r.status === 'EN_ATTENTE').length;
  const inProgressCount = verificationRequests.filter((r) => r.status === 'EN_VERIFICATION').length;
  const approvedCount = verificationRequests.filter((r) => r.status === 'APPROUVEE').length;
  const rejectedCount = verificationRequests.filter((r) => r.status === 'REFUSEE').length;

  const canReview =
    currentUser.role === 'SUPER_ADMIN' ||
    currentUser.role === 'ADMIN_FAMILIAL' ||
    currentUser.role === 'VALIDATEUR' ||
    can('PROCESS_VERIFICATION');

  return (
    <div id="verification-center-view" className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-stone-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-serif font-bold text-stone-900">
              Centre de Vérification &amp; Adhésions
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-900 border border-amber-300">
              {verificationRequests.length} dossiers au total
            </span>
          </div>
          <p className="text-xs sm:text-sm text-stone-500 mt-1">
            Système d'examen des demandes d'appartenance à la <strong>Famille Nzala</strong> et d'affiliation des <strong>familles alliées</strong>.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setActiveTab('SUBMIT')}
            className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition shadow-xs cursor-pointer ${
              activeTab === 'SUBMIT'
                ? 'bg-amber-600 text-stone-950 shadow-md shadow-amber-950/20'
                : 'bg-stone-100 hover:bg-stone-200 text-stone-800 border border-stone-300'
            }`}
          >
            <PlusCircle className="w-4 h-4" />
            <span>Déposer une demande</span>
          </button>

          <button
            onClick={() => setActiveTab('QUEUE')}
            className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeTab === 'QUEUE'
                ? 'bg-stone-900 text-stone-100 shadow-md'
                : 'bg-stone-100 hover:bg-stone-200 text-stone-800 border border-stone-300'
            }`}
          >
            <FileCheck2 className="w-4 h-4" />
            <span>Dossiers ({pendingCount + inProgressCount} actifs)</span>
          </button>
        </div>
      </div>

      {/* Main Tab: Queue */}
      {activeTab === 'QUEUE' && (
        <div className="space-y-6">
          {/* Status Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div
              onClick={() => setStatusFilter('EN_ATTENTE')}
              className={`p-4 rounded-2xl border transition cursor-pointer ${
                statusFilter === 'EN_ATTENTE'
                  ? 'bg-amber-500/15 border-amber-400 text-amber-900'
                  : 'bg-white border-stone-200 hover:border-amber-300'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-semibold text-stone-500">
                <span>En attente</span>
                <Clock className="w-4 h-4 text-amber-600" />
              </div>
              <div className="text-2xl font-bold font-serif text-amber-700 mt-1">
                {pendingCount}
              </div>
            </div>

            <div
              onClick={() => setStatusFilter('EN_VERIFICATION')}
              className={`p-4 rounded-2xl border transition cursor-pointer ${
                statusFilter === 'EN_VERIFICATION'
                  ? 'bg-blue-50 border-blue-400 text-blue-900'
                  : 'bg-white border-stone-200 hover:border-blue-300'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-semibold text-stone-500">
                <span>En vérification</span>
                <ShieldCheck className="w-4 h-4 text-blue-600" />
              </div>
              <div className="text-2xl font-bold font-serif text-blue-700 mt-1">
                {inProgressCount}
              </div>
            </div>

            <div
              onClick={() => setStatusFilter('APPROUVEE')}
              className={`p-4 rounded-2xl border transition cursor-pointer ${
                statusFilter === 'APPROUVEE'
                  ? 'bg-emerald-50 border-emerald-400 text-emerald-900'
                  : 'bg-white border-stone-200 hover:border-emerald-300'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-semibold text-stone-500">
                <span>Approuvées</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-2xl font-bold font-serif text-emerald-700 mt-1">
                {approvedCount}
              </div>
            </div>

            <div
              onClick={() => setStatusFilter('REFUSEE')}
              className={`p-4 rounded-2xl border transition cursor-pointer ${
                statusFilter === 'REFUSEE'
                  ? 'bg-rose-50 border-rose-400 text-rose-900'
                  : 'bg-white border-stone-200 hover:border-rose-300'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-semibold text-stone-500">
                <span>Refusées / Rejet</span>
                <XCircle className="w-4 h-4 text-rose-600" />
              </div>
              <div className="text-2xl font-bold font-serif text-rose-700 mt-1">
                {rejectedCount}
              </div>
            </div>
          </div>

          {/* Filter and search row */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setStatusFilter('ALL')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                  statusFilter === 'ALL'
                    ? 'bg-stone-900 text-stone-100'
                    : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
                }`}
              >
                Tous les statuts ({verificationRequests.length})
              </button>
              <button
                onClick={() => setStatusFilter('EN_ATTENTE')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                  statusFilter === 'EN_ATTENTE'
                    ? 'bg-amber-700 text-amber-50'
                    : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
                }`}
              >
                En attente ({pendingCount})
              </button>
              <button
                onClick={() => setStatusFilter('EN_VERIFICATION')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                  statusFilter === 'EN_VERIFICATION'
                    ? 'bg-blue-700 text-blue-50'
                    : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
                }`}
              >
                En cours ({inProgressCount})
              </button>
              <button
                onClick={() => setStatusFilter('APPROUVEE')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                  statusFilter === 'APPROUVEE'
                    ? 'bg-emerald-700 text-emerald-50'
                    : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
                }`}
              >
                Approuvées ({approvedCount})
              </button>
            </div>

            <div className="relative w-full sm:w-72">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Rechercher un demandeur..."
                className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-white border border-stone-200 text-xs focus:outline-hidden focus:border-amber-500"
              />
            </div>
          </div>

          {/* Requests Cards List */}
          {filteredRequests.length > 0 ? (
            <div className="space-y-3">
              {filteredRequests.map((req) => {
                const isDirect = req.claimedFamilyType === 'NZALA_DIRECT';

                return (
                  <div
                    key={req.id}
                    onClick={() => setSelectedRequest(req)}
                    className="p-5 rounded-3xl bg-white border border-stone-200 hover:border-amber-400 hover:shadow-md transition cursor-pointer space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-stone-100 pb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-2xl bg-stone-100 flex items-center justify-center font-bold text-stone-800 text-sm">
                          {req.applicantName.charAt(0)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-bold text-base text-stone-900">
                              {req.applicantName}
                            </h3>
                            <StatusBadge status={req.status} size="sm" />
                          </div>
                          <p className="text-xs text-stone-500">
                            {req.applicantEmail} • {req.applicantPhone}
                          </p>
                        </div>
                      </div>

                      <div className="text-xs text-stone-400 sm:text-right">
                        Déposé le {new Date(req.createdAt).toLocaleDateString('fr-FR')}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs bg-stone-50 p-3 rounded-2xl border border-stone-150">
                      <div>
                        <span className="text-stone-400 block mb-0.5">Famille Déclarée</span>
                        <strong className="text-stone-900">{req.originFamilyName}</strong>
                      </div>

                      <div>
                        <span className="text-stone-400 block mb-0.5">Statut Revendiqué</span>
                        <span className={`font-semibold ${isDirect ? 'text-amber-800' : 'text-sky-800'}`}>
                          {isDirect ? '👑 Membre Direct Nzala' : '🤝 Famille Alliée'}
                        </span>
                      </div>

                      <div>
                        <span className="text-stone-400 block mb-0.5">Lien / Membre Nzala</span>
                        <span className="font-medium text-stone-800">
                          {req.relationshipNature.replace('_', ' ')}{' '}
                          {req.targetNzalaMemberName && `(${req.targetNzalaMemberName})`}
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-stone-600 line-clamp-2 italic">
                      "{req.explanation}"
                    </p>

                    {req.reviewerNotes && (
                      <div className="text-xs text-amber-900 bg-amber-50/70 p-2.5 rounded-xl border border-amber-200">
                        <strong>Note d'examen :</strong> {req.reviewerNotes}
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-1 text-xs font-semibold text-amber-800">
                      <span>Cliquez pour examiner le dossier &amp; modifier le statut</span>
                      <ChevronRight className="w-4 h-4 text-amber-600" />
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-12 text-center bg-white rounded-3xl border border-stone-200 space-y-2">
              <FileCheck2 className="w-8 h-8 text-stone-400 mx-auto" />
              <h3 className="text-sm font-bold text-stone-800">Aucun dossier trouvé</h3>
              <p className="text-xs text-stone-500">
                Aucune demande ne correspond aux critères de filtre sélectionnés.
              </p>
            </div>
          )}
        </div>
      )}

      {/* Main Tab: Submit Form */}
      {activeTab === 'SUBMIT' && (
        <SubmitVerificationForm onSuccess={() => setActiveTab('QUEUE')} />
      )}

      {/* Detail Modal */}
      {selectedRequest && (
        <VerificationDetailModal
          request={selectedRequest}
          onClose={() => setSelectedRequest(null)}
        />
      )}
    </div>
  );
};
