import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { VerificationRequest, VerificationStatus } from '../../types';
import { StatusBadge } from '../common/Badges';
import {
  X,
  FileCheck2,
  User,
  Mail,
  Phone,
  Building2,
  GitFork,
  CheckCircle,
  XCircle,
  Clock,
  AlertTriangle,
  PauseCircle,
  MessageSquare,
  Send,
  HelpCircle,
  Crown
} from 'lucide-react';

interface VerificationDetailModalProps {
  request: VerificationRequest;
  onClose: () => void;
}

export const VerificationDetailModal: React.FC<VerificationDetailModalProps> = ({
  request,
  onClose,
}) => {
  const { processVerificationRequest, currentUser, can } = useFamily();

  const [reviewerNotes, setReviewerNotes] = useState(request.reviewerNotes || '');
  const [publicFeedback, setPublicFeedback] = useState(request.publicFeedback || '');
  const [showComplementInput, setShowComplementInput] = useState(false);

  const canProcess =
    currentUser.role === 'SUPER_ADMIN' ||
    currentUser.role === 'ADMIN_FAMILIAL' ||
    currentUser.role === 'VALIDATEUR' ||
    can('PROCESS_VERIFICATION');

  const handleUpdateStatus = (newStatus: VerificationStatus) => {
    processVerificationRequest(request.id, newStatus, reviewerNotes, publicFeedback);
    onClose();
  };

  const isDirect = request.claimedFamilyType === 'NZALA_DIRECT';

  return (
    <div
      id="verification-detail-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-xs overflow-y-auto"
    >
      <div
        id="verification-detail-modal"
        className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="bg-stone-900 text-stone-100 p-6 flex items-start justify-between">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30 font-serif font-bold text-xl">
              {request.applicantName.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-serif font-bold text-stone-100">
                  {request.applicantName}
                </h2>
                <StatusBadge status={request.status} />
              </div>
              <p className="text-xs text-stone-400 mt-0.5">
                Dossier déposé le {new Date(request.createdAt).toLocaleDateString('fr-FR')} • Réf: {request.id}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full text-stone-400 hover:text-stone-100 hover:bg-stone-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5 max-h-[70vh] overflow-y-auto text-xs">
          {/* Declared Lineage & Family Connection */}
          <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200/80 space-y-3">
            <h3 className="font-bold text-amber-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-amber-700" />
              <span>Déclaration d'Appartenance ou d'Alliance</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <span className="text-stone-500 block mb-0.5">Famille d'Origine Déclarée :</span>
                <span className="font-bold text-stone-900 text-sm">{request.originFamilyName}</span>
              </div>

              <div>
                <span className="text-stone-500 block mb-0.5">Statut Revendiqué :</span>
                <span className="font-bold text-amber-900 text-sm flex items-center gap-1">
                  {isDirect ? (
                    <>
                      <Crown className="w-3.5 h-3.5 text-amber-600" />
                      <span>Membre Direct de la Famille Nzala</span>
                    </>
                  ) : (
                    <>
                      <Building2 className="w-3.5 h-3.5 text-sky-600" />
                      <span>Membre d'une Famille Alliée</span>
                    </>
                  )}
                </span>
              </div>

              <div>
                <span className="text-stone-500 block mb-0.5">Nature de la Relation :</span>
                <span className="font-semibold text-stone-900">
                  {request.relationshipNature.replace('_', ' ')}
                </span>
              </div>

              {request.targetNzalaMemberName && (
                <div>
                  <span className="text-stone-500 block mb-0.5">Membre Nzala Référent :</span>
                  <span className="font-bold text-stone-900">
                    {request.targetNzalaMemberName}
                  </span>
                </div>
              )}

              {request.branchOrTown && (
                <div className="sm:col-span-2">
                  <span className="text-stone-500 block mb-0.5">Branche / Ville :</span>
                  <span className="font-medium text-stone-900">{request.branchOrTown}</span>
                </div>
              )}
            </div>
          </div>

          {/* Contact Details */}
          <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="flex items-center gap-2 text-stone-700">
              <Mail className="w-4 h-4 text-stone-400 shrink-0" />
              <span>{request.applicantEmail}</span>
            </div>
            <div className="flex items-center gap-2 text-stone-700">
              <Phone className="w-4 h-4 text-stone-400 shrink-0" />
              <span>{request.applicantPhone}</span>
            </div>
          </div>

          {/* Detailed explanation */}
          <div className="space-y-1.5">
            <h4 className="font-bold uppercase tracking-wider text-stone-400 text-[11px]">
              Explications &amp; Justification Fournies par le Demandeur
            </h4>
            <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 text-stone-800 leading-relaxed text-sm">
              "{request.explanation}"
            </div>
          </div>

          {/* Family References */}
          {request.references && (
            <div className="space-y-1.5">
              <h4 className="font-bold uppercase tracking-wider text-stone-400 text-[11px]">
                Témoins &amp; Références Familiales Citées
              </h4>
              <div className="p-3 rounded-xl bg-stone-50 border border-stone-200 text-stone-700 text-xs">
                {request.references}
              </div>
            </div>
          )}

          {/* Public Feedback (sent to user) */}
          <div className="space-y-2 pt-2 border-t border-stone-200">
            <div className="flex items-center justify-between">
              <h4 className="font-bold uppercase tracking-wider text-purple-900 text-[11px] flex items-center gap-1.5">
                <Send className="w-3.5 h-3.5 text-purple-600" />
                <span>Message / Consigne transmise au demandeur (Visible par le demandeur)</span>
              </h4>
              <button
                type="button"
                onClick={() => setShowComplementInput(!showComplementInput)}
                className="text-[10px] text-purple-700 hover:underline font-bold"
              >
                {showComplementInput ? 'Masquer' : 'Demander un complément'}
              </button>
            </div>
            <textarea
              rows={2}
              disabled={!canProcess}
              value={publicFeedback}
              onChange={(e) => setPublicFeedback(e.target.value)}
              placeholder="Ex: Merci de préciser le prénom de vos grands-parents paternels pour validation par les aînés..."
              className="w-full p-2.5 rounded-xl bg-purple-50/50 border border-purple-200 focus:outline-hidden focus:border-purple-500 text-xs text-purple-950"
            />
          </div>

          {/* Reviewer Internal Confidential Notes */}
          <div className="space-y-2 pt-1 border-t border-stone-200">
            <h4 className="font-bold uppercase tracking-wider text-stone-700 text-[11px] flex items-center gap-1.5">
              <MessageSquare className="w-3.5 h-3.5 text-stone-500" />
              <span>Notes Internes du Validateur (Confidentielles - Non Visibles par le demandeur)</span>
            </h4>
            <textarea
              rows={2}
              disabled={!canProcess}
              value={reviewerNotes}
              onChange={(e) => setReviewerNotes(e.target.value)}
              placeholder="Indiquer les vérifications auprès des aînés, motif d'acceptation ou de rejet..."
              className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-hidden focus:border-amber-500 text-xs"
            />
            {request.reviewedByName && (
              <p className="text-[11px] text-stone-500 italic">
                Dernier examen par {request.reviewedByName} le{' '}
                {request.reviewedAt ? new Date(request.reviewedAt).toLocaleDateString('fr-FR') : ''}
              </p>
            )}
          </div>
        </div>

        {/* Modal Actions */}
        <div className="p-5 bg-stone-50 border-t border-stone-200 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-stone-300 text-stone-700 font-semibold text-xs hover:bg-stone-100 transition cursor-pointer"
          >
            Fermer
          </button>

          {canProcess ? (
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => handleUpdateStatus('EN_VERIFICATION')}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 text-xs font-semibold transition cursor-pointer"
              >
                <Clock className="w-3.5 h-3.5" />
                <span>En vérification</span>
              </button>

              <button
                onClick={() => handleUpdateStatus('COMPLEMENT_REQUIS')}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-800 border border-purple-200 text-xs font-semibold transition cursor-pointer"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Demander Complément</span>
              </button>

              <button
                onClick={() => handleUpdateStatus('REFUSEE')}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 text-xs font-semibold transition cursor-pointer"
              >
                <XCircle className="w-3.5 h-3.5" />
                <span>Refuser</span>
              </button>

              <button
                onClick={() => handleUpdateStatus('SUSPENDUE')}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-stone-200 hover:bg-stone-300 text-stone-800 text-xs font-semibold transition cursor-pointer"
              >
                <PauseCircle className="w-3.5 h-3.5" />
                <span>Suspendre</span>
              </button>

              <button
                onClick={() => handleUpdateStatus('APPROUVEE')}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold transition shadow-md shadow-emerald-900/20 cursor-pointer"
              >
                <CheckCircle className="w-4 h-4" />
                <span>Approuver &amp; {isDirect ? 'Intégrer Nzala' : 'Intégrer Allié'}</span>
              </button>
            </div>
          ) : (
            <span className="text-xs text-stone-500 italic">
              Seuls les administrateurs et validateurs peuvent modifier le statut.
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

