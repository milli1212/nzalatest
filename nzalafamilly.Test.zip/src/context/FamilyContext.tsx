import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import {
  Family,
  FamilyBranch,
  Member,
  Relationship,
  RelationshipType,
  Alliance,
  AllianceType,
  VerificationRequest,
  VerificationStatus,
  AuditLog,
  CurrentUser,
  UserAccount,
  UserRole,
  AffiliationOption,
  FamilyAnnouncement,
  FamilyEvent,
  InvitationStatus,
  InvitationTargetType,
  UpcomingBirthday,
  FamilyPost,
  PostComment,
  PostReaction,
  ReactionType,
  PostStatus,
  PostModerationStatus,
  FamilyNotification,
  FamilyStory,
  StoryViewer,
  StoryReaction,
  FamilyStatusItem,
  FamilyConversation,
  FamilyMessage,
  UserPresence,
  BlockedContact,
  QuotedMessage,
  MessageMediaType,
  MessageAttachment,
  MessageReportReason,
  ConversationParticipant,
  MemoryAlbum,
  HistoricalPublication,
  BirthdayCelebrationDraft,
  PostType,
  PostScope,
  MediaItem,
  AccountCertification,
  CertificationType,
  CertificationColorRequest,
  LiveStream,
  LiveComment,
  IssueReport,
  IssueCategory,
  IssuePriority,
} from '../types';
import {
  INITIAL_FAMILIES,
  INITIAL_BRANCHES,
  INITIAL_MEMBERS,
  INITIAL_RELATIONSHIPS,
  INITIAL_ALLIANCES,
  INITIAL_VERIFICATION_REQUESTS,
  INITIAL_AUDIT_LOGS,
  INITIAL_ANNOUNCEMENTS,
  INITIAL_POSTS,
  INITIAL_EVENTS,
  AVAILABLE_PROFILES,
  INITIAL_STORIES,
  INITIAL_STATUSES,
  INITIAL_MEMORY_ALBUMS,
  INITIAL_HISTORICAL_PUBLICATIONS,
} from '../services/mockData';
import {
  INITIAL_CONVERSATIONS,
  INITIAL_MESSAGES,
  INITIAL_PRESENCES,
  INITIAL_BLOCKED_CONTACTS,
} from '../services/messagingMockData';
import { MessagingService } from '../services/messagingService';
import {
  CallSession,
  CallType,
  CallHistoryItem,
  CallStatus,
} from '../types/calls';
import {
  UserPrivacySettings,
  NotificationPreferences,
  PrivacyAudience,
} from '../types/notifications';
import {
  SocialReport,
  ReportCategory,
  ReportTargetType,
} from '../types/moderation';
import { INITIAL_CALL_HISTORY } from '../services/calls/callsMockData';
import { NotificationService } from '../services/notifications/NotificationService';
import { PrivacyService } from '../services/privacy/PrivacyService';
import { CallService } from '../services/calls/CallService';
import { ModerationService } from '../services/moderation/ModerationService';
import { RealtimeService } from '../services/realtime/RealtimeService';
import {
  INITIAL_USER_ACCOUNTS,
  simulateHashPassword,
  simulateVerifyPassword,
} from '../services/authService';
import { AuthApi } from '../services/api/authApi';
import { apiClient } from '../services/api/apiClient';
import {
  validateRelationship,
  validateAlliance,
  validateUserMemberLink,
  getRelationshipLabel,
  getMemberRelatives,
  filterMemberVisibility,
  MemberRelatives
} from '../services/relationshipEngine';
import { hasPermission, AppPermission } from '../services/permissions';
import {
  validateEventData,
  calculateUpcomingBirthdays,
} from '../services/eventService';
import {
  canUserViewPost,
  canUserEditPost,
  canUserDeletePost,
  canUserModeratePost,
  canUserCreateOfficialPost,
  canUserComment,
  canUserReact,
  validatePostData,
  createNotification,
} from '../services/postService';

interface ToastInfo {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  text: string;
}

interface FamilyContextType {
  families: Family[];
  branches: FamilyBranch[];
  members: Member[];
  relationships: Relationship[];
  alliances: Alliance[];
  verificationRequests: VerificationRequest[];
  auditLogs: AuditLog[];
  announcements: FamilyAnnouncement[];
  events: FamilyEvent[];
  upcomingBirthdays: UpcomingBirthday[];
  selectedEvent: FamilyEvent | null;
  setSelectedEvent: (event: FamilyEvent | null) => void;
  currentUser: CurrentUser;
  userAccounts: UserAccount[];
  activeTab: string;
  setActiveTab: (tab: string) => void;
  setCurrentUser: (user: CurrentUser) => void;
  switchProfile: (index: number) => void;
  availableProfiles: typeof AVAILABLE_PROFILES;
  
  // Authentication & Security
  login: (email: string, password: string) => { success: boolean; error?: string };
  register: (data: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    password: string;
  }) => { success: boolean; error?: string; user?: UserAccount };
  logout: () => void;
  updateUserProfile: (id: string, data: Partial<UserAccount>) => void;
  changePassword: (oldPass: string, newPass: string) => { success: boolean; error?: string };
  toggleTwoFactor: () => boolean;
  requestPasswordReset: (email: string) => { success: boolean; message: string };

  // Verification & Affiliation actions
  submitVerificationRequest: (data: {
    applicantFirstName?: string;
    applicantLastName?: string;
    applicantName?: string;
    applicantEmail: string;
    applicantPhone: string;
    originFamilyName: string;
    claimedFamilyType: 'NZALA_DIRECT' | 'FAMILLE_ALLIEE';
    affiliationOption?: AffiliationOption;
    targetNzalaMemberId?: string;
    targetNzalaMemberName?: string;
    relationshipNature: VerificationRequest['relationshipNature'];
    branchOrTown?: string;
    explanation: string;
    references?: string;
  }) => VerificationRequest;
  
  processVerificationRequest: (
    requestId: string,
    newStatus: VerificationStatus,
    reviewerNotes: string,
    publicFeedback?: string
  ) => void;

  // Family, Branch & Member operations
  addFamily: (familyData: Omit<Family, 'id' | 'createdAt' | 'updatedAt' | 'membersCount' | 'alliancesCount'>) => Family;
  addBranch: (branchData: Omit<FamilyBranch, 'id' | 'createdAt' | 'updatedAt' | 'membersCount'>) => FamilyBranch;
  addMember: (memberData: Omit<Member, 'id' | 'createdAt' | 'updatedAt'>) => { success: boolean; member?: Member; error?: string };
  updateMember: (id: string, data: Partial<Member>) => void;
  archiveMember: (id: string, reason?: string) => { success: boolean; error?: string };

  // Relationship operations
  addRelationship: (data: {
    memberAId: string;
    memberBId: string;
    relationshipType: RelationshipType;
    status?: Relationship['status'];
    source?: Relationship['source'];
    startDate?: string;
    notes?: string;
  }) => { success: boolean; error?: string; warning?: string; relationship?: Relationship };

  proposeRelationship: (data: {
    memberAId: string;
    memberBId: string;
    relationshipType: RelationshipType;
    startDate?: string;
    notes?: string;
  }) => { success: boolean; error?: string; warning?: string };

  validateRelationshipAction: (
    relationshipId: string,
    newStatus: 'VALIDEE' | 'REFUSEE' | 'SUSPENDUE',
    notes?: string
  ) => void;
  deleteRelationship: (relationshipId: string) => void;

  // Alliance operations
  addAlliance: (allianceData: Omit<Alliance, 'id' | 'createdAt'>) => { success: boolean; error?: string; alliance?: Alliance };
  validateAllianceAction: (allianceId: string, newStatus: Alliance['status'], notes?: string) => void;

  // Event & Calendar operations
  addEvent: (eventData: Omit<FamilyEvent, 'id' | 'createdAt' | 'updatedAt' | 'participantsCount'>) => {
    success: boolean;
    event?: FamilyEvent;
    error?: string;
  };
  updateEvent: (id: string, data: Partial<FamilyEvent>) => { success: boolean; error?: string };
  cancelEvent: (id: string, reason?: string) => { success: boolean; error?: string };
  deleteEvent: (id: string) => { success: boolean; error?: string };
  rsvpEvent: (eventId: string, status: InvitationStatus, note?: string) => { success: boolean; error?: string };
  inviteToEvent: (
    eventId: string,
    target: {
      targetType: InvitationTargetType;
      targetId?: string;
      targetName: string;
      userId?: string;
      memberId?: string;
      userEmail?: string;
    }
  ) => { success: boolean; error?: string };

  // User-Member Link operations
  linkUserToMember: (userId: string, memberId: string) => { success: boolean; error?: string };
  unlinkUserFromMember: (userId: string, memberId: string) => { success: boolean; error?: string };

  // Helper query for member relatives
  getRelatives: (memberId: string) => MemberRelatives | null;
  getFilteredMember: (member: Member) => Member;

  // Selected item modals / drawers
  selectedMember: Member | null;
  setSelectedMember: (member: Member | null) => void;
  selectedFamily: Family | null;
  setSelectedFamily: (family: Family | null) => void;
  viewingUserId: string | null;
  setViewingUserId: (id: string | null) => void;
  openUserProfile: (userId: string) => void;

  // Notifications / Feedback
  toasts: ToastInfo[];
  showToast: (type: ToastInfo['type'], text: string) => void;
  removeToast: (id: string) => void;

  // Permissions helper
  can: (permission: AppPermission) => boolean;

  // Publications & Fil Familial & Réseau Social
  posts: FamilyPost[];
  visiblePosts: FamilyPost[];
  alliedFamilies: Family[];
  stories: FamilyStory[];
  statuses: FamilyStatusItem[];
  notifications: FamilyNotification[];
  selectedPost: FamilyPost | null;
  setSelectedPost: (post: FamilyPost | null) => void;
  createPost: (data: Partial<FamilyPost>) => { success: boolean; post?: FamilyPost; error?: string };
  addPost: (data: Partial<FamilyPost>) => { success: boolean; post?: FamilyPost; error?: string };
  updatePost: (id: string, data: Partial<FamilyPost>) => { success: boolean; error?: string };
  deletePost: (id: string, reason?: string) => { success: boolean; error?: string };
  archivePost: (id: string) => { success: boolean; error?: string };
  suspendPost: (id: string, reason?: string) => { success: boolean; error?: string };
  restorePost: (id: string) => { success: boolean; error?: string };
  togglePinPost: (id: string) => { success: boolean; error?: string };
  moderatePost: (id: string, decision: 'APPROUVE' | 'REFUSE', notes?: string) => { success: boolean; error?: string };
  addPostReaction: (postId: string, reactionType: ReactionType) => { success: boolean; error?: string };
  removePostReaction: (postId: string) => { success: boolean; error?: string };
  addPostComment: (postId: string, content: string) => { success: boolean; comment?: PostComment; error?: string };
  updatePostComment: (postId: string, commentId: string, content: string) => { success: boolean; error?: string };
  deletePostComment: (postId: string, commentId: string) => { success: boolean; error?: string };
  reportPostComment: (postId: string, commentId: string, reason?: string) => { success: boolean; error?: string };
  moderatePostComment: (postId: string, commentId: string, status: 'ACTIF' | 'MASQUE' | 'SUPPRIME') => { success: boolean; error?: string };
  createPostFromEvent: (event: FamilyEvent, customNote?: string) => { success: boolean; post?: FamilyPost; error?: string };
  markNotificationAsRead: (notificationId: string) => void;
  markAllNotificationsAsRead: () => void;
  deleteNotification: (notificationId: string) => void;
  clearReadNotifications: () => void;
  handleNotificationQuickAction: (notificationId: string, action: 'ACCEPT' | 'REJECT') => void;
  createOfficialNotification: (title: string, body: string, priority?: 'NORMALE' | 'HAUTE' | 'URGENTE') => void;

  // Stories & Statuts
  addStory: (story: Omit<FamilyStory, 'id' | 'createdAt' | 'expiresAt' | 'viewedByUserIds'>) => void;
  deleteStory: (id: string) => void;
  viewStory: (id: string) => void;
  addStoryReaction: (storyId: string, emoji: string) => void;
  addStatus: (status: Omit<FamilyStatusItem, 'id' | 'createdAt'>) => void;
  deleteStatus: (id: string) => void;
  reactToStatus: (statusId: string, emoji: string) => void;

  // Messagerie Familiale Privée (Nzala Messages)
  conversations: FamilyConversation[];
  messages: FamilyMessage[];
  presences: UserPresence[];
  blockedContacts: BlockedContact[];
  activeConversationId: string | null;
  totalUnreadMessagesCount: number;
  setActiveConversationId: (id: string | null) => void;
  sendMessage: (data: {
    conversationId: string;
    content: string;
    mediaType?: MessageMediaType;
    attachments?: MessageAttachment[];
    quotedMessage?: QuotedMessage;
    mentions?: string[];
    isViewOnce?: boolean;
  }) => { success: boolean; message?: FamilyMessage; error?: string };
  markMessageViewOnceAsOpened: (messageId: string, attachmentId?: string) => void;
  editMessage: (messageId: string, content: string) => { success: boolean; error?: string };
  deleteMessage: (messageId: string) => { success: boolean; error?: string };
  toggleMessageReaction: (messageId: string, emoji: string) => { success: boolean; error?: string };
  createDirectConversation: (targetUserId: string) => { success: boolean; conversation?: FamilyConversation; error?: string };
  createGroupConversation: (data: {
    title: string;
    description?: string;
    avatarUrl?: string;
    participantIds: string[];
    relatedBranchId?: string;
    relatedBranchName?: string;
    relatedAlliedFamilyId?: string;
    relatedAlliedFamilyName?: string;
    relatedAllianceId?: string;
    relatedAllianceName?: string;
    isCouncilGroup?: boolean;
  }) => { success: boolean; conversation?: FamilyConversation; error?: string };
  addGroupParticipants: (conversationId: string, userIds: string[]) => { success: boolean; error?: string };
  removeGroupParticipant: (conversationId: string, userId: string) => { success: boolean; error?: string };
  toggleGroupAdminRole: (conversationId: string, userId: string) => { success: boolean; error?: string };
  leaveGroupConversation: (conversationId: string) => { success: boolean; error?: string };
  togglePinConversation: (conversationId: string) => { success: boolean; error?: string };
  toggleArchiveConversation: (conversationId: string) => { success: boolean; error?: string };
  markConversationAsRead: (conversationId: string) => void;
  deleteConversation: (conversationId: string) => { success: boolean; error?: string };
  blockContact: (targetUserId: string, reason?: string) => { success: boolean; error?: string };
  unblockContact: (targetUserId: string) => { success: boolean; error?: string };
  reportConversationOrMessage: (data: {
    conversationId: string;
    messageId?: string;
    reportedUserId: string;
    reason: MessageReportReason;
    details?: string;
  }) => { success: boolean; error?: string };
  sharePostToConversation: (postId: string, conversationId: string, customComment?: string) => { success: boolean; error?: string };
  shareEventToConversation: (eventId: string, conversationId: string, customComment?: string) => { success: boolean; error?: string };

  // Nzala Calls (Audio & Vidéo)
  callHistory: CallHistoryItem[];
  activeCallSession: CallSession | null;
  incomingCallSession: CallSession | null;
  startCall: (
    targetUser: { id: string; name: string; avatarUrl?: string; role?: string; familyName?: string },
    type: CallType,
    conversationId?: string
  ) => { success: boolean; error?: string };
  answerIncomingCall: (acceptVideo: boolean) => void;
  rejectIncomingCall: (reason?: string) => void;
  endActiveCall: (durationSeconds?: number) => void;
  toggleMuteCall: () => void;
  toggleVideoCall: () => void;
  switchCameraCall: () => Promise<boolean>;
  toggleSpeakerCall: () => void;
  simulateIncomingCall: (
    fromUser?: { id: string; name: string; avatarUrl?: string; familyName?: string },
    type?: CallType
  ) => void;
  clearCallHistory: () => void;

  // Confidentialité & Permissions Sociales
  userPrivacySettings: UserPrivacySettings;
  updatePrivacySettings: (newSettings: Partial<UserPrivacySettings>) => void;

  // Notifications & Alertes
  notificationPreferences: NotificationPreferences;
  isNotificationDrawerOpen: boolean;
  setIsNotificationDrawerOpen: (open: boolean) => void;
  isNotificationSettingsOpen: boolean;
  setIsNotificationSettingsOpen: (open: boolean) => void;
  updateNotificationPreferences: (newPrefs: Partial<NotificationPreferences>) => void;
  addNotification: (notif: Omit<FamilyNotification, 'id' | 'createdAt' | 'read'>) => void;

  // Modération & Signalements Unifiés
  socialReports: SocialReport[];
  reportingTarget: {
    targetType: ReportTargetType;
    targetId: string;
    targetTitle?: string;
    reportedUserId?: string;
    reportedUserName?: string;
  } | null;
  setReportingTarget: (
    target: {
      targetType: ReportTargetType;
      targetId: string;
      targetTitle?: string;
      reportedUserId?: string;
      reportedUserName?: string;
    } | null
  ) => void;
  submitSocialReport: (data: {
    targetType: ReportTargetType;
    targetId: string;
    targetTitle?: string;
    reportedUserId?: string;
    reportedUserName?: string;
    category: ReportCategory;
    description: string;
  }) => { success: boolean; error?: string };
  processSocialReport: (
    reportId: string,
    decision: 'TRAITE' | 'REJETE',
    resolutionNotes?: string
  ) => { success: boolean; error?: string };
  setUserOnlineStatus: (status: UserPresence['status'], customText?: string) => void;

  // Mémoire & Archives Historiques (Mémoire Nzala)
  memoryAlbums: MemoryAlbum[];
  historicalPublications: HistoricalPublication[];
  adminPublicationModalOpen: boolean;
  setAdminPublicationModalOpen: (open: boolean) => void;
  birthdayCelebrationModalOpen: boolean;
  setBirthdayCelebrationModalOpen: (open: boolean) => void;
  activeBirthdayDraft: UpcomingBirthday | null;
  setActiveBirthdayDraft: (b: UpcomingBirthday | null) => void;
  addMemoryAlbum: (albumData: Omit<MemoryAlbum, 'id' | 'createdAt'>) => { success: boolean; album?: MemoryAlbum; error?: string };
  addHistoricalPublication: (pubData: Omit<HistoricalPublication, 'id' | 'publishedAt' | 'likesCount' | 'commentsCount'>) => { success: boolean; publication?: HistoricalPublication; error?: string };
  celebrateBirthday: (draft: BirthdayCelebrationDraft) => { success: boolean; post?: FamilyPost; error?: string };
  createAdminOfficialPost: (data: {
    title: string;
    content: string;
    postType: PostType;
    relatedMemberId?: string;
    relatedMemberName?: string;
    media?: MediaItem[];
    scope?: PostScope;
    isOfficial?: boolean;
    isImportant?: boolean;
  }) => { success: boolean; post?: FamilyPost; error?: string };

  // Certifications des Comptes Officiels & Administrateurs
  certifications: AccountCertification[];
  certificationColorRequests: CertificationColorRequest[];
  certifyAccount: (data: {
    userId: string;
    userName?: string;
    userEmail?: string;
    userRole?: UserRole;
    familyName?: string;
    branchName?: string;
    certificationType: CertificationType;
    badgeLabel: string;
    icon: string;
    badgeColor?: string;
    reason: string;
  }) => { success: boolean; error?: string };
  revokeCertification: (certificationId: string, reason: string) => { success: boolean; error?: string };
  updateCertificationBadgeColor: (certificationId: string, badgeColor: string) => { success: boolean; error?: string };
  requestCertificationColor: (data: { requestedColor: string; reason: string; requestedLabel?: string }) => { success: boolean; error?: string };
  approveCertificationColorRequest: (requestId: string, chosenColor: string, decisionNotes?: string) => { success: boolean; error?: string };
  rejectCertificationColorRequest: (requestId: string, reason: string) => { success: boolean; error?: string };

  // Nzala Live (Diffusions en Direct)
  liveStreams: LiveStream[];
  activeLiveStreamId: string | null;
  startNewLiveStream: (data: {
    title: string;
    description?: string;
    scope: PostScope;
    status?: 'LIVE' | 'SCHEDULED';
    targetFamilyId?: string;
    targetFamilyName?: string;
    targetBranchId?: string;
    targetBranchName?: string;
    allowComments?: boolean;
    scheduledFor?: string;
  }) => { success: boolean; liveStream?: LiveStream; error?: string };
  joinLiveStream: (liveId: string) => void;
  leaveLiveStream: () => void;
  endLiveStream: (liveId: string) => void;
  sendLiveComment: (liveId: string, content: string) => void;
  sendLiveReaction: (liveId: string, emoji: string) => void;
  deleteLiveComment: (liveId: string, commentId: string) => void;

  // Sécurité & Blocage Utilisateur
  blockUser: (targetUserId: string, targetUserName?: string, reason?: string) => { success: boolean; error?: string };
  unblockUser: (targetUserId: string) => { success: boolean; error?: string };

  // Assistance & Signalement de Problèmes
  issueReports: IssueReport[];
  submitIssueReport: (data: {
    category: IssueCategory;
    priority: IssuePriority;
    title: string;
    description: string;
    attachments?: MediaItem[];
    deviceInfo?: string;
  }) => { success: boolean; report?: IssueReport; error?: string };
  resolveIssueReport: (reportId: string, adminNotes?: string) => void;

  // Utilities
  resetToDefaults: () => void;
}

const FamilyContext = createContext<FamilyContextType | undefined>(undefined);

const STORAGE_KEYS = {
  FAMILIES: 'nzala_families_v2',
  BRANCHES: 'nzala_branches_v2',
  MEMBERS: 'nzala_members_v2',
  RELATIONSHIPS: 'nzala_relationships_v2',
  ALLIANCES: 'nzala_alliances_v2',
  REQUESTS: 'nzala_verifications_v2',
  AUDIT: 'nzala_audit_v2',
  CURRENT_USER: 'nzala_current_user_v2',
  USER_ACCOUNTS: 'nzala_user_accounts_v2',
  EVENTS: 'nzala_events_v2',
  POSTS: 'nzala_posts_v2',
  NOTIFICATIONS: 'nzala_notifs_v2',
  STORIES: 'nzala_stories_v2',
  STATUSES: 'nzala_statuses_v2',
  CONVERSATIONS: 'nzala_conversations_v2',
  MESSAGES: 'nzala_messages_v2',
  PRESENCES: 'nzala_presences_v2',
  BLOCKED_CONTACTS: 'nzala_blocked_contacts_v2',
  ACTIVE_CONVERSATION_ID: 'nzala_active_conv_id_v2',
  CALL_HISTORY: 'nzala_call_history_v2',
  PRIVACY_SETTINGS: 'nzala_privacy_settings_v2',
  NOTIF_PREFS: 'nzala_notif_prefs_v2',
  SOCIAL_REPORTS: 'nzala_social_reports_v2',
  MEMORY_ALBUMS: 'nzala_memory_albums_v2',
  HISTORICAL_PUBS: 'nzala_historical_pubs_v2',
  CERTIFICATIONS: 'nzala_certifications_v2',
  LIVE_STREAMS: 'nzala_live_streams_v2',
  ISSUE_REPORTS: 'nzala_issue_reports_v2',
};

export const FamilyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [families, setFamilies] = useState<Family[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.FAMILIES);
    return saved ? JSON.parse(saved) : INITIAL_FAMILIES;
  });

  const [branches, setBranches] = useState<FamilyBranch[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.BRANCHES);
    return saved ? JSON.parse(saved) : INITIAL_BRANCHES;
  });

  const [members, setMembers] = useState<Member[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MEMBERS);
    return saved ? JSON.parse(saved) : INITIAL_MEMBERS;
  });

  const [relationships, setRelationships] = useState<Relationship[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.RELATIONSHIPS);
    return saved ? JSON.parse(saved) : INITIAL_RELATIONSHIPS;
  });

  const [alliances, setAlliances] = useState<Alliance[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ALLIANCES);
    return saved ? JSON.parse(saved) : INITIAL_ALLIANCES;
  });

  const [verificationRequests, setVerificationRequests] = useState<VerificationRequest[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.REQUESTS);
    return saved ? JSON.parse(saved) : INITIAL_VERIFICATION_REQUESTS;
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.AUDIT);
    return saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
  });

  const [userAccounts, setUserAccounts] = useState<UserAccount[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USER_ACCOUNTS);
    return saved ? JSON.parse(saved) : INITIAL_USER_ACCOUNTS;
  });

  const [announcements] = useState<FamilyAnnouncement[]>(INITIAL_ANNOUNCEMENTS);
  const [events, setEvents] = useState<FamilyEvent[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.EVENTS);
    return saved ? JSON.parse(saved) : INITIAL_EVENTS;
  });

  const [posts, setPosts] = useState<FamilyPost[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.POSTS);
    return saved ? JSON.parse(saved) : INITIAL_POSTS;
  });

  const [stories, setStories] = useState<FamilyStory[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.STORIES);
    return saved ? JSON.parse(saved) : INITIAL_STORIES;
  });

  const [statuses, setStatuses] = useState<FamilyStatusItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.STATUSES);
    return saved ? JSON.parse(saved) : INITIAL_STATUSES;
  });

  const [notifications, setNotifications] = useState<FamilyNotification[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    return saved && JSON.parse(saved).length > 0
      ? JSON.parse(saved)
      : NotificationService.getInitialNotifications('usr-jean-pierre');
  });

  const [callHistory, setCallHistory] = useState<CallHistoryItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CALL_HISTORY);
    return saved ? JSON.parse(saved) : INITIAL_CALL_HISTORY;
  });

  const [activeCallSession, setActiveCallSession] = useState<CallSession | null>(null);
  const [incomingCallSession, setIncomingCallSession] = useState<CallSession | null>(null);

  const [userPrivacySettings, setUserPrivacySettings] = useState<UserPrivacySettings>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PRIVACY_SETTINGS);
    return saved ? JSON.parse(saved) : PrivacyService.DEFAULT_PRIVACY_SETTINGS;
  });

  const [notificationPreferences, setNotificationPreferences] = useState<NotificationPreferences>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.NOTIF_PREFS);
    return saved ? JSON.parse(saved) : NotificationService.DEFAULT_PREFERENCES;
  });

  const [socialReports, setSocialReports] = useState<SocialReport[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SOCIAL_REPORTS);
    return saved ? JSON.parse(saved) : ModerationService.getInitialReports();
  });

  const [isNotificationDrawerOpen, setIsNotificationDrawerOpen] = useState(false);
  const [isNotificationSettingsOpen, setIsNotificationSettingsOpen] = useState(false);
  const [reportingTarget, setReportingTarget] = useState<{
    targetType: ReportTargetType;
    targetId: string;
    targetTitle?: string;
    reportedUserId?: string;
    reportedUserName?: string;
  } | null>(null);

  const [conversations, setConversations] = useState<FamilyConversation[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CONVERSATIONS);
    return saved ? JSON.parse(saved) : INITIAL_CONVERSATIONS;
  });

  const [messages, setMessages] = useState<FamilyMessage[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MESSAGES);
    return saved ? JSON.parse(saved) : INITIAL_MESSAGES;
  });

  const [presences, setPresences] = useState<UserPresence[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PRESENCES);
    return saved ? JSON.parse(saved) : INITIAL_PRESENCES;
  });

  const [blockedContacts, setBlockedContacts] = useState<BlockedContact[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.BLOCKED_CONTACTS);
    return saved ? JSON.parse(saved) : INITIAL_BLOCKED_CONTACTS;
  });

  const [activeConversationId, setActiveConversationId] = useState<string | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ACTIVE_CONVERSATION_ID);
    return saved || 'conv-matadi-1';
  });

  const [currentUser, setCurrentUser] = useState<CurrentUser>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return saved ? JSON.parse(saved) : AVAILABLE_PROFILES[1].user; // Default: Jean-Pierre Nzala
  });

  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [viewingUserId, setViewingUserId] = useState<string | null>(null);
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [selectedFamily, setSelectedFamily] = useState<Family | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<FamilyEvent | null>(null);
  const [selectedPost, setSelectedPost] = useState<FamilyPost | null>(null);
  const [toasts, setToasts] = useState<ToastInfo[]>([]);

  const openUserProfile = (userId: string) => {
    setViewingUserId(userId);
    setActiveTab('profile');
  };

  // Mémoire & Archives State
  const [memoryAlbums, setMemoryAlbums] = useState<MemoryAlbum[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.MEMORY_ALBUMS);
    return saved ? JSON.parse(saved) : INITIAL_MEMORY_ALBUMS;
  });

  const [historicalPublications, setHistoricalPublications] = useState<HistoricalPublication[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.HISTORICAL_PUBS);
    return saved ? JSON.parse(saved) : INITIAL_HISTORICAL_PUBLICATIONS;
  });

  const [adminPublicationModalOpen, setAdminPublicationModalOpen] = useState(false);
  const [birthdayCelebrationModalOpen, setBirthdayCelebrationModalOpen] = useState(false);
  const [activeBirthdayDraft, setActiveBirthdayDraft] = useState<UpcomingBirthday | null>(null);

  // Certifications des Comptes
  const [certifications, setCertifications] = useState<AccountCertification[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CERTIFICATIONS);
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'cert-1',
        userId: 'usr-jean-pierre',
        userName: 'Jean-Pierre Nzala',
        userRole: 'SUPER_ADMIN' as UserRole,
        familyName: 'Famille Nzala',
        branchName: 'Branche Kinshasa (Aînée)',
        certificationType: 'SUPER_ADMIN' as CertificationType,
        badgeLabel: 'Super Administrateur de la Plateforme',
        icon: '👑',
        badgeColor: '#EC4899', // Rose officiel pour Super Admin
        reason: 'Fondateur et Patriarche Principal de la plateforme NzalaFamilly',
        certifiedByUserId: 'usr-jean-pierre',
        certifiedByUserName: 'Système NzalaFamilly',
        certifiedAt: '2025-01-01T08:00:00.000Z',
        isActive: true,
      },
      {
        id: 'cert-2',
        userId: 'usr-marie-therese',
        userName: 'Marie-Thérèse Nzala (Maman)',
        userRole: 'ADMIN_FAMILIAL' as UserRole,
        familyName: 'Famille Nzala',
        branchName: 'Branche Kinshasa (Aînée)',
        certificationType: 'SAGE_CONSEIL' as CertificationType,
        badgeLabel: 'Membre du Conseil des Sages Nzala',
        icon: '📜',
        badgeColor: '#2563EB', // Bleu Nzala
        reason: 'Matriarche et Gardienne des Traditions Familiales',
        certifiedByUserId: 'usr-jean-pierre',
        certifiedByUserName: 'Jean-Pierre Nzala',
        certifiedAt: '2025-01-10T10:00:00.000Z',
        isActive: true,
      },
      {
        id: 'cert-3',
        userId: 'usr-honore',
        userName: 'Honoré Nzala',
        userRole: 'ADMIN_FAMILIAL' as UserRole,
        familyName: 'Famille Nzala',
        branchName: 'Branche Matadi',
        certificationType: 'ADMIN_FAMILIAL' as CertificationType,
        badgeLabel: 'Administrateur de Famille / Branche',
        icon: '🛡️',
        badgeColor: '#2563EB', // Bleu Nzala
        reason: 'Responsable référent de la Branche Matadi',
        certifiedByUserId: 'usr-jean-pierre',
        certifiedByUserName: 'Jean-Pierre Nzala',
        certifiedAt: '2025-02-01T12:00:00.000Z',
        isActive: true,
      },
    ];
  });

  // Demandes de couleur / badge soumises à l'administration
  const [certificationColorRequests, setCertificationColorRequests] = useState<CertificationColorRequest[]>(() => {
    const saved = localStorage.getItem('nzala_cert_color_requests');
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'req-col-1',
        userId: 'usr-marie-therese',
        userName: 'Marie-Thérèse Nzala (Maman)',
        userEmail: 'marie.therese@example.com',
        userRole: 'ADMIN_FAMILIAL' as UserRole,
        currentCertificationId: 'cert-2',
        requestedColor: '#D97706', // Or Sagesse
        requestedLabel: 'Doyenne Matriarche - Conseil des Sages',
        reason: 'Demande d’attribution de la couleur dorée en tant que Doyenne du Conseil des Sages.',
        status: 'EN_ATTENTE',
        createdAt: '2025-02-18T10:00:00.000Z',
      },
    ];
  });

  // Nzala Live
  const [liveStreams, setLiveStreams] = useState<LiveStream[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.LIVE_STREAMS);
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'live-matadi-1',
        title: 'Célébration & Récits des Aînés de Matadi',
        description: 'Direct exceptionnel avec les doyens de la branche Matadi sur l’histoire et les origines de la famille.',
        hostUserId: 'usr-honore',
        hostName: 'Honoré Nzala',
        hostAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
        hostRole: 'ADMIN_FAMILIAL' as UserRole,
        hostFamilyName: 'Famille Nzala',
        isHostVerified: true,
        hostVerifiedBadge: '🛡️ Administrateur Matadi',
        status: 'LIVE' as const,
        scope: 'PUBLIC' as const,
        viewersCount: 18,
        maxViewersReached: 24,
        thumbnailUrl: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=800',
        isMicOn: true,
        isCameraOn: true,
        allowComments: true,
        comments: [
          {
            id: 'lc-1',
            liveId: 'live-matadi-1',
            userId: 'usr-marie-therese',
            userName: 'Marie-Thérèse Nzala (Maman)',
            userRole: 'ADMIN_FAMILIAL' as UserRole,
            isVerified: true,
            verifiedBadge: '📜 Conseil des Sages',
            content: 'Mbote na bino nyonso ! Que les bénédictions reposent sur notre descendance.',
            isPinned: true,
            createdAt: new Date(Date.now() - 300000).toISOString(),
          },
          {
            id: 'lc-2',
            liveId: 'live-matadi-1',
            userId: 'usr-christian',
            userName: 'Christian Nzala',
            userRole: 'MEMBRE' as UserRole,
            content: 'Merci pour ces enseignements précieux sur nos racines !',
            createdAt: new Date(Date.now() - 120000).toISOString(),
          },
        ],
        reactionsCount: { '❤️': 45, '🙏': 32, '👏': 28, '🔥': 14 },
        createdAt: new Date(Date.now() - 1800000).toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'live-ag-2026',
        title: 'Grande Assemblée Générale de la Famille Nzala 2026',
        description: 'Rencontre annuelle de toutes les branches (Kinshasa, Matadi, Lubumbashi, Diaspora).',
        hostUserId: 'usr-jean-pierre',
        hostName: 'Jean-Pierre Nzala',
        hostRole: 'SUPER_ADMIN' as UserRole,
        hostFamilyName: 'Famille Nzala',
        isHostVerified: true,
        hostVerifiedBadge: '👑 Super Admin',
        status: 'SCHEDULED' as const,
        scope: 'PUBLIC' as const,
        scheduledFor: new Date(Date.now() + 86400000 * 3).toISOString(),
        viewersCount: 0,
        thumbnailUrl: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=800',
        isMicOn: true,
        isCameraOn: true,
        allowComments: true,
        comments: [],
        reactionsCount: {},
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ];
  });
  const [activeLiveStreamId, setActiveLiveStreamId] = useState<string | null>(null);

  // Signalements de problèmes
  const [issueReports, setIssueReports] = useState<IssueReport[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ISSUE_REPORTS);
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'rep-101',
        reporterUserId: 'usr-christian',
        reporterName: 'Christian Nzala',
        reporterEmail: 'christian.nzala@example.com',
        category: 'MESSAGERIE' as IssueCategory,
        priority: 'NORMALE' as IssuePriority,
        title: 'Notification sonore des messages directs',
        description: 'Les alertes sonores étaient muettes lors de la réception d’un message en arrière-plan sur mobile.',
        status: 'RESOLU' as const,
        adminNotes: 'Paramètres audio et permissions de notifications optimisés.',
        handledByUserId: 'usr-jean-pierre',
        handledByUserName: 'Jean-Pierre Nzala',
        resolvedAt: '2025-02-15T14:30:00.000Z',
        createdAt: '2025-02-14T10:00:00.000Z',
        updatedAt: '2025-02-15T14:30:00.000Z',
      },
    ];
  });

  // Local storage synchronization
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CERTIFICATIONS, JSON.stringify(certifications));
  }, [certifications]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LIVE_STREAMS, JSON.stringify(liveStreams));
  }, [liveStreams]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ISSUE_REPORTS, JSON.stringify(issueReports));
  }, [issueReports]);

  // Local storage synchronization
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MEMORY_ALBUMS, JSON.stringify(memoryAlbums));
  }, [memoryAlbums]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.HISTORICAL_PUBS, JSON.stringify(historicalPublications));
  }, [historicalPublications]);

  // Local storage synchronization
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CONVERSATIONS, JSON.stringify(conversations));
  }, [conversations]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PRESENCES, JSON.stringify(presences));
  }, [presences]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.BLOCKED_CONTACTS, JSON.stringify(blockedContacts));
  }, [blockedContacts]);

  useEffect(() => {
    if (activeConversationId) {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_CONVERSATION_ID, activeConversationId);
    } else {
      localStorage.removeItem(STORAGE_KEYS.ACTIVE_CONVERSATION_ID);
    }
  }, [activeConversationId]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FAMILIES, JSON.stringify(families));
  }, [families]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.BRANCHES, JSON.stringify(branches));
  }, [branches]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MEMBERS, JSON.stringify(members));
  }, [members]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.EVENTS, JSON.stringify(events));
  }, [events]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.POSTS, JSON.stringify(posts));
  }, [posts]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STORIES, JSON.stringify(stories));
  }, [stories]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STATUSES, JSON.stringify(statuses));
  }, [statuses]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.RELATIONSHIPS, JSON.stringify(relationships));
  }, [relationships]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ALLIANCES, JSON.stringify(alliances));
  }, [alliances]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.REQUESTS, JSON.stringify(verificationRequests));
  }, [verificationRequests]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.AUDIT, JSON.stringify(auditLogs));
  }, [auditLogs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USER_ACCOUNTS, JSON.stringify(userAccounts));
  }, [userAccounts]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CALL_HISTORY, JSON.stringify(callHistory));
  }, [callHistory]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PRIVACY_SETTINGS, JSON.stringify(userPrivacySettings));
  }, [userPrivacySettings]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.NOTIF_PREFS, JSON.stringify(notificationPreferences));
  }, [notificationPreferences]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SOCIAL_REPORTS, JSON.stringify(socialReports));
  }, [socialReports]);

  const showToast = (type: ToastInfo['type'], text: string) => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, type, text }]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const switchProfile = (index: number) => {
    const profile = AVAILABLE_PROFILES[index];
    if (profile) {
      setCurrentUser(profile.user);
      showToast('info', `Profil basculé : ${profile.user.name} (${profile.label})`);
    }
  };

  const can = (permission: AppPermission): boolean => {
    return hasPermission(currentUser.role, permission);
  };

  // Helper query for relatives
  const getRelatives = (memberId: string): MemberRelatives | null => {
    return getMemberRelatives(memberId, members, relationships, alliances);
  };

  // Helper visibility filter
  const getFilteredMember = (member: Member): Member => {
    const isOwn = currentUser.memberId === member.id || currentUser.email?.toLowerCase() === member.email?.toLowerCase();
    return filterMemberVisibility(member, currentUser.role, isOwn);
  };

  // --- Authentication Handlers ---
  const login = (email: string, password: string): { success: boolean; error?: string } => {
    const cleanEmail = email.trim().toLowerCase();
    const account = userAccounts.find((acc) => acc.email.toLowerCase() === cleanEmail);

    if (!account) {
      return { success: false, error: 'Aucun compte associé à cette adresse e-mail.' };
    }

    if (account.accountStatus === 'SUSPENDU') {
      return { success: false, error: 'Ce compte utilisateur a été suspendu par les administrateurs.' };
    }

    const isValid = simulateVerifyPassword(password, account.passwordHash);
    if (!isValid) {
      return { success: false, error: 'Mot de passe incorrect.' };
    }

    // Call AuthApi to initialize server tokens and session
    AuthApi.login({ email: cleanEmail, password }).catch(() => {
      // In standalone demo mode, continue with local session
    });

    // Update lastLoginAt
    const updatedAccount = { ...account, lastLoginAt: new Date().toISOString() };
    setUserAccounts((prev) => prev.map((a) => (a.id === account.id ? updatedAccount : a)));

    const loggedUser: CurrentUser = {
      id: account.id,
      name: `${account.firstName} ${account.lastName}`,
      firstName: account.firstName,
      lastName: account.lastName,
      email: account.email,
      phone: account.phone,
      role: account.role,
      accountStatus: account.accountStatus,
      affiliationStatus: account.affiliationStatus,
      isEmailVerified: account.isEmailVerified,
      twoFactorEnabled: account.twoFactorEnabled,
      avatarUrl: account.avatarUrl,
      bio: account.bio,
      memberId: account.memberId,
      familyId: account.primaryFamilyId,
      familyName: account.primaryFamilyName,
      familyType: account.familyType,
      verificationStatus: account.affiliationStatus === 'APPROUVEE' ? 'APPROUVEE' : 'EN_ATTENTE',
    };

    setCurrentUser(loggedUser);

    // Audit log
    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: loggedUser.name,
      actorRole: loggedUser.role,
      action: 'CONNEXION_UTILISATEUR',
      actionType: 'SECURITY',
      targetType: 'USER',
      targetId: loggedUser.id,
      targetName: loggedUser.name,
      details: `Authentification réussie (${cleanEmail}). Rôle actif : ${loggedUser.role}.`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast('success', `Bienvenue, ${loggedUser.firstName} !`);
    return { success: true };
  };

  const register = (data: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    password: string;
  }): { success: boolean; error?: string; user?: UserAccount } => {
    const cleanEmail = data.email.trim().toLowerCase();
    const existing = userAccounts.find((acc) => acc.email.toLowerCase() === cleanEmail);
    if (existing) {
      return { success: false, error: 'Un compte existe déjà avec cette adresse email.' };
    }

    const newAccount: UserAccount = {
      id: `usr-${Date.now()}`,
      firstName: data.firstName.trim(),
      lastName: data.lastName.trim(),
      email: cleanEmail,
      phone: data.phone.trim(),
      passwordHash: simulateHashPassword(data.password),
      role: 'VISITEUR', // Explicit rule: Initial registration is strictly VISITEUR
      accountStatus: 'COMPTE_CREE',
      affiliationStatus: 'NON_DEPOSEE',
      isEmailVerified: false,
      twoFactorEnabled: false,
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
    };

    // Invoke AuthApi to create user on server and acquire session
    AuthApi.register({
      firstName: data.firstName,
      lastName: data.lastName,
      email: cleanEmail,
      phone: data.phone,
      password: data.password,
    }).catch(() => {
      // In standalone demo mode, continue with local session
    });

    setUserAccounts((prev) => [newAccount, ...prev]);

    const newUser: CurrentUser = {
      id: newAccount.id,
      name: `${newAccount.firstName} ${newAccount.lastName}`,
      firstName: newAccount.firstName,
      lastName: newAccount.lastName,
      email: newAccount.email,
      phone: newAccount.phone,
      role: 'VISITEUR',
      accountStatus: 'COMPTE_CREE',
      affiliationStatus: 'NON_DEPOSEE',
      isEmailVerified: false,
      twoFactorEnabled: false,
      verificationStatus: 'EN_ATTENTE',
    };

    setCurrentUser(newUser);

    // Audit log
    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: newUser.name,
      actorRole: 'VISITEUR',
      action: 'CREATION_COMPTE',
      actionType: 'SECURITY',
      targetType: 'USER',
      targetId: newAccount.id,
      targetName: newUser.name,
      details: `Création de compte (${cleanEmail}). Statut initial: COMPTE_CREE, rôle: VISITEUR.`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast('success', 'Votre compte NzalaFamilly a été créé avec succès !');
    return { success: true, user: newAccount };
  };

  const logout = () => {
    AuthApi.logout().catch(() => {
      // Fallback
    });
    apiClient.clearTokens();

    const guestUser: CurrentUser = {
      id: 'guest',
      name: 'Visiteur Invité',
      email: 'invite@nzalafamilly.org',
      role: 'VISITEUR',
      accountStatus: 'COMPTE_CREE',
      affiliationStatus: 'NON_DEPOSEE',
    };
    setCurrentUser(guestUser);
    setActiveTab('landing');
    showToast('info', 'Vous avez été déconnecté(e).');
  };

  const updateUserProfile = (id: string, data: Partial<UserAccount>) => {
    setUserAccounts((prev) =>
      prev.map((acc) => {
        if (acc.id === id) {
          const updated = { ...acc, ...data };
          if (currentUser.id === id) {
            setCurrentUser((prevCur) => ({
              ...prevCur,
              firstName: updated.firstName,
              lastName: updated.lastName,
              name: `${updated.firstName} ${updated.lastName}`,
              phone: updated.phone,
              bio: updated.bio,
              avatarUrl: updated.avatarUrl,
            }));
          }
          return updated;
        }
        return acc;
      })
    );
    showToast('success', 'Profil mis à jour.');
  };

  const changePassword = (oldPass: string, newPass: string): { success: boolean; error?: string } => {
    const acc = userAccounts.find((a) => a.id === currentUser.id);
    if (!acc) return { success: false, error: 'Compte introuvable.' };

    if (!simulateVerifyPassword(oldPass, acc.passwordHash)) {
      return { success: false, error: 'Le mot de passe actuel est incorrect.' };
    }

    if (newPass.length < 8) {
      return { success: false, error: 'Le nouveau mot de passe doit comporter au moins 8 caractères.' };
    }

    const newHash = simulateHashPassword(newPass);
    setUserAccounts((prev) => prev.map((a) => (a.id === acc.id ? { ...a, passwordHash: newHash } : a)));

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'MODIFICATION_MOT_DE_PASSE',
      actionType: 'SECURITY',
      targetType: 'USER',
      targetId: currentUser.id,
      targetName: currentUser.name,
      details: 'Mise à jour sécurisée du mot de passe.',
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast('success', 'Mot de passe modifié avec succès.');
    return { success: true };
  };

  const toggleTwoFactor = (): boolean => {
    const acc = userAccounts.find((a) => a.id === currentUser.id);
    const newStatus = acc ? !acc.twoFactorEnabled : !currentUser.twoFactorEnabled;

    if (acc) {
      setUserAccounts((prev) => prev.map((a) => (a.id === acc.id ? { ...a, twoFactorEnabled: newStatus } : a)));
    }
    setCurrentUser((prev) => ({ ...prev, twoFactorEnabled: newStatus }));

    showToast('info', newStatus ? 'Authentification à deux facteurs (2FA) activée.' : '2FA désactivée.');
    return newStatus;
  };

  const requestPasswordReset = (email: string): { success: boolean; message: string } => {
    const cleanEmail = email.trim().toLowerCase();
    const account = userAccounts.find((acc) => acc.email.toLowerCase() === cleanEmail);

    if (account) {
      const newAudit: AuditLog = {
        id: `log-${Date.now()}`,
        actorName: 'Système Sécurité',
        actorRole: 'SUPER_ADMIN',
        action: 'DEMANDE_REINITIALISATION_MOT_DE_PASSE',
        actionType: 'SECURITY',
        targetType: 'USER',
        targetId: account.id,
        targetName: `${account.firstName} ${account.lastName}`,
        details: `Lien de réinitialisation simulé transmis à ${cleanEmail}.`,
        timestamp: new Date().toISOString(),
      };
      setAuditLogs((prev) => [newAudit, ...prev]);
    }

    return {
      success: true,
      message: `Si cette adresse existe dans notre annuaire, un e-mail avec les instructions de réinitialisation a été envoyé à ${cleanEmail}.`,
    };
  };

  // --- Affiliation & Verification Submissions ---
  const submitVerificationRequest = (data: {
    applicantFirstName?: string;
    applicantLastName?: string;
    applicantName?: string;
    applicantEmail: string;
    applicantPhone: string;
    originFamilyName: string;
    claimedFamilyType: 'NZALA_DIRECT' | 'FAMILLE_ALLIEE';
    affiliationOption?: AffiliationOption;
    targetNzalaMemberId?: string;
    targetNzalaMemberName?: string;
    relationshipNature: VerificationRequest['relationshipNature'];
    branchOrTown?: string;
    explanation: string;
    references?: string;
  }): VerificationRequest => {
    const fullName =
      data.applicantName ||
      `${data.applicantFirstName || ''} ${data.applicantLastName || ''}`.trim() ||
      currentUser.name;

    const newRequest: VerificationRequest = {
      id: `req-${Date.now()}`,
      userId: currentUser.id !== 'guest' ? currentUser.id : undefined,
      applicantName: fullName,
      applicantFirstName: data.applicantFirstName || currentUser.firstName,
      applicantLastName: data.applicantLastName || currentUser.lastName,
      applicantEmail: data.applicantEmail,
      applicantPhone: data.applicantPhone,
      originFamilyName: data.originFamilyName,
      claimedFamilyType: data.claimedFamilyType,
      affiliationOption: data.affiliationOption,
      targetNzalaMemberId: data.targetNzalaMemberId,
      targetNzalaMemberName: data.targetNzalaMemberName,
      relationshipNature: data.relationshipNature,
      branchOrTown: data.branchOrTown,
      explanation: data.explanation,
      references: data.references,
      status: 'EN_ATTENTE',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setVerificationRequests((prev) => [newRequest, ...prev]);

    // Update current user affiliation status
    if (currentUser.id) {
      setCurrentUser((prev) => ({
        ...prev,
        affiliationStatus: 'EN_ATTENTE',
        verificationStatus: 'EN_ATTENTE',
        familyName: data.originFamilyName,
        familyType: data.claimedFamilyType === 'NZALA_DIRECT' ? 'NZALA_DIRECT' : 'ALLIE',
      }));

      setUserAccounts((prev) =>
        prev.map((acc) =>
          acc.id === currentUser.id
            ? {
                ...acc,
                affiliationStatus: 'EN_ATTENTE',
                primaryFamilyName: data.originFamilyName,
                familyType: data.claimedFamilyType === 'NZALA_DIRECT' ? 'NZALA_DIRECT' : 'ALLIE',
              }
            : acc
        )
      );
    }

    // Add audit entry
    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: fullName,
      actorRole: currentUser.role,
      action: 'SOUMISSION_AFFILIATION',
      actionType: 'VALIDATION',
      targetType: 'VERIFICATION_REQUEST',
      targetId: newRequest.id,
      targetName: fullName,
      details: `Demande d'affiliation déposée (${data.claimedFamilyType === 'NZALA_DIRECT' ? 'Lignée Nzala Directe' : 'Famille Alliée: ' + data.originFamilyName}).`,
      timestamp: new Date().toISOString(),
    };

    setAuditLogs((prev) => [newAudit, ...prev]);
    showToast('success', 'Votre déclaration d\'affiliation a été transmise au Conseil de Famille.');
    return newRequest;
  };

  const processVerificationRequest = (
    requestId: string,
    newStatus: VerificationStatus,
    reviewerNotes: string,
    publicFeedback?: string
  ) => {
    const targetReq = verificationRequests.find((r) => r.id === requestId);
    if (!targetReq) return;

    const applicantName = targetReq.applicantName;
    const isDirect = targetReq.claimedFamilyType === 'NZALA_DIRECT';
    const targetUserId = targetReq.userId;

    const assignedRole: UserRole = isDirect ? 'MEMBRE_NZALA' : 'MEMBRE_ALLIE';

    setVerificationRequests((prev) =>
      prev.map((req) => {
        if (req.id === requestId) {
          return {
            ...req,
            status: newStatus,
            reviewerNotes: reviewerNotes || req.reviewerNotes,
            publicFeedback: publicFeedback || req.publicFeedback,
            reviewedBy: currentUser.id,
            reviewedByName: currentUser.name,
            reviewedAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };
        }
        return req;
      })
    );

    // If approved, create/link directory member without duplicate
    if (newStatus === 'APPROUVEE') {
      let familyId = 'fam-nzala';
      let familyName = 'Famille Nzala';

      if (!isDirect) {
        const existingFam = families.find(
          (f) => f.name.toLowerCase() === targetReq.originFamilyName.toLowerCase()
        );
        if (existingFam) {
          familyId = existingFam.id;
          familyName = existingFam.name;
        } else {
          familyName = targetReq.originFamilyName;
        }
      }

      // Check if a member already exists for this email or userId
      let existingMember = members.find(
        (m) =>
          (targetUserId && m.userId === targetUserId) ||
          (targetReq.applicantEmail && m.email?.toLowerCase() === targetReq.applicantEmail.toLowerCase())
      );

      let finalMemberId = existingMember ? existingMember.id : `mem-${Date.now()}`;

      if (!existingMember) {
        const newMember: Member = {
          id: finalMemberId,
          userId: targetUserId,
          firstName: targetReq.applicantFirstName || applicantName.split(' ')[0] || applicantName,
          lastName: targetReq.applicantLastName || applicantName.split(' ').slice(1).join(' ') || (isDirect ? 'Nzala' : targetReq.originFamilyName),
          gender: 'M',
          livingStatus: 'VIVANT',
          email: targetReq.applicantEmail,
          phone: targetReq.applicantPhone,
          primaryFamilyId: familyId,
          primaryFamilyName: familyName,
          familyType: isDirect ? 'NZALA_DIRECT' : 'ALLIE',
          belongingType: isDirect ? 'APPARTENANCE_DIRECTE' : 'ALLIANCE_MARIAGE',
          membershipStatus: 'ACTIF',
          generationLevel: 3,
          generationStatus: 'ESTIMEE',
          branchName: targetReq.branchOrTown || (targetReq.targetNzalaMemberName ? `Lié à ${targetReq.targetNzalaMemberName}` : undefined),
          visibilityLevel: 'FAMILY',
          bio: `Membre validé suite à l'examen de l'affiliation : ${targetReq.explanation.slice(0, 140)}...`,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        setMembers((prev) => [...prev, newMember]);
      } else {
        // Update existing member record
        setMembers((prev) =>
          prev.map((m) =>
            m.id === existingMember!.id
              ? {
                  ...m,
                  userId: targetUserId || m.userId,
                  membershipStatus: 'ACTIF',
                  updatedAt: new Date().toISOString(),
                }
              : m
          )
        );
      }

      // Upgrade User Account and link memberId
      if (targetUserId) {
        setUserAccounts((prev) =>
          prev.map((acc) => {
            if (acc.id === targetUserId || acc.email.toLowerCase() === targetReq.applicantEmail.toLowerCase()) {
              return {
                ...acc,
                role: assignedRole,
                accountStatus: 'ACTIF',
                affiliationStatus: 'APPROUVEE',
                memberId: finalMemberId,
                primaryFamilyId: familyId,
                primaryFamilyName: familyName,
                familyType: isDirect ? 'NZALA_DIRECT' : 'ALLIE',
              };
            }
            return acc;
          })
        );
      }

      // If current active session is this user, upgrade session live
      if (currentUser.id === targetUserId || currentUser.email.toLowerCase() === targetReq.applicantEmail.toLowerCase()) {
        setCurrentUser((prev) => ({
          ...prev,
          role: assignedRole,
          accountStatus: 'ACTIF',
          affiliationStatus: 'APPROUVEE',
          verificationStatus: 'APPROUVEE',
          memberId: finalMemberId,
          familyId,
          familyName,
          familyType: isDirect ? 'NZALA_DIRECT' : 'ALLIE',
        }));
      }

      showToast('success', `Dossier approuvé. ${applicantName} a reçu le statut ${assignedRole === 'MEMBRE_NZALA' ? 'Membre Nzala' : 'Membre Allié'}.`);
    } else if (newStatus === 'COMPLEMENT_REQUIS') {
      if (targetUserId) {
        setUserAccounts((prev) =>
          prev.map((acc) =>
            acc.id === targetUserId ? { ...acc, affiliationStatus: 'COMPLEMENT_REQUIS' } : acc
          )
        );
      }
      if (currentUser.id === targetUserId) {
        setCurrentUser((prev) => ({ ...prev, affiliationStatus: 'COMPLEMENT_REQUIS' }));
      }
      showToast('warning', `Complément d'information demandé à ${applicantName}.`);
    } else if (newStatus === 'REFUSEE') {
      if (targetUserId) {
        setUserAccounts((prev) =>
          prev.map((acc) =>
            acc.id === targetUserId ? { ...acc, affiliationStatus: 'REFUSEE' } : acc
          )
        );
      }
      if (currentUser.id === targetUserId) {
        setCurrentUser((prev) => ({ ...prev, affiliationStatus: 'REFUSEE' }));
      }
      showToast('info', `Demande d'affiliation rejetée pour ${applicantName}.`);
    } else {
      showToast('info', `Statut mis à jour pour ${applicantName} : ${newStatus}`);
    }

    // Add audit entry
    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: `DECISION_VALIDATION_${newStatus}`,
      actionType: newStatus === 'APPROUVEE' ? 'ROLE_CHANGE' : 'VALIDATION',
      targetType: 'VERIFICATION_REQUEST',
      targetId: requestId,
      targetName: applicantName,
      details: `Statut: ${newStatus}. Décision par ${currentUser.name} (${currentUser.role}). Note: "${reviewerNotes || 'N/A'}"`,
      timestamp: new Date().toISOString(),
    };

    setAuditLogs((prev) => [newAudit, ...prev]);
  };

  // --- Family & Branch Operations ---
  const addFamily = (familyData: Omit<Family, 'id' | 'createdAt' | 'updatedAt' | 'membersCount' | 'alliancesCount'>): Family => {
    const newFamily: Family = {
      id: `fam-${Date.now()}`,
      ...familyData,
      membersCount: 0,
      alliancesCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setFamilies((prev) => [...prev, newFamily]);

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'CREATION_FAMILLE',
      actionType: 'FAMILY',
      targetType: 'FAMILY',
      targetId: newFamily.id,
      targetName: newFamily.name,
      details: `Création de la famille "${newFamily.name}" (${newFamily.type}).`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast('success', `Famille "${newFamily.name}" ajoutée.`);
    return newFamily;
  };

  const addBranch = (branchData: Omit<FamilyBranch, 'id' | 'createdAt' | 'updatedAt' | 'membersCount'>): FamilyBranch => {
    const newBranch: FamilyBranch = {
      id: `br-${Date.now()}`,
      ...branchData,
      membersCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setBranches((prev) => [...prev, newBranch]);

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'CREATION_BRANCHE',
      actionType: 'BRANCH',
      targetType: 'BRANCH',
      targetId: newBranch.id,
      targetName: newBranch.name,
      details: `Création de la branche "${newBranch.name}" pour ${newBranch.familyName}.`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast('success', `Branche "${newBranch.name}" créée.`);
    return newBranch;
  };

  // --- Member Operations ---
  const addMember = (
    memberData: Omit<Member, 'id' | 'createdAt' | 'updatedAt'>
  ): { success: boolean; member?: Member; error?: string } => {
    // Check if duplicate user link is attempted
    if (memberData.userId) {
      const check = validateUserMemberLink(memberData.userId, 'new', userAccounts, members);
      if (!check.isValid && check.error?.includes('déjà rattaché')) {
        return { success: false, error: check.error };
      }
    }

    const newMember: Member = {
      id: `mem-${Date.now()}`,
      ...memberData,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setMembers((prev) => [...prev, newMember]);

    // Update family members count
    setFamilies((prev) =>
      prev.map((f) => (f.id === newMember.primaryFamilyId ? { ...f, membersCount: f.membersCount + 1 } : f))
    );

    // If linked to a user account, update user account
    if (memberData.userId) {
      setUserAccounts((prev) =>
        prev.map((acc) => (acc.id === memberData.userId ? { ...acc, memberId: newMember.id } : acc))
      );
    }

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'CREATION_MEMBRE',
      actionType: 'MEMBER',
      targetType: 'MEMBER',
      targetId: newMember.id,
      targetName: `${newMember.firstName} ${newMember.lastName}`,
      details: `Création de la fiche membre (${newMember.familyType === 'NZALA_DIRECT' ? 'Famille Nzala' : 'Famille Alliée'}, Génération ${newMember.generationLevel}, Statut: ${newMember.livingStatus}).`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast('success', `Fiche membre créée pour ${newMember.firstName} ${newMember.lastName}.`);
    return { success: true, member: newMember };
  };

  const updateMember = (id: string, data: Partial<Member>) => {
    setMembers((prev) =>
      prev.map((m) => {
        if (m.id === id) {
          return {
            ...m,
            ...data,
            updatedAt: new Date().toISOString(),
          };
        }
        return m;
      })
    );

    const target = members.find((m) => m.id === id);
    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'MODIFICATION_MEMBRE',
      actionType: 'MEMBER',
      targetType: 'MEMBER',
      targetId: id,
      targetName: target ? `${target.firstName} ${target.lastName}` : id,
      details: `Mise à jour des informations de la fiche membre.`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast('success', 'Fiche membre mise à jour.');
  };

  const archiveMember = (id: string, reason?: string): { success: boolean; error?: string } => {
    const member = members.find((m) => m.id === id);
    if (!member) return { success: false, error: 'Membre introuvable.' };

    const activeRels = relationships.filter(
      (r) => (r.memberAId === id || r.memberBId === id) && r.status === 'VALIDEE'
    );

    // Soft delete: status ARCHIVE
    setMembers((prev) =>
      prev.map((m) => (m.id === id ? { ...m, membershipStatus: 'ARCHIVE', updatedAt: new Date().toISOString() } : m))
    );

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'ARCHIVAGE_MEMBRE',
      actionType: 'MEMBER',
      targetType: 'MEMBER',
      targetId: id,
      targetName: `${member.firstName} ${member.lastName}`,
      details: `Archivage de la fiche membre. ${activeRels.length} relations actives conservées dans le registre historique. Raison : ${reason || 'Archivage administratif'}.`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast('info', `Fiche de ${member.firstName} ${member.lastName} archivée.`);
    return { success: true };
  };

  // --- Relationship Operations ---
  const addRelationship = (data: {
    memberAId: string;
    memberBId: string;
    relationshipType: RelationshipType;
    status?: Relationship['status'];
    source?: Relationship['source'];
    startDate?: string;
    notes?: string;
  }): { success: boolean; error?: string; warning?: string; relationship?: Relationship } => {
    const check = validateRelationship(
      data.memberAId,
      data.memberBId,
      data.relationshipType,
      relationships,
      members
    );

    if (!check.isValid) {
      return { success: false, error: check.error };
    }

    const memberA = members.find((m) => m.id === data.memberAId)!;
    const memberB = members.find((m) => m.id === data.memberBId)!;
    const labels = getRelationshipLabel(data.relationshipType, memberA, memberB);

    const isDirectAdmin =
      currentUser.role === 'SUPER_ADMIN' ||
      currentUser.role === 'ADMIN_FAMILIAL' ||
      currentUser.role === 'VALIDATEUR';

    const newRelStatus: Relationship['status'] = data.status || (isDirectAdmin ? 'VALIDEE' : 'PROPOSEE');
    const newRelSource: Relationship['source'] = data.source || (isDirectAdmin ? 'ADMINISTRATEUR' : 'MEMBRE_PROPOSITION');

    const newRelationship: Relationship = {
      id: `rel-${Date.now()}`,
      memberAId: data.memberAId,
      memberAName: `${memberA.firstName} ${memberA.lastName}`,
      memberBId: data.memberBId,
      memberBName: `${memberB.firstName} ${memberB.lastName}`,
      relationshipType: data.relationshipType,
      relationLabel: labels.labelAtoB,
      status: newRelStatus,
      source: newRelSource,
      proposedBy: currentUser.id,
      proposedByName: currentUser.name,
      validatedBy: newRelStatus === 'VALIDEE' ? currentUser.id : undefined,
      validatedByName: newRelStatus === 'VALIDEE' ? currentUser.name : undefined,
      validatedAt: newRelStatus === 'VALIDEE' ? new Date().toISOString() : undefined,
      startDate: data.startDate,
      notes: data.notes,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setRelationships((prev) => [newRelationship, ...prev]);

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: newRelStatus === 'VALIDEE' ? 'VALIDATION_RELATION' : 'PROPOSITION_RELATION',
      actionType: 'RELATIONSHIP',
      targetType: 'RELATIONSHIP',
      targetId: newRelationship.id,
      targetName: `${memberA.firstName} ↔ ${memberB.firstName} (${data.relationshipType})`,
      details: `${newRelStatus === 'VALIDEE' ? 'Création et validation' : 'Proposition'} de la relation "${labels.labelAtoB}".`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast(
      'success',
      newRelStatus === 'VALIDEE'
        ? `Relation enregistrée et validée.`
        : `Proposition de relation soumise au Conseil de Famille.`
    );

    return { success: true, warning: check.warning, relationship: newRelationship };
  };

  const proposeRelationship = (data: {
    memberAId: string;
    memberBId: string;
    relationshipType: RelationshipType;
    startDate?: string;
    notes?: string;
  }): { success: boolean; error?: string; warning?: string } => {
    return addRelationship({
      ...data,
      status: 'PROPOSEE',
      source: 'MEMBRE_PROPOSITION',
    });
  };

  const validateRelationshipAction = (
    relationshipId: string,
    newStatus: 'VALIDEE' | 'REFUSEE' | 'SUSPENDUE',
    notes?: string
  ) => {
    const targetRel = relationships.find((r) => r.id === relationshipId);
    if (!targetRel) return;

    setRelationships((prev) =>
      prev.map((r) => {
        if (r.id === relationshipId) {
          return {
            ...r,
            status: newStatus,
            validatedBy: currentUser.id,
            validatedByName: currentUser.name,
            validatedAt: new Date().toISOString(),
            notes: notes || r.notes,
            updatedAt: new Date().toISOString(),
          };
        }
        return r;
      })
    );

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: `DECISION_RELATION_${newStatus}`,
      actionType: 'RELATIONSHIP',
      targetType: 'RELATIONSHIP',
      targetId: relationshipId,
      targetName: `${targetRel.memberAName} ↔ ${targetRel.memberBName} (${targetRel.relationshipType})`,
      details: `Statut de la relation passé à ${newStatus} par ${currentUser.name}. Note: "${notes || 'N/A'}"`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast(
      newStatus === 'VALIDEE' ? 'success' : 'info',
      `Relation ${newStatus === 'VALIDEE' ? 'validée avec succès' : newStatus === 'REFUSEE' ? 'rejetée' : 'suspendue'}.`
    );
  };

  const deleteRelationship = (relationshipId: string) => {
    const targetRel = relationships.find((r) => r.id === relationshipId);
    if (!targetRel) return;

    setRelationships((prev) => prev.filter((r) => r.id !== relationshipId));

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'SUPPRESSION_RELATION',
      actionType: 'RELATIONSHIP',
      targetType: 'RELATIONSHIP',
      targetId: relationshipId,
      targetName: `${targetRel.memberAName} ↔ ${targetRel.memberBName} (${targetRel.relationshipType})`,
      details: `Suppression définitive du lien de parenté.`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [newAudit, ...prev]);
    showToast('info', 'Lien de parenté supprimé du registre.');
  };

  // --- Alliance Operations ---
  const addAlliance = (
    allianceData: Omit<Alliance, 'id' | 'createdAt'>
  ): { success: boolean; error?: string; alliance?: Alliance } => {
    const check = validateAlliance(
      allianceData.sourceFamilyId,
      allianceData.alliedFamilyId,
      allianceData.allianceType,
      alliances
    );

    if (!check.isValid) {
      return { success: false, error: check.error };
    }

    const newAlliance: Alliance = {
      id: `ali-${Date.now()}`,
      ...allianceData,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setAlliances((prev) => [newAlliance, ...prev]);

    setFamilies((prev) =>
      prev.map((f) => {
        if (f.id === allianceData.sourceFamilyId || f.id === allianceData.alliedFamilyId) {
          return { ...f, alliancesCount: f.alliancesCount + 1 };
        }
        return f;
      })
    );

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'CREATION_ALLIANCE',
      actionType: 'ALLIANCE',
      targetType: 'ALLIANCE',
      targetId: newAlliance.id,
      targetName: newAlliance.title,
      details: `Alliance enregistrée entre ${newAlliance.sourceFamilyName} et ${newAlliance.alliedFamilyName} (${newAlliance.status}).`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast('success', `Alliance enregistrée avec succès.`);
    return { success: true, alliance: newAlliance };
  };

  const validateAllianceAction = (
    allianceId: string,
    newStatus: Alliance['status'],
    notes?: string
  ) => {
    const target = alliances.find((a) => a.id === allianceId);
    if (!target) return;

    setAlliances((prev) =>
      prev.map((a) => {
        if (a.id === allianceId) {
          return {
            ...a,
            status: newStatus,
            validatedBy: currentUser.id,
            validatedByName: currentUser.name,
            validatedAt: new Date().toISOString(),
            notes: notes || a.notes,
            updatedAt: new Date().toISOString(),
          };
        }
        return a;
      })
    );

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: `DECISION_ALLIANCE_${newStatus}`,
      actionType: 'ALLIANCE',
      targetType: 'ALLIANCE',
      targetId: allianceId,
      targetName: target.title,
      details: `Statut de l'alliance passé à ${newStatus}.`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast('success', `Alliance mise à jour : ${newStatus}`);
  };

  // --- User-Member Link Operations ---
  const linkUserToMember = (userId: string, memberId: string): { success: boolean; error?: string } => {
    const check = validateUserMemberLink(userId, memberId, userAccounts, members);
    if (!check.isValid) {
      return { success: false, error: check.error };
    }

    const member = members.find((m) => m.id === memberId)!;
    const user = userAccounts.find((u) => u.id === userId)!;

    // Update UserAccount
    setUserAccounts((prev) =>
      prev.map((acc) =>
        acc.id === userId
          ? {
              ...acc,
              memberId: member.id,
              primaryFamilyId: member.primaryFamilyId,
              primaryFamilyName: member.primaryFamilyName,
              familyType: member.familyType,
              role: member.familyType === 'NZALA_DIRECT' ? 'MEMBRE_NZALA' : 'MEMBRE_ALLIE',
            }
          : acc
      )
    );

    // Update Member
    setMembers((prev) =>
      prev.map((m) => (m.id === memberId ? { ...m, userId: user.id, email: user.email, phone: user.phone || m.phone } : m))
    );

    // If linking active session user
    if (currentUser.id === userId) {
      setCurrentUser((prev) => ({
        ...prev,
        memberId: member.id,
        familyId: member.primaryFamilyId,
        familyName: member.primaryFamilyName,
        familyType: member.familyType,
        role: member.familyType === 'NZALA_DIRECT' ? 'MEMBRE_NZALA' : 'MEMBRE_ALLIE',
      }));
    }

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'LIAISON_COMPTE_MEMBRE',
      actionType: 'ROLE_CHANGE',
      targetType: 'USER',
      targetId: userId,
      targetName: `${user.firstName} ${user.lastName}`,
      details: `Liaison du compte utilisateur ${user.email} avec la fiche membre ${member.firstName} ${member.lastName} (${member.id}).`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast('success', `Compte de ${user.firstName} associé à la fiche de ${member.firstName} ${member.lastName}.`);
    return { success: true };
  };

  const unlinkUserFromMember = (userId: string, memberId: string): { success: boolean; error?: string } => {
    setUserAccounts((prev) =>
      prev.map((acc) => (acc.id === userId ? { ...acc, memberId: undefined } : acc))
    );

    setMembers((prev) =>
      prev.map((m) => (m.id === memberId ? { ...m, userId: undefined } : m))
    );

    if (currentUser.id === userId) {
      setCurrentUser((prev) => ({
        ...prev,
        memberId: undefined,
      }));
    }

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'DISSOCIATION_COMPTE_MEMBRE',
      actionType: 'ROLE_CHANGE',
      targetType: 'USER',
      targetId: userId,
      targetName: userId,
      details: `Dissociation du compte utilisateur et de la fiche membre ${memberId}.`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast('info', 'Liaison compte-membre dissociée.');
    return { success: true };
  };

  // --- Upcoming Birthdays Calculation ---
  const upcomingBirthdays = useMemo(() => {
    return calculateUpcomingBirthdays(members, currentUser);
  }, [members, currentUser]);

  // --- Event & Calendar Operations ---
  const addEvent = (
    eventData: Omit<FamilyEvent, 'id' | 'createdAt' | 'updatedAt' | 'participantsCount'>
  ): { success: boolean; event?: FamilyEvent; error?: string } => {
    if (!can('CREATE_EVENT')) {
      showToast('error', "Vous n'avez pas l'autorisation requise pour créer un événement.");
      return { success: false, error: 'Permission refusée' };
    }

    const validation = validateEventData(eventData);
    if (!validation.isValid) {
      const errorMsg = validation.errors[0] || 'Données invalides pour l’événement.';
      showToast('error', errorMsg);
      return { success: false, error: errorMsg };
    }

    const newId = `evt-${Date.now()}`;
    const nowIso = new Date().toISOString();

    const createdEvent: FamilyEvent = {
      ...eventData,
      id: newId,
      status: eventData.status || 'PLANIFIE',
      participantsCount: eventData.invitations?.filter((i) => i.status === 'CONFIRME').length || 1,
      createdAt: nowIso,
      updatedAt: nowIso,
      organizerId: eventData.organizerId || currentUser.id,
      organizerName: eventData.organizerName || currentUser.name,
      organizerFamily: eventData.organizerFamily || currentUser.familyName || 'Famille Nzala',
    };

    setEvents((prev) => [createdEvent, ...prev]);

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'CREATION_EVENEMENT',
      actionType: 'EVENT',
      targetType: 'EVENT',
      targetId: newId,
      targetName: createdEvent.title,
      details: `Création de l'événement "${createdEvent.title}" (${createdEvent.eventType}) prévu le ${createdEvent.startDate}.`,
      timestamp: nowIso,
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast('success', `L'événement "${createdEvent.title}" a été programmé avec succès !`);
    return { success: true, event: createdEvent };
  };

  // --- PUBLICATIONS & FIL FAMILIAL METHODS ---
  const visiblePosts = useMemo(() => {
    return posts
      .filter((p) => canUserViewPost(p, currentUser))
      .sort((a, b) => {
        // Epinglé d'abord
        if (a.isPinned && !b.isPinned) return -1;
        if (!a.isPinned && b.isPinned) return 1;
        const timeA = new Date(a.publishedAt || a.createdAt).getTime();
        const timeB = new Date(b.publishedAt || b.createdAt).getTime();
        return timeB - timeA;
      });
  }, [posts, currentUser]);

  const createPost = (
    data: Partial<FamilyPost>
  ): { success: boolean; post?: FamilyPost; error?: string } => {
    const validation = validatePostData(data);
    if (!validation.isValid) {
      const msg = validation.errors[0] || 'Données de publication invalides.';
      showToast('error', msg);
      return { success: false, error: msg };
    }

    const isOfficialDraft = data.isOfficial || data.postType === 'COMMUNIQUE_OFFICIEL';
    if (isOfficialDraft && !canUserCreateOfficialPost(currentUser)) {
      showToast('error', 'Seuls les Administrateurs Familiaux et le Conseil peuvent publier des communiqués officiels.');
      return { success: false, error: 'Permission refusée pour publication officielle.' };
    }

    const nowIso = new Date().toISOString();
    const newId = `post-${Date.now()}`;
    const initialStatus = data.status || 'PUBLIE';
    const initialModStatus: PostModerationStatus =
      initialStatus === 'BROUILLON'
        ? 'EN_ATTENTE_MODERATION'
        : currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL' || currentUser.role === 'VALIDATEUR'
        ? 'APPROUVE'
        : 'EN_ATTENTE_MODERATION';

    const newPost: FamilyPost = {
      id: newId,
      title: data.title!.trim(),
      content: data.content!.trim(),
      summary: data.summary?.trim() || undefined,
      postType: data.postType || 'ACTUALITE_FAMILIALE',
      scope: data.scope || 'NZALA_INTERNE',
      status: initialStatus,
      moderationStatus: initialModStatus,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorRole: currentUser.role,
      authorAvatar: currentUser.avatarUrl,
      authorType:
        currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL'
          ? (data.authorType || 'CONSEIL_FAMILLE')
          : 'MEMBRE',
      authorFamilyId: currentUser.familyId || 'fam-nzala',
      authorFamilyName: currentUser.familyName || 'Famille Nzala',
      targetFamilyId: data.targetFamilyId,
      targetFamilyName: data.targetFamilyName,
      targetBranchId: data.targetBranchId,
      targetBranchName: data.targetBranchName,
      targetAlliedFamilyId: data.targetAlliedFamilyId,
      targetAlliedFamilyName: data.targetAlliedFamilyName,
      targetAllianceId: data.targetAllianceId,
      relatedEventId: data.relatedEventId,
      relatedEventTitle: data.relatedEventTitle,
      relatedMemberId: data.relatedMemberId,
      relatedMemberName: data.relatedMemberName,
      imageUrl: data.imageUrl,
      mediaCaption: data.mediaCaption,
      isOfficial: Boolean(data.isOfficial || data.postType === 'COMMUNIQUE_OFFICIEL'),
      isPinned: Boolean(data.isPinned),
      isImportant: Boolean(data.isImportant),
      reactions: [],
      reactionsCount: 0,
      comments: [],
      commentsCount: 0,
      publishedAt: initialStatus === 'PUBLIE' ? nowIso : undefined,
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    setPosts((prev) => [newPost, ...prev]);

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'CREATION_POST' as any,
      actionType: 'POST',
      targetType: 'POST',
      targetId: newId,
      targetName: newPost.title || 'Publication sans titre',
      details: `Création d'une publication "${newPost.title || 'Sans titre'}" [${newPost.postType}, Portée: ${newPost.scope}].`,
      timestamp: nowIso,
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast(
      'success',
      initialStatus === 'BROUILLON'
        ? 'Brouillon de publication enregistré.'
        : initialModStatus === 'EN_ATTENTE_MODERATION'
        ? 'Publication soumise. Elle apparaîtra après validation par le conseil.'
        : 'Publication diffusée sur le fil familial !'
    );

    return { success: true, post: newPost };
  };

  const updatePost = (
    id: string,
    data: Partial<FamilyPost>
  ): { success: boolean; error?: string } => {
    const existing = posts.find((p) => p.id === id);
    if (!existing) {
      return { success: false, error: 'Publication introuvable.' };
    }

    if (!canUserEditPost(existing, currentUser)) {
      showToast('error', 'Vous n’avez pas les droits pour modifier cette publication.');
      return { success: false, error: 'Accès non autorisé.' };
    }

    const nowIso = new Date().toISOString();
    setPosts((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              ...data,
              updatedAt: nowIso,
            }
          : p
      )
    );

    showToast('success', 'Publication mise à jour avec succès.');
    return { success: true };
  };

  const deletePost = (id: string, reason?: string): { success: boolean; error?: string } => {
    const existing = posts.find((p) => p.id === id);
    if (!existing) return { success: false, error: 'Publication introuvable.' };

    if (!canUserDeletePost(existing, currentUser)) {
      showToast('error', 'Vous n’avez pas l’autorisation de supprimer cette publication.');
      return { success: false, error: 'Accès non autorisé.' };
    }

    setPosts((prev) => prev.filter((p) => p.id !== id));

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'SUPPRESSION_POST' as any,
      actionType: 'POST',
      targetType: 'POST',
      targetId: id,
      targetName: existing.title || 'Publication sans titre',
      details: `Suppression de la publication "${existing.title || 'Sans titre'}". Motif : ${reason || 'Non spécifié'}`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast('info', 'La publication a été supprimée.');
    return { success: true };
  };

  const archivePost = (id: string): { success: boolean; error?: string } => {
    return updatePost(id, { status: 'ARCHIVE' });
  };

  const suspendPost = (id: string, reason?: string): { success: boolean; error?: string } => {
    if (!canUserModeratePost(currentUser)) {
      showToast('error', 'Action réservée aux modérateurs et administrateurs.');
      return { success: false, error: 'Accès non autorisé.' };
    }
    return updatePost(id, { status: 'SUSPENDU', moderationDecision: reason });
  };

  const restorePost = (id: string): { success: boolean; error?: string } => {
    return updatePost(id, { status: 'PUBLIE' });
  };

  const togglePinPost = (id: string): { success: boolean; error?: string } => {
    if (!canUserModeratePost(currentUser)) {
      showToast('error', 'Seuls les modérateurs peuvent épingler une publication.');
      return { success: false, error: 'Action non autorisée.' };
    }
    const target = posts.find((p) => p.id === id);
    if (!target) return { success: false, error: 'Publication introuvable.' };

    const newPinned = !target.isPinned;
    setPosts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, isPinned: newPinned, updatedAt: new Date().toISOString() } : p))
    );
    showToast('success', newPinned ? 'Publication épinglée en tête du fil.' : 'Publication désépinglée.');
    return { success: true };
  };

  const moderatePost = (
    id: string,
    decision: 'APPROUVE' | 'REFUSE',
    notes?: string
  ): { success: boolean; error?: string } => {
    if (!canUserModeratePost(currentUser)) {
      showToast('error', 'Action réservée aux validateurs et administrateurs.');
      return { success: false, error: 'Accès non autorisé.' };
    }
    const target = posts.find((p) => p.id === id);
    if (!target) return { success: false, error: 'Publication introuvable.' };

    const nowIso = new Date().toISOString();
    setPosts((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              moderationStatus: decision,
              status: decision === 'APPROUVE' ? 'PUBLIE' : 'SUSPENDU',
              moderatedBy: currentUser.id,
              moderatedByName: currentUser.name,
              moderatedAt: nowIso,
              moderationDecision: notes,
              publishedAt: decision === 'APPROUVE' && !p.publishedAt ? nowIso : p.publishedAt,
              updatedAt: nowIso,
            }
          : p
      )
    );

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'MODERATION_POST' as any,
      actionType: 'MODERATION',
      targetType: 'POST',
      targetId: id,
      targetName: target.title || 'Publication sans titre',
      details: `Modération de la publication "${target.title || 'Sans titre'}" : ${decision}. Notes: ${notes || 'Aucune'}`,
      timestamp: nowIso,
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast('success', `La publication a été ${decision === 'APPROUVE' ? 'approuvée et publiée' : 'rejetée'}.`);
    return { success: true };
  };

  const addPostReaction = (
    postId: string,
    reactionType: ReactionType
  ): { success: boolean; error?: string } => {
    const target = posts.find((p) => p.id === postId);
    if (!target) return { success: false, error: 'Publication introuvable.' };

    if (!canUserReact(target, currentUser)) {
      showToast('error', 'Vous n’avez pas l’autorisation de réagir à cette publication.');
      return { success: false, error: 'Non autorisé.' };
    }

    const existingReactionIndex = target.reactions.findIndex(
      (r) => r.userId === currentUser.id || (currentUser.memberId && r.memberId === currentUser.memberId)
    );

    const nowIso = new Date().toISOString();
    let updatedReactions = [...target.reactions];

    if (existingReactionIndex >= 0) {
      if (updatedReactions[existingReactionIndex].reactionType === reactionType) {
        // Toggle off (remove)
        updatedReactions.splice(existingReactionIndex, 1);
      } else {
        // Change reaction type
        updatedReactions[existingReactionIndex] = {
          ...updatedReactions[existingReactionIndex],
          reactionType,
          createdAt: nowIso,
        };
      }
    } else {
      const newReaction: PostReaction = {
        id: `react-${Date.now()}`,
        postId,
        userId: currentUser.id,
        memberId: currentUser.memberId,
        userName: currentUser.name,
        userFamilyName: currentUser.familyName,
        reactionType,
        createdAt: nowIso,
      };
      updatedReactions.push(newReaction);
    }

    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId
          ? {
              ...p,
              reactions: updatedReactions,
              reactionsCount: updatedReactions.length,
            }
          : p
      )
    );

    return { success: true };
  };

  const removePostReaction = (postId: string): { success: boolean; error?: string } => {
    const target = posts.find((p) => p.id === postId);
    if (!target) return { success: false, error: 'Publication introuvable.' };

    const updated = target.reactions.filter(
      (r) => r.userId !== currentUser.id && (!currentUser.memberId || r.memberId !== currentUser.memberId)
    );

    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId
          ? {
              ...p,
              reactions: updated,
              reactionsCount: updated.length,
            }
          : p
      )
    );

    return { success: true };
  };

  const addPostComment = (
    postId: string,
    content: string
  ): { success: boolean; comment?: PostComment; error?: string } => {
    if (!content || content.trim().length === 0) {
      return { success: false, error: 'Le commentaire ne peut pas être vide.' };
    }

    const target = posts.find((p) => p.id === postId);
    if (!target) return { success: false, error: 'Publication introuvable.' };

    if (!canUserComment(target, currentUser)) {
      showToast('error', 'Vous n’avez pas les droits pour commenter cette publication.');
      return { success: false, error: 'Non autorisé.' };
    }

    const nowIso = new Date().toISOString();
    const newComment: PostComment = {
      id: `com-${Date.now()}`,
      postId,
      authorId: currentUser.id,
      authorMemberId: currentUser.memberId,
      authorName: currentUser.name,
      authorRole: currentUser.role,
      authorAvatar: currentUser.avatarUrl,
      authorFamilyName: currentUser.familyName,
      content: content.trim(),
      status: 'ACTIF',
      createdAt: nowIso,
    };

    const updatedComments = [...target.comments, newComment];

    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId
          ? {
              ...p,
              comments: updatedComments,
              commentsCount: updatedComments.length,
            }
          : p
      )
    );

    showToast('success', 'Votre commentaire a été publié.');
    return { success: true, comment: newComment };
  };

  const updatePostComment = (
    postId: string,
    commentId: string,
    content: string
  ): { success: boolean; error?: string } => {
    const target = posts.find((p) => p.id === postId);
    if (!target) return { success: false, error: 'Publication introuvable.' };

    const comment = target.comments.find((c) => c.id === commentId);
    if (!comment) return { success: false, error: 'Commentaire introuvable.' };

    if (comment.authorId !== currentUser.id && currentUser.role !== 'SUPER_ADMIN' && currentUser.role !== 'ADMIN_FAMILIAL') {
      return { success: false, error: 'Non autorisé à modifier ce commentaire.' };
    }

    const updatedComments = target.comments.map((c) =>
      c.id === commentId ? { ...c, content: content.trim(), updatedAt: new Date().toISOString() } : c
    );

    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId
          ? {
              ...p,
              comments: updatedComments,
            }
          : p
      )
    );

    showToast('success', 'Commentaire mis à jour.');
    return { success: true };
  };

  const deletePostComment = (
    postId: string,
    commentId: string
  ): { success: boolean; error?: string } => {
    const target = posts.find((p) => p.id === postId);
    if (!target) return { success: false, error: 'Publication introuvable.' };

    const comment = target.comments.find((c) => c.id === commentId);
    if (!comment) return { success: false, error: 'Commentaire introuvable.' };

    if (comment.authorId !== currentUser.id && !canUserModeratePost(currentUser)) {
      return { success: false, error: 'Non autorisé à supprimer ce commentaire.' };
    }

    const updatedComments = target.comments.filter((c) => c.id !== commentId);

    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId
          ? {
              ...p,
              comments: updatedComments,
              commentsCount: updatedComments.length,
            }
          : p
      )
    );

    showToast('info', 'Commentaire supprimé.');
    return { success: true };
  };

  const reportPostComment = (
    postId: string,
    commentId: string,
    reason?: string
  ): { success: boolean; error?: string } => {
    const target = posts.find((p) => p.id === postId);
    if (!target) return { success: false, error: 'Publication introuvable.' };

    const updatedComments = target.comments.map((c) =>
      c.id === commentId
        ? {
            ...c,
            isReported: true,
            reportCount: (c.reportCount || 0) + 1,
            reportReason: reason || 'Contenu inapproprié signalé',
          }
        : c
    );

    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId
          ? {
              ...p,
              comments: updatedComments,
            }
          : p
      )
    );

    showToast('info', 'Commentaire signalé à la modération du Conseil.');
    return { success: true };
  };

  const moderatePostComment = (
    postId: string,
    commentId: string,
    status: 'ACTIF' | 'MASQUE' | 'SUPPRIME'
  ): { success: boolean; error?: string } => {
    if (!canUserModeratePost(currentUser)) {
      return { success: false, error: 'Accès modérateur requis.' };
    }

    const target = posts.find((p) => p.id === postId);
    if (!target) return { success: false, error: 'Publication introuvable.' };

    const updatedComments = target.comments.map((c) =>
      c.id === commentId ? { ...c, status } : c
    );

    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId
          ? {
              ...p,
              comments: updatedComments,
            }
          : p
      )
    );

    showToast('success', `Statut du commentaire mis à jour (${status}).`);
    return { success: true };
  };

  const createPostFromEvent = (
    event: FamilyEvent,
    customNote?: string
  ): { success: boolean; post?: FamilyPost; error?: string } => {
    const eventPostType: any =
      event.eventType === 'MARIAGE'
        ? 'MARIAGE'
        : event.eventType === 'COMMEMORATION'
        ? 'MEMOIRE_FAMILIALE'
        : event.eventType === 'CONSEIL_FAMILLE'
        ? 'COMMUNIQUE_OFFICIEL'
        : 'EVENEMENT';

    const eventScope =
      event.visibility === 'PUBLIC'
        ? 'PUBLIC'
        : event.visibility === 'NZALA_INTERNE'
        ? 'NZALA_INTERNE'
        : event.visibility === 'FAMILLE_ALLIEE'
        ? 'FAMILLE_ALLIEE'
        : event.visibility === 'INTER_FAMILLES'
        ? 'INTER_FAMILLES'
        : 'PRIVE';

    return createPost({
      title: `Événement : ${event.title}`,
      content: `${event.description}${customNote ? `\n\nNote complémentaire : ${customNote}` : ''}\n\nDate : ${event.startDate} à ${event.location}.`,
      summary: `Publication automatique liée à l’événement "${event.title}".`,
      postType: eventPostType,
      scope: eventScope,
      status: 'PUBLIE',
      relatedEventId: event.id,
      relatedEventTitle: event.title,
      targetFamilyId: event.familyId,
      targetAlliedFamilyId: event.alliedFamilyId,
      targetBranchId: event.branchId,
      isOfficial: event.isConfidential || event.eventType === 'CONSEIL_FAMILLE',
    });
  };

  const markNotificationAsRead = (notificationId: string) => {
    setNotifications((prev) =>
      prev.map((n) =>
        n.id === notificationId
          ? { ...n, isRead: true, read: true, readAt: new Date().toISOString() }
          : n
      )
    );
  };

  const markAllNotificationsAsRead = () => {
    const nowIso = new Date().toISOString();
    setNotifications((prev) =>
      prev.map((n) => ({ ...n, isRead: true, read: true, readAt: nowIso }))
    );
    showToast('info', 'Toutes les notifications ont été marquées comme lues.');
  };

  const deleteNotification = (notificationId: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== notificationId));
    showToast('info', 'Notification retirée.');
  };

  const clearReadNotifications = () => {
    setNotifications((prev) => prev.filter((n) => !n.read && !n.isRead));
    showToast('info', 'Toutes les notifications lues ont été effacées.');
  };

  const handleNotificationQuickAction = (
    notificationId: string,
    action: 'ACCEPT' | 'REJECT'
  ) => {
    const notif = notifications.find((n) => n.id === notificationId);
    if (!notif) return;

    if (notif.type === 'DEMANDE_ACCES_PROFIL') {
      if (action === 'ACCEPT') {
        showToast('success', `Accès accordé à ${notif.senderName || 'ce membre'}.`);
        if (notif.senderId) {
          addNotification({
            userId: notif.senderId,
            category: 'FAMILY',
            type: 'ACCES_PROFIL_ACCEPTE',
            title: 'Demande d’accès acceptée',
            body: `${currentUser.name} a accepté votre demande d'accès à son profil privé.`,
            targetId: currentUser.id,
            targetType: 'PROFILE',
            senderId: currentUser.id,
            senderName: currentUser.name,
            senderAvatar: currentUser.avatarUrl,
            linkTab: 'profile',
          });
        }
      } else {
        showToast('info', "Demande d'accès refusée.");
      }
    }

    setNotifications((prev) =>
      prev.map((n) =>
        n.id === notificationId
          ? {
              ...n,
              read: true,
              isRead: true,
              metadata: {
                ...n.metadata,
                quickActionState: action === 'ACCEPT' ? 'ACCEPTED' : 'REJECTED',
              },
            }
          : n
      )
    );
  };

  const createOfficialNotification = (
    title: string,
    body: string,
    priority: 'NORMALE' | 'HAUTE' | 'URGENTE' = 'NORMALE'
  ) => {
    const notifId = `notif-sys-${Date.now()}`;
    const newNotif: FamilyNotification = {
      id: notifId,
      userId: 'all',
      category: 'SYSTEM',
      type: 'SYSTEME_COMMUNIQUE',
      title: title.trim(),
      body: body.trim(),
      targetType: 'ADMIN',
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderRole: currentUser.role,
      senderAvatar: currentUser.avatarUrl,
      senderVerifiedBadge: '👑 Conseil / Administration',
      read: false,
      isRead: false,
      createdAt: new Date().toISOString(),
      linkTab: 'announcements',
      metadata: {
        isOfficialAnnouncement: true,
        priority,
      },
    };

    setNotifications((prev) => [newNotif, ...prev]);

    const audit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'PUBLICATION_CREEE',
      actionType: 'POST',
      targetType: 'POST',
      targetId: notifId,
      targetName: title,
      details: `Notification officielle diffusée : ${title} (${priority})`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [audit, ...prev]);

    showToast('success', 'Notification officielle diffusée à tous les membres.');
  };

  const updateEvent = (
    id: string,
    data: Partial<FamilyEvent>
  ): { success: boolean; error?: string } => {
    const existing = events.find((e) => e.id === id);
    if (!existing) {
      return { success: false, error: 'Événement introuvable.' };
    }

    const isOrganizer =
      existing.organizerId === currentUser.id ||
      (currentUser.memberId && existing.organizerId === currentUser.memberId);
    const isAdmin = currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL';

    if (!isAdmin && !isOrganizer && !can('EDIT_EVENT')) {
      showToast('error', "Vous n'avez pas l'autorisation de modifier cet événement.");
      return { success: false, error: 'Permission refusée' };
    }

    const nowIso = new Date().toISOString();
    setEvents((prev) =>
      prev.map((evt) => {
        if (evt.id === id) {
          const updated = {
            ...evt,
            ...data,
            updatedAt: nowIso,
          };
          if (data.invitations) {
            updated.participantsCount = data.invitations.filter((i) => i.status === 'CONFIRME').length;
          }
          return updated;
        }
        return evt;
      })
    );

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'MODIFICATION_EVENEMENT',
      actionType: 'EVENT',
      targetType: 'EVENT',
      targetId: id,
      targetName: data.title || existing.title,
      details: `Modification de l'événement "${existing.title}".`,
      timestamp: nowIso,
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast('success', `Événement "${existing.title}" mis à jour.`);
    return { success: true };
  };

  const cancelEvent = (id: string, reason?: string): { success: boolean; error?: string } => {
    const existing = events.find((e) => e.id === id);
    if (!existing) {
      return { success: false, error: 'Événement introuvable.' };
    }

    const isOrganizer =
      existing.organizerId === currentUser.id ||
      (currentUser.memberId && existing.organizerId === currentUser.memberId);
    const isAdmin = currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL';

    if (!isAdmin && !isOrganizer) {
      showToast('error', "Seul l'organisateur ou un administrateur peut annuler cet événement.");
      return { success: false, error: 'Permission refusée' };
    }

    const nowIso = new Date().toISOString();
    setEvents((prev) =>
      prev.map((evt) => (evt.id === id ? { ...evt, status: 'ANNULE', updatedAt: nowIso } : evt))
    );

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'ANNULATION_EVENEMENT',
      actionType: 'EVENT',
      targetType: 'EVENT',
      targetId: id,
      targetName: existing.title,
      details: `Annulation de l'événement "${existing.title}". Motif : ${reason || 'Non précisé'}`,
      timestamp: nowIso,
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast('warning', `L'événement "${existing.title}" a été annulé.`);
    return { success: true };
  };

  const deleteEvent = (id: string): { success: boolean; error?: string } => {
    const existing = events.find((e) => e.id === id);
    if (!existing) {
      return { success: false, error: 'Événement introuvable.' };
    }

    const isOrganizer =
      existing.organizerId === currentUser.id ||
      (currentUser.memberId && existing.organizerId === currentUser.memberId);
    const isAdmin = currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL';

    if (!isAdmin && !isOrganizer) {
      showToast('error', "Seul l'organisateur ou un administrateur peut supprimer cet événement.");
      return { success: false, error: 'Permission refusée' };
    }

    setEvents((prev) => prev.filter((evt) => evt.id !== id));

    const newAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'SUPPRESSION_EVENEMENT',
      actionType: 'EVENT',
      targetType: 'EVENT',
      targetId: id,
      targetName: existing.title,
      details: `Suppression définitive de l'événement "${existing.title}".`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [newAudit, ...prev]);

    showToast('info', `Événement "${existing.title}" supprimé.`);
    return { success: true };
  };

  const rsvpEvent = (
    eventId: string,
    status: InvitationStatus,
    note?: string
  ): { success: boolean; error?: string } => {
    const existing = events.find((e) => e.id === eventId);
    if (!existing) {
      return { success: false, error: 'Événement introuvable.' };
    }

    const nowIso = new Date().toISOString();
    const invitations = existing.invitations || [];
    const userMemberId = currentUser.memberId;
    const userId = currentUser.id;

    const existingInvIndex = invitations.findIndex(
      (inv) =>
        (userId && inv.userId === userId) ||
        (userMemberId && inv.memberId === userMemberId) ||
        (inv.targetType === 'PERSON' && inv.targetId === userMemberId)
    );

    let updatedInvitations = [...invitations];

    if (existingInvIndex >= 0) {
      updatedInvitations[existingInvIndex] = {
        ...updatedInvitations[existingInvIndex],
        status,
        responseNote: note || updatedInvitations[existingInvIndex].responseNote,
        respondedAt: nowIso,
        userId: userId,
        memberId: userMemberId,
      };
    } else {
      updatedInvitations.push({
        id: `inv-${Date.now()}`,
        eventId,
        targetType: 'PERSON',
        targetId: userMemberId || userId,
        targetName: currentUser.name,
        userId: userId,
        memberId: userMemberId,
        status,
        responseNote: note,
        respondedAt: nowIso,
        invitedAt: nowIso,
        invitedBy: 'Auto-inscription',
      });
    }

    const confirmedCount = updatedInvitations.filter((i) => i.status === 'CONFIRME').length;

    setEvents((prev) =>
      prev.map((evt) =>
        evt.id === eventId
          ? {
              ...evt,
              invitations: updatedInvitations,
              participantsCount: confirmedCount,
              updatedAt: nowIso,
            }
          : evt
      )
    );

    const statusLabels: Record<InvitationStatus, string> = {
      CONFIRME: 'confirmé votre présence',
      DECLINE: 'décliné l’invitation',
      PEUT_ETRE: 'indiqué votre présence comme incertaine',
      INVITE: 'enregistré votre statut',
    };

    showToast('success', `Vous avez ${statusLabels[status]} à "${existing.title}".`);
    return { success: true };
  };

  const inviteToEvent = (
    eventId: string,
    target: {
      targetType: InvitationTargetType;
      targetId?: string;
      targetName: string;
      userId?: string;
      memberId?: string;
      userEmail?: string;
    }
  ): { success: boolean; error?: string } => {
    const existing = events.find((e) => e.id === eventId);
    if (!existing) {
      return { success: false, error: 'Événement introuvable.' };
    }

    const nowIso = new Date().toISOString();
    const newInvitation = {
      id: `inv-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      eventId,
      targetType: target.targetType,
      targetId: target.targetId,
      targetName: target.targetName,
      userId: target.userId,
      memberId: target.memberId,
      userEmail: target.userEmail,
      status: 'INVITE' as InvitationStatus,
      invitedAt: nowIso,
      invitedBy: currentUser.name,
    };

    const updatedInvitations = [...(existing.invitations || []), newInvitation];

    setEvents((prev) =>
      prev.map((evt) =>
        evt.id === eventId
          ? {
              ...evt,
              invitations: updatedInvitations,
              updatedAt: nowIso,
            }
          : evt
      )
    );

    showToast('success', `Invitation envoyée à ${target.targetName}.`);
    return { success: true };
  };

  const alliedFamilies = useMemo(() => {
    return families.filter((f) => f.type === 'ALLIEE');
  }, [families]);

  // --- STORIES & STATUTS ACTIONS ---
  const addStory = (storyData: Omit<FamilyStory, 'id' | 'createdAt' | 'expiresAt' | 'viewedByUserIds'>) => {
    const now = new Date();
    const expires = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    const newStory: FamilyStory = {
      ...storyData,
      id: `story-${Date.now()}`,
      createdAt: now.toISOString(),
      expiresAt: expires.toISOString(),
      viewedByUserIds: [],
      views: [],
      reactions: [],
    };
    setStories((prev) => [newStory, ...prev]);
    showToast('success', 'Votre story a été publiée pour 24 heures !');
  };

  const deleteStory = (id: string) => {
    setStories((prev) => prev.filter((s) => s.id !== id));
    showToast('info', 'Story supprimée.');
  };

  const viewStory = (id: string) => {
    setStories((prev) =>
      prev.map((s) => {
        if (s.id === id) {
          const viewedBy = s.viewedByUserIds.includes(currentUser.id)
            ? s.viewedByUserIds
            : [...s.viewedByUserIds, currentUser.id];

          const existingViews = s.views || [];
          const hasViewed = existingViews.some((v) => v.userId === currentUser.id);
          const updatedViews: StoryViewer[] = hasViewed
            ? existingViews
            : [
                ...existingViews,
                {
                  userId: currentUser.id,
                  userName: currentUser.name,
                  userAvatar: currentUser.avatarUrl,
                  viewedAt: new Date().toISOString(),
                },
              ];

          return {
            ...s,
            viewedByUserIds: viewedBy,
            views: updatedViews,
          };
        }
        return s;
      })
    );
  };

  const addStoryReaction = (storyId: string, emoji: string) => {
    setStories((prev) =>
      prev.map((s) => {
        if (s.id === storyId) {
          const newReaction: StoryReaction = {
            id: `story-react-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            userId: currentUser.id,
            userName: currentUser.name,
            userAvatar: currentUser.avatarUrl,
            reaction: emoji,
            createdAt: new Date().toISOString(),
          };
          const updatedReactions = [...(s.reactions || []), newReaction];
          return { ...s, reactions: updatedReactions };
        }
        return s;
      })
    );
    showToast('success', `Réaction ${emoji} envoyée !`);
  };

  const addStatus = (statusData: Omit<FamilyStatusItem, 'id' | 'createdAt'>) => {
    const newStatus: FamilyStatusItem = {
      ...statusData,
      id: `status-${Date.now()}`,
      createdAt: new Date().toISOString(),
      reactions: [],
    };
    setStatuses((prev) => [newStatus, ...prev.filter((s) => s.authorId !== currentUser.id)]);
    showToast('success', 'Votre statut familial a été mis à jour !');
  };

  const deleteStatus = (id: string) => {
    setStatuses((prev) => prev.filter((s) => s.id !== id));
    showToast('info', 'Statut supprimé.');
  };

  const reactToStatus = (statusId: string, emoji: string) => {
    setStatuses((prev) =>
      prev.map((s) => {
        if (s.id === statusId) {
          const userReaction = s.reactions?.find((r) => r.userId === currentUser.id);
          let newReactions = s.reactions || [];
          if (userReaction) {
            newReactions = newReactions.filter((r) => r.userId !== currentUser.id);
          } else {
            newReactions = [
              ...newReactions,
              {
                id: `st-react-${Date.now()}`,
                postId: statusId,
                userId: currentUser.id,
                userName: currentUser.name,
                reactionType: 'LIKE' as ReactionType,
                createdAt: new Date().toISOString(),
              },
            ];
          }
          return { ...s, reactions: newReactions };
        }
        return s;
      })
    );
  };

  const addPost = createPost;

  // ==========================================
  // NZALA MESSAGES - GESTION DE LA MESSAGERIE
  // ==========================================

  const totalUnreadMessagesCount = useMemo(() => {
    return MessagingService.getTotalUnreadCount(
      MessagingService.getVisibleConversations(currentUser, conversations, blockedContacts),
      currentUser.id
    );
  }, [conversations, currentUser, blockedContacts]);

  const sendMessage = (data: {
    conversationId: string;
    content: string;
    mediaType?: MessageMediaType;
    attachments?: MessageAttachment[];
    quotedMessage?: QuotedMessage;
    mentions?: string[];
    isViewOnce?: boolean;
  }): { success: boolean; message?: FamilyMessage; error?: string } => {
    const conv = conversations.find((c) => c.id === data.conversationId);
    if (!conv) {
      showToast('error', 'Conversation introuvable.');
      return { success: false, error: 'Conversation introuvable.' };
    }

    if (!MessagingService.canUserAccessConversation(currentUser, conv)) {
      showToast('error', 'Vous n’êtes pas autorisé à envoyer un message dans cette discussion.');
      return { success: false, error: 'Non autorisé.' };
    }

    const nowIso = new Date().toISOString();
    const newMsg: FamilyMessage = {
      id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      conversationId: data.conversationId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderRole: currentUser.role,
      senderAvatar: currentUser.avatarUrl,
      senderFamilyName: currentUser.familyName,
      isSenderVerified: currentUser.isVerified || currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL',
      content: data.content || '',
      mediaType: data.mediaType || (data.attachments && data.attachments.length > 0 ? (data.attachments[0].type as MessageMediaType) : 'NONE'),
      attachments: data.attachments,
      isViewOnce: data.isViewOnce,
      viewOnceState: data.isViewOnce ? 'UNOPENED' : undefined,
      quotedMessage: data.quotedMessage,
      mentions: data.mentions,
      status: 'ENVOYE',
      readByUserIds: [currentUser.id],
      reactions: [],
      createdAt: nowIso,
    };

    // Update messages
    setMessages((prev) => [...prev, newMsg]);

    // Update conversation last message & unread count
    const lastPreview = data.isViewOnce
      ? '📸 Photo à vue unique'
      : data.content || (data.attachments?.[0]?.caption) || (data.attachments?.[0]?.fileName) || 'Média partagé';
    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === data.conversationId) {
          const updatedParticipants = c.participants.map((p) => {
            if (p.userId !== currentUser.id) {
              return { ...p, unreadCount: (p.unreadCount || 0) + 1 };
            }
            return p;
          });

          return {
            ...c,
            lastMessage: {
              id: newMsg.id,
              content: lastPreview,
              senderId: currentUser.id,
              senderName: currentUser.name,
              createdAt: nowIso,
              mediaType: newMsg.mediaType,
              status: 'ENVOYE',
            },
            participants: updatedParticipants,
            updatedAt: nowIso,
          };
        }
        return c;
      })
    );

    // Simulate delivery & read transition after short delay
    setTimeout(() => {
      setMessages((prev) =>
        prev.map((m) => (m.id === newMsg.id ? { ...m, status: 'LIVRE' } : m))
      );
    }, 1200);

    return { success: true, message: newMsg };
  };

  const markMessageViewOnceAsOpened = (messageId: string, attachmentId?: string) => {
    const nowIso = new Date().toISOString();
    setMessages((prev) =>
      prev.map((m) => {
        if (m.id === messageId) {
          const updatedAttachments = m.attachments?.map((att) =>
            !attachmentId || att.id === attachmentId
              ? {
                  ...att,
                  viewOnceState: 'VIEWED' as const,
                  viewOnceOpenedAt: nowIso,
                  viewOnceOpenedByUserId: currentUser.id,
                }
              : att
          );
          return {
            ...m,
            viewOnceState: 'VIEWED',
            viewOnceOpenedAt: nowIso,
            viewOnceOpenedByUserId: currentUser.id,
            viewOnceOpenedByUserName: currentUser.name,
            attachments: updatedAttachments,
          };
        }
        return m;
      })
    );
  };

  const editMessage = (messageId: string, content: string): { success: boolean; error?: string } => {
    const target = messages.find((m) => m.id === messageId);
    if (!target) return { success: false, error: 'Message introuvable.' };
    if (target.senderId !== currentUser.id) {
      showToast('error', 'Vous ne pouvez modifier que vos propres messages.');
      return { success: false, error: 'Non autorisé.' };
    }

    const nowIso = new Date().toISOString();
    setMessages((prev) =>
      prev.map((m) =>
        m.id === messageId ? { ...m, content, isEdited: true, updatedAt: nowIso } : m
      )
    );
    showToast('success', 'Message modifié.');
    return { success: true };
  };

  const deleteMessage = (messageId: string): { success: boolean; error?: string } => {
    const target = messages.find((m) => m.id === messageId);
    if (!target) return { success: false, error: 'Message introuvable.' };

    const isAdmin = currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL';
    if (target.senderId !== currentUser.id && !isAdmin) {
      showToast('error', 'Vous ne pouvez pas supprimer ce message.');
      return { success: false, error: 'Non autorisé.' };
    }

    setMessages((prev) => prev.filter((m) => m.id !== messageId));
    showToast('info', 'Message supprimé.');
    return { success: true };
  };

  const toggleMessageReaction = (messageId: string, emoji: string): { success: boolean; error?: string } => {
    setMessages((prev) =>
      prev.map((m) => {
        if (m.id === messageId) {
          const reactions = m.reactions || [];
          const existingIdx = reactions.findIndex(
            (r) => r.userId === currentUser.id && r.emoji === emoji
          );

          let updated = [...reactions];
          if (existingIdx >= 0) {
            updated.splice(existingIdx, 1);
          } else {
            updated.push({
              id: `react-${Date.now()}`,
              messageId,
              userId: currentUser.id,
              userName: currentUser.name,
              emoji,
              createdAt: new Date().toISOString(),
            });
          }
          return { ...m, reactions: updated };
        }
        return m;
      })
    );
    return { success: true };
  };

  const createDirectConversation = (
    targetUserId: string
  ): { success: boolean; conversation?: FamilyConversation; error?: string } => {
    const targetUser = userAccounts.find((u) => u.id === targetUserId);
    if (!targetUser) return { success: false, error: 'Utilisateur introuvable.' };

    // Check if direct conversation already exists
    const existing = conversations.find(
      (c) =>
        c.type === 'DIRECT' &&
        c.participants.some((p) => p.userId === currentUser.id) &&
        c.participants.some((p) => p.userId === targetUserId)
    );

    if (existing) {
      return { success: true, conversation: existing };
    }

    const targetName = `${targetUser.firstName || ''} ${targetUser.lastName || ''}`.trim() || targetUser.email;
    const nowIso = new Date().toISOString();
    const newConv: FamilyConversation = {
      id: `conv-direct-${Date.now()}`,
      type: 'DIRECT',
      participantIds: [currentUser.id, targetUser.id],
      participants: [
        {
          userId: currentUser.id,
          userName: currentUser.name,
          userAvatar: currentUser.avatarUrl,
          familyName: currentUser.familyName,
          role: 'ADMIN',
          unreadCount: 0,
          joinedAt: nowIso,
        },
        {
          userId: targetUser.id,
          userName: targetName,
          userAvatar: targetUser.avatarUrl,
          familyName: targetUser.primaryFamilyName,
          role: 'ADMIN',
          unreadCount: 0,
          joinedAt: nowIso,
        },
      ],
      admins: [currentUser.id, targetUser.id],
      createdBy: currentUser.id,
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    setConversations((prev) => [newConv, ...prev]);
    showToast('success', `Conversation ouverte avec ${targetName}.`);
    return { success: true, conversation: newConv };
  };

  const createGroupConversation = (data: {
    title: string;
    description?: string;
    avatarUrl?: string;
    participantIds: string[];
    relatedBranchId?: string;
    relatedBranchName?: string;
    relatedAlliedFamilyId?: string;
    relatedAlliedFamilyName?: string;
    relatedAllianceId?: string;
    relatedAllianceName?: string;
    isCouncilGroup?: boolean;
  }): { success: boolean; conversation?: FamilyConversation; error?: string } => {
    const nowIso = new Date().toISOString();

    const participants: ConversationParticipant[] = [
      {
        userId: currentUser.id,
        userName: currentUser.name,
        userAvatar: currentUser.avatarUrl,
        familyName: currentUser.familyName,
        role: 'ADMIN',
        unreadCount: 0,
        joinedAt: nowIso,
      },
    ];

    data.participantIds.forEach((uid) => {
      if (uid !== currentUser.id) {
        const u = userAccounts.find((acc) => acc.id === uid);
        if (u) {
          const uName = `${u.firstName || ''} ${u.lastName || ''}`.trim() || u.email;
          participants.push({
            userId: u.id,
            userName: uName,
            userAvatar: u.avatarUrl,
            familyName: u.primaryFamilyName,
            role: 'MEMBER',
            unreadCount: 0,
            joinedAt: nowIso,
          });
        }
      }
    });

    const newConv: FamilyConversation = {
      id: `conv-grp-${Date.now()}`,
      type: 'GROUP',
      title: data.title,
      description: data.description,
      avatarUrl: data.avatarUrl,
      participantIds: participants.map((p) => p.userId),
      participants,
      admins: [currentUser.id],
      createdBy: currentUser.id,
      isCouncilGroup: !!data.isCouncilGroup,
      relatedBranchId: data.relatedBranchId,
      relatedBranchName: data.relatedBranchName,
      relatedAlliedFamilyId: data.relatedAlliedFamilyId,
      relatedAlliedFamilyName: data.relatedAlliedFamilyName,
      relatedAllianceId: data.relatedAllianceId,
      relatedAllianceName: data.relatedAllianceName,
      createdAt: nowIso,
      updatedAt: nowIso,
      lastMessage: {
        id: `msg-${Date.now()}`,
        content: `Groupe "${data.title}" créé`,
        senderId: currentUser.id,
        senderName: currentUser.name,
        createdAt: nowIso,
        mediaType: 'NONE',
        status: 'ENVOYE',
      },
    };

    setConversations((prev) => [newConv, ...prev]);

    // Initial system message
    const initMsg: FamilyMessage = {
      id: `msg-${Date.now()}`,
      conversationId: newConv.id,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderRole: currentUser.role,
      content: `A créé le groupe "${data.title}"`,
      mediaType: 'NONE',
      status: 'ENVOYE',
      readByUserIds: [currentUser.id],
      reactions: [],
      createdAt: nowIso,
    };
    setMessages((prev) => [...prev, initMsg]);

    showToast('success', `Groupe "${data.title}" créé avec succès.`);
    return { success: true, conversation: newConv };
  };

  const addGroupParticipants = (
    conversationId: string,
    userIds: string[]
  ): { success: boolean; error?: string } => {
    const nowIso = new Date().toISOString();
    const newParticipants: ConversationParticipant[] = [];

    userIds.forEach((uid) => {
      const u = userAccounts.find((acc) => acc.id === uid);
      if (u) {
        const uName = `${u.firstName || ''} ${u.lastName || ''}`.trim() || u.email;
        newParticipants.push({
          userId: u.id,
          userName: uName,
          userAvatar: u.avatarUrl,
          familyName: u.primaryFamilyName,
          role: 'MEMBER',
          unreadCount: 0,
          joinedAt: nowIso,
        });
      }
    });

    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === conversationId) {
          const currentIds = c.participants.map((p) => p.userId);
          const toAdd = newParticipants.filter((p) => !currentIds.includes(p.userId));
          const updatedParticipants = [...c.participants, ...toAdd];
          return {
            ...c,
            participantIds: updatedParticipants.map((p) => p.userId),
            participants: updatedParticipants,
            updatedAt: nowIso,
          };
        }
        return c;
      })
    );

    showToast('success', `${newParticipants.length} participant(s) ajouté(s).`);
    return { success: true };
  };

  const removeGroupParticipant = (
    conversationId: string,
    userId: string
  ): { success: boolean; error?: string } => {
    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === conversationId) {
          const updatedParticipants = c.participants.filter((p) => p.userId !== userId);
          return {
            ...c,
            participantIds: updatedParticipants.map((p) => p.userId),
            participants: updatedParticipants,
            admins: c.admins.filter((a) => a !== userId),
            updatedAt: new Date().toISOString(),
          };
        }
        return c;
      })
    );
    showToast('info', 'Participant retiré du groupe.');
    return { success: true };
  };

  const toggleGroupAdminRole = (
    conversationId: string,
    userId: string
  ): { success: boolean; error?: string } => {
    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === conversationId) {
          const isAdmin = c.admins.includes(userId);
          const newAdmins = isAdmin ? c.admins.filter((a) => a !== userId) : [...c.admins, userId];
          const newParticipants = c.participants.map((p) =>
            p.userId === userId ? { ...p, role: (isAdmin ? 'MEMBER' : 'ADMIN') as 'ADMIN' | 'MEMBER' } : p
          );
          return {
            ...c,
            admins: newAdmins,
            participants: newParticipants,
            updatedAt: new Date().toISOString(),
          };
        }
        return c;
      })
    );
    showToast('success', 'Rôles d’administration mis à jour.');
    return { success: true };
  };

  const leaveGroupConversation = (conversationId: string): { success: boolean; error?: string } => {
    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === conversationId) {
          const updatedParticipants = c.participants.filter((p) => p.userId !== currentUser.id);
          return {
            ...c,
            participantIds: updatedParticipants.map((p) => p.userId),
            participants: updatedParticipants,
            admins: c.admins.filter((a) => a !== currentUser.id),
            updatedAt: new Date().toISOString(),
          };
        }
        return c;
      })
    );

    if (activeConversationId === conversationId) {
      setActiveConversationId(null);
    }
    showToast('info', 'Vous avez quitté le groupe.');
    return { success: true };
  };

  const togglePinConversation = (conversationId: string): { success: boolean; error?: string } => {
    setConversations((prev) =>
      prev.map((c) => (c.id === conversationId ? { ...c, isPinned: !c.isPinned } : c))
    );
    return { success: true };
  };

  const toggleArchiveConversation = (conversationId: string): { success: boolean; error?: string } => {
    setConversations((prev) =>
      prev.map((c) => (c.id === conversationId ? { ...c, isArchived: !c.isArchived } : c))
    );
    return { success: true };
  };

  const markConversationAsRead = (conversationId: string) => {
    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === conversationId) {
          return {
            ...c,
            participants: c.participants.map((p) =>
              p.userId === currentUser.id ? { ...p, unreadCount: 0 } : p
            ),
          };
        }
        return c;
      })
    );

    setMessages((prev) =>
      prev.map((m) => {
        if (m.conversationId === conversationId && !m.readByUserIds?.includes(currentUser.id)) {
          return {
            ...m,
            status: 'LU',
            readByUserIds: [...(m.readByUserIds || []), currentUser.id],
          };
        }
        return m;
      })
    );
  };

  const deleteConversation = (conversationId: string): { success: boolean; error?: string } => {
    setConversations((prev) => prev.filter((c) => c.id !== conversationId));
    setMessages((prev) => prev.filter((m) => m.conversationId !== conversationId));
    if (activeConversationId === conversationId) {
      setActiveConversationId(null);
    }
    showToast('info', 'Conversation supprimée.');
    return { success: true };
  };

  const blockContact = (targetUserId: string, reason?: string): { success: boolean; error?: string } => {
    const targetUser = userAccounts.find((u) => u.id === targetUserId);
    const targetName = targetUser
      ? `${targetUser.firstName || ''} ${targetUser.lastName || ''}`.trim() || targetUser.email
      : 'Membre';
    const newBlock: BlockedContact = {
      id: `block-${Date.now()}`,
      userId: currentUser.id,
      blockedUserId: targetUserId,
      blockedUserName: targetName,
      blockedAt: new Date().toISOString(),
      reason: reason || 'Bloqué par l’utilisateur',
    };

    setBlockedContacts((prev) => [
      ...prev.filter((b) => !(b.blockedUserId === targetUserId && b.userId === currentUser.id)),
      newBlock,
    ]);
    showToast('info', `${targetName} a été bloqué.`);
    return { success: true };
  };

  const unblockContact = (targetUserId: string): { success: boolean; error?: string } => {
    setBlockedContacts((prev) =>
      prev.filter((b) => !(b.blockedUserId === targetUserId && b.userId === currentUser.id))
    );
    showToast('success', 'Contact débloqué.');
    return { success: true };
  };

  const reportConversationOrMessage = (data: {
    conversationId: string;
    messageId?: string;
    reportedUserId: string;
    reason: MessageReportReason;
    details?: string;
  }): { success: boolean; error?: string } => {
    const nowIso = new Date().toISOString();
    const newAudit: AuditLog = {
      id: `log-rep-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'SIGNALEMENT_MESSAGERIE' as any,
      actionType: 'MODERATION',
      targetType: 'MESSAGE' as any,
      targetId: data.messageId || data.conversationId,
      targetName: `Signalement ${data.reason}`,
      details: `Signalement émis par ${currentUser.name} concernant l'utilisateur ${data.reportedUserId}. Motif: ${data.reason}. Précisions: ${data.details || 'Aucune'}`,
      timestamp: nowIso,
    };

    setAuditLogs((prev) => [newAudit, ...prev]);
    showToast('success', 'Votre signalement a été transmis en toute confidentialité au Conseil des Sages.');
    return { success: true };
  };

  const sharePostToConversation = (
    postId: string,
    conversationId: string,
    customComment?: string
  ): { success: boolean; error?: string } => {
    const post = posts.find((p) => p.id === postId);
    if (!post) return { success: false, error: 'Publication introuvable.' };

    const firstImage = post.media?.find((m) => m.type === 'IMAGE')?.url;

    const nowIso = new Date().toISOString();
    const newMsg: FamilyMessage = {
      id: `msg-share-${Date.now()}`,
      conversationId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderRole: currentUser.role,
      senderFamilyName: currentUser.familyName,
      content: customComment || 'Regardez cette publication partagée depuis le Fil Familial :',
      mediaType: 'SHARED_POST',
      sharedPost: {
        postId: post.id,
        title: post.title,
        authorName: post.authorName,
        content: post.content,
        publishedAt: post.createdAt,
        firstImageUrl: firstImage,
        postType: post.postType,
        scope: post.scope,
      },
      status: 'ENVOYE',
      readByUserIds: [currentUser.id],
      reactions: [],
      createdAt: nowIso,
    };

    setMessages((prev) => [...prev, newMsg]);

    setConversations((prev) =>
      prev.map((c) =>
        c.id === conversationId
          ? {
              ...c,
              lastMessage: {
                id: newMsg.id,
                content: `📰 Publication partagée : ${post.title || post.authorName}`,
                senderId: currentUser.id,
                senderName: currentUser.name,
                createdAt: nowIso,
                mediaType: 'SHARED_POST',
                status: 'ENVOYE',
              },
              updatedAt: nowIso,
            }
          : c
      )
    );

    showToast('success', 'Publication partagée dans la discussion.');
    return { success: true };
  };

  const shareEventToConversation = (
    eventId: string,
    conversationId: string,
    customComment?: string
  ): { success: boolean; error?: string } => {
    const event = events.find((e) => e.id === eventId);
    if (!event) return { success: false, error: 'Événement introuvable.' };

    const nowIso = new Date().toISOString();
    const newMsg: FamilyMessage = {
      id: `msg-share-evt-${Date.now()}`,
      conversationId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderRole: currentUser.role,
      senderFamilyName: currentUser.familyName,
      content: customComment || 'Regardez cet événement familial :',
      mediaType: 'SHARED_EVENT',
      sharedEvent: {
        eventId: event.id,
        title: event.title,
        startDate: event.startDate,
        location: event.location,
        eventType: event.eventType,
        organizerName: event.organizerName,
      },
      status: 'ENVOYE',
      readByUserIds: [currentUser.id],
      reactions: [],
      createdAt: nowIso,
    };

    setMessages((prev) => [...prev, newMsg]);

    setConversations((prev) =>
      prev.map((c) =>
        c.id === conversationId
          ? {
              ...c,
              lastMessage: {
                id: newMsg.id,
                content: `📅 Événement partagé : ${event.title}`,
                senderId: currentUser.id,
                senderName: currentUser.name,
                createdAt: nowIso,
                mediaType: 'SHARED_EVENT',
                status: 'ENVOYE',
              },
              updatedAt: nowIso,
            }
          : c
      )
    );

    showToast('success', 'Événement partagé dans la discussion.');
    return { success: true };
  };

  // ====================================================
  // NZALA CALLS (AUDIO & VIDÉO) & SIGNALISATION LOCALE
  // ====================================================

  const startCall = (
    targetUser: { id: string; name: string; avatarUrl?: string; role?: string; familyName?: string },
    type: CallType,
    conversationId?: string
  ): { success: boolean; error?: string } => {
    // 1. Check if caller is trying to call themselves
    if (targetUser.id === currentUser.id) {
      showToast('error', 'Vous ne pouvez pas vous appeler vous-même.');
      return { success: false, error: 'Auto-appel impossible' };
    }

    // 2. Check privacy settings of recipient
    const recipientAccount = userAccounts.find((u) => u.id === targetUser.id);
    const privacyCheck = PrivacyService.canCallUser(currentUser, recipientAccount || (targetUser as any));
    if (!privacyCheck.allowed) {
      showToast('error', privacyCheck.reason || 'Ce membre n’autorise pas les appels selon ses réglages.');
      return { success: false, error: privacyCheck.reason };
    }

    // 3. Create active session
    const newSession: CallSession = {
      id: `call-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      conversationId,
      initiatorId: currentUser.id,
      initiatorName: currentUser.name,
      initiatorAvatar: currentUser.avatarUrl,
      recipientId: targetUser.id,
      recipientName: targetUser.name,
      recipientAvatar: targetUser.avatarUrl,
      type,
      status: 'RINGING',
      direction: 'OUTGOING',
      startedAt: new Date().toISOString(),
      durationSeconds: 0,
      isMuted: false,
      isVideoEnabled: type === 'VIDEO',
      isSpeakerOn: true,
      isFrontCamera: true,
      isGroup: false,
      isSimulated: false,
    };

    setActiveCallSession(newSession);

    // Notify realtime bus
    RealtimeService.getInstance().emit('CALL_INCOMING', {
      caller: currentUser.name,
      type,
      recipientId: targetUser.id,
    });

    return { success: true };
  };

  const answerIncomingCall = (acceptVideo: boolean) => {
    if (!incomingCallSession) return;
    CallService.stopRingtone();

    const activeSession: CallSession = {
      ...incomingCallSession,
      status: 'CONNECTED',
      direction: 'INCOMING',
      isVideoEnabled: acceptVideo,
      connectedAt: new Date().toISOString(),
    };

    setIncomingCallSession(null);
    setActiveCallSession(activeSession);
    showToast('success', `Communication ${acceptVideo ? 'vidéo' : 'audio'} établie.`);
  };

  const rejectIncomingCall = (reason?: string) => {
    if (!incomingCallSession) return;
    CallService.stopRingtone();

    // Record as missed in history
    const historyItem: CallHistoryItem = {
      id: `call-hist-${Date.now()}`,
      type: incomingCallSession.type,
      direction: 'INCOMING',
      status: 'MISSED',
      callerId: incomingCallSession.initiatorId,
      callerName: incomingCallSession.initiatorName,
      callerAvatar: incomingCallSession.initiatorAvatar,
      receiverId: currentUser.id,
      receiverName: currentUser.name,
      timestamp: new Date().toISOString(),
      durationSeconds: 0,
      recordedNote: reason || 'Appel non décroché',
      isSimulated: true,
    };

    setCallHistory((prev) => [historyItem, ...prev]);

    // Add missed call notification
    addNotification({
      userId: currentUser.id,
      category: 'MESSAGES',
      type: 'APPEL_MANQUE',
      title: `Appel ${incomingCallSession.type === 'VIDEO' ? 'vidéo' : 'audio'} manqué`,
      body: `${incomingCallSession.initiatorName} a tenté de vous joindre.`,
      senderId: incomingCallSession.initiatorId,
      senderName: incomingCallSession.initiatorName,
      targetType: 'CALL',
      linkTab: 'messages',
    });

    setIncomingCallSession(null);
    showToast('info', 'Appel refusé.');
  };

  const endActiveCall = (durationSeconds: number = 0) => {
    if (!activeCallSession) return;
    CallService.stopRingtone();

    const isOutgoing = activeCallSession.initiatorId === currentUser.id;
    const historyItem: CallHistoryItem = {
      id: `call-hist-${Date.now()}`,
      type: activeCallSession.type,
      direction: isOutgoing ? 'OUTGOING' : 'INCOMING',
      status: 'COMPLETED',
      callerId: activeCallSession.initiatorId,
      callerName: activeCallSession.initiatorName,
      callerAvatar: activeCallSession.initiatorAvatar,
      receiverId: activeCallSession.recipientId,
      receiverName: activeCallSession.recipientName,
      receiverAvatar: activeCallSession.recipientAvatar,
      timestamp: new Date().toISOString(),
      durationSeconds: Math.max(0, durationSeconds),
      isSimulated: true,
    };

    setCallHistory((prev) => [historyItem, ...prev]);
    setActiveCallSession(null);
    showToast('info', `Appel terminé (${CallService.formatDuration(durationSeconds)}).`);
  };

  const toggleMuteCall = () => {
    setActiveCallSession((prev) => (prev ? { ...prev, isMuted: !prev.isMuted } : null));
  };

  const toggleVideoCall = () => {
    setActiveCallSession((prev) =>
      prev ? { ...prev, isVideoEnabled: !prev.isVideoEnabled } : null
    );
  };

  const switchCameraCall = async (): Promise<boolean> => {
    if (!activeCallSession) return false;
    const newFront = !activeCallSession.isFrontCamera;
    setActiveCallSession((prev) => (prev ? { ...prev, isFrontCamera: newFront } : null));
    return true;
  };

  const toggleSpeakerCall = () => {
    setActiveCallSession((prev) => (prev ? { ...prev, isSpeakerOn: !prev.isSpeakerOn } : null));
  };

  const simulateIncomingCall = (
    fromUser?: { id: string; name: string; avatarUrl?: string; familyName?: string },
    type: CallType = 'VIDEO'
  ) => {
    const caller = fromUser || {
      id: 'usr-clotilde',
      name: 'Maman Clotilde Nzala',
      avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150',
      familyName: 'Famille Nzala',
    };

    const session: CallSession = {
      id: `call-inc-${Date.now()}`,
      initiatorId: caller.id,
      initiatorName: caller.name,
      initiatorAvatar: caller.avatarUrl,
      recipientId: currentUser.id,
      recipientName: currentUser.name,
      type,
      status: 'RINGING',
      direction: 'INCOMING',
      startedAt: new Date().toISOString(),
      durationSeconds: 0,
      isMuted: false,
      isVideoEnabled: type === 'VIDEO',
      isSpeakerOn: true,
      isFrontCamera: true,
      isSimulated: true,
    };

    setIncomingCallSession(session);
  };

  const clearCallHistory = () => {
    setCallHistory([]);
    showToast('info', 'Historique des appels effacé.');
  };

  // ====================================================
  // CONFIDENTIALITÉ, NOTIFICATIONS & SIGNALEMENTS
  // ====================================================

  const updatePrivacySettings = (newSettings: Partial<UserPrivacySettings>) => {
    setUserPrivacySettings((prev) => ({ ...prev, ...newSettings }));
    showToast('success', 'Paramètres de confidentialité mis à jour.');
  };

  const updateNotificationPreferences = (newPrefs: Partial<NotificationPreferences>) => {
    setNotificationPreferences((prev) => ({ ...prev, ...newPrefs }));
    showToast('success', 'Préférences de notifications enregistrées.');
  };

  const addNotification = (notifData: Omit<FamilyNotification, 'id' | 'createdAt' | 'read'>) => {
    const newNotif: FamilyNotification = {
      ...notifData,
      id: `notif-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      read: false,
      createdAt: new Date().toISOString(),
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  const submitSocialReport = (data: {
    targetType: ReportTargetType;
    targetId: string;
    targetTitle?: string;
    reportedUserId?: string;
    reportedUserName?: string;
    category: ReportCategory;
    description: string;
  }): { success: boolean; error?: string } => {
    const newReport: SocialReport = {
      id: `rep-${Date.now()}`,
      reporterId: currentUser.id,
      reporterName: currentUser.name,
      targetType: data.targetType,
      targetId: data.targetId,
      targetTitle: data.targetTitle,
      reportedUserId: data.reportedUserId,
      reportedUserName: data.reportedUserName,
      category: data.category,
      description: data.description,
      status: 'EN_ATTENTE',
      createdAt: new Date().toISOString(),
    };

    setSocialReports((prev) => [newReport, ...prev]);

    // Add audit log entry
    const audit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'SIGNALEMENT_CREE' as any,
      actionType: 'MODERATION' as any,
      targetType: 'AUTRE' as any,
      targetId: data.targetId,
      targetName: data.targetTitle || 'Contenu / Membre',
      details: `Signalement confidentiel soumis (${data.category}) pour ${data.targetType}.`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [audit, ...prev]);

    showToast('success', 'Signalement confidentiel transmis à la modération du Conseil.');
    return { success: true };
  };

  const processSocialReport = (
    reportId: string,
    decision: 'TRAITE' | 'REJETE',
    resolutionNotes?: string
  ): { success: boolean; error?: string } => {
    setSocialReports((prev) =>
      prev.map((r) =>
        r.id === reportId
          ? {
              ...r,
              status: decision,
              resolvedAt: new Date().toISOString(),
              resolvedBy: currentUser.name,
              resolutionNotes,
            }
          : r
      )
    );

    showToast('info', `Signalement ${decision === 'TRAITE' ? 'traité et clôturé' : 'rejeté'}.`);
    return { success: true };
  };

  const setUserOnlineStatus = (status: UserPresence['status'], customText?: string) => {
    const nowIso = new Date().toISOString();
    setPresences((prev) =>
      prev.map((p) =>
        p.userId === currentUser.id
          ? {
              ...p,
              status,
              customStatusText: customText,
              lastSeen: nowIso,
            }
          : p
      )
    );

    RealtimeService.getInstance().emit('PRESENCE_CHANGE', {
      userId: currentUser.id,
      status,
      lastSeen: nowIso,
    });
  };

  const addMemoryAlbum = (albumData: Omit<MemoryAlbum, 'id' | 'createdAt'>): { success: boolean; album?: MemoryAlbum; error?: string } => {
    const newAlbum: MemoryAlbum = {
      ...albumData,
      id: `alb-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setMemoryAlbums((prev) => [newAlbum, ...prev]);
    showToast('success', 'Album de mémoire créé avec succès.');
    return { success: true, album: newAlbum };
  };

  const addHistoricalPublication = (pubData: Omit<HistoricalPublication, 'id' | 'publishedAt' | 'likesCount' | 'commentsCount'>): { success: boolean; publication?: HistoricalPublication; error?: string } => {
    const newPub: HistoricalPublication = {
      ...pubData,
      id: `hist-${Date.now()}`,
      publishedAt: new Date().toISOString(),
      likesCount: 0,
      commentsCount: 0,
    };
    setHistoricalPublications((prev) => [newPub, ...prev]);
    showToast('success', 'Récit historique publié et archivé dans la Mémoire Nzala.');
    return { success: true, publication: newPub };
  };

  const celebrateBirthday = (draft: BirthdayCelebrationDraft): { success: boolean; post?: FamilyPost; error?: string } => {
    const title = draft.isDeceasedHonor
      ? `Hommage & Pensée Pieuse : En mémoire de ${draft.personName} 🕊️`
      : `Joyeux Anniversaire à notre cher(e) ${draft.personName} ! 🎂🎉`;

    const newPost: FamilyPost = {
      id: `post-bday-${Date.now()}`,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorRole: currentUser.role,
      authorAvatar: currentUser.avatarUrl,
      authorType: currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL' ? 'OFFICIEL_NZALA' : 'MEMBRE',
      authorFamilyId: currentUser.familyId || 'fam-nzala',
      authorFamilyName: currentUser.familyName || 'Famille Nzala',
      title: title,
      content: draft.suggestedMessage,
      scope: 'PUBLIC',
      postType: draft.isDeceasedHonor ? 'MEMOIRE_FAMILIALE' : 'ANNIVERSAIRE',
      status: 'PUBLIE',
      moderationStatus: 'APPROUVE',
      isOfficial: true,
      isPinned: true,
      relatedMemberId: draft.personId,
      relatedMemberName: draft.personName,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      media: draft.avatarUrl
        ? [
            {
              id: `med-${Date.now()}`,
              type: 'IMAGE',
              url: draft.avatarUrl,
              caption: draft.isDeceasedHonor
                ? `En mémoire éternelle de ${draft.personName}`
                : `Célébration d'anniversaire de ${draft.personName}`,
            },
          ]
        : [],
      reactions: [],
      reactionsCount: 0,
      comments: [],
      commentsCount: 0,
    };

    setPosts((prev) => [newPost, ...prev]);
    showToast('success', 'La célébration d’anniversaire a été publiée dans le fil familial.');
    return { success: true, post: newPost };
  };

  const createAdminOfficialPost = (data: {
    title: string;
    content: string;
    postType: PostType;
    relatedMemberId?: string;
    relatedMemberName?: string;
    media?: MediaItem[];
    scope?: PostScope;
    isOfficial?: boolean;
    isImportant?: boolean;
  }): { success: boolean; post?: FamilyPost; error?: string } => {
    const newPost: FamilyPost = {
      id: `post-admin-${Date.now()}`,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorRole: currentUser.role,
      authorAvatar: currentUser.avatarUrl,
      authorType: 'OFFICIEL_NZALA',
      authorFamilyId: currentUser.familyId || 'fam-nzala',
      authorFamilyName: currentUser.familyName || 'Famille Nzala',
      title: data.title,
      content: data.content,
      scope: data.scope || 'PUBLIC',
      postType: data.postType || 'COMMUNIQUE_OFFICIEL',
      status: 'PUBLIE',
      moderationStatus: 'APPROUVE',
      isOfficial: data.isOfficial ?? true,
      isPinned: data.isImportant ?? false,
      relatedMemberId: data.relatedMemberId,
      relatedMemberName: data.relatedMemberName,
      media: data.media || [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      reactions: [],
      reactionsCount: 0,
      comments: [],
      commentsCount: 0,
    };

    setPosts((prev) => [newPost, ...prev]);
    return { success: true, post: newPost };
  };

  // --- CERTIFICATIONS DES COMPTES ---
  const certifyAccount = (data: {
    userId: string;
    userName?: string;
    userEmail?: string;
    userRole?: UserRole;
    familyName?: string;
    branchName?: string;
    certificationType: CertificationType;
    badgeLabel: string;
    icon: string;
    badgeColor?: string;
    reason: string;
  }): { success: boolean; error?: string } => {
    if (currentUser.role !== 'SUPER_ADMIN') {
      showToast('error', 'Seul le Super Administrateur peut certifier un compte.');
      return { success: false, error: 'Non autorisé' };
    }

    const targetAccount = userAccounts.find((u) => u.id === data.userId);
    if (!targetAccount) {
      showToast('error', 'Compte utilisateur introuvable.');
      return { success: false, error: 'Compte introuvable' };
    }

    const targetUserName = data.userName || `${targetAccount.firstName} ${targetAccount.lastName}`;
    const targetFamilyName = data.familyName || (targetAccount as any).primaryFamilyName || 'Famille Nzala';

    // Default color rule: SUPER_ADMIN = Rose (#EC4899), others = Nzala Blue (#2563EB), or custom selected
    const resolvedBadgeColor = data.badgeColor
      ? data.badgeColor
      : data.certificationType === 'SUPER_ADMIN' || targetAccount.role === 'SUPER_ADMIN'
      ? '#EC4899'
      : '#2563EB';

    const newCert: AccountCertification = {
      id: `cert-${Date.now()}`,
      userId: targetAccount.id,
      userName: targetUserName,
      userEmail: data.userEmail || targetAccount.email,
      userRole: data.userRole || targetAccount.role,
      familyName: targetFamilyName,
      branchName: data.branchName || (targetAccount as any).branchName,
      certificationType: data.certificationType,
      badgeLabel: data.badgeLabel,
      icon: data.icon,
      badgeColor: resolvedBadgeColor,
      reason: data.reason,
      certifiedByUserId: currentUser.id,
      certifiedByUserName: currentUser.name,
      certifiedAt: new Date().toISOString(),
      isActive: true,
    };

    setCertifications((prev) => [newCert, ...prev]);
    
    // Update userAccount isVerified status
    setUserAccounts((prev) =>
      prev.map((acc) => (acc.id === data.userId ? { ...acc, isVerified: true } : acc))
    );

    // Audit log
    const audit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'CREATION' as any,
      actionType: 'ADMINISTRATION' as any,
      targetType: 'MEMBRE' as any,
      targetId: targetAccount.id,
      targetName: targetUserName,
      details: `Certification officielle attribuée : ${data.badgeLabel} (${data.certificationType}, Couleur: ${resolvedBadgeColor}).`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [audit, ...prev]);

    showToast('success', `Le compte de ${targetUserName} a été certifié.`);
    return { success: true };
  };

  const updateCertificationBadgeColor = (
    certificationId: string,
    badgeColor: string
  ): { success: boolean; error?: string } => {
    if (currentUser.role !== 'SUPER_ADMIN') {
      showToast('error', 'Seul le Super Administrateur peut modifier la couleur du sceau de certification.');
      return { success: false, error: 'Non autorisé' };
    }

    const targetCert = certifications.find((c) => c.id === certificationId);
    if (!targetCert) {
      showToast('error', 'Certification introuvable.');
      return { success: false, error: 'Introuvable' };
    }

    setCertifications((prev) =>
      prev.map((c) => (c.id === certificationId ? { ...c, badgeColor } : c))
    );

    const audit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'MODIFICATION' as any,
      actionType: 'ADMINISTRATION' as any,
      targetType: 'MEMBRE' as any,
      targetId: targetCert.userId,
      targetName: targetCert.userName,
      details: `Couleur du sceau de certification mise à jour pour ${targetCert.userName} (${targetCert.badgeLabel}) : ${badgeColor}.`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [audit, ...prev]);

    showToast('success', `Couleur du sceau mise à jour pour ${targetCert.userName}.`);
    return { success: true };
  };

  const requestCertificationColor = (data: {
    requestedColor: string;
    reason: string;
    requestedLabel?: string;
  }): { success: boolean; error?: string } => {
    if (currentUser.id === 'guest') {
      showToast('error', 'Veuillez vous connecter pour soumettre une demande.');
      return { success: false, error: 'Non connecté' };
    }

    const existingCert = certifications.find((c) => c.userId === currentUser.id && c.isActive);

    const newRequest: CertificationColorRequest = {
      id: `req-col-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userEmail: currentUser.email,
      userRole: currentUser.role,
      currentCertificationId: existingCert?.id,
      requestedColor: data.requestedColor,
      requestedLabel: data.requestedLabel,
      reason: data.reason,
      status: 'EN_ATTENTE',
      createdAt: new Date().toISOString(),
    };

    setCertificationColorRequests((prev) => [newRequest, ...prev]);

    const audit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'CREATION' as any,
      actionType: 'ADMINISTRATION' as any,
      targetType: 'MEMBRE' as any,
      targetId: currentUser.id,
      targetName: currentUser.name,
      details: `Demande de couleur / badge soumise par ${currentUser.name} (${data.requestedColor}).`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [audit, ...prev]);

    showToast('success', 'Votre demande de badge/couleur a été transmise au Conseil d’administration.');
    return { success: true };
  };

  const approveCertificationColorRequest = (
    requestId: string,
    chosenColor: string,
    decisionNotes?: string
  ): { success: boolean; error?: string } => {
    if (currentUser.role !== 'SUPER_ADMIN') {
      showToast('error', 'Seul le Super Administrateur peut approuver une demande de couleur.');
      return { success: false, error: 'Non autorisé' };
    }

    const targetReq = certificationColorRequests.find((r) => r.id === requestId);
    if (!targetReq) {
      showToast('error', 'Demande introuvable.');
      return { success: false, error: 'Introuvable' };
    }

    setCertificationColorRequests((prev) =>
      prev.map((r) =>
        r.id === requestId
          ? {
              ...r,
              status: 'APPROUVEE' as const,
              adminDecisionNotes: decisionNotes || 'Demande acceptée par la Super Administration.',
              reviewedByUserId: currentUser.id,
              reviewedByUserName: currentUser.name,
              reviewedAt: new Date().toISOString(),
            }
          : r
      )
    );

    // Apply color to certification if exists, or create new certification
    if (targetReq.currentCertificationId) {
      setCertifications((prev) =>
        prev.map((c) =>
          c.id === targetReq.currentCertificationId
            ? { ...c, badgeColor: chosenColor, badgeLabel: targetReq.requestedLabel || c.badgeLabel }
            : c
        )
      );
    } else {
      // Create new certification
      certifyAccount({
        userId: targetReq.userId,
        userName: targetReq.userName,
        userEmail: targetReq.userEmail,
        userRole: targetReq.userRole,
        certificationType: 'RESPONSABLE_OFFICIEL',
        badgeLabel: targetReq.requestedLabel || 'Compte Officiel Certifié',
        icon: '✓',
        badgeColor: chosenColor,
        reason: `Demande approuvée : ${targetReq.reason}`,
      });
    }

    const audit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'VALIDATION' as any,
      actionType: 'ADMINISTRATION' as any,
      targetType: 'MEMBRE' as any,
      targetId: targetReq.userId,
      targetName: targetReq.userName,
      details: `Demande de couleur de badge approuvée pour ${targetReq.userName} (Couleur: ${chosenColor}).`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [audit, ...prev]);

    showToast('success', `Demande approuvée pour ${targetReq.userName} avec la couleur ${chosenColor}.`);
    return { success: true };
  };

  const rejectCertificationColorRequest = (
    requestId: string,
    reason: string
  ): { success: boolean; error?: string } => {
    if (currentUser.role !== 'SUPER_ADMIN') {
      showToast('error', 'Seul le Super Administrateur peut rejeter une demande de couleur.');
      return { success: false, error: 'Non autorisé' };
    }

    const targetReq = certificationColorRequests.find((r) => r.id === requestId);
    if (!targetReq) return { success: false, error: 'Introuvable' };

    setCertificationColorRequests((prev) =>
      prev.map((r) =>
        r.id === requestId
          ? {
              ...r,
              status: 'REFUSEE' as const,
              adminDecisionNotes: reason || 'Refusé par la Super Administration.',
              reviewedByUserId: currentUser.id,
              reviewedByUserName: currentUser.name,
              reviewedAt: new Date().toISOString(),
            }
          : r
      )
    );

    const audit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'REJET' as any,
      actionType: 'ADMINISTRATION' as any,
      targetType: 'MEMBRE' as any,
      targetId: targetReq.userId,
      targetName: targetReq.userName,
      details: `Demande de couleur de badge refusée pour ${targetReq.userName}. Motif : ${reason || 'Non précisé'}.`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [audit, ...prev]);

    showToast('info', `Demande refusée pour ${targetReq.userName}.`);
    return { success: true };
  };

  const revokeCertification = (certificationId: string, reason: string): { success: boolean; error?: string } => {
    if (currentUser.role !== 'SUPER_ADMIN') {
      showToast('error', 'Seul le Super Administrateur peut révoquer une certification.');
      return { success: false, error: 'Non autorisé' };
    }

    const targetCert = certifications.find((c) => c.id === certificationId);
    if (!targetCert) {
      showToast('error', 'Certification introuvable.');
      return { success: false, error: 'Introuvable' };
    }

    setCertifications((prev) =>
      prev.map((c) =>
        c.id === certificationId
          ? {
              ...c,
              isActive: false,
              revokedAt: new Date().toISOString(),
              revokedReason: reason,
            }
          : c
      )
    );

    // Audit log on revocation
    const revokeAudit: AuditLog = {
      id: `log-${Date.now()}`,
      actorName: currentUser.name,
      actorRole: currentUser.role,
      action: 'MODIFICATION' as any,
      actionType: 'ADMINISTRATION' as any,
      targetType: 'MEMBRE' as any,
      targetId: targetCert.userId,
      targetName: targetCert.userName,
      details: `Certification de compte révoquée : ${targetCert.badgeLabel} (${targetCert.certificationType}). Motif : ${reason || 'Non précisé'}.`,
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [revokeAudit, ...prev]);

    showToast('info', `Certification révoquée pour ${targetCert.userName}.`);
    return { success: true };
  };

  // --- NZALA LIVE (DIFFUSIONS EN DIRECT) ---
  const startNewLiveStream = (data: {
    title: string;
    description?: string;
    scope: PostScope;
    status?: 'LIVE' | 'SCHEDULED';
    targetFamilyId?: string;
    targetFamilyName?: string;
    targetBranchId?: string;
    targetBranchName?: string;
    allowComments?: boolean;
    scheduledFor?: string;
  }): { success: boolean; liveStream?: LiveStream; error?: string } => {
    const isLiveNow = data.status === 'LIVE' || (!data.scheduledFor && data.status !== 'SCHEDULED');
    const nowIso = new Date().toISOString();

    const newLive: LiveStream = {
      id: `live-${Date.now()}`,
      title: data.title.trim(),
      description: data.description?.trim(),
      hostUserId: currentUser.id,
      hostName: currentUser.name,
      hostAvatar: currentUser.avatarUrl,
      hostRole: currentUser.role,
      hostFamilyName: currentUser.familyName || 'Famille Nzala',
      isHostVerified: currentUser.isVerified || currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL',
      hostVerifiedBadge: currentUser.role === 'SUPER_ADMIN' ? '👑 Super Admin' : '🛡️ Administrateur',
      status: isLiveNow ? 'LIVE' : 'SCHEDULED',
      scope: data.scope || 'PUBLIC',
      targetFamilyId: data.targetFamilyId,
      targetFamilyName: data.targetFamilyName,
      targetBranchId: data.targetBranchId,
      targetBranchName: data.targetBranchName,
      scheduledFor: data.scheduledFor,
      startedAt: isLiveNow ? nowIso : undefined,
      viewersCount: isLiveNow ? 1 : 0,
      maxViewersReached: isLiveNow ? 1 : 0,
      thumbnailUrl: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=800',
      isMicOn: true,
      isCameraOn: true,
      allowComments: data.allowComments ?? true,
      comments: [],
      reactionsCount: {},
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    setLiveStreams((prev) => [newLive, ...prev]);
    if (isLiveNow) {
      setActiveLiveStreamId(newLive.id);
      showToast('success', 'Votre diffusion en direct Nzala Live a démarré !');
    } else {
      showToast('success', 'Votre diffusion en direct a été programmée.');
    }

    return { success: true, liveStream: newLive };
  };

  const joinLiveStream = (liveId: string) => {
    setActiveLiveStreamId(liveId);
    setLiveStreams((prev) =>
      prev.map((l) => {
        if (l.id === liveId) {
          const nextCount = l.viewersCount + 1;
          return {
            ...l,
            viewersCount: nextCount,
            maxViewersReached: Math.max(l.maxViewersReached || 0, nextCount),
          };
        }
        return l;
      })
    );
  };

  const leaveLiveStream = () => {
    if (activeLiveStreamId) {
      setLiveStreams((prev) =>
        prev.map((l) => {
          if (l.id === activeLiveStreamId && l.viewersCount > 0) {
            return { ...l, viewersCount: Math.max(0, l.viewersCount - 1) };
          }
          return l;
        })
      );
    }
    setActiveLiveStreamId(null);
  };

  const endLiveStream = (liveId: string) => {
    const nowIso = new Date().toISOString();
    setLiveStreams((prev) =>
      prev.map((l) => (l.id === liveId ? { ...l, status: 'ENDED' as const, endedAt: nowIso } : l))
    );
    if (activeLiveStreamId === liveId) {
      setActiveLiveStreamId(null);
    }
    showToast('info', 'La diffusion en direct est terminée.');
  };

  const sendLiveComment = (liveId: string, content: string) => {
    if (!content.trim()) return;
    const nowIso = new Date().toISOString();
    const newComment: LiveComment = {
      id: `lc-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      liveId,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatarUrl,
      userRole: currentUser.role,
      isVerified: currentUser.isVerified || currentUser.role === 'SUPER_ADMIN',
      verifiedBadge: currentUser.role === 'SUPER_ADMIN' ? '👑 Super Admin' : undefined,
      content: content.trim(),
      isHost: liveStreams.find((l) => l.id === liveId)?.hostUserId === currentUser.id,
      createdAt: nowIso,
    };

    setLiveStreams((prev) =>
      prev.map((l) =>
        l.id === liveId ? { ...l, comments: [...l.comments, newComment], updatedAt: nowIso } : l
      )
    );
  };

  const sendLiveReaction = (liveId: string, emoji: string) => {
    setLiveStreams((prev) =>
      prev.map((l) => {
        if (l.id === liveId) {
          const currentCount = l.reactionsCount[emoji] || 0;
          return {
            ...l,
            reactionsCount: {
              ...l.reactionsCount,
              [emoji]: currentCount + 1,
            },
          };
        }
        return l;
      })
    );
  };

  const deleteLiveComment = (liveId: string, commentId: string) => {
    setLiveStreams((prev) =>
      prev.map((l) => {
        if (l.id === liveId) {
          return {
            ...l,
            comments: l.comments.filter((c) => c.id !== commentId),
          };
        }
        return l;
      })
    );
  };

  // --- BLOCAGE & SÉCURITÉ UTILISATEUR ---
  const blockUser = (
    targetUserId: string,
    targetUserName?: string,
    reason?: string
  ): { success: boolean; error?: string } => {
    if (targetUserId === currentUser.id) {
      showToast('error', 'Vous ne pouvez pas vous bloquer vous-même.');
      return { success: false, error: 'Auto-blocage impossible' };
    }

    const name = targetUserName || userAccounts.find((u) => u.id === targetUserId)?.firstName || 'Utilisateur';

    // Check if already blocked in blockedContacts
    const alreadyBlocked = blockedContacts.some((b) => b.blockedUserId === targetUserId);
    if (!alreadyBlocked) {
      const newBlocked: BlockedContact = {
        id: `blk-${Date.now()}`,
        userId: currentUser.id,
        blockedUserId: targetUserId,
        blockedUserName: name,
        reason: reason || 'Bloqué par l’utilisateur',
        blockedAt: new Date().toISOString(),
      };
      setBlockedContacts((prev) => [newBlocked, ...prev]);
    }

    showToast('info', `${name} a été bloqué(e). Ses interactions vous seront masquées.`);
    return { success: true };
  };

  const unblockUser = (targetUserId: string): { success: boolean; error?: string } => {
    setBlockedContacts((prev) => prev.filter((b) => b.blockedUserId !== targetUserId));
    showToast('info', 'Utilisateur débloqué.');
    return { success: true };
  };

  // --- SIGNALEMENT DE PROBLÈMES TECHNIQUES ---
  const submitIssueReport = (data: {
    category: IssueCategory;
    priority: IssuePriority;
    title: string;
    description: string;
    attachments?: MediaItem[];
    deviceInfo?: string;
  }): { success: boolean; report?: IssueReport; error?: string } => {
    const nowIso = new Date().toISOString();
    const newRep: IssueReport = {
      id: `rep-${Date.now()}`,
      reporterUserId: currentUser.id,
      reporterName: currentUser.name,
      reporterEmail: currentUser.email,
      reporterAvatar: currentUser.avatarUrl,
      category: data.category,
      priority: data.priority,
      title: data.title.trim(),
      description: data.description.trim(),
      attachments: data.attachments || [],
      deviceInfo: data.deviceInfo,
      status: 'NOUVEAU',
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    setIssueReports((prev) => [newRep, ...prev]);
    showToast('success', 'Votre signalement d’assistance a été transmis aux équipes techniques.');
    return { success: true, report: newRep };
  };

  const resolveIssueReport = (reportId: string, adminNotes?: string) => {
    const nowIso = new Date().toISOString();
    setIssueReports((prev) =>
      prev.map((r) =>
        r.id === reportId
          ? {
              ...r,
              status: 'RESOLU' as const,
              adminNotes,
              handledByUserId: currentUser.id,
              handledByUserName: currentUser.name,
              resolvedAt: nowIso,
              updatedAt: nowIso,
            }
          : r
      )
    );
    showToast('success', 'Signalement technique marqué comme résolu.');
  };

  const resetToDefaults = () => {
    localStorage.removeItem(STORAGE_KEYS.FAMILIES);
    localStorage.removeItem(STORAGE_KEYS.BRANCHES);
    localStorage.removeItem(STORAGE_KEYS.MEMBERS);
    localStorage.removeItem(STORAGE_KEYS.RELATIONSHIPS);
    localStorage.removeItem(STORAGE_KEYS.ALLIANCES);
    localStorage.removeItem(STORAGE_KEYS.REQUESTS);
    localStorage.removeItem(STORAGE_KEYS.AUDIT);
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    localStorage.removeItem(STORAGE_KEYS.USER_ACCOUNTS);
    localStorage.removeItem(STORAGE_KEYS.EVENTS);
    localStorage.removeItem(STORAGE_KEYS.POSTS);
    localStorage.removeItem(STORAGE_KEYS.STORIES);
    localStorage.removeItem(STORAGE_KEYS.STATUSES);
    localStorage.removeItem(STORAGE_KEYS.CONVERSATIONS);
    localStorage.removeItem(STORAGE_KEYS.MESSAGES);
    localStorage.removeItem(STORAGE_KEYS.PRESENCES);
    localStorage.removeItem(STORAGE_KEYS.BLOCKED_CONTACTS);
    localStorage.removeItem(STORAGE_KEYS.ACTIVE_CONVERSATION_ID);
    localStorage.removeItem(STORAGE_KEYS.CALL_HISTORY);
    localStorage.removeItem(STORAGE_KEYS.PRIVACY_SETTINGS);
    localStorage.removeItem(STORAGE_KEYS.NOTIF_PREFS);
    localStorage.removeItem(STORAGE_KEYS.SOCIAL_REPORTS);
    localStorage.removeItem(STORAGE_KEYS.MEMORY_ALBUMS);
    localStorage.removeItem(STORAGE_KEYS.HISTORICAL_PUBS);
    localStorage.removeItem(STORAGE_KEYS.CERTIFICATIONS);
    localStorage.removeItem(STORAGE_KEYS.LIVE_STREAMS);
    localStorage.removeItem(STORAGE_KEYS.ISSUE_REPORTS);

    setFamilies(INITIAL_FAMILIES);
    setBranches(INITIAL_BRANCHES);
    setMembers(INITIAL_MEMBERS);
    setRelationships(INITIAL_RELATIONSHIPS);
    setAlliances(INITIAL_ALLIANCES);
    setVerificationRequests(INITIAL_VERIFICATION_REQUESTS);
    setAuditLogs(INITIAL_AUDIT_LOGS);
    setUserAccounts(INITIAL_USER_ACCOUNTS);
    setEvents(INITIAL_EVENTS);
    setPosts(INITIAL_POSTS);
    setStories(INITIAL_STORIES);
    setStatuses(INITIAL_STATUSES);
    setConversations(INITIAL_CONVERSATIONS);
    setMessages(INITIAL_MESSAGES);
    setPresences(INITIAL_PRESENCES);
    setBlockedContacts(INITIAL_BLOCKED_CONTACTS);
    setActiveConversationId('conv-matadi-1');
    setNotifications(NotificationService.getInitialNotifications('usr-jean-pierre'));
    setCallHistory(INITIAL_CALL_HISTORY);
    setUserPrivacySettings(PrivacyService.DEFAULT_PRIVACY_SETTINGS);
    setNotificationPreferences(NotificationService.DEFAULT_PREFERENCES);
    setSocialReports(ModerationService.getInitialReports());
    setMemoryAlbums(INITIAL_MEMORY_ALBUMS);
    setHistoricalPublications(INITIAL_HISTORICAL_PUBLICATIONS);
    setCertifications([
      {
        id: 'cert-1',
        userId: 'usr-jean-pierre',
        userName: 'Jean-Pierre Nzala',
        userRole: 'SUPER_ADMIN' as UserRole,
        familyName: 'Famille Nzala',
        branchName: 'Branche Kinshasa (Aînée)',
        certificationType: 'SUPER_ADMIN' as CertificationType,
        badgeLabel: 'Super Administrateur de la Plateforme',
        icon: '👑',
        reason: 'Fondateur et Patriarche Principal de la plateforme NzalaFamilly',
        certifiedByUserId: 'usr-jean-pierre',
        certifiedByUserName: 'Système NzalaFamilly',
        certifiedAt: '2025-01-01T08:00:00.000Z',
        isActive: true,
      },
      {
        id: 'cert-2',
        userId: 'usr-marie-therese',
        userName: 'Marie-Thérèse Nzala (Maman)',
        userRole: 'ADMIN_FAMILIAL' as UserRole,
        familyName: 'Famille Nzala',
        branchName: 'Branche Kinshasa (Aînée)',
        certificationType: 'SAGE_CONSEIL' as CertificationType,
        badgeLabel: 'Membre du Conseil des Sages Nzala',
        icon: '📜',
        reason: 'Matriarche et Gardienne des Traditions Familiales',
        certifiedByUserId: 'usr-jean-pierre',
        certifiedByUserName: 'Jean-Pierre Nzala',
        certifiedAt: '2025-01-10T10:00:00.000Z',
        isActive: true,
      },
      {
        id: 'cert-3',
        userId: 'usr-honore',
        userName: 'Honoré Nzala',
        userRole: 'ADMIN_FAMILIAL' as UserRole,
        familyName: 'Famille Nzala',
        branchName: 'Branche Matadi',
        certificationType: 'ADMIN_FAMILIAL' as CertificationType,
        badgeLabel: 'Administrateur de Famille / Branche',
        icon: '🛡️',
        reason: 'Responsable référent de la Branche Matadi',
        certifiedByUserId: 'usr-jean-pierre',
        certifiedByUserName: 'Jean-Pierre Nzala',
        certifiedAt: '2025-02-01T12:00:00.000Z',
        isActive: true,
      },
    ]);
    setLiveStreams([]);
    setIssueReports([]);
    setCurrentUser(AVAILABLE_PROFILES[1].user);
    showToast('info', 'Données réinitialisées aux valeurs initiales de démonstration.');
  };

  return (
    <FamilyContext.Provider
      value={{
        families,
        branches,
        members,
        relationships,
        alliances,
        verificationRequests,
        auditLogs,
        announcements,
        events,
        upcomingBirthdays,
        selectedEvent,
        setSelectedEvent,
        currentUser,
        userAccounts,
        activeTab,
        setActiveTab,
        setCurrentUser,
        switchProfile,
        availableProfiles: AVAILABLE_PROFILES,
        login,
        register,
        logout,
        updateUserProfile,
        changePassword,
        toggleTwoFactor,
        requestPasswordReset,
        submitVerificationRequest,
        processVerificationRequest,
        addFamily,
        addBranch,
        addMember,
        updateMember,
        archiveMember,
        addRelationship,
        proposeRelationship,
        validateRelationshipAction,
        deleteRelationship,
        addAlliance,
        validateAllianceAction,
        addEvent,
        updateEvent,
        cancelEvent,
        deleteEvent,
        rsvpEvent,
        inviteToEvent,
        linkUserToMember,
        unlinkUserFromMember,
        getRelatives,
        getFilteredMember,
        selectedMember,
        setSelectedMember,
        selectedFamily,
        setSelectedFamily,
        viewingUserId,
        setViewingUserId,
        openUserProfile,
        posts,
        visiblePosts,
        alliedFamilies,
        stories,
        statuses,
        notifications,
        selectedPost,
        setSelectedPost,
        createPost,
        addPost,
        updatePost,
        deletePost,
        archivePost,
        suspendPost,
        restorePost,
        togglePinPost,
        moderatePost,
        addPostReaction,
        removePostReaction,
        addPostComment,
        updatePostComment,
        deletePostComment,
        reportPostComment,
        moderatePostComment,
        createPostFromEvent,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        deleteNotification,
        clearReadNotifications,
        handleNotificationQuickAction,
        createOfficialNotification,
        addStory,
        deleteStory,
        viewStory,
        addStoryReaction,
        addStatus,
        deleteStatus,
        reactToStatus,
        conversations,
        messages,
        presences,
        blockedContacts,
        activeConversationId,
        totalUnreadMessagesCount,
        setActiveConversationId,
        sendMessage,
        markMessageViewOnceAsOpened,
        editMessage,
        deleteMessage,
        toggleMessageReaction,
        createDirectConversation,
        createGroupConversation,
        addGroupParticipants,
        removeGroupParticipant,
        toggleGroupAdminRole,
        leaveGroupConversation,
        togglePinConversation,
        toggleArchiveConversation,
        markConversationAsRead,
        deleteConversation,
        blockContact,
        unblockContact,
        reportConversationOrMessage,
        sharePostToConversation,
        shareEventToConversation,
        callHistory,
        activeCallSession,
        incomingCallSession,
        startCall,
        answerIncomingCall,
        rejectIncomingCall,
        endActiveCall,
        toggleMuteCall,
        toggleVideoCall,
        switchCameraCall,
        toggleSpeakerCall,
        simulateIncomingCall,
        clearCallHistory,
        userPrivacySettings,
        updatePrivacySettings,
        notificationPreferences,
        isNotificationDrawerOpen,
        setIsNotificationDrawerOpen,
        isNotificationSettingsOpen,
        setIsNotificationSettingsOpen,
        updateNotificationPreferences,
        addNotification,
        socialReports,
        reportingTarget,
        setReportingTarget,
        submitSocialReport,
        processSocialReport,
        setUserOnlineStatus,
        memoryAlbums,
        historicalPublications,
        adminPublicationModalOpen,
        setAdminPublicationModalOpen,
        birthdayCelebrationModalOpen,
        setBirthdayCelebrationModalOpen,
        activeBirthdayDraft,
        setActiveBirthdayDraft,
        addMemoryAlbum,
        addHistoricalPublication,
        celebrateBirthday,
        createAdminOfficialPost,
        certifications,
        certificationColorRequests,
        certifyAccount,
        revokeCertification,
        updateCertificationBadgeColor,
        requestCertificationColor,
        approveCertificationColorRequest,
        rejectCertificationColorRequest,
        liveStreams,
        activeLiveStreamId,
        startNewLiveStream,
        joinLiveStream,
        leaveLiveStream,
        endLiveStream,
        sendLiveComment,
        sendLiveReaction,
        deleteLiveComment,
        blockUser,
        unblockUser,
        issueReports,
        submitIssueReport,
        resolveIssueReport,
        toasts,
        showToast,
        removeToast,
        can,
        resetToDefaults,
      }}
    >
      {children}
    </FamilyContext.Provider>
  );
};

export const useFamily = (): FamilyContextType => {
  const context = useContext(FamilyContext);
  if (!context) {
    throw new Error('useFamily must be used within a FamilyProvider');
  }
  return context;
};
