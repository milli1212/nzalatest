/**
 * NzalaFamilly - Centralized API Client (Frontend)
 * 
 * Features:
 * - Automatic Authorization Bearer header attachment
 * - Automatic Token Refresh on 401 Unauthorized
 * - Request queueing during token refresh to avoid race conditions
 * - Mode fallback (calls server controller directly in DEMO/mock mode, or fetches live API)
 */

import { ApiResponse } from '../production/serverContracts';
import { AuthServerController } from '../production/auth/authController';
import { ServerDispatcher } from '../production/serverDispatcher';
import { APP_CONFIG, isDemoMode } from './config';

export interface RequestOptions extends RequestInit {
  requiresAuth?: boolean;
  skipRefresh?: boolean;
}

class ApiClient {
  private accessToken: string | null = null;
  private refreshToken: string | null = null;
  private isRefreshing: boolean = false;
  private refreshSubscribers: Array<(token: string) => void> = [];

  constructor() {
    // Attempt to load tokens from secure in-memory/session storage
    if (typeof window !== 'undefined') {
      this.accessToken = sessionStorage.getItem('nzala_at_v1') || localStorage.getItem('nzala_at_v1');
      this.refreshToken = sessionStorage.getItem('nzala_rt_v1') || localStorage.getItem('nzala_rt_v1');
    }
  }

  public setTokens(accessToken: string, refreshToken?: string) {
    this.accessToken = accessToken;
    if (refreshToken) this.refreshToken = refreshToken;

    if (typeof window !== 'undefined') {
      sessionStorage.setItem('nzala_at_v1', accessToken);
      if (refreshToken) sessionStorage.setItem('nzala_rt_v1', refreshToken);
    }
  }

  public clearTokens() {
    this.accessToken = null;
    this.refreshToken = null;
    if (typeof window !== 'undefined') {
      sessionStorage.removeItem('nzala_at_v1');
      sessionStorage.removeItem('nzala_rt_v1');
      localStorage.removeItem('nzala_at_v1');
      localStorage.removeItem('nzala_rt_v1');
    }
  }

  public getAccessToken(): string | null {
    return this.accessToken;
  }

  public getRefreshToken(): string | null {
    return this.refreshToken;
  }

  private onTokenRefreshed(token: string) {
    this.refreshSubscribers.forEach((callback) => callback(token));
    this.refreshSubscribers = [];
  }

  private addRefreshSubscriber(callback: (token: string) => void) {
    this.refreshSubscribers.push(callback);
  }

  /**
   * Generic request method supporting both local development dispatch and remote HTTP API
   */
  public async request<T = any>(endpoint: string, options: RequestOptions = {}): Promise<ApiResponse<T>> {
    const requiresAuth = options.requiresAuth !== false;
    const authHeader = this.accessToken ? `Bearer ${this.accessToken}` : undefined;

    // --- In Demo / Standalone Mode: Direct Controller Invocation ---
    if (isDemoMode() || !APP_CONFIG.apiBaseUrl.startsWith('http')) {
      return this.handleLocalDispatch<T>(endpoint, options, authHeader);
    }

    // --- In Live API Mode: Standard HTTP Fetch ---
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string>),
    };

    if (requiresAuth && authHeader) {
      headers['Authorization'] = authHeader;
    }

    try {
      const url = `${APP_CONFIG.apiBaseUrl}${endpoint}`;
      const response = await fetch(url, {
        ...options,
        headers,
      });

      // Handle 401 Unauthorized with token refresh
      if (response.status === 401 && !options.skipRefresh && this.refreshToken) {
        if (!this.isRefreshing) {
          this.isRefreshing = true;
          const refreshResult = await this.refreshTokenRequest();

          if (refreshResult.success && refreshResult.data?.accessToken) {
            this.setTokens(refreshResult.data.accessToken, refreshResult.data.newRefreshToken);
            this.isRefreshing = false;
            this.onTokenRefreshed(refreshResult.data.accessToken);

            // Retry original request
            return this.request<T>(endpoint, { ...options, skipRefresh: true });
          } else {
            this.isRefreshing = false;
            this.clearTokens();
            return {
              success: false,
              error: { code: 'SESSION_EXPIRED', message: 'Session expirée. Veuillez vous reconnecter.' },
            };
          }
        } else {
          // Wait for ongoing refresh
          return new Promise((resolve) => {
            this.addRefreshSubscriber(async () => {
              const res = await this.request<T>(endpoint, { ...options, skipRefresh: true });
              resolve(res);
            });
          });
        }
      }

      const json = await response.json();
      return json;
    } catch (err: any) {
      return {
        success: false,
        error: { code: 'NETWORK_ERROR', message: err.message || 'Serveur indisponible.' },
      };
    }
  }

  /**
   * Internal local dispatcher for standalone preview environment
   */
  private async handleLocalDispatch<T>(
    endpoint: string,
    options: RequestOptions,
    authHeader?: string
  ): Promise<ApiResponse<T>> {
    const body = options.body ? JSON.parse(options.body as string) : {};
    const method = options.method || 'GET';
    return ServerDispatcher.dispatch<T>(endpoint, method, body, authHeader);
  }

  private async refreshTokenRequest(): Promise<ApiResponse<{ accessToken: string; newRefreshToken: string }>> {
    if (isDemoMode() || !APP_CONFIG.apiBaseUrl.startsWith('http')) {
      return (await AuthServerController.refresh(this.refreshToken || '')) as any;
    }

    try {
      const res = await fetch(`${APP_CONFIG.apiBaseUrl}/auth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken: this.refreshToken }),
      });
      return await res.json();
    } catch {
      return { success: false, error: { code: 'REFRESH_FAILED', message: 'Échec du rafraîchissement.' } };
    }
  }
}

export const apiClient = new ApiClient();
