/**
 * NzalaFamilly - Auth API Client Services
 * 
 * Provides type-safe methods for interacting with /api/v1/auth/* endpoints:
 * - register()
 * - login()
 * - logout()
 * - getMe()
 * - forgotPassword()
 * - resetPassword()
 */

import { apiClient } from './apiClient';
import { ApiResponse } from '../production/serverContracts';
import { UserSafeDto, CreateUserData } from '../production/repositories/userRepository';
import { AuthSuccessPayload } from '../production/auth/authController';

export class AuthApi {
  /**
   * Registers a new user.
   * Server assigns 'VISITEUR' and 'NON_DEPOSEE' by default.
   */
  public static async register(data: CreateUserData): Promise<ApiResponse<AuthSuccessPayload>> {
    const response = await apiClient.request<AuthSuccessPayload>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
      requiresAuth: false,
    });

    if (response.success && response.data?.accessToken) {
      apiClient.setTokens(response.data.accessToken, response.data.refreshToken);
    }

    return response;
  }

  /**
   * Logs in an existing user and stores session tokens
   */
  public static async login(credentials: { email: string; password: string }): Promise<ApiResponse<AuthSuccessPayload>> {
    const response = await apiClient.request<AuthSuccessPayload>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
      requiresAuth: false,
    });

    if (response.success && response.data?.accessToken) {
      apiClient.setTokens(response.data.accessToken, response.data.refreshToken);
    }

    return response;
  }

  /**
   * Logs out the user and clears session tokens locally and server-side
   */
  public static async logout(): Promise<ApiResponse<{ message: string }>> {
    const response = await apiClient.request<{ message: string }>('/auth/logout', {
      method: 'POST',
    });
    apiClient.clearTokens();
    return response;
  }

  /**
   * Fetches currently authenticated user data via Bearer token
   */
  public static async getMe(): Promise<ApiResponse<UserSafeDto>> {
    return apiClient.request<UserSafeDto>('/auth/me', {
      method: 'GET',
    });
  }

  /**
   * Sends password reset instructions to email
   */
  public static async forgotPassword(email: string): Promise<ApiResponse<{ message: string }>> {
    return apiClient.request<{ message: string }>('/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
      requiresAuth: false,
    });
  }

  /**
   * Confirms password reset with security token
   */
  public static async resetPassword(token: string, newPassword: string): Promise<ApiResponse<{ message: string }>> {
    return apiClient.request<{ message: string }>('/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify({ token, newPassword }),
      requiresAuth: false,
    });
  }
}
