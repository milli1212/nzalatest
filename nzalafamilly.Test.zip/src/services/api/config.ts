/**
 * NzalaFamilly - Environment & Runtime Mode Configuration
 * 
 * Controls whether the client is in DEMO_MODE (browser sandbox / mock fallback)
 * or PRODUCTION_MODE (connected to live PostgreSQL and API server).
 */

export interface AppConfig {
  mode: 'DEMO_MODE' | 'PRODUCTION_MODE';
  apiBaseUrl: string;
  isOnline: boolean;
  version: string;
  buildDate: string;
}

// Check for runtime environment flags
const isProductionEnv = typeof process !== 'undefined' && process.env?.NODE_ENV === 'production';
const envApiUrl = typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_API_BASE_URL;

export const APP_CONFIG: AppConfig = {
  mode: envApiUrl ? 'PRODUCTION_MODE' : 'DEMO_MODE',
  apiBaseUrl: envApiUrl || '/api/v1',
  isOnline: typeof navigator !== 'undefined' ? navigator.onLine : true,
  version: '1.0.0-rc1',
  buildDate: '2026-09-01',
};

export function isDemoMode(): boolean {
  return APP_CONFIG.mode === 'DEMO_MODE';
}

export function setAppMode(mode: 'DEMO_MODE' | 'PRODUCTION_MODE') {
  APP_CONFIG.mode = mode;
}
