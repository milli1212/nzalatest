/**
 * NzalaFamilly - Events, Verification, Privacy, Search & Audit API Services
 */

import { apiClient } from './apiClient';
import { ApiResponse } from '../production/serverContracts';
import { FamilyEvent, InvitationStatus, VerificationRequest, VerificationStatus, AuditLog, Member, FamilyPost } from '../../types';
import { UserPrivacySettings } from '../../types/notifications';
import { ProfileAccessRequest } from '../production/repositories/notificationRepository';

export class EventApi {
  public static async getEvents(options: { upcomingOnly?: boolean; type?: string } = {}): Promise<ApiResponse<{ events: FamilyEvent[]; total: number }>> {
    const params = new URLSearchParams();
    if (options.upcomingOnly) params.append('upcomingOnly', 'true');
    if (options.type) params.append('type', options.type);
    const query = params.toString() ? `?${params.toString()}` : '';
    return apiClient.request<{ events: FamilyEvent[]; total: number }>(`/events${query}`, { method: 'GET' });
  }

  public static async createEvent(eventData: Omit<FamilyEvent, 'id'>): Promise<ApiResponse<FamilyEvent>> {
    return apiClient.request<FamilyEvent>('/events', {
      method: 'POST',
      body: JSON.stringify(eventData),
    });
  }

  public static async rsvp(eventId: string, status: InvitationStatus, guestsCount: number = 1, note?: string): Promise<ApiResponse<FamilyEvent>> {
    return apiClient.request<FamilyEvent>(`/events/${eventId}/rsvp`, {
      method: 'POST',
      body: JSON.stringify({ status, guestsCount, note }),
    });
  }
}

export class VerificationApi {
  public static async getRequests(): Promise<ApiResponse<VerificationRequest[]>> {
    return apiClient.request<VerificationRequest[]>('/verifications', { method: 'GET' });
  }

  public static async submitRequest(requestData: Omit<VerificationRequest, 'id' | 'submittedAt' | 'status' | 'currentStep'>): Promise<ApiResponse<VerificationRequest>> {
    return apiClient.request<VerificationRequest>('/verifications/submit', {
      method: 'POST',
      body: JSON.stringify(requestData),
    });
  }

  public static async processDecision(
    id: string,
    decision: {
      status: VerificationStatus;
      reviewerNotes?: string;
      publicFeedback?: string;
      currentStep: number;
    }
  ): Promise<ApiResponse<VerificationRequest>> {
    return apiClient.request<VerificationRequest>(`/verifications/${id}/process`, {
      method: 'POST',
      body: JSON.stringify(decision),
    });
  }
}

export class PrivacyApi {
  public static async getSettings(userId: string): Promise<ApiResponse<UserPrivacySettings>> {
    return apiClient.request<UserPrivacySettings>(`/privacy/settings/${userId}`, { method: 'GET' });
  }

  public static async updateSettings(settings: Partial<UserPrivacySettings>): Promise<ApiResponse<UserPrivacySettings>> {
    return apiClient.request<UserPrivacySettings>('/privacy/settings', {
      method: 'PUT',
      body: JSON.stringify(settings),
    });
  }

  public static async requestProfileAccess(targetUserId: string): Promise<ApiResponse<ProfileAccessRequest>> {
    return apiClient.request<ProfileAccessRequest>('/privacy/access-requests', {
      method: 'POST',
      body: JSON.stringify({ targetUserId }),
    });
  }

  public static async respondProfileAccess(requestId: string, accept: boolean): Promise<ApiResponse<ProfileAccessRequest>> {
    return apiClient.request<ProfileAccessRequest>(`/privacy/access-requests/${requestId}/respond`, {
      method: 'POST',
      body: JSON.stringify({ accept }),
    });
  }
}

export interface SearchResultsPayload {
  members: Member[];
  posts: FamilyPost[];
  events: FamilyEvent[];
}

export class SearchApi {
  public static async globalSearch(query: string): Promise<ApiResponse<SearchResultsPayload>> {
    return apiClient.request<SearchResultsPayload>(`/search?q=${encodeURIComponent(query)}`, {
      method: 'GET',
    });
  }
}

export class AuditApi {
  public static async getLogs(filter: { action?: string; limit?: number } = {}): Promise<ApiResponse<AuditLog[]>> {
    const params = new URLSearchParams();
    if (filter.action) params.append('action', filter.action);
    if (filter.limit) params.append('limit', filter.limit.toString());
    const query = params.toString() ? `?${params.toString()}` : '';
    return apiClient.request<AuditLog[]>(`/audit/logs${query}`, { method: 'GET' });
  }
}
