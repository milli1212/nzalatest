/**
 * NzalaFamilly - Genealogy & Members API Services
 * Endpoints for Members, Families, Branches, Lineage Relationships & Alliances
 */

import { apiClient } from './apiClient';
import { ApiResponse } from '../production/serverContracts';
import { Family, FamilyBranch, Member, Relationship, Alliance } from '../../types';
import { MemberFilterOptions } from '../production/repositories/memberRepository';

export class GenealogyApi {
  // --- Families & Branches ---
  public static async getFamilies(): Promise<ApiResponse<Family[]>> {
    return apiClient.request<Family[]>('/families', { method: 'GET' });
  }

  public static async getBranches(familyId?: string): Promise<ApiResponse<FamilyBranch[]>> {
    const query = familyId ? `?familyId=${encodeURIComponent(familyId)}` : '';
    return apiClient.request<FamilyBranch[]>(`/branches${query}`, { method: 'GET' });
  }

  // --- Members ---
  public static async getMembers(filter: MemberFilterOptions = {}): Promise<ApiResponse<{ members: Member[]; total: number }>> {
    const params = new URLSearchParams();
    if (filter.familyId) params.append('familyId', filter.familyId);
    if (filter.branchId) params.append('branchId', filter.branchId);
    if (filter.search) params.append('search', filter.search);
    if (filter.generation !== undefined) params.append('generation', filter.generation.toString());
    const query = params.toString() ? `?${params.toString()}` : '';
    return apiClient.request<{ members: Member[]; total: number }>(`/members${query}`, { method: 'GET' });
  }

  public static async getMemberById(id: string): Promise<ApiResponse<Member>> {
    return apiClient.request<Member>(`/members/${id}`, { method: 'GET' });
  }

  public static async createMember(memberData: Omit<Member, 'id'>): Promise<ApiResponse<Member>> {
    return apiClient.request<Member>('/members', {
      method: 'POST',
      body: JSON.stringify(memberData),
    });
  }

  public static async updateMember(id: string, updates: Partial<Member>): Promise<ApiResponse<Member>> {
    return apiClient.request<Member>(`/members/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(updates),
    });
  }

  public static async archiveMember(id: string): Promise<ApiResponse<{ message: string }>> {
    return apiClient.request<{ message: string }>(`/members/${id}/archive`, {
      method: 'POST',
    });
  }

  // --- Relationships ---
  public static async getRelationships(): Promise<ApiResponse<Relationship[]>> {
    return apiClient.request<Relationship[]>('/relationships', { method: 'GET' });
  }

  public static async proposeRelationship(relData: Omit<Relationship, 'id'>): Promise<ApiResponse<Relationship>> {
    return apiClient.request<Relationship>('/relationships/propose', {
      method: 'POST',
      body: JSON.stringify(relData),
    });
  }

  public static async validateRelationship(id: string): Promise<ApiResponse<Relationship>> {
    return apiClient.request<Relationship>(`/relationships/${id}/validate`, {
      method: 'POST',
    });
  }

  // --- Alliances ---
  public static async getAlliances(): Promise<ApiResponse<Alliance[]>> {
    return apiClient.request<Alliance[]>('/alliances', { method: 'GET' });
  }

  public static async createAlliance(allianceData: Omit<Alliance, 'id'>): Promise<ApiResponse<Alliance>> {
    return apiClient.request<Alliance>('/alliances', {
      method: 'POST',
      body: JSON.stringify(allianceData),
    });
  }

  public static async ratifyAlliance(id: string): Promise<ApiResponse<Alliance>> {
    return apiClient.request<Alliance>(`/alliances/${id}/validate`, {
      method: 'POST',
    });
  }
}
