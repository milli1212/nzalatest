/**
 * NzalaFamilly - Messaging, Audio Notes & View-Once API Services
 */

import { apiClient } from './apiClient';
import { ApiResponse } from '../production/serverContracts';
import { FamilyConversation, FamilyMessage, ConversationParticipant } from '../../types';

export class MessagingApi {
  public static async getConversations(): Promise<ApiResponse<FamilyConversation[]>> {
    return apiClient.request<FamilyConversation[]>('/conversations', { method: 'GET' });
  }

  public static async createConversation(data: {
    type: 'DIRECT' | 'GROUP_BRANCH' | 'GROUP_FAMILY' | 'COUNCIL_SAGES';
    title?: string;
    avatarUrl?: string;
    participants: ConversationParticipant[];
  }): Promise<ApiResponse<FamilyConversation>> {
    return apiClient.request<FamilyConversation>('/conversations', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  public static async getMessages(conversationId: string, limit: number = 50): Promise<ApiResponse<FamilyMessage[]>> {
    return apiClient.request<FamilyMessage[]>(`/conversations/${conversationId}/messages?limit=${limit}`, {
      method: 'GET',
    });
  }

  public static async sendMessage(
    conversationId: string,
    messageData: Omit<FamilyMessage, 'id' | 'timestamp' | 'status'>
  ): Promise<ApiResponse<FamilyMessage>> {
    return apiClient.request<FamilyMessage>(`/conversations/${conversationId}/messages`, {
      method: 'POST',
      body: JSON.stringify(messageData),
    });
  }

  public static async markConversationRead(conversationId: string): Promise<ApiResponse<{ success: boolean }>> {
    return apiClient.request<{ success: boolean }>(`/conversations/${conversationId}/read`, {
      method: 'POST',
    });
  }

  /**
   * Consume View-Once single ephemeral media view
   */
  public static async consumeViewOnce(messageId: string): Promise<ApiResponse<{ success: boolean }>> {
    return apiClient.request<{ success: boolean }>(`/messages/${messageId}/view-once/consume`, {
      method: 'POST',
    });
  }
}
