/**
 * NzalaFamilly - Social Feed, Posts, Stories & Status API Services
 */

import { apiClient } from './apiClient';
import { ApiResponse } from '../production/serverContracts';
import { FamilyPost, FamilyStory, FamilyStatusItem, PostComment, ReactionType } from '../../types';

export class SocialApi {
  // --- Posts ---
  public static async getFeed(options: { page?: number; limit?: number; scope?: string } = {}): Promise<ApiResponse<{ posts: FamilyPost[]; total: number }>> {
    const params = new URLSearchParams();
    if (options.page) params.append('page', options.page.toString());
    if (options.limit) params.append('limit', options.limit.toString());
    if (options.scope) params.append('scope', options.scope);
    const query = params.toString() ? `?${params.toString()}` : '';
    return apiClient.request<{ posts: FamilyPost[]; total: number }>(`/posts${query}`, { method: 'GET' });
  }

  public static async createPost(postData: Omit<FamilyPost, 'id' | 'createdAt'>): Promise<ApiResponse<FamilyPost>> {
    return apiClient.request<FamilyPost>('/posts', {
      method: 'POST',
      body: JSON.stringify(postData),
    });
  }

  public static async reactToPost(postId: string, reactionType: ReactionType): Promise<ApiResponse<FamilyPost>> {
    return apiClient.request<FamilyPost>(`/posts/${postId}/react`, {
      method: 'POST',
      body: JSON.stringify({ reactionType }),
    });
  }

  public static async addComment(postId: string, content: string): Promise<ApiResponse<PostComment>> {
    return apiClient.request<PostComment>(`/posts/${postId}/comments`, {
      method: 'POST',
      body: JSON.stringify({ content }),
    });
  }

  public static async deletePost(postId: string): Promise<ApiResponse<{ message: string }>> {
    return apiClient.request<{ message: string }>(`/posts/${postId}`, {
      method: 'DELETE',
    });
  }

  // --- Stories (24h Ephemeral) ---
  public static async getActiveStories(): Promise<ApiResponse<FamilyStory[]>> {
    return apiClient.request<FamilyStory[]>('/stories/active', { method: 'GET' });
  }

  public static async createStory(storyData: Omit<FamilyStory, 'id' | 'createdAt' | 'expiresAt'>): Promise<ApiResponse<FamilyStory>> {
    return apiClient.request<FamilyStory>('/stories', {
      method: 'POST',
      body: JSON.stringify(storyData),
    });
  }

  public static async recordStoryView(storyId: string): Promise<ApiResponse<FamilyStory>> {
    return apiClient.request<FamilyStory>(`/stories/${storyId}/view`, {
      method: 'POST',
    });
  }

  public static async reactToStory(storyId: string, emoji: string): Promise<ApiResponse<FamilyStory>> {
    return apiClient.request<FamilyStory>(`/stories/${storyId}/react`, {
      method: 'POST',
      body: JSON.stringify({ emoji }),
    });
  }

  // --- Statuses ---
  public static async getStatuses(): Promise<ApiResponse<FamilyStatusItem[]>> {
    return apiClient.request<FamilyStatusItem[]>('/statuses', { method: 'GET' });
  }

  public static async createStatus(statusData: Omit<FamilyStatusItem, 'id' | 'createdAt'>): Promise<ApiResponse<FamilyStatusItem>> {
    return apiClient.request<FamilyStatusItem>('/statuses', {
      method: 'POST',
      body: JSON.stringify(statusData),
    });
  }
}
