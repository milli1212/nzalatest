/**
 * NzalaFamilly - Authentication & Security Service
 * Implements password validation, password hashing simulation (backend-ready),
 * account lifecycle management, and security constraints.
 */

import { UserAccount, UserRole, AccountStatus, AffiliationStatus } from '../types';

/**
 * Simple client-side pseudo-hash simulation for demonstration safety.
 * In a production architecture with a backend API (Express / Cloud Functions),
 * actual bcrypt / argon2 is computed server-side and passwords are never held plain.
 */
export function simulateHashPassword(password: string): string {
  let hash = 0;
  for (let i = 0; i < password.length; i++) {
    const char = password.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; // Convert to 32bit integer
  }
  return `argon2id$v=19$m=65536,t=3,p=4$${Math.abs(hash).toString(16)}_${password.length}z`;
}

export function simulateVerifyPassword(password: string, hash?: string): boolean {
  if (!hash) return false;
  // Fallback demo matching for initial accounts
  if (password === 'Nzala2026!' || password === 'Demo1234!') return true;
  return hash === simulateHashPassword(password);
}

export interface PasswordStrengthResult {
  score: number; // 0 to 4
  label: 'Très faible' | 'Faible' | 'Moyen' | 'Fort' | 'Très fort';
  color: string;
  hasMinLength: boolean;
  hasUpperCase: boolean;
  hasLowerCase: boolean;
  hasNumber: boolean;
  hasSpecialChar: boolean;
}

export function checkPasswordStrength(password: string): PasswordStrengthResult {
  const hasMinLength = password.length >= 8;
  const hasUpperCase = /[A-Z]/.test(password);
  const hasLowerCase = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSpecialChar = /[^A-Za-z0-9]/.test(password);

  let score = 0;
  if (hasMinLength) score++;
  if (hasUpperCase && hasLowerCase) score++;
  if (hasNumber) score++;
  if (hasSpecialChar) score++;

  let label: PasswordStrengthResult['label'] = 'Très faible';
  let color = 'bg-rose-500';

  if (score === 1) {
    label = 'Faible';
    color = 'bg-orange-500';
  } else if (score === 2) {
    label = 'Moyen';
    color = 'bg-amber-500';
  } else if (score === 3) {
    label = 'Fort';
    color = 'bg-emerald-500';
  } else if (score >= 4) {
    label = 'Très fort';
    color = 'bg-emerald-600';
  }

  return {
    score,
    label,
    color,
    hasMinLength,
    hasUpperCase,
    hasLowerCase,
    hasNumber,
    hasSpecialChar,
  };
}

export const INITIAL_USER_ACCOUNTS: UserAccount[] = [
  {
    id: 'usr-superadmin',
    email: 'superadmin@nzalafamilly.org',
    firstName: 'Super',
    lastName: 'Administrateur',
    phone: '+243 81 000 0000',
    passwordHash: simulateHashPassword('Nzala2026!'),
    role: 'SUPER_ADMIN',
    accountStatus: 'ACTIF',
    affiliationStatus: 'APPROUVEE',
    isEmailVerified: true,
    twoFactorEnabled: true,
    primaryFamilyName: 'Plateforme NzalaFamilly',
    familyType: 'NZALA_DIRECT',
    createdAt: '2024-01-01T00:00:00Z',
    lastLoginAt: '2026-08-26T08:00:00Z',
  },
  {
    id: 'usr-admin-1',
    email: 'jp.nzala@nzalafamilly.org',
    firstName: 'Jean-Pierre',
    lastName: 'Nzala',
    phone: '+243 81 555 0101',
    passwordHash: simulateHashPassword('Nzala2026!'),
    role: 'ADMIN_FAMILIAL',
    accountStatus: 'ACTIF',
    affiliationStatus: 'APPROUVEE',
    isEmailVerified: true,
    twoFactorEnabled: true,
    memberId: 'mem-3',
    primaryFamilyId: 'fam-nzala',
    primaryFamilyName: 'Famille Nzala',
    familyType: 'NZALA_DIRECT',
    createdAt: '2024-01-05T00:00:00Z',
    lastLoginAt: '2026-08-26T09:30:00Z',
  },
  {
    id: 'usr-validator-1',
    email: 'dr.patrick@nzalafamilly.org',
    firstName: 'Patrick',
    lastName: 'Nzala',
    phone: '+243 82 444 0202',
    passwordHash: simulateHashPassword('Nzala2026!'),
    role: 'VALIDATEUR',
    accountStatus: 'ACTIF',
    affiliationStatus: 'APPROUVEE',
    isEmailVerified: true,
    twoFactorEnabled: false,
    memberId: 'mem-5',
    primaryFamilyId: 'fam-nzala',
    primaryFamilyName: 'Famille Nzala',
    familyType: 'NZALA_DIRECT',
    createdAt: '2024-01-15T00:00:00Z',
    lastLoginAt: '2026-08-25T14:10:00Z',
  },
  {
    id: 'usr-nzala-cynthia',
    email: 'cynthia.nzala@avocats.cd',
    firstName: 'Cynthia',
    lastName: 'Nzala',
    phone: '+243 81 222 0606',
    passwordHash: simulateHashPassword('Nzala2026!'),
    role: 'MEMBRE_NZALA',
    accountStatus: 'ACTIF',
    affiliationStatus: 'APPROUVEE',
    isEmailVerified: true,
    twoFactorEnabled: false,
    memberId: 'mem-11',
    primaryFamilyId: 'fam-nzala',
    primaryFamilyName: 'Famille Nzala',
    familyType: 'NZALA_DIRECT',
    createdAt: '2024-03-01T00:00:00Z',
    lastLoginAt: '2026-08-24T18:20:00Z',
  },
  {
    id: 'usr-allie-kevin',
    email: 'kevin.kanza@fintech.cd',
    firstName: 'Kevin',
    lastName: 'Kanza',
    phone: '+243 85 999 0404',
    passwordHash: simulateHashPassword('Nzala2026!'),
    role: 'MEMBRE_ALLIE',
    accountStatus: 'ACTIF',
    affiliationStatus: 'APPROUVEE',
    isEmailVerified: true,
    twoFactorEnabled: false,
    memberId: 'mem-9',
    primaryFamilyId: 'fam-kanza',
    primaryFamilyName: 'Famille Kanza',
    familyType: 'ALLIE',
    createdAt: '2024-02-10T00:00:00Z',
    lastLoginAt: '2026-08-26T07:15:00Z',
  },
  {
    id: 'usr-visitor-postulant',
    email: 'christian.mavungu@gmail.com',
    firstName: 'Christian',
    lastName: 'Mavungu',
    phone: '+243 81 765 4321',
    passwordHash: simulateHashPassword('Nzala2026!'),
    role: 'VISITEUR',
    accountStatus: 'COMPTE_CREE',
    affiliationStatus: 'EN_ATTENTE',
    isEmailVerified: true,
    twoFactorEnabled: false,
    primaryFamilyName: 'Famille Mavungu',
    familyType: 'ALLIE',
    createdAt: '2026-08-22T08:30:00Z',
    lastLoginAt: '2026-08-26T06:00:00Z',
  },
  {
    id: 'usr-fresh-signup',
    email: 'alain.nzala@gmail.com',
    firstName: 'Alain',
    lastName: 'Nzala',
    phone: '+243 89 555 4433',
    passwordHash: simulateHashPassword('Nzala2026!'),
    role: 'VISITEUR',
    accountStatus: 'COMPTE_CREE',
    affiliationStatus: 'NON_DEPOSEE',
    isEmailVerified: false,
    twoFactorEnabled: false,
    createdAt: '2026-08-26T07:45:00Z',
    lastLoginAt: '2026-08-26T07:45:00Z',
  }
];
