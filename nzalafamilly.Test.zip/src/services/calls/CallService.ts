/**
 * NzalaFamilly - Service Métier d'Orchestration des Appels (NZALA CALLS)
 * Gère le cycle de vie des appels, la sonnerie, les autorisations, et l'historique
 */

import { CallSession, CallType, CallHistoryItem, CallStatus } from '../../types/calls';
import { CurrentUser, UserAccount } from '../../types';
import { BlockedContact } from '../../types/messaging';
import { PrivacyService } from '../privacy/PrivacyService';
import { WebRTCService } from './WebRTCService';
import { SignalingService } from './SignalingService';

type AnyUser = CurrentUser | UserAccount;

export class CallService {
  private static ringAudioContext: AudioContext | null = null;
  private static ringOscillator: OscillatorNode | null = null;
  private static ringGain: GainNode | null = null;
  private static ringInterval: any = null;

  /**
   * Vérifie si l'utilisateur actuel a le droit d'appeler le destinataire
   */
  public static canInitiateCall(
    caller: AnyUser,
    recipient: AnyUser,
    blockedContacts: BlockedContact[] = []
  ): { allowed: boolean; reason?: string } {
    // 1. Vérifier si le compte est suspendu
    const callerSuspended = (caller as any).accountStatus === 'SUSPENDU' || (caller as any).status === 'SUSPENDU';
    if (callerSuspended) {
      return { allowed: false, reason: 'Votre compte est actuellement suspendu.' };
    }
    const recipientSuspended = (recipient as any).accountStatus === 'SUSPENDU' || (recipient as any).status === 'SUSPENDU';
    if (recipientSuspended) {
      return { allowed: false, reason: 'Ce membre est temporairement indisponible.' };
    }

    // 2. Vérifier si l'un a bloqué l'autre
    const isBlockedByRecipient = blockedContacts.some(
      (b) => b.userId === recipient.id && b.blockedUserId === caller.id
    );
    const isCallerBlocking = blockedContacts.some(
      (b) => b.userId === caller.id && b.blockedUserId === recipient.id
    );

    if (isBlockedByRecipient || isCallerBlocking) {
      return { allowed: false, reason: 'Impossible de contacter ce membre (blocage actif).' };
    }

    // 3. Vérifier les paramètres de confidentialité
    const privacyCheck = PrivacyService.canCallUser(caller, recipient);
    if (!privacyCheck.allowed) {
      return { allowed: false, reason: privacyCheck.reason || 'Les paramètres de confidentialité de ce membre n’autorisent pas cet appel.' };
    }

    return { allowed: true };
  }

  /**
   * Crée une session d'appel sortant
   */
  public static createOutgoingSession(
    caller: AnyUser,
    recipient: { id: string; name: string; avatarUrl?: string },
    type: CallType,
    conversationId?: string
  ): CallSession {
    const isReal = SignalingService.getInstance().isRealBackendConnected();
    const callerName = (caller as any).name || `${(caller as any).firstName || ''} ${(caller as any).lastName || ''}`.trim() || 'Membre Nzala';
    return {
      id: `call-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      type,
      status: 'RINGING',
      direction: 'OUTGOING',
      initiatorId: caller.id,
      initiatorName: callerName,
      initiatorAvatar: caller.avatarUrl,
      recipientId: recipient.id,
      recipientName: recipient.name,
      recipientAvatar: recipient.avatarUrl,
      conversationId,
      startedAt: new Date().toISOString(),
      durationSeconds: 0,
      isMuted: false,
      isVideoEnabled: type === 'VIDEO',
      isFrontCamera: true,
      isSpeakerOn: true,
      isSimulated: !isReal,
    };
  }

  /**
   * Génère une tonalité de sonnerie via Web Audio API
   */
  public static startRingtone(type: 'OUTGOING' | 'INCOMING') {
    try {
      if (typeof window === 'undefined') return;
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;

      this.stopRingtone();
      const ctx = new AudioCtx();
      this.ringAudioContext = ctx;

      const freq1 = type === 'OUTGOING' ? 440 : 523.25; // La (440Hz) ou Do (523Hz)
      const freq2 = type === 'OUTGOING' ? 480 : 659.25; // Mi

      let isBeeping = false;

      const playTone = () => {
        if (!this.ringAudioContext || this.ringAudioContext.state === 'closed') return;
        try {
          const osc1 = this.ringAudioContext.createOscillator();
          const osc2 = this.ringAudioContext.createOscillator();
          const gain = this.ringAudioContext.createGain();

          osc1.type = 'sine';
          osc2.type = 'sine';
          osc1.frequency.value = freq1;
          osc2.frequency.value = freq2;

          gain.gain.setValueAtTime(0.08, this.ringAudioContext.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.0001, this.ringAudioContext.currentTime + (type === 'OUTGOING' ? 1.5 : 1.0));

          osc1.connect(gain);
          osc2.connect(gain);
          gain.connect(this.ringAudioContext.destination);

          osc1.start();
          osc2.start();
          osc1.stop(this.ringAudioContext.currentTime + 1.5);
          osc2.stop(this.ringAudioContext.currentTime + 1.5);
        } catch (e) {
          // Ignorer si audio autoplay est suspendu
        }
      };

      playTone();
      this.ringInterval = setInterval(playTone, type === 'OUTGOING' ? 3000 : 2000);
    } catch (err) {
      console.warn('Audio tone unavailable:', err);
    }
  }

  public static stopRingtone() {
    if (this.ringInterval) {
      clearInterval(this.ringInterval);
      this.ringInterval = null;
    }
    if (this.ringAudioContext && this.ringAudioContext.state !== 'closed') {
      this.ringAudioContext.close().catch(() => {});
      this.ringAudioContext = null;
    }
  }

  /**
   * Formate la durée en mm:ss ou hh:mm:ss
   */
  public static formatDuration(seconds: number): string {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    const pad = (n: number) => n.toString().padStart(2, '0');

    if (hrs > 0) {
      return `${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
    }
    return `${pad(mins)}:${pad(secs)}`;
  }
}
