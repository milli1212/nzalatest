/**
 * NzalaFamilly - Service de Signalisation pour les Appels Audio & Vidéo (WebRTC Signaling)
 * Fournit l'abstraction pour la négociation d'appels, compatible WebSocket / Firebase / Émulateur local
 */

import { SignalingMessage } from '../../types/calls';

export type SignalingListener = (message: SignalingMessage) => void;

export class SignalingService {
  private static instance: SignalingService;
  private listeners: Set<SignalingListener> = new Set();
  private isConnectedToRealBackend: boolean = false;
  private currentUserId: string | null = null;

  private constructor() {}

  public static getInstance(): SignalingService {
    if (!SignalingService.instance) {
      SignalingService.instance = new SignalingService();
    }
    return SignalingService.instance;
  }

  public init(userId: string) {
    this.currentUserId = userId;
  }

  public subscribe(listener: SignalingListener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  /**
   * Envoie un message de signalisation
   */
  public sendMessage(msg: SignalingMessage) {
    // Si connecté à un serveur WebSocket ou Firestore, router vers le serveur
    if (this.isConnectedToRealBackend) {
      // Ex: websocket.send(JSON.stringify(msg));
    }

    // Dispatch local aux écouteurs enregistrés
    this.listeners.forEach((listener) => {
      try {
        listener(msg);
      } catch (err) {
        console.error('Signaling listener error:', err);
      }
    });
  }

  /**
   * Indique si un backend de signalisation temps réel distant (WebSocket / Firebase) est connecté
   */
  public isRealBackendConnected(): boolean {
    return this.isConnectedToRealBackend;
  }

  /**
   * Permet de brancher un connecteur distant (ex: WebSocket, Firebase RTC)
   */
  public setRealBackendConnected(connected: boolean) {
    this.isConnectedToRealBackend = connected;
  }
}
