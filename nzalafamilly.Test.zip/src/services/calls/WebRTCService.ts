/**
 * NzalaFamilly - Service WebRTC Professionnel
 * Gestion des flux médias locaux (Microphone, Caméra), pistes Audio/Vidéo et WebRTC PeerConnection
 */

export interface WebRTCMediaConfig {
  audio: boolean;
  video: boolean;
  facingMode?: 'user' | 'environment';
}

export interface WebRTCCallbacks {
  onLocalStream?: (stream: MediaStream) => void;
  onRemoteStream?: (stream: MediaStream) => void;
  onIceCandidate?: (candidate: RTCIceCandidate) => void;
  onConnectionStateChange?: (state: RTCPeerConnectionState) => void;
  onError?: (errorMessage: string, rawError?: any) => void;
}

export class WebRTCService {
  private localStream: MediaStream | null = null;
  private peerConnection: RTCPeerConnection | null = null;
  private callbacks: WebRTCCallbacks = {};
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private currentFacingMode: 'user' | 'environment' = 'user';

  private static readonly ICE_SERVERS: RTCIceServer[] = [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' },
  ];

  constructor(callbacks: WebRTCCallbacks = {}) {
    this.callbacks = callbacks;
  }

  public setCallbacks(callbacks: WebRTCCallbacks) {
    this.callbacks = { ...this.callbacks, ...callbacks };
  }

  /**
   * Initialise le flux média local (micro/caméra) avec gestion propre des permissions navigateur
   */
  public async startLocalMedia(config: WebRTCMediaConfig): Promise<MediaStream | null> {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Votre navigateur ne prend pas en charge la capture audio/vidéo.');
      }

      this.currentFacingMode = config.facingMode || 'user';

      const constraints: MediaStreamConstraints = {
        audio: config.audio ? { echoCancellation: true, noiseSuppression: true, autoGainControl: true } : false,
        video: config.video
          ? {
              facingMode: this.currentFacingMode,
              width: { ideal: 1280 },
              height: { ideal: 720 },
            }
          : false,
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      this.localStream = stream;
      this.callbacks.onLocalStream?.(stream);
      return stream;
    } catch (err: any) {
      const friendlyMessage = this.translateMediaError(err);
      this.callbacks.onError?.(friendlyMessage, err);
      return null;
    }
  }

  /**
   * Initialise la PeerConnection WebRTC
   */
  public initPeerConnection(): RTCPeerConnection {
    this.closePeerConnection();

    const config: RTCConfiguration = {
      iceServers: WebRTCService.ICE_SERVERS,
    };

    const pc = new RTCPeerConnection(config);
    this.peerConnection = pc;

    // Attacher les pistes locales si disponibles
    if (this.localStream) {
      this.localStream.getTracks().forEach((track) => {
        pc.addTrack(track, this.localStream!);
      });
    }

    pc.onicecandidate = (event) => {
      if (event.candidate && this.callbacks.onIceCandidate) {
        this.callbacks.onIceCandidate(event.candidate);
      }
    };

    pc.ontrack = (event) => {
      if (event.streams && event.streams[0]) {
        this.callbacks.onRemoteStream?.(event.streams[0]);
      }
    };

    pc.onconnectionstatechange = () => {
      this.callbacks.onConnectionStateChange?.(pc.connectionState);
    };

    return pc;
  }

  /**
   * Active / désactive le microphone local
   */
  public setAudioEnabled(enabled: boolean): boolean {
    if (!this.localStream) return false;
    this.localStream.getAudioTracks().forEach((track) => {
      track.enabled = enabled;
    });
    return enabled;
  }

  /**
   * Active / désactive la caméra locale
   */
  public setVideoEnabled(enabled: boolean): boolean {
    if (!this.localStream) return false;
    this.localStream.getVideoTracks().forEach((track) => {
      track.enabled = enabled;
    });
    return enabled;
  }

  /**
   * Bascule entre caméra avant et arrière (mobile)
   */
  public async switchCamera(): Promise<boolean> {
    if (!this.localStream || !this.localStream.getVideoTracks().length) return false;
    const newFacingMode = this.currentFacingMode === 'user' ? 'environment' : 'user';

    try {
      // Arrêter l'ancienne piste vidéo
      this.localStream.getVideoTracks().forEach((t) => t.stop());

      const newStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: newFacingMode },
        audio: false,
      });

      const newTrack = newStream.getVideoTracks()[0];
      if (newTrack) {
        // Mettre à jour le localStream
        this.localStream.removeTrack(this.localStream.getVideoTracks()[0]);
        this.localStream.addTrack(newTrack);

        // Mettre à jour le PeerConnection sender
        if (this.peerConnection) {
          const senders = this.peerConnection.getSenders();
          const videoSender = senders.find((s) => s.track && s.track.kind === 'video');
          if (videoSender) {
            await videoSender.replaceTrack(newTrack);
          }
        }

        this.currentFacingMode = newFacingMode;
        this.callbacks.onLocalStream?.(this.localStream);
        return true;
      }
      return false;
    } catch (err: any) {
      console.warn('Impossible de changer de caméra:', err);
      return false;
    }
  }

  /**
   * Crée une offre WebRTC (SDP Offer)
   */
  public async createOffer(): Promise<RTCSessionDescriptionInit | null> {
    if (!this.peerConnection) return null;
    try {
      const offer = await this.peerConnection.createOffer({
        offerToReceiveAudio: true,
        offerToReceiveVideo: true,
      });
      await this.peerConnection.setLocalDescription(offer);
      return offer;
    } catch (err: any) {
      this.callbacks.onError?.('Erreur lors de la préparation de la session d’appel.', err);
      return null;
    }
  }

  /**
   * Crée une réponse WebRTC (SDP Answer)
   */
  public async createAnswer(remoteOffer: RTCSessionDescriptionInit): Promise<RTCSessionDescriptionInit | null> {
    if (!this.peerConnection) return null;
    try {
      await this.peerConnection.setRemoteDescription(new RTCSessionDescription(remoteOffer));
      const answer = await this.peerConnection.createAnswer();
      await this.peerConnection.setLocalDescription(answer);
      return answer;
    } catch (err: any) {
      this.callbacks.onError?.('Erreur lors de la réponse à l’appel.', err);
      return null;
    }
  }

  /**
   * Reçoit la réponse distante
   */
  public async handleAnswer(remoteAnswer: RTCSessionDescriptionInit): Promise<void> {
    if (!this.peerConnection) return;
    try {
      await this.peerConnection.setRemoteDescription(new RTCSessionDescription(remoteAnswer));
    } catch (err: any) {
      console.warn('Erreur setRemoteDescription (answer):', err);
    }
  }

  /**
   * Ajoute un candidat ICE reçu
   */
  public async addIceCandidate(candidate: RTCIceCandidateInit): Promise<void> {
    if (!this.peerConnection) return;
    try {
      await this.peerConnection.addIceCandidate(new RTCIceCandidate(candidate));
    } catch (err: any) {
      console.warn('Erreur addIceCandidate:', err);
    }
  }

  /**
   * Nettoyage complet
   */
  public stopAll(): void {
    if (this.localStream) {
      this.localStream.getTracks().forEach((track) => track.stop());
      this.localStream = null;
    }
    this.closePeerConnection();
    if (this.audioContext && this.audioContext.state !== 'closed') {
      this.audioContext.close().catch(() => {});
      this.audioContext = null;
    }
  }

  private closePeerConnection(): void {
    if (this.peerConnection) {
      this.peerConnection.close();
      this.peerConnection = null;
    }
  }

  public getLocalStream(): MediaStream | null {
    return this.localStream;
  }

  /**
   * Traduction des erreurs de médias
   */
  private translateMediaError(err: any): string {
    if (!err) return 'Erreur inconnue d’accès aux périphériques.';
    const name = err.name || '';
    switch (name) {
      case 'NotAllowedError':
      case 'PermissionDeniedError':
        return 'Accès au microphone ou à la caméra refusé. Veuillez autoriser l’accès dans les paramètres de votre navigateur.';
      case 'NotFoundError':
      case 'DevicesNotFoundError':
        return 'Aucun microphone ou caméra détecté sur cet appareil.';
      case 'NotReadableError':
      case 'TrackStartError':
        return 'Le microphone ou la caméra est déjà utilisé par une autre application.';
      case 'OverconstrainedError':
        return 'La configuration vidéo demandée n’est pas supportée par votre caméra.';
      case 'SecurityError':
        return 'L’accès aux médias est bloqué pour des raisons de sécurité du navigateur.';
      default:
        return err.message || 'Impossible d’initialiser l’appel audio/vidéo.';
    }
  }
}
