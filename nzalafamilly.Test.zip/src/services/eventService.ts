import {
  FamilyEvent,
  EventType,
  EventVisibility,
  EventStatus,
  EventInvitation,
  UpcomingBirthday,
  Member,
  CurrentUser,
  UserRole,
} from '../types';

/**
 * NZALAFAMILLY - EVENT & CALENDAR ENGINE
 * Handles permissions, visibility filters, RSVP management, birthday calculations,
 * and calendar date manipulations.
 */

// Current reference date (deterministic for preview/sandbox)
export const SYSTEM_TODAY = new Date('2026-08-26T00:00:00Z');

/**
 * Determine if a user has permission to view an event based on visibility and roles.
 */
export function canUserViewEvent(event: FamilyEvent, user: CurrentUser): boolean {
  // Super Admin and Family Admin can view all events
  if (user.role === 'SUPER_ADMIN' || user.role === 'ADMIN_FAMILIAL') {
    return true;
  }

  // Confidential Family Council meetings
  if (event.eventType === 'CONSEIL_FAMILLE' || event.isConfidential) {
    if (user.role === 'VALIDATEUR') return true;
    // Check if explicitly invited
    if (event.invitations && user.memberId) {
      const isInvited = event.invitations.some(
        (inv) => inv.memberId === user.memberId || inv.userId === user.id
      );
      if (isInvited) return true;
    }
    return false;
  }

  // 1. PUBLIC EVENTS: Visible to all visitors and members
  if (event.visibility === 'PUBLIC') {
    return true;
  }

  // Visitors can ONLY view strictly PUBLIC events
  if (user.role === 'VISITEUR') {
    return false;
  }

  // Organizer can always view their own event
  if (event.organizerId === user.id || (user.memberId && event.organizerId === user.memberId)) {
    return true;
  }

  // Check if explicitly invited
  if (event.invitations && (user.id || user.memberId)) {
    const isDirectlyInvited = event.invitations.some(
      (inv) =>
        (user.id && inv.userId === user.id) ||
        (user.memberId && inv.memberId === user.memberId) ||
        (user.familyId && inv.targetType === 'FAMILY' && inv.targetId === user.familyId) ||
        (user.familyId && inv.targetType === 'ALLIED_FAMILY' && inv.targetId === user.familyId)
    );
    if (isDirectlyInvited) return true;
  }

  // 2. NZALA_INTERNE: Visible to Nzala family members & validators
  if (event.visibility === 'NZALA_INTERNE') {
    return user.familyType === 'NZALA_DIRECT' || user.role === 'VALIDATEUR';
  }

  // 3. FAMILLE_ALLIEE: Visible to members of the specific allied family
  if (event.visibility === 'FAMILLE_ALLIEE') {
    if (event.alliedFamilyId && user.familyId === event.alliedFamilyId) {
      return true;
    }
    if (event.familyId && user.familyId === event.familyId) {
      return true;
    }
    return false;
  }

  // 4. INTER_FAMILLES: Visible to Nzala members AND the specific Allied Family members
  if (event.visibility === 'INTER_FAMILLES') {
    if (user.familyType === 'NZALA_DIRECT') return true;
    if (event.alliedFamilyId && user.familyId === event.alliedFamilyId) return true;
    if (event.familyId && user.familyId === event.familyId) return true;
    return false;
  }

  // 5. PRIVE: Only invited people or organizer
  if (event.visibility === 'PRIVE') {
    return false;
  }

  return false;
}

/**
 * Filter event list according to user's permissions and visibility constraints.
 */
export function filterEventsForUser(events: FamilyEvent[], user: CurrentUser): FamilyEvent[] {
  return events.filter((event) => canUserViewEvent(event, user));
}

/**
 * Validate new or updated event data.
 */
export function validateEventData(data: Partial<FamilyEvent>): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!data.title || data.title.trim().length < 3) {
    errors.push("Le titre de l'événement doit contenir au moins 3 caractères.");
  }

  if (!data.startDate) {
    errors.push('La date de début est obligatoire.');
  }

  if (data.startDate && data.endDate && data.endDate < data.startDate) {
    errors.push('La date de fin ne peut pas être antérieure à la date de début.');
  }

  if (data.startDate === data.endDate && data.startTime && data.endTime && data.endTime <= data.startTime) {
    errors.push("L'heure de fin doit être postérieure à l'heure de début pour une même journée.");
  }

  if (!data.location || data.location.trim().length < 2) {
    errors.push('Le lieu ou le lien de la rencontre est requis.');
  }

  if (!data.eventType) {
    errors.push("Le type d'événement est requis.");
  }

  if (!data.visibility) {
    errors.push("La portée de visibilité de l'événement est requise.");
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
}

/**
 * Calculate upcoming birthdays from members' birth dates.
 */
export function calculateUpcomingBirthdays(
  members: Member[],
  currentUser: CurrentUser,
  options: { limit?: number; month?: number } = {}
): UpcomingBirthday[] {
  const now = SYSTEM_TODAY;
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth(); // 0-11
  const currentDay = now.getDate();

  const results: UpcomingBirthday[] = [];

  const isVisitor = currentUser.role === 'VISITEUR';

  for (const member of members) {
    // Only living members
    if (member.livingStatus !== 'VIVANT' || !member.birthDate) continue;

    // Respect member profile visibility
    if (member.visibilityLevel === 'PRIVATE' && currentUser.role !== 'SUPER_ADMIN' && currentUser.role !== 'ADMIN_FAMILIAL') {
      continue;
    }

    const birthParts = member.birthDate.split('-');
    if (birthParts.length < 3) continue;

    const bYear = parseInt(birthParts[0], 10);
    const bMonth = parseInt(birthParts[1], 10) - 1; // 0-indexed
    const bDay = parseInt(birthParts[2], 10);

    if (isNaN(bMonth) || isNaN(bDay)) continue;

    // If specific month filter is applied
    if (options.month !== undefined && bMonth !== options.month) {
      continue;
    }

    // Calculate this year's birthday date
    let targetYear = currentYear;
    let nextBday = new Date(Date.UTC(targetYear, bMonth, bDay));
    const todayMidnight = new Date(Date.UTC(currentYear, currentMonth, currentDay));

    // If birthday already passed this year, look at next year
    if (nextBday < todayMidnight) {
      targetYear += 1;
      nextBday = new Date(Date.UTC(targetYear, bMonth, bDay));
    }

    // Days difference
    const diffTime = nextBday.getTime() - todayMidnight.getTime();
    const daysUntil = Math.round(diffTime / (1000 * 60 * 60 * 24));

    // Age calculation
    const ageNext = !isNaN(bYear) && bYear > 1900 ? targetYear - bYear : undefined;

    // Show age rule: Visitors don't see age; private setting hides age
    const showAge = !isVisitor && ageNext !== undefined && member.visibilityLevel !== 'PRIVATE';

    const monthNames = [
      'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
      'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
    ];

    results.push({
      memberId: member.id,
      firstName: member.firstName,
      lastName: member.lastName,
      fullName: `${member.firstName} ${member.lastName}`,
      avatarUrl: member.avatarUrl,
      birthDate: member.birthDate,
      birthMonth: bMonth,
      birthDay: bDay,
      daysUntil,
      formattedDate: `${bDay} ${monthNames[bMonth]}`,
      ageNext,
      showAge,
      primaryFamilyName: member.primaryFamilyName,
      primaryFamilyId: member.primaryFamilyId,
      familyType: member.familyType,
      branchName: member.branchName,
      branchId: member.branchId,
      livingStatus: member.livingStatus,
      privacyLevel: isVisitor ? 'MONTH_DAY_ONLY' : 'FAMILY_ONLY',
    });
  }

  // Sort by closest upcoming
  results.sort((a, b) => a.daysUntil - b.daysUntil);

  if (options.limit && options.limit > 0) {
    return results.slice(0, options.limit);
  }

  return results;
}

/**
 * Get visual badge and metadata for Event Type.
 */
export function getEventTypeConfig(type: EventType): {
  label: string;
  shortLabel: string;
  description: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  cardAccent: string;
  dotColor: string;
} {
  switch (type) {
    case 'ANNIVERSAIRE':
      return {
        label: 'Anniversaire',
        shortLabel: 'Anniv.',
        description: 'Célébration d’un anniversaire de naissance familial',
        badgeBg: 'bg-rose-50',
        badgeText: 'text-rose-800',
        badgeBorder: 'border-rose-200',
        cardAccent: 'border-l-rose-500',
        dotColor: 'bg-rose-500',
      };
    case 'REUNION_FAMILIALE':
      return {
        label: 'Réunion Familiale',
        shortLabel: 'Réunion',
        description: 'Rencontre et assemblée de branche ou de famille',
        badgeBg: 'bg-amber-50',
        badgeText: 'text-amber-900',
        badgeBorder: 'border-amber-300',
        cardAccent: 'border-l-amber-500',
        dotColor: 'bg-amber-500',
      };
    case 'CONSEIL_FAMILLE':
      return {
        label: 'Conseil de Famille',
        shortLabel: 'Conseil',
        description: 'Session solennelle et confidentielle du Conseil des Sages',
        badgeBg: 'bg-purple-50',
        badgeText: 'text-purple-900',
        badgeBorder: 'border-purple-300',
        cardAccent: 'border-l-purple-600',
        dotColor: 'bg-purple-600',
      };
    case 'MARIAGE':
      return {
        label: 'Mariage & Dote',
        shortLabel: 'Mariage',
        description: 'Célébration nuptiale, dot coutumière ou fiançailles',
        badgeBg: 'bg-pink-50',
        badgeText: 'text-pink-900',
        badgeBorder: 'border-pink-300',
        cardAccent: 'border-l-pink-500',
        dotColor: 'bg-pink-500',
      };
    case 'NAISSANCE':
      return {
        label: 'Naissance & Bénédiction',
        shortLabel: 'Naissance',
        description: 'Accueil et présentation d’un nouveau-né dans la lignée',
        badgeBg: 'bg-emerald-50',
        badgeText: 'text-emerald-900',
        badgeBorder: 'border-emerald-300',
        cardAccent: 'border-l-emerald-500',
        dotColor: 'bg-emerald-500',
      };
    case 'CEREMONIE':
      return {
        label: 'Cérémonie Coutumière',
        shortLabel: 'Cérémonie',
        description: 'Rites traditionnels, intronisations ou actions de grâce',
        badgeBg: 'bg-amber-100',
        badgeText: 'text-amber-950',
        badgeBorder: 'border-amber-400',
        cardAccent: 'border-l-amber-700',
        dotColor: 'bg-amber-700',
      };
    case 'COMMEMORATION':
      return {
        label: 'Commémoration & Hommage',
        shortLabel: 'Hommage',
        description: 'Mémoire des patriarches, défunts et bâtisseurs de la famille',
        badgeBg: 'bg-stone-100',
        badgeText: 'text-stone-800',
        badgeBorder: 'border-stone-300',
        cardAccent: 'border-l-stone-600',
        dotColor: 'bg-stone-600',
      };
    case 'RENCONTRE_ALLIANCE':
      return {
        label: 'Rencontre Inter-Alliances',
        shortLabel: 'Alliance',
        description: 'Échange bilatéral ou festif entre familles alliées',
        badgeBg: 'bg-sky-50',
        badgeText: 'text-sky-900',
        badgeBorder: 'border-sky-300',
        cardAccent: 'border-l-sky-500',
        dotColor: 'bg-sky-500',
      };
    case 'AUTRE':
    default:
      return {
        label: 'Autre Événement',
        shortLabel: 'Événement',
        description: 'Moment marquant de la vie collective',
        badgeBg: 'bg-stone-100',
        badgeText: 'text-stone-700',
        badgeBorder: 'border-stone-200',
        cardAccent: 'border-l-stone-400',
        dotColor: 'bg-stone-400',
      };
  }
}

/**
 * Get visual badge and description for Event Visibility Scope.
 */
export function getEventVisibilityConfig(visibility: EventVisibility): {
  label: string;
  shortLabel: string;
  description: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  iconName: string;
} {
  switch (visibility) {
    case 'NZALA_INTERNE':
      return {
        label: 'Famille Nzala (Interne)',
        shortLabel: 'Interne Nzala',
        description: 'Réservé aux membres de la famille souche Nzala et validateurs',
        badgeBg: 'bg-amber-50',
        badgeText: 'text-amber-900',
        badgeBorder: 'border-amber-300',
        iconName: 'Shield',
      };
    case 'FAMILLE_ALLIEE':
      return {
        label: 'Famille Alliée Spécifique',
        shortLabel: 'Famille Alliée',
        description: 'Réservé aux membres de la famille alliée désignée',
        badgeBg: 'bg-sky-50',
        badgeText: 'text-sky-900',
        badgeBorder: 'border-sky-300',
        iconName: 'Building2',
      };
    case 'INTER_FAMILLES':
      return {
        label: 'Inter-Familles (Alliances)',
        shortLabel: 'Inter-Familles',
        description: 'Visible conjointement par la Famille Nzala et les familles alliées participantes',
        badgeBg: 'bg-emerald-50',
        badgeText: 'text-emerald-900',
        badgeBorder: 'border-emerald-300',
        iconName: 'HeartHandshake',
      };
    case 'PUBLIC':
      return {
        label: 'Public Familial & Visiteurs',
        shortLabel: 'Public',
        description: 'Ouvert et visible aux visiteurs et à tous les membres',
        badgeBg: 'bg-blue-50',
        badgeText: 'text-blue-900',
        badgeBorder: 'border-blue-300',
        iconName: 'Globe',
      };
    case 'PRIVE':
      return {
        label: 'Privé (Sur Invitation)',
        shortLabel: 'Privé',
        description: 'Uniquement visible aux personnes explicitement invitées',
        badgeBg: 'bg-stone-100',
        badgeText: 'text-stone-800',
        badgeBorder: 'border-stone-300',
        iconName: 'Lock',
      };
  }
}

/**
 * Calculate countdown and relative human text for event date.
 */
export function getEventCountdown(dateStr: string): {
  text: string;
  isPast: boolean;
  isToday: boolean;
  isTomorrow: boolean;
  daysRemaining: number;
} {
  const now = SYSTEM_TODAY;
  const eventDate = new Date(dateStr + 'T00:00:00Z');
  const nowMidnight = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()));

  const diffMs = eventDate.getTime() - nowMidnight.getTime();
  const daysRemaining = Math.round(diffMs / (1000 * 60 * 60 * 24));

  if (daysRemaining < 0) {
    return {
      text: `Passé (${Math.abs(daysRemaining)} j)`,
      isPast: true,
      isToday: false,
      isTomorrow: false,
      daysRemaining,
    };
  }

  if (daysRemaining === 0) {
    return {
      text: "Aujourd'hui",
      isPast: false,
      isToday: true,
      isTomorrow: false,
      daysRemaining: 0,
    };
  }

  if (daysRemaining === 1) {
    return {
      text: 'Demain',
      isPast: false,
      isToday: false,
      isTomorrow: true,
      daysRemaining: 1,
    };
  }

  return {
    text: `Dans ${daysRemaining} jours`,
    isPast: false,
    isToday: false,
    isTomorrow: false,
    daysRemaining,
  };
}

/**
 * Format date string into French readable string.
 */
export function formatFrenchDate(dateStr: string, options?: { withWeekday?: boolean; withYear?: boolean }): string {
  if (!dateStr) return '';
  const date = new Date(dateStr + 'T00:00:00Z');
  if (isNaN(date.getTime())) return dateStr;

  const weekdays = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
  const months = [
    'janvier', 'février', 'mars', 'avril', 'mai', 'juin',
    'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'
  ];

  const weekday = weekdays[date.getUTCDay()];
  const day = date.getUTCDate();
  const month = months[date.getUTCMonth()];
  const year = date.getUTCFullYear();

  let formatted = `${day} ${month}`;
  if (options?.withWeekday) {
    formatted = `${weekday} ${formatted}`;
  }
  if (options?.withYear !== false) {
    formatted = `${formatted} ${year}`;
  }

  return formatted;
}
