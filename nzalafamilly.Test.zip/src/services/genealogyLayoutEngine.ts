import {
  Member,
  Relationship,
  Alliance,
  Family,
  FamilyBranch,
  RelationshipType,
  UserRole,
} from '../types';

export interface TreeNode {
  id: string;
  member: Member;
  x: number;
  y: number;
  width: number;
  height: number;
  generation: number;
  isDirectNzala: boolean;
  spouse?: Member;
  spouseRelationship?: Relationship;
  parentIds: string[];
  childrenIds: string[];
  spouseIds: string[];
  siblingIds: string[];
}

export interface TreeLink {
  id: string;
  sourceId: string;
  targetId: string;
  type: RelationshipType;
  path: string; // SVG path d attribute
  label?: string;
  isAlliance?: boolean;
}

export interface TreeLayout {
  nodes: TreeNode[];
  links: TreeLink[];
  width: number;
  height: number;
  generations: number[];
  bounds: { minX: number; maxX: number; minY: number; maxY: number };
}

export interface GenealogicalConsistencyIssue {
  id: string;
  severity: 'ERROR' | 'WARNING';
  type: 'SELF_LINK' | 'CYCLE' | 'DATE_ANOMALY' | 'GENERATION_GAP' | 'DUPLICATE';
  message: string;
  memberIds: string[];
}

/**
 * Dynamically computes generations for all members using relationship graph.
 * If a member already has generationLevel, uses it, but also computes dynamic generations
 * from roots (G1 = members with no parents in data) down to children (G = G_parent + 1).
 */
export const computeDynamicGenerations = (
  members: Member[],
  relationships: Relationship[]
): Map<string, number> => {
  const genMap = new Map<string, number>();
  const parentOfMap = new Map<string, string[]>(); // parentId -> childIds[]
  const childOfMap = new Map<string, string[]>(); // childId -> parentIds[]

  members.forEach((m) => {
    parentOfMap.set(m.id, []);
    childOfMap.set(m.id, []);
  });

  const validParentRel = relationships.filter(
    (r) => r.relationshipType === 'PARENT_ENFANT' && r.status === 'VALIDEE'
  );

  validParentRel.forEach((r) => {
    const pId = r.memberAId;
    const cId = r.memberBId;
    if (parentOfMap.has(pId) && childOfMap.has(cId)) {
      parentOfMap.get(pId)!.push(cId);
      childOfMap.get(cId)!.push(pId);
    }
  });

  // Step 1: initialize with explicit generationLevel if present
  members.forEach((m) => {
    if (typeof m.generationLevel === 'number' && m.generationLevel > 0) {
      genMap.set(m.id, m.generationLevel);
    }
  });

  // Step 2: identify roots (no parents)
  const roots = members.filter((m) => (childOfMap.get(m.id)?.length || 0) === 0);

  roots.forEach((root) => {
    if (!genMap.has(root.id)) {
      genMap.set(root.id, 1);
    }
  });

  // Step 3: BFS propagation to compute or reconcile generations
  const queue: string[] = roots.map((r) => r.id);
  const visited = new Set<string>();

  while (queue.length > 0) {
    const currentId = queue.shift()!;
    if (visited.has(currentId)) continue;
    visited.add(currentId);

    const currentGen = genMap.get(currentId) || 1;
    const children = parentOfMap.get(currentId) || [];

    children.forEach((childId) => {
      const existingChildGen = genMap.get(childId);
      const computedChildGen = currentGen + 1;

      if (!existingChildGen || computedChildGen > existingChildGen) {
        genMap.set(childId, computedChildGen);
      }
      queue.push(childId);
    });
  }

  // Fallback for disconnected nodes
  members.forEach((m) => {
    if (!genMap.has(m.id)) {
      genMap.set(m.id, m.generationLevel || 1);
    }
  });

  return genMap;
};

/**
 * Calculates a clean 2D layout for the dynamic interactive tree.
 * Pairs spouses horizontally and positions generations vertically.
 */
export const calculateTreeLayout = (
  members: Member[],
  relationships: Relationship[],
  options: {
    nodeWidth?: number;
    nodeHeight?: number;
    horizontalGap?: number;
    verticalGap?: number;
    filterGeneration?: number | 'ALL';
    filterBranchId?: string;
    filterFamilyType?: 'ALL' | 'NZALA_ONLY' | 'ALLIES_ONLY';
    searchQuery?: string;
  } = {}
): TreeLayout => {
  const {
    nodeWidth = 260,
    nodeHeight = 150,
    horizontalGap = 60,
    verticalGap = 130,
    filterGeneration = 'ALL',
    filterBranchId = 'ALL',
    filterFamilyType = 'ALL',
  } = options;

  if (members.length === 0) {
    return {
      nodes: [],
      links: [],
      width: 800,
      height: 600,
      generations: [],
      bounds: { minX: 0, maxX: 800, minY: 0, maxY: 600 },
    };
  }

  const dynamicGenMap = computeDynamicGenerations(members, relationships);

  // Filter members based on criteria
  let filteredMembers = members.filter((m) => {
    const gen = dynamicGenMap.get(m.id) || m.generationLevel || 1;
    if (filterGeneration !== 'ALL' && gen !== filterGeneration) return false;
    if (filterBranchId !== 'ALL' && m.branchId !== filterBranchId) return false;
    if (filterFamilyType === 'NZALA_ONLY' && m.familyType !== 'NZALA_DIRECT') return false;
    if (filterFamilyType === 'ALLIES_ONLY' && m.familyType !== 'ALLIE') return false;
    return true;
  });

  if (filteredMembers.length === 0) {
    filteredMembers = members; // fallback to avoid empty canvas
  }

  const filteredMemberIds = new Set(filteredMembers.map((m) => m.id));

  // Map relationships
  const parentChildRel = relationships.filter(
    (r) =>
      r.relationshipType === 'PARENT_ENFANT' &&
      r.status === 'VALIDEE' &&
      filteredMemberIds.has(r.memberAId) &&
      filteredMemberIds.has(r.memberBId)
  );

  const spouseRel = relationships.filter(
    (r) =>
      r.relationshipType === 'CONJOINT' &&
      r.status === 'VALIDEE' &&
      filteredMemberIds.has(r.memberAId) &&
      filteredMemberIds.has(r.memberBId)
  );

  // Group members by generation
  const genGroups = new Map<number, Member[]>();
  filteredMembers.forEach((m) => {
    const gen = dynamicGenMap.get(m.id) || m.generationLevel || 1;
    if (!genGroups.has(gen)) {
      genGroups.set(gen, []);
    }
    genGroups.get(gen)!.push(m);
  });

  const distinctGens = Array.from(genGroups.keys()).sort((a, b) => a - b);

  // Position nodes layer by layer
  const nodes: TreeNode[] = [];
  const nodeMap = new Map<string, TreeNode>();

  let maxRowWidth = 0;
  const startY = 80;

  distinctGens.forEach((gen, genIndex) => {
    const membersInGen = genGroups.get(gen) || [];
    const yPos = startY + genIndex * (nodeHeight + verticalGap);

    // Group spouses side-by-side in same generation
    const placedMemberIds = new Set<string>();
    const rowUnits: { primary: Member; spouse?: Member }[] = [];

    membersInGen.forEach((m) => {
      if (placedMemberIds.has(m.id)) return;

      // Check if this member has a spouse in the same generation
      const spRel = spouseRel.find(
        (r) => r.memberAId === m.id || r.memberBId === m.id
      );

      let spouseMember: Member | undefined;
      if (spRel) {
        const spouseId = spRel.memberAId === m.id ? spRel.memberBId : spRel.memberAId;
        spouseMember = membersInGen.find((other) => other.id === spouseId);
      }

      if (spouseMember && !placedMemberIds.has(spouseMember.id)) {
        // Direct Nzala first, spouse second
        const isNzalaA = m.familyType === 'NZALA_DIRECT';
        const primary = isNzalaA ? m : spouseMember;
        const spouse = isNzalaA ? spouseMember : m;

        rowUnits.push({ primary, spouse });
        placedMemberIds.add(primary.id);
        placedMemberIds.add(spouse.id);
      } else {
        rowUnits.push({ primary: m });
        placedMemberIds.add(m.id);
      }
    });

    // Calculate total width of this row
    let currentX = 60;
    rowUnits.forEach((unit) => {
      const unitWidth = unit.spouse ? nodeWidth * 2 + 20 : nodeWidth;

      // Place primary
      const primaryNode: TreeNode = {
        id: unit.primary.id,
        member: unit.primary,
        x: currentX,
        y: yPos,
        width: nodeWidth,
        height: nodeHeight,
        generation: gen,
        isDirectNzala: unit.primary.familyType === 'NZALA_DIRECT',
        parentIds: relationships
          .filter((r) => r.relationshipType === 'PARENT_ENFANT' && r.memberBId === unit.primary.id && r.status === 'VALIDEE')
          .map((r) => r.memberAId),
        childrenIds: relationships
          .filter((r) => r.relationshipType === 'PARENT_ENFANT' && r.memberAId === unit.primary.id && r.status === 'VALIDEE')
          .map((r) => r.memberBId),
        spouseIds: relationships
          .filter((r) => r.relationshipType === 'CONJOINT' && (r.memberAId === unit.primary.id || r.memberBId === unit.primary.id) && r.status === 'VALIDEE')
          .map((r) => (r.memberAId === unit.primary.id ? r.memberBId : r.memberAId)),
        siblingIds: relationships
          .filter((r) => r.relationshipType === 'FRERE_SOEUR' && (r.memberAId === unit.primary.id || r.memberBId === unit.primary.id) && r.status === 'VALIDEE')
          .map((r) => (r.memberAId === unit.primary.id ? r.memberBId : r.memberAId)),
      };
      nodes.push(primaryNode);
      nodeMap.set(primaryNode.id, primaryNode);

      if (unit.spouse) {
        const spouseNode: TreeNode = {
          id: unit.spouse.id,
          member: unit.spouse,
          x: currentX + nodeWidth + 20,
          y: yPos,
          width: nodeWidth,
          height: nodeHeight,
          generation: gen,
          isDirectNzala: unit.spouse.familyType === 'NZALA_DIRECT',
          parentIds: relationships
            .filter((r) => r.relationshipType === 'PARENT_ENFANT' && r.memberBId === unit.spouse!.id && r.status === 'VALIDEE')
            .map((r) => r.memberAId),
          childrenIds: relationships
            .filter((r) => r.relationshipType === 'PARENT_ENFANT' && r.memberAId === unit.spouse!.id && r.status === 'VALIDEE')
            .map((r) => r.memberBId),
          spouseIds: [unit.primary.id],
          siblingIds: [],
        };
        nodes.push(spouseNode);
        nodeMap.set(spouseNode.id, spouseNode);
      }

      currentX += unitWidth + horizontalGap;
    });

    if (currentX > maxRowWidth) {
      maxRowWidth = currentX;
    }
  });

  // Generate links with smooth Bézier curves
  const links: TreeLink[] = [];

  // 1. Parent -> Child Links
  parentChildRel.forEach((r) => {
    const parentNode = nodeMap.get(r.memberAId);
    const childNode = nodeMap.get(r.memberBId);

    if (parentNode && childNode) {
      const sourceX = parentNode.x + parentNode.width / 2;
      const sourceY = parentNode.y + parentNode.height;
      const targetX = childNode.x + childNode.width / 2;
      const targetY = childNode.y;

      const midY = (sourceY + targetY) / 2;
      // Cubic Bézier curve
      const path = `M ${sourceX} ${sourceY} C ${sourceX} ${midY}, ${targetX} ${midY}, ${targetX} ${targetY}`;

      links.push({
        id: `link-pc-${r.id}`,
        sourceId: parentNode.id,
        targetId: childNode.id,
        type: 'PARENT_ENFANT',
        path,
        label: 'Filiation',
        isAlliance: false,
      });
    }
  });

  // 2. Spouse <-> Spouse Links
  spouseRel.forEach((r) => {
    const nodeA = nodeMap.get(r.memberAId);
    const nodeB = nodeMap.get(r.memberBId);

    if (nodeA && nodeB) {
      // Connect horizontal sides
      const isALeft = nodeA.x < nodeB.x;
      const sourceX = isALeft ? nodeA.x + nodeA.width : nodeA.x;
      const sourceY = nodeA.y + nodeA.height / 2;
      const targetX = isALeft ? nodeB.x : nodeB.x + nodeB.width;
      const targetY = nodeB.y + nodeB.height / 2;

      const path = `M ${sourceX} ${sourceY} L ${targetX} ${targetY}`;

      links.push({
        id: `link-sp-${r.id}`,
        sourceId: nodeA.id,
        targetId: nodeB.id,
        type: 'CONJOINT',
        path,
        label: 'Alliance / Mariage',
        isAlliance: true,
      });
    }
  });

  const totalWidth = Math.max(maxRowWidth + 120, 1200);
  const totalHeight = Math.max(
    distinctGens.length * (nodeHeight + verticalGap) + 160,
    700
  );

  return {
    nodes,
    links,
    width: totalWidth,
    height: totalHeight,
    generations: distinctGens,
    bounds: { minX: 0, maxX: totalWidth, minY: 0, maxY: totalHeight },
  };
};

/**
 * Computes the "Around Me / Close Family" subgraph for a specific member up to a configurable depth (1, 2, 3)
 */
export const getAroundMeNetwork = (
  targetMemberId: string,
  depth: number,
  members: Member[],
  relationships: Relationship[]
): {
  targetMember: Member | undefined;
  relativeNodes: { member: Member; depth: number; relationToTarget: string; category: 'PARENTS' | 'CHILDREN' | 'SPOUSE' | 'SIBLING' | 'EXTENDED' }[];
  relationships: Relationship[];
} => {
  const targetMember = members.find((m) => m.id === targetMemberId);
  if (!targetMember) {
    return { targetMember: undefined, relativeNodes: [], relationships: [] };
  }

  const validRels = relationships.filter((r) => r.status === 'VALIDEE');
  const visited = new Map<string, number>(); // memberId -> min depth
  const relationLabels = new Map<string, { label: string; category: 'PARENTS' | 'CHILDREN' | 'SPOUSE' | 'SIBLING' | 'EXTENDED' }>();

  visited.set(targetMemberId, 0);

  // BFS Queue
  const queue: { memberId: string; currentDepth: number }[] = [{ memberId: targetMemberId, currentDepth: 0 }];

  while (queue.length > 0) {
    const { memberId, currentDepth } = queue.shift()!;
    if (currentDepth >= depth) continue;

    const adjacentRels = validRels.filter(
      (r) => r.memberAId === memberId || r.memberBId === memberId
    );

    adjacentRels.forEach((rel) => {
      const otherId = rel.memberAId === memberId ? rel.memberBId : rel.memberAId;
      const isMemberA = rel.memberAId === memberId;

      if (!visited.has(otherId) || visited.get(otherId)! > currentDepth + 1) {
        visited.set(otherId, currentDepth + 1);

        // Determine category & label relative to target if direct (depth 1) or secondary
        let category: 'PARENTS' | 'CHILDREN' | 'SPOUSE' | 'SIBLING' | 'EXTENDED' = 'EXTENDED';
        let label = 'Parenté';

        if (currentDepth === 0) {
          if (rel.relationshipType === 'PARENT_ENFANT') {
            if (isMemberA) {
              category = 'CHILDREN';
              label = 'Enfant direct';
            } else {
              category = 'PARENTS';
              label = 'Parent direct';
            }
          } else if (rel.relationshipType === 'CONJOINT') {
            category = 'SPOUSE';
            label = 'Conjoint(e)';
          } else if (rel.relationshipType === 'FRERE_SOEUR') {
            category = 'SIBLING';
            label = 'Frère / Sœur';
          }
        } else if (currentDepth === 1) {
          if (rel.relationshipType === 'PARENT_ENFANT') {
            category = 'EXTENDED';
            label = isMemberA ? 'Petit-enfant' : 'Grand-parent';
          } else {
            category = 'EXTENDED';
            label = 'Parenté proche (Niveau 2)';
          }
        } else {
          category = 'EXTENDED';
          label = 'Réseau familial élargi (Niveau 3)';
        }

        relationLabels.set(otherId, { label, category });
        queue.push({ memberId: otherId, currentDepth: currentDepth + 1 });
      }
    });
  }

  const relativeNodes = Array.from(visited.entries())
    .filter(([id]) => id !== targetMemberId)
    .map(([id, d]) => {
      const member = members.find((m) => m.id === id)!;
      const relInfo = relationLabels.get(id) || { label: 'Parenté', category: 'EXTENDED' as const };
      return {
        member,
        depth: d,
        relationToTarget: relInfo.label,
        category: relInfo.category,
      };
    })
    .filter((item) => !!item.member);

  const includedIds = new Set(Array.from(visited.keys()));
  const includedRels = validRels.filter(
    (r) => includedIds.has(r.memberAId) && includedIds.has(r.memberBId)
  );

  return {
    targetMember,
    relativeNodes,
    relationships: includedRels,
  };
};

/**
 * Validates genealogical consistency across the entire database to catch cycles, self-links, and anomalies
 */
export const auditGenealogicalConsistency = (
  members: Member[],
  relationships: Relationship[]
): GenealogicalConsistencyIssue[] => {
  const issues: GenealogicalConsistencyIssue[] = [];

  // 1. Self links
  relationships.forEach((r) => {
    if (r.memberAId === r.memberBId) {
      issues.push({
        id: `self-link-${r.id}`,
        severity: 'ERROR',
        type: 'SELF_LINK',
        message: `Relation impossible : Une personne (${r.memberAName || r.memberAId}) est liée à elle-même.`,
        memberIds: [r.memberAId],
      });
    }
  });

  // 2. Duplicate active relationships
  const seenPairs = new Set<string>();
  relationships.forEach((r) => {
    if (r.status === 'REFUSEE') return;
    const pairKey = [r.memberAId, r.memberBId, r.relationshipType].sort().join('|');
    if (seenPairs.has(pairKey)) {
      issues.push({
        id: `dup-${r.id}`,
        severity: 'WARNING',
        type: 'DUPLICATE',
        message: `Doublon détecté : relation ${r.relationshipType} en double entre deux personnes.`,
        memberIds: [r.memberAId, r.memberBId],
      });
    }
    seenPairs.add(pairKey);
  });

  // 3. Generation inconsistencies (Parent in higher or equal generation than child)
  const validParentChild = relationships.filter(
    (r) => r.relationshipType === 'PARENT_ENFANT' && r.status === 'VALIDEE'
  );

  validParentChild.forEach((r) => {
    const parent = members.find((m) => m.id === r.memberAId);
    const child = members.find((m) => m.id === r.memberBId);

    if (parent && child && parent.generationLevel && child.generationLevel) {
      if (parent.generationLevel >= child.generationLevel) {
        issues.push({
          id: `gen-gap-${r.id}`,
          severity: 'WARNING',
          type: 'GENERATION_GAP',
          message: `Incohérence générationnelle : ${parent.firstName} (G${parent.generationLevel}) est déclaré parent de ${child.firstName} (G${child.generationLevel}).`,
          memberIds: [parent.id, child.id],
        });
      }
    }

    // Birth dates check
    if (parent?.birthDate && child?.birthDate) {
      const birthP = new Date(parent.birthDate).getFullYear();
      const birthC = new Date(child.birthDate).getFullYear();
      if (!isNaN(birthP) && !isNaN(birthC) && birthP >= birthC) {
        issues.push({
          id: `date-anom-${r.id}`,
          severity: 'ERROR',
          type: 'DATE_ANOMALY',
          message: `Anomalie chronologique : ${parent.firstName} (${birthP}) est né après son enfant ${child.firstName} (${birthC}).`,
          memberIds: [parent.id, child.id],
        });
      }
    }
  });

  return issues;
};
