import { MediaItem, MediaType, LinkPreview, FamilyAudioTrack } from '../types';
import { GlobalMediaService } from './production/storage';

/**
 * Interface d'abstraction MediaStorage.
 * Permet de découpler la logique métier du stockage sous-jacent
 * (LocalStorage / Blob / Firebase Storage / Google Cloud Storage / AWS S3).
 */
export interface IMediaStorageService {
  uploadFile: (
    file: File,
    caption?: string,
    onProgress?: (percent: number) => void
  ) => Promise<MediaItem>;
  validateFile: (file: File) => { isValid: boolean; error?: string };
  generateLinkPreview: (url: string) => Promise<LinkPreview>;
}

// Limites de taille configurables
export const MAX_IMAGE_SIZE_BYTES = 15 * 1024 * 1024; // 15 Mo
export const MAX_VIDEO_SIZE_BYTES = 100 * 1024 * 1024; // 100 Mo
export const MAX_AUDIO_SIZE_BYTES = 30 * 1024 * 1024; // 30 Mo
export const MAX_DOCUMENT_SIZE_BYTES = 50 * 1024 * 1024; // 50 Mo
export const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
export const ALLOWED_VIDEO_TYPES = ['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime'];
export const ALLOWED_AUDIO_TYPES = ['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/ogg', 'audio/m4a', 'audio/webm'];
export const ALLOWED_DOC_TYPES = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'text/plain',
];

/**
 * Validation des fichiers multimédias & documents
 */
export function validateMediaFile(file: File): { isValid: boolean; error?: string } {
  if (!file) {
    return { isValid: false, error: 'Fichier absent.' };
  }

  const isImage = ALLOWED_IMAGE_TYPES.includes(file.type);
  const isVideo = ALLOWED_VIDEO_TYPES.includes(file.type);
  const isAudio = ALLOWED_AUDIO_TYPES.includes(file.type) || file.type.startsWith('audio/');
  const isDoc = ALLOWED_DOC_TYPES.includes(file.type) || file.name.match(/\.(pdf|docx?|xlsx?|pptx?|txt)$/i);

  if (!isImage && !isVideo && !isAudio && !isDoc) {
    return {
      isValid: false,
      error: `Format non supporté (${file.type}). Formats acceptés : Images (JPG, PNG, WEBP), Vidéos (MP4, WEBM), Audio (MP3, WAV, M4A), Documents (PDF, Word, Excel, PPT, TXT).`,
    };
  }

  if (isImage && file.size > MAX_IMAGE_SIZE_BYTES) {
    return {
      isValid: false,
      error: `L'image dépasse la taille maximale de 15 Mo (${(file.size / (1024 * 1024)).toFixed(1)} Mo).`,
    };
  }

  if (isVideo && file.size > MAX_VIDEO_SIZE_BYTES) {
    return {
      isValid: false,
      error: `La vidéo dépasse la taille maximale de 100 Mo (${(file.size / (1024 * 1024)).toFixed(1)} Mo).`,
    };
  }

  if (isAudio && file.size > MAX_AUDIO_SIZE_BYTES) {
    return {
      isValid: false,
      error: `L'audio dépasse la taille maximale de 30 Mo (${(file.size / (1024 * 1024)).toFixed(1)} Mo).`,
    };
  }

  if (isDoc && file.size > MAX_DOCUMENT_SIZE_BYTES) {
    return {
      isValid: false,
      error: `Le document dépasse la taille maximale de 50 Mo (${(file.size / (1024 * 1024)).toFixed(1)} Mo).`,
    };
  }

  return { isValid: true };
}

/**
 * Abstraction du service de stockage multimédia connectée au pipeline Cloud Storage réel.
 */
class MediaStorageService implements IMediaStorageService {
  /**
   * Téléverse un fichier via le pipeline unifié MediaService avec extraction de métadonnées
   */
  async uploadFile(
    file: File,
    caption?: string,
    onProgress?: (percent: number) => void
  ): Promise<MediaItem> {
    const isVideo = file.type.startsWith('video/');
    const isAudio = file.type.startsWith('audio/');
    
    let category: 'POST_IMAGE' | 'POST_VIDEO' | 'VOICE_NOTE' = 'POST_IMAGE';
    if (isVideo) category = 'POST_VIDEO';
    else if (isAudio) category = 'VOICE_NOTE';

    return GlobalMediaService.uploadMedia(file, {
      category,
      ownerId: 'current-user',
      customFileName: caption || file.name,
      onProgress,
    });
  }

  validateFile(file: File) {
    return validateMediaFile(file);
  }

  /**
   * Génération / extraction sécurisée d'un aperçu de lien web.
   */
  async generateLinkPreview(url: string): Promise<LinkPreview> {
    return GlobalMediaService.generateLinkPreview(url);
  }
}

export const MediaStorage = new MediaStorageService();

/**
 * Galerie de médias de démonstration pour NzalaFamilly
 */
export const CURATED_FAMILY_MEDIA = {
  reunions: [
    {
      id: 'demo-media-1',
      type: 'IMAGE' as const,
      url: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=1000&auto=format&fit=crop&q=80',
      caption: 'Retrouvailles de la Branche Ngaliema et nos cousins à Kinshasa',
      mimeType: 'image/jpeg',
    },
    {
      id: 'demo-media-2',
      type: 'IMAGE' as const,
      url: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=1000&auto=format&fit=crop&q=80',
      caption: 'Table d\'honneur lors du repas familial des aînés',
      mimeType: 'image/jpeg',
    },
    {
      id: 'demo-media-3',
      type: 'IMAGE' as const,
      url: 'https://images.unsplash.com/photo-1543807535-eceef0bc6599?w=1000&auto=format&fit=crop&q=80',
      caption: 'Photo de famille inter-générationnelle (G2, G3 et G4)',
      mimeType: 'image/jpeg',
    },
  ],
  ceremonies: [
    {
      id: 'demo-media-4',
      type: 'IMAGE' as const,
      url: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=1000&auto=format&fit=crop&q=80',
      caption: 'Célébration du pacte d\'alliance Nzala - Lukoki',
      mimeType: 'image/jpeg',
    },
    {
      id: 'demo-media-5',
      type: 'IMAGE' as const,
      url: 'https://images.unsplash.com/photo-1469371670807-013ccf25f16a?w=1000&auto=format&fit=crop&q=80',
      caption: 'Accueil traditionnel des familles alliées',
      mimeType: 'image/jpeg',
    },
  ],
  archives: [
    {
      id: 'demo-media-6',
      type: 'IMAGE' as const,
      url: 'https://images.unsplash.com/photo-1461360370896-922624d12aa1?w=1000&auto=format&fit=crop&q=80',
      caption: 'Archives familiales : Manuscrits et registres de Boma (1955)',
      mimeType: 'image/jpeg',
    },
  ],
  videoArchives: [
    {
      id: 'demo-video-1',
      type: 'VIDEO' as const,
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=800&auto=format&fit=crop&q=80',
      caption: 'Extrait du discours d\'ouverture du doyen Jean-Pierre Nzala lors de la convention annuelle',
      mimeType: 'video/mp4',
      duration: 15,
    },
  ],
};

export const CURATED_FAMILY_AUDIO_TRACKS: FamilyAudioTrack[] = [
  {
    id: 'audio-trad-1',
    title: 'Chant Ancestral & Bénédiction de la Lignée',
    artistOrTradition: 'Patrimoine Oral Nzala',
    category: 'TRADITIONNEL' as const,
    url: 'https://cdn.freesound.org/previews/530/530669_11524891-lq.mp3',
    durationSec: 42,
  },
  {
    id: 'audio-celeb-2',
    title: 'Rumba & Célébration Familiale',
    artistOrTradition: 'Ambiance de Fête & Mariage',
    category: 'CELEBRATION' as const,
    url: 'https://cdn.freesound.org/previews/476/476178_9497060-lq.mp3',
    durationSec: 36,
  },
  {
    id: 'audio-memo-3',
    title: 'Douceur & Hommage aux Aînés',
    artistOrTradition: 'Méditation & Mémoire',
    category: 'MEMOIRE' as const,
    url: 'https://cdn.freesound.org/previews/518/518887_11270503-lq.mp3',
    durationSec: 48,
  },
  {
    id: 'audio-tamtam-4',
    title: 'Rythmes de Tam-tams & Ralliement',
    artistOrTradition: 'Traditions du Fleuve & Bakongo',
    category: 'TRADITIONNEL' as const,
    url: 'https://cdn.freesound.org/previews/567/567210_11861866-lq.mp3',
    durationSec: 30,
  },
];
