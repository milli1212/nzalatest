/**
 * NzalaFamilly - Service Métier & Abstraction pour NZALA MESSAGES
 * Conçu pour fonctionner en local avec localStorage et prêt pour intégration WebSocket / Firebase
 */

import {
  FamilyConversation,
  FamilyMessage,
  UserPresence,
  BlockedContact,
  MessageReaction,
  MessageDeliveryStatus,
  MessageMediaType,
  MessageReport,
  MessageReportReason,
  ConversationParticipant,
} from '../types/messaging';
import { UserAccount, UserRole, CurrentUser } from '../types';

export class MessagingService {
  /**
   * Vérifie si un utilisateur est strictement autorisé à voir et participer à une conversation.
   * Règle absolue de sécurité et de confidentialité :
   * - Le Conseil de Famille est strictement confidentiel (SUPER_ADMIN, ADMIN_FAMILIAL ou participants explicites).
   * - Une conversation directe requiert d'être dans les participants.
   * - Une conversation de groupe requiert d'être dans les participants.
   */
  static canUserAccessConversation(
    userOrId: UserAccount | CurrentUser | string,
    conversation: FamilyConversation,
    roleOverride?: UserRole
  ): boolean {
    if (!conversation) return false;

    let userId = '';
    let userRole: UserRole | undefined = roleOverride;

    if (typeof userOrId === 'string') {
      userId = userOrId;
    } else if (userOrId) {
      userId = userOrId.id;
      userRole = userRole || userOrId.role;
    }

    if (!userId || userRole === 'VISITEUR') {
      return false;
    }

    const participantIds = conversation.participantIds || conversation.participants.map((p) => p.userId);

    // Règle stricte pour le Conseil de Famille
    if (conversation.isCouncilGroup) {
      const isCouncilMember =
        userRole === 'SUPER_ADMIN' ||
        userRole === 'ADMIN_FAMILIAL' ||
        participantIds.includes(userId);
      return isCouncilMember;
    }

    // Conversation directe : doit être explicitement l'un des participants
    if (conversation.type === 'DIRECT') {
      return participantIds.includes(userId);
    }

    // Conversation de groupe : doit être membre de la liste des participants
    return participantIds.includes(userId);
  }

  /**
   * Récupère la liste filtrée et triée des conversations autorisées pour un utilisateur.
   */
  static getVisibleConversations(
    user: UserAccount | CurrentUser,
    conversations: FamilyConversation[],
    blockedContacts: BlockedContact[] = []
  ): FamilyConversation[] {
    const blockedUserIds = new Set(
      blockedContacts.filter((b) => b.userId === user.id).map((b) => b.blockedUserId)
    );

    return conversations
      .filter((conv) => {
        // Filtrer les conversations non autorisées
        if (!this.canUserAccessConversation(user, conv)) return false;

        // Si direct avec un utilisateur bloqué, masquer ou marquer
        if (conv.type === 'DIRECT') {
          const participantIds = conv.participantIds || conv.participants.map((p) => p.userId);
          const otherParticipantId = participantIds.find((id) => id !== user.id);
          if (otherParticipantId && blockedUserIds.has(otherParticipantId)) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        // Épinglés en premier, puis tri par date du dernier message / mise à jour descendante
        if (a.isPinned && !b.isPinned) return -1;
        if (!a.isPinned && b.isPinned) return 1;
        const timeA = a.lastMessage?.createdAt || a.updatedAt || a.createdAt;
        const timeB = b.lastMessage?.createdAt || b.updatedAt || b.createdAt;
        return new Date(timeB).getTime() - new Date(timeA).getTime();
      });
  }

  /**
   * Calcule le nombre total de messages non lus pour l'utilisateur.
   */
  static getTotalUnreadCount(conversations: FamilyConversation[], userId: string): number {
    return conversations.reduce((total, conv) => {
      const participant = conv.participants.find((p) => p.userId === userId);
      return total + (participant?.unreadCount || 0);
    }, 0);
  }

  /**
   * Obtient le titre d'affichage pour une conversation (nom de l'interlocuteur pour un direct, titre pour un groupe).
   */
  static getConversationTitle(conversation: FamilyConversation, currentUserId: string): string {
    if (conversation.type === 'GROUP') {
      return conversation.title || 'Groupe sans nom';
    }

    const otherParticipant = conversation.participants.find((p) => p.userId !== currentUserId);
    return otherParticipant?.userName || 'Membre Nzala';
  }

  /**
   * Obtient l'avatar d'affichage pour une conversation.
   */
  static getConversationAvatar(
    conversation: FamilyConversation,
    currentUserId: string
  ): string | undefined {
    if (conversation.type === 'GROUP') {
      return conversation.avatarUrl;
    }

    const otherParticipant = conversation.participants.find((p) => p.userId !== currentUserId);
    return otherParticipant?.userAvatar;
  }

  /**
   * Obtient le statut ou sous-titre de la conversation (présence en ligne, rôle, etc.).
   */
  static getConversationSubtitle(
    conversation: FamilyConversation,
    currentUserId: string,
    presences: UserPresence[]
  ): string {
    if (conversation.type === 'GROUP') {
      const count = conversation.participantIds.length;
      const adminNames = conversation.participants
        .filter((p) => conversation.admins.includes(p.userId))
        .map((p) => p.userName)
        .slice(0, 2)
        .join(', ');

      if (conversation.relatedBranchName) {
        return `${count} participants • ${conversation.relatedBranchName}`;
      }
      if (conversation.relatedAlliedFamilyName) {
        return `${count} participants • ${conversation.relatedAlliedFamilyName}`;
      }
      return `${count} participants ${adminNames ? `• Admin : ${adminNames}` : ''}`;
    }

    const otherParticipant = conversation.participants.find((p) => p.userId !== currentUserId);
    if (!otherParticipant) return '';

    const presence = presences.find((pr) => pr.userId === otherParticipant.userId);
    if (!presence || !presence.showOnlineStatus) {
      return otherParticipant.familyName || 'Membre de la famille';
    }

    if (presence.status === 'EN_LIGNE') {
      return 'En ligne';
    }

    if (presence.lastSeen) {
      return `Vu ${this.formatRelativeTime(presence.lastSeen)}`;
    }

    return presence.customStatusText || otherParticipant.familyName || 'Hors ligne';
  }

  /**
   * Vérifie si un participant de la conversation est actuellement en ligne.
   */
  static isConversationOnline(
    conversation: FamilyConversation,
    currentUserId: string,
    presences: UserPresence[]
  ): boolean {
    if (conversation.type === 'DIRECT') {
      const otherParticipant = conversation.participants.find((p) => p.userId !== currentUserId);
      if (!otherParticipant) return false;
      const presence = presences.find((pr) => pr.userId === otherParticipant.userId);
      return presence?.status === 'EN_LIGNE';
    }
    return conversation.participants.some((p) => {
      if (p.userId === currentUserId) return false;
      const pr = presences.find((prs) => prs.userId === p.userId);
      return pr?.status === 'EN_LIGNE';
    });
  }

  /**
   * Formate une date relative (ex: "il y a 5 min", "hier", "14:30")
   */
  static formatRelativeTime(isoString: string): string {
    try {
      const date = new Date(isoString);
      const now = new Date();
      const diffMs = now.getTime() - date.getTime();
      const diffSec = Math.floor(diffMs / 1000);
      const diffMin = Math.floor(diffSec / 60);
      const diffHours = Math.floor(diffMin / 60);
      const diffDays = Math.floor(diffHours / 24);

      if (diffSec < 60) return "À l'instant";
      if (diffMin < 60) return `Il y a ${diffMin} min`;
      if (diffHours < 24 && date.getDate() === now.getDate()) {
        return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
      }
      if (diffDays === 1) return 'Hier';
      if (diffDays < 7) {
        return date.toLocaleDateString('fr-FR', { weekday: 'short' });
      }
      return date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
    } catch {
      return '';
    }
  }

  /**
   * Formate l'heure exacte d'un message (ex: "14:35")
   */
  static formatMessageTime(isoString: string): string {
    try {
      const date = new Date(isoString);
      return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '';
    }
  }

  /**
   * Formate la date de séparation de groupe de messages (ex: "Aujourd'hui", "Hier", "15 août 2026")
   */
  static formatDateSeparator(isoString: string): string {
    try {
      const date = new Date(isoString);
      const now = new Date();
      const yesterday = new Date(now);
      yesterday.setDate(now.getDate() - 1);

      if (date.toDateString() === now.toDateString()) {
        return "Aujourd'hui";
      }
      if (date.toDateString() === yesterday.toDateString()) {
        return 'Hier';
      }
      return date.toLocaleDateString('fr-FR', {
        day: 'numeric',
        month: 'long',
        year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined,
      });
    } catch {
      return '';
    }
  }

  /**
   * Formate la taille d'un fichier en Ko / Mo
   */
  static formatFileSize(bytes?: number): string {
    if (!bytes) return '';
    if (bytes < 1024) return `${bytes} o`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} Ko`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} Mo`;
  }

  /**
   * Formate une durée en secondes (ex: "0:18" ou "2:45")
   */
  static formatDuration(seconds?: number): string {
    if (!seconds) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  }

  /**
   * Recherche de messages dans une conversation ou globalement
   */
  static searchMessages(
    messages: FamilyMessage[],
    query: string,
    conversationId?: string
  ): FamilyMessage[] {
    if (!query.trim()) return [];
    const q = query.toLowerCase().trim();

    return messages.filter((msg) => {
      if (conversationId && msg.conversationId !== conversationId) return false;
      if (msg.isDeleted) return false;

      const inContent = msg.content.toLowerCase().includes(q);
      const inSender = msg.senderName.toLowerCase().includes(q);
      const inAttachments = msg.attachments?.some(
        (a) => a.fileName?.toLowerCase().includes(q) || a.caption?.toLowerCase().includes(q)
      );
      const inSharedPost = msg.sharedPost?.title?.toLowerCase().includes(q) || msg.sharedPost?.content.toLowerCase().includes(q);
      const inSharedEvent = msg.sharedEvent?.title.toLowerCase().includes(q);

      return inContent || inSender || inAttachments || inSharedPost || inSharedEvent;
    });
  }

  /**
   * Validation d'un fichier joint (taille max 25 Mo, types autorisés)
   */
  static validateFileAttachment(file: { name: string; size: number; type: string }): {
    valid: boolean;
    error?: string;
  } {
    const MAX_SIZE = 25 * 1024 * 1024; // 25 Mo
    if (file.size > MAX_SIZE) {
      return { valid: false, error: 'Le fichier dépasse la taille maximale autorisée (25 Mo).' };
    }

    const dangerousExtensions = ['.exe', '.bat', '.cmd', '.sh', '.vbs', '.js', '.scr'];
    const lowerName = file.name.toLowerCase();
    if (dangerousExtensions.some((ext) => lowerName.endsWith(ext))) {
      return { valid: false, error: 'Ce type de fichier exécutable n’est pas autorisé pour des raisons de sécurité.' };
    }

    return { valid: true };
  }
}
