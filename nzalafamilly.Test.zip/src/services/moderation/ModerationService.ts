/**
 * NzalaFamilly - Service de Modération Unifiée & Signalements (NZALA MODERATION)
 * Gère les signalements sociaux, la file d'examen et l'intégration AuditLog
 */

import { SocialReport, ReportCategory, ReportTargetType } from '../../types/moderation';

export class ModerationService {
  /**
   * Signalements de départ pour l'administration et la démonstration
   */
  public static getInitialReports(): SocialReport[] {
    return [
      {
        id: 'rep-1',
        reporterId: 'usr-clotilde',
        reporterName: 'Maman Clotilde Nzala',
        targetType: 'PUBLICATION',
        targetId: 'post-demo-spam',
        targetTitle: 'Publication promotionnelle externe',
        reportedUserId: 'usr-temp-1',
        reportedUserName: 'Invité Non Validé',
        category: 'SPAM',
        description: 'Lien commercial non sollicité publié dans le fil communautaire.',
        status: 'EN_ATTENTE',
        createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
      },
    ];
  }

  /**
   * Libellé en français des catégories de signalement
   */
  public static getCategoryLabel(category: ReportCategory): string {
    switch (category) {
      case 'SPAM':
        return 'Spam ou publicité abusive';
      case 'COMPORTEMENT_ABUSIF':
        return 'Comportement abusif ou harcèlement';
      case 'CONTENU_INAPPROPRIE':
        return 'Contenu inapproprié ou non conforme';
      case 'USURPATION':
        return 'Usurpation d’identité ou faux profil';
      case 'AUTRE':
      default:
        return 'Autre motif légitime';
    }
  }

  /**
   * Libellé en français du type de cible
   */
  public static getTargetTypeLabel(type: ReportTargetType): string {
    switch (type) {
      case 'MEMBRE':
        return 'Profil Membre';
      case 'PUBLICATION':
        return 'Publication Fil Familial';
      case 'COMMENTAIRE':
        return 'Commentaire';
      case 'STORY':
        return 'Story Familiale';
      case 'MESSAGE':
        return 'Message Privé';
      case 'GROUPE':
        return 'Groupe de Discussion';
      default:
        return 'Élément';
    }
  }
}
