/**
 * NzalaFamilly - Service Centralisé & Intelligent des Notifications (NZALA NOTIFICATION SERVICE)
 * Gère la création, le formatage, le filtrage, le regroupement et les actions directes
 */

import {
  FamilyNotification,
  NotificationCategory,
  NotificationPreferences,
  NotificationType,
  NotificationTargetType,
  NotificationMetadata,
} from '../../types/notifications';
import { UserRole } from '../../types';

export interface GroupedNotification {
  id: string;
  category: NotificationCategory;
  type: NotificationType;
  title: string;
  body: string;
  targetId?: string;
  targetType?: NotificationTargetType;
  senderId?: string;
  senderName?: string;
  senderAvatar?: string;
  senderVerifiedBadge?: string;
  senderRole?: string;
  read: boolean;
  createdAt: string;
  linkTab?: string;
  actionUrl?: string;
  thumbnailUrl?: string;
  metadata?: NotificationMetadata;
  itemsCount: number;
  rawNotifications: FamilyNotification[];
}

export class NotificationService {
  public static readonly DEFAULT_PREFERENCES: NotificationPreferences = {
    messages: true,
    stories: true,
    publications: true,
    events: true,
    birthdays: true,
    calls: true,
    governance: true,
    security: true,
    system: true,
    soundEnabled: true,
    pushEnabled: false,
  };

  /**
   * Associe chaque type de notification à sa catégorie principale
   */
  public static getCategoryForType(type: NotificationType): NotificationCategory {
    switch (type) {
      case 'REACTION':
      case 'COMMENTAIRE':
      case 'REPONSE_COMMENTAIRE':
      case 'MENTION':
      case 'PARTAGE':
      case 'NOUVELLE_PUBLICATION':
      case 'NEW_COMMENT':
      case 'NEW_REACTION':
      case 'PUBLICATION':
      case 'POST_PUBLISHED':
        return 'SOCIAL';

      case 'STORY_REACTION':
      case 'STORY_REPLY':
      case 'STORY_MENTION':
      case 'STORY':
        return 'STORIES';

      case 'MESSAGE':
      case 'MESSAGE_AUDIO':
      case 'MESSAGE_MEDIA':
      case 'MESSAGE_VUE_UNIQUE':
      case 'INVITATION_GROUPE':
      case 'APPEL_ENTRANT':
      case 'APPEL_MANQUE':
        return 'MESSAGES';

      case 'DEMANDE_ACCES_PROFIL':
      case 'ACCES_PROFIL_ACCEPTE':
      case 'ACCES_PROFIL_REFUSE':
      case 'ACCES_PROFIL_RETIRE':
      case 'AFFILIATION_DOSSIER_RECU':
      case 'AFFILIATION_EN_EXAMEN':
      case 'AFFILIATION_COMPLEMENT':
      case 'AFFILIATION_APPROUVEE':
      case 'AFFILIATION_REFUSEE':
      case 'AFFILIATION_SUSPENDUE':
      case 'AFFILIATION':
      case 'ARBRE_MODIFIE':
        return 'FAMILY';

      case 'EVENEMENT_INVITATION':
      case 'EVENEMENT_RAPPEL':
      case 'EVENEMENT_MODIFIE':
      case 'EVENEMENT_ANNULE':
      case 'EVENEMENT_RSVP':
      case 'EVENEMENT':
      case 'ANNIVERSAIRE_JOUR':
      case 'ANNIVERSAIRE_AVENIR':
      case 'ANNIVERSAIRE':
        return 'EVENTS';

      case 'LIVE_PROGRAMME':
      case 'LIVE_BIENTOT':
      case 'LIVE_EN_COURS':
      case 'LIVE_INVITATION':
        return 'LIVE';

      case 'ADMIN_NOUVELLE_AFFILIATION':
      case 'ADMIN_DOSSIER_EXAMEN':
      case 'ADMIN_MODERATION_POST':
      case 'ADMIN_SIGNALEMENT':
      case 'ADMIN_TICKET_TECHNIQUE':
      case 'ADMIN_CERTIFICATION':
      case 'GOUVERNANCE':
      case 'MODERATION_UPDATE':
      case 'COUNCIL_ANNOUNCEMENT':
        return 'ADMIN';

      case 'SECURITE_CONNEXION':
      case 'SECURITE_MOT_DE_PASSE':
      case 'SECURITE_PARAMETRES':
      case 'SECURITE_2FA':
      case 'SECURITE_ALERTE':
        return 'SECURITY';

      case 'SYSTEME_COMMUNIQUE':
      case 'SYSTEME_MAINTENANCE':
      case 'SYSTEME_MISE_A_JOUR':
      case 'OFFICIAL_COMMUNIQUE':
      default:
        return 'SYSTEM';
    }
  }

  /**
   * Génère la base de notifications initiales de démonstration ultra-complète
   */
  public static getInitialNotifications(currentUserId: string, userRole: UserRole = 'SUPER_ADMIN'): FamilyNotification[] {
    const now = new Date();
    const agoMins = (mins: number) => new Date(now.getTime() - mins * 60000).toISOString();
    const agoHours = (hrs: number) => new Date(now.getTime() - hrs * 3600000).toISOString();
    const agoDays = (days: number) => new Date(now.getTime() - days * 86400000).toISOString();

    const notifs: FamilyNotification[] = [
      // 1. LIVE EN COURS (Haute priorité)
      {
        id: 'notif-live-active',
        userId: currentUserId,
        category: 'LIVE',
        type: 'LIVE_EN_COURS',
        title: '🔴 Nzala Live en direct !',
        body: 'Patriarche Antoine Nzala a débuté le direct : « Récit des Origines et Transmission aux Jeunes »',
        targetId: 'live-recit-origines',
        targetType: 'LIVE',
        senderId: 'usr-patriarche',
        senderName: 'Patriarche Antoine Nzala',
        senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
        senderVerifiedBadge: '📜 Conseil des Sages',
        senderRole: 'CONSEIL_SAGES',
        read: false,
        createdAt: agoMins(5),
        linkTab: 'announcements',
        metadata: {
          liveScope: 'PUBLIC',
          priority: 'URGENTE',
        },
      },

      // 2. SOCIAL - RÉACTIONS REGROUPÉES
      {
        id: 'notif-react-post-grouped',
        userId: currentUserId,
        category: 'SOCIAL',
        type: 'REACTION',
        title: 'Réactions sur votre publication',
        body: 'Marie Mavungu, Honoré Nzala et 3 autres personnes ont réagi ❤️ à votre hommage historique.',
        targetId: 'post-hommage-fondateurs',
        targetType: 'POST',
        senderId: 'usr-marie-mavungu',
        senderName: 'Marie Mavungu',
        senderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
        senderVerifiedBadge: 'Alliance Mavungu',
        senderRole: 'MEMBRE_ALLIE',
        read: false,
        createdAt: agoMins(15),
        linkTab: 'announcements',
        metadata: {
          reactionType: 'LIKE',
          reactionEmoji: '❤️',
          count: 5,
          actorNames: ['Marie Mavungu', 'Honoré Nzala', 'Samuel Nzala', 'Clotilde Nzala', 'David Nzala'],
        },
      },

      // 3. MESSAGERIE - NOUVEAUX MESSAGES REGROUPÉS
      {
        id: 'notif-msg-grouped',
        userId: currentUserId,
        category: 'MESSAGES',
        type: 'MESSAGE',
        title: 'Nouveaux messages privés',
        body: 'Maman Clotilde Nzala vous a envoyé 3 nouveaux messages et un message vocal (0:38).',
        targetId: 'conv-clotilde',
        targetType: 'CONVERSATION',
        senderId: 'usr-clotilde',
        senderName: 'Maman Clotilde Nzala',
        senderAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150',
        senderVerifiedBadge: 'Doyenne de Famille',
        senderRole: 'MEMBRE_NZALA',
        read: false,
        createdAt: agoMins(25),
        linkTab: 'messages',
        metadata: {
          count: 3,
        },
      },

      // 4. SOCIAL - MENTION DANS UNE PUBLICATION
      {
        id: 'notif-mention-post',
        userId: currentUserId,
        category: 'SOCIAL',
        type: 'MENTION',
        title: 'Mention dans une publication',
        body: 'Honoré Nzala vous a mentionné dans : « Remerciements chaleureux à @Jean-Pierre pour la numérisation des archives »',
        targetId: 'post-archives-num',
        targetType: 'POST',
        senderId: 'usr-honore',
        senderName: 'Honoré Nzala',
        senderAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
        senderVerifiedBadge: 'Admin Branche Kinkanda',
        senderRole: 'ADMIN_FAMILIAL',
        read: false,
        createdAt: agoHours(1),
        linkTab: 'announcements',
      },

      // 5. STORIES - INTERACTIONS SUR STORY
      {
        id: 'notif-story-reaction',
        userId: currentUserId,
        category: 'STORIES',
        type: 'STORY_REACTION',
        title: 'Réaction à votre Story',
        body: '4 membres ont réagi 🎉 à votre Story « Préparatifs de la Rencontre Familiale »',
        targetId: 'story-prep-2026',
        targetType: 'STORY',
        senderId: 'usr-samuel',
        senderName: 'Samuel Nzala',
        senderAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150',
        senderRole: 'MEMBRE_NZALA',
        read: false,
        createdAt: agoHours(2),
        linkTab: 'announcements',
        metadata: {
          reactionEmoji: '🎉',
          count: 4,
        },
      },

      // 6. PROFILS PRIVÉS - DEMANDE D'ACCÈS AVEC ACTIONS RAPIDES
      {
        id: 'notif-profile-access-req',
        userId: currentUserId,
        category: 'FAMILY',
        type: 'DEMANDE_ACCES_PROFIL',
        title: 'Demande d’accès à votre profil privé',
        body: 'Dieudonné Mavungu (Alliance Mavungu) souhaite consulter votre fiche généalogique détaillée et coordonnées.',
        targetId: 'usr-dieudonne-mavungu',
        targetType: 'PROFILE',
        senderId: 'usr-dieudonne-mavungu',
        senderName: 'Dieudonné Mavungu',
        senderAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
        senderVerifiedBadge: 'Représentant Alliance Mavungu',
        senderRole: 'MEMBRE_ALLIE',
        read: false,
        createdAt: agoHours(3),
        linkTab: 'profile',
        metadata: {
          requestId: 'req-access-dieudonne-1',
          quickActionState: 'PENDING',
        },
      },

      // 7. ÉVÉNEMENTS - INVITATION & RAPPEL
      {
        id: 'notif-event-invitation',
        userId: currentUserId,
        category: 'EVENTS',
        type: 'EVENEMENT_INVITATION',
        title: 'Invitation à la Réunion du Conseil',
        body: 'Vous êtes convié à l’Assemblée Générale des Lignées Nzala ce dimanche 06 septembre à 15h00.',
        targetId: 'evt-conseil-sept-2026',
        targetType: 'EVENT',
        senderId: 'usr-patriarche',
        senderName: 'Patriarche Antoine Nzala',
        senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
        senderVerifiedBadge: '📜 Conseil des Sages',
        read: false,
        createdAt: agoHours(5),
        linkTab: 'events',
        metadata: {
          eventDate: '2026-09-06T15:00:00Z',
        },
      },

      // 8. ANNIVERSAIRE DU JOUR
      {
        id: 'notif-birthday-today',
        userId: currentUserId,
        category: 'EVENTS',
        type: 'ANNIVERSAIRE_JOUR',
        title: '🎂 Joyeux Anniversaire à Samuel Nzala !',
        body: 'C’est l’anniversaire de Samuel Nzala aujourd’hui ! Envoyez-lui vos bénédictions et chaleureux vœux.',
        targetId: 'mbr-samuel-nzala',
        targetType: 'PROFILE',
        senderId: 'mbr-samuel-nzala',
        senderName: 'Samuel Nzala',
        senderAvatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150',
        read: true,
        createdAt: agoDays(1),
        linkTab: 'events',
        metadata: {
          birthdayMemberName: 'Samuel Nzala',
        },
      },

      // 9. AFFILIATION - APPROBATION OFFICIELLE
      {
        id: 'notif-affiliation-approved',
        userId: currentUserId,
        category: 'FAMILY',
        type: 'AFFILIATION_APPROUVEE',
        title: 'Affiliation Validée avec Succès',
        body: 'Votre demande d’affiliation à la Branche Nzala-Kinkanda a été approuvée par le Conseil de Famille.',
        targetId: 'verif-dossier-jp-2026',
        targetType: 'VERIFICATION',
        senderName: 'Conseil de Famille Nzala',
        senderVerifiedBadge: '👑 Super Admin',
        read: true,
        createdAt: agoDays(2),
        linkTab: 'affiliation',
      },

      // 10. SÉCURITÉ DU COMPTE
      {
        id: 'notif-sec-login',
        userId: currentUserId,
        category: 'SECURITY',
        type: 'SECURITE_CONNEXION',
        title: 'Nouvelle connexion sécurisée',
        body: 'Connexion réussie depuis Chrome sous Windows (Kinshasa, RDC). Si vous en êtes à l’origine, ignorez ce message.',
        targetType: 'SETTINGS',
        read: true,
        createdAt: agoDays(2),
        linkTab: 'profile',
        metadata: {
          securityDevice: 'Chrome on Windows 11',
          securityIpMasked: '197.234.***.***',
          securityLocation: 'Kinshasa, RDC',
        },
      },

      // 11. SYSTÈME & COMMUNIQUÉ OFFICIEL
      {
        id: 'notif-sys-communique',
        userId: currentUserId,
        category: 'SYSTEM',
        type: 'SYSTEME_COMMUNIQUE',
        title: 'Information Officielle NzalaFamilly',
        body: 'Déploiement réussi du Centre de Notifications v2.0 et des Directs Nzala Live sécurisés.',
        targetType: 'ADMIN',
        read: true,
        createdAt: agoDays(3),
        linkTab: 'landing',
        metadata: {
          isOfficialAnnouncement: true,
        },
      },
    ];

    // Si le compte actuel est Administrateur ou Validateur, ajouter les alertes d'administration
    if (userRole === 'SUPER_ADMIN' || userRole === 'ADMIN_FAMILIAL' || userRole === 'VALIDATEUR') {
      notifs.unshift(
        {
          id: 'notif-admin-new-dossier',
          userId: currentUserId,
          category: 'ADMIN',
          type: 'ADMIN_NOUVELLE_AFFILIATION',
          title: 'Nouvelle affiliation à vérifier',
          body: 'Sarah Mpolo Nzala a soumis un dossier d’affiliation pour la branche Nzala-Lemba avec 2 pièces justificatives.',
          targetId: 'req-sarah-mpolo',
          targetType: 'VERIFICATION',
          senderName: 'Sarah Mpolo Nzala',
          senderAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150',
          read: false,
          createdAt: agoMins(40),
          linkTab: 'verifications',
        },
        {
          id: 'notif-admin-signalement',
          userId: currentUserId,
          category: 'ADMIN',
          type: 'ADMIN_SIGNALEMENT',
          title: 'Signalement social à examiner',
          body: 'Un commentaire sur la publication #4 a été signalé pour non-respect de la charte de respect mutuel.',
          targetId: 'rep-com-4',
          targetType: 'ADMIN',
          read: false,
          createdAt: agoHours(6),
          linkTab: 'admin',
        }
      );
    }

    return notifs;
  }

  /**
   * Filtre les notifications selon la catégorie choisie, les permissions et les préférences
   */
  public static filterNotifications(
    notifications: FamilyNotification[],
    filterCategory: NotificationCategory,
    userRole: UserRole,
    preferences: NotificationPreferences
  ): FamilyNotification[] {
    const isUserAdmin =
      userRole === 'SUPER_ADMIN' || userRole === 'ADMIN_FAMILIAL' || userRole === 'VALIDATEUR';

    return notifications.filter((notif) => {
      // Sécurité & Permissions : Masquer les notifications Admin pour les non-administrateurs
      if (notif.category === 'ADMIN' && !isUserAdmin) {
        return false;
      }

      // Filtrage par préférences utilisateur
      if (!this.matchesUserPreferences(notif, preferences)) {
        return false;
      }

      // Filtrage par onglet / catégorie
      if (filterCategory === 'ALL') return true;
      if (filterCategory === 'UNREAD') return !notif.read && !notif.isRead;
      return notif.category === filterCategory;
    });
  }

  /**
   * Vérifie la conformité avec les préférences
   */
  private static matchesUserPreferences(
    notif: FamilyNotification,
    preferences: NotificationPreferences
  ): boolean {
    switch (notif.category) {
      case 'MESSAGES':
        return preferences.messages;
      case 'STORIES':
        return preferences.stories;
      case 'SOCIAL':
        return preferences.publications;
      case 'EVENTS':
        return notif.type.startsWith('ANNIVERSAIRE') ? preferences.birthdays : preferences.events;
      case 'FAMILY':
        return preferences.governance;
      case 'SECURITY':
        return preferences.security;
      case 'SYSTEM':
        return preferences.system;
      default:
        return true;
    }
  }

  /**
   * Regroupe intelligemment les notifications similaires récentes (ex: plusieurs réactions sur le même post, messages de la même personne)
   */
  public static groupSimilarNotifications(
    notifications: FamilyNotification[]
  ): GroupedNotification[] {
    const grouped: GroupedNotification[] = [];
    const postReactionsMap = new Map<string, FamilyNotification[]>();
    const senderMessagesMap = new Map<string, FamilyNotification[]>();

    notifications.forEach((notif) => {
      // Regroupement des réactions sur un même post
      if (notif.type === 'REACTION' && notif.targetId && notif.targetType === 'POST') {
        const key = `post-${notif.targetId}`;
        const existing = postReactionsMap.get(key) || [];
        existing.push(notif);
        postReactionsMap.set(key, existing);
        return;
      }

      // Regroupement des messages d'un même expéditeur
      if (notif.type === 'MESSAGE' && notif.senderId && notif.targetType === 'CONVERSATION') {
        const key = `msg-${notif.senderId}`;
        const existing = senderMessagesMap.get(key) || [];
        existing.push(notif);
        senderMessagesMap.set(key, existing);
        return;
      }

      // Notification standard non regroupée
      grouped.push({
        ...notif,
        itemsCount: 1,
        rawNotifications: [notif],
      });
    });

    // Traitement des réactions regroupées
    postReactionsMap.forEach((list, key) => {
      if (list.length === 1) {
        grouped.push({
          ...list[0],
          itemsCount: 1,
          rawNotifications: list,
        });
      } else {
        const primary = list[0];
        const allUnread = list.some((n) => !n.read && !n.isRead);
        const names = Array.from(new Set(list.map((n) => n.senderName).filter(Boolean))) as string[];
        const namesStr =
          names.length > 2
            ? `${names.slice(0, 2).join(', ')} et ${names.length - 2} autre${names.length - 2 > 1 ? 's' : ''}`
            : names.join(' et ');

        grouped.push({
          ...primary,
          id: `grouped-${key}-${Date.now()}`,
          title: `Réactions sur votre publication`,
          body: `${namesStr} ont réagi ❤️ à votre publication.`,
          read: !allUnread,
          itemsCount: list.length,
          rawNotifications: list,
          metadata: {
            ...primary.metadata,
            count: list.length,
            actorNames: names,
          },
        });
      }
    });

    // Traitement des messages regroupés
    senderMessagesMap.forEach((list, key) => {
      if (list.length === 1) {
        grouped.push({
          ...list[0],
          itemsCount: 1,
          rawNotifications: list,
        });
      } else {
        const primary = list[0];
        const allUnread = list.some((n) => !n.read && !n.isRead);
        const sender = primary.senderName || 'Un membre';

        grouped.push({
          ...primary,
          id: `grouped-${key}-${Date.now()}`,
          title: `Nouveaux messages privés`,
          body: `${sender} vous a envoyé ${list.length} nouveaux messages.`,
          read: !allUnread,
          itemsCount: list.length,
          rawNotifications: list,
          metadata: {
            ...primary.metadata,
            count: list.length,
          },
        });
      }
    });

    // Tri chronologique décroissant
    return grouped.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  /**
   * Demande de permission Push Web du navigateur
   */
  public static async requestPushPermission(): Promise<{ granted: boolean; status: string }> {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      return { granted: false, status: 'NOT_SUPPORTED' };
    }

    try {
      const permission = await Notification.requestPermission();
      return {
        granted: permission === 'granted',
        status: permission,
      };
    } catch (err) {
      console.warn('Push permission request error:', err);
      return { granted: false, status: 'ERROR' };
    }
  }
}
