import { UserRole } from '../types';

export type AppPermission =
  | 'VIEW_DASHBOARD'
  | 'VIEW_MEMBERS'
  | 'VIEW_MEMBER_DETAILS'
  | 'VIEW_NZALA_PRIVATE_DATA'
  | 'VIEW_ALLIED_FAMILIES'
  | 'VIEW_ALLIANCES'
  | 'CREATE_ALLIANCE'
  | 'VIEW_VERIFICATION_QUEUE'
  | 'PROCESS_VERIFICATION'
  | 'SUBMIT_VERIFICATION'
  | 'MANAGE_FAMILIES'
  | 'MANAGE_ROLES'
  | 'VIEW_AUDIT_LOGS'
  | 'POST_ANNOUNCEMENT'
  | 'POST_OFFICIAL_ANNOUNCEMENT'
  | 'VIEW_FEED'
  | 'CREATE_POST'
  | 'CREATE_OFFICIAL_POST'
  | 'MODERATE_POSTS'
  | 'COMMENT_POST'
  | 'REACT_POST'
  | 'PIN_POST'
  | 'ARCHIVE_POST'
  | 'VIEW_GENEALOGY'
  | 'VIEW_EVENTS'
  | 'CREATE_EVENT'
  | 'EDIT_EVENT'
  | 'DELETE_EVENT'
  | 'MANAGE_EVENT_INVITATIONS'
  | 'VIEW_FAMILY_COUNCIL'
  | 'RSVP_EVENT';

const ROLE_PERMISSIONS: Record<UserRole, AppPermission[]> = {
  SUPER_ADMIN: [
    'VIEW_DASHBOARD',
    'VIEW_MEMBERS',
    'VIEW_MEMBER_DETAILS',
    'VIEW_NZALA_PRIVATE_DATA',
    'VIEW_ALLIED_FAMILIES',
    'VIEW_ALLIANCES',
    'CREATE_ALLIANCE',
    'VIEW_VERIFICATION_QUEUE',
    'PROCESS_VERIFICATION',
    'SUBMIT_VERIFICATION',
    'MANAGE_FAMILIES',
    'MANAGE_ROLES',
    'VIEW_AUDIT_LOGS',
    'POST_ANNOUNCEMENT',
    'POST_OFFICIAL_ANNOUNCEMENT',
    'VIEW_FEED',
    'CREATE_POST',
    'CREATE_OFFICIAL_POST',
    'MODERATE_POSTS',
    'COMMENT_POST',
    'REACT_POST',
    'PIN_POST',
    'ARCHIVE_POST',
    'VIEW_GENEALOGY',
    'VIEW_EVENTS',
    'CREATE_EVENT',
    'EDIT_EVENT',
    'DELETE_EVENT',
    'MANAGE_EVENT_INVITATIONS',
    'VIEW_FAMILY_COUNCIL',
    'RSVP_EVENT',
  ],
  ADMIN_FAMILIAL: [
    'VIEW_DASHBOARD',
    'VIEW_MEMBERS',
    'VIEW_MEMBER_DETAILS',
    'VIEW_NZALA_PRIVATE_DATA',
    'VIEW_ALLIED_FAMILIES',
    'VIEW_ALLIANCES',
    'CREATE_ALLIANCE',
    'VIEW_VERIFICATION_QUEUE',
    'PROCESS_VERIFICATION',
    'SUBMIT_VERIFICATION',
    'MANAGE_FAMILIES',
    'VIEW_AUDIT_LOGS',
    'POST_ANNOUNCEMENT',
    'POST_OFFICIAL_ANNOUNCEMENT',
    'VIEW_FEED',
    'CREATE_POST',
    'CREATE_OFFICIAL_POST',
    'MODERATE_POSTS',
    'COMMENT_POST',
    'REACT_POST',
    'PIN_POST',
    'ARCHIVE_POST',
    'VIEW_GENEALOGY',
    'VIEW_EVENTS',
    'CREATE_EVENT',
    'EDIT_EVENT',
    'DELETE_EVENT',
    'MANAGE_EVENT_INVITATIONS',
    'VIEW_FAMILY_COUNCIL',
    'RSVP_EVENT',
  ],
  VALIDATEUR: [
    'VIEW_DASHBOARD',
    'VIEW_MEMBERS',
    'VIEW_MEMBER_DETAILS',
    'VIEW_NZALA_PRIVATE_DATA',
    'VIEW_ALLIED_FAMILIES',
    'VIEW_ALLIANCES',
    'VIEW_VERIFICATION_QUEUE',
    'PROCESS_VERIFICATION',
    'SUBMIT_VERIFICATION',
    'POST_ANNOUNCEMENT',
    'VIEW_FEED',
    'CREATE_POST',
    'MODERATE_POSTS',
    'COMMENT_POST',
    'REACT_POST',
    'VIEW_GENEALOGY',
    'VIEW_EVENTS',
    'CREATE_EVENT',
    'EDIT_EVENT',
    'VIEW_FAMILY_COUNCIL',
    'RSVP_EVENT',
  ],
  MEMBRE_NZALA: [
    'VIEW_DASHBOARD',
    'VIEW_MEMBERS',
    'VIEW_MEMBER_DETAILS',
    'VIEW_NZALA_PRIVATE_DATA',
    'VIEW_ALLIED_FAMILIES',
    'VIEW_ALLIANCES',
    'SUBMIT_VERIFICATION',
    'POST_ANNOUNCEMENT',
    'VIEW_FEED',
    'CREATE_POST',
    'COMMENT_POST',
    'REACT_POST',
    'VIEW_GENEALOGY',
    'VIEW_EVENTS',
    'CREATE_EVENT',
    'RSVP_EVENT',
  ],
  MEMBRE_ALLIE: [
    'VIEW_DASHBOARD',
    'VIEW_MEMBERS',
    'VIEW_MEMBER_DETAILS',
    'VIEW_ALLIED_FAMILIES',
    'VIEW_ALLIANCES',
    'SUBMIT_VERIFICATION',
    'POST_ANNOUNCEMENT',
    'VIEW_FEED',
    'CREATE_POST',
    'COMMENT_POST',
    'REACT_POST',
    'VIEW_GENEALOGY',
    'VIEW_EVENTS',
    'CREATE_EVENT',
    'RSVP_EVENT',
  ],
  VISITEUR: [
    'VIEW_DASHBOARD',
    'VIEW_ALLIED_FAMILIES',
    'SUBMIT_VERIFICATION',
    'VIEW_EVENTS',
    'VIEW_FEED',
  ],
};

export function hasPermission(role: UserRole | undefined, permission: AppPermission): boolean {
  if (!role) return false;
  const permissions = ROLE_PERMISSIONS[role] || [];
  return permissions.includes(permission);
}

export function getRoleBadgeInfo(role: UserRole): { label: string; color: string; bgColor: string; borderColor: string } {
  switch (role) {
    case 'SUPER_ADMIN':
      return {
        label: 'Super Admin',
        color: 'text-purple-800',
        bgColor: 'bg-purple-50',
        borderColor: 'border-purple-200',
      };
    case 'ADMIN_FAMILIAL':
      return {
        label: 'Admin Familial',
        color: 'text-indigo-800',
        bgColor: 'bg-indigo-50',
        borderColor: 'border-indigo-200',
      };
    case 'VALIDATEUR':
      return {
        label: 'Validateur',
        color: 'text-blue-800',
        bgColor: 'bg-blue-50',
        borderColor: 'border-blue-200',
      };
    case 'MEMBRE_NZALA':
      return {
        label: 'Membre Nzala',
        color: 'text-blue-900',
        bgColor: 'bg-blue-50',
        borderColor: 'border-blue-200',
      };
    case 'MEMBRE_ALLIE':
      return {
        label: 'Membre Allié',
        color: 'text-sky-800',
        bgColor: 'bg-sky-50',
        borderColor: 'border-sky-200',
      };
    case 'VISITEUR':
      return {
        label: 'Visiteur / En attente',
        color: 'text-slate-700',
        bgColor: 'bg-slate-100',
        borderColor: 'border-slate-300',
      };
    default:
      return {
        label: role,
        color: 'text-slate-700',
        bgColor: 'bg-slate-100',
        borderColor: 'border-slate-300',
      };
  }
}
