import {
  FamilyPost,
  PostType,
  PostScope,
  PostStatus,
  PostModerationStatus,
  ReactionType,
  CurrentUser,
  FamilyNotification,
  NotificationType,
} from '../types';

/**
 * Détermine si un utilisateur a le droit de visualiser une publication donnée.
 * Règle de stricte confidentialité multi-niveaux.
 */
export function canUserViewPost(post: FamilyPost, user: CurrentUser): boolean {
  if (!post || !user) return false;

  const isSuperAdmin = user.role === 'SUPER_ADMIN';
  const isAdminFamilial = user.role === 'ADMIN_FAMILIAL';
  const isValidateur = user.role === 'VALIDATEUR';
  const isAuthor =
    (user.id && post.authorId === user.id) ||
    (user.memberId && post.authorId === user.memberId);

  // 1. Contrôle des statuts d'édition & brouillons
  if (post.status === 'BROUILLON') {
    return Boolean(isAuthor || isSuperAdmin || isAdminFamilial);
  }

  if (post.status === 'SUSPENDU' || post.status === 'ARCHIVE') {
    return Boolean(isAuthor || isSuperAdmin || isAdminFamilial);
  }

  // 2. Contrôle du statut de modération
  if (post.moderationStatus === 'EN_ATTENTE_MODERATION' || post.moderationStatus === 'REFUSE') {
    return Boolean(isAuthor || isSuperAdmin || isAdminFamilial || isValidateur);
  }

  // 3. Contrôle spécial : Publications du Conseil de Famille / Confidentielles
  if (post.postType === 'COMMUNIQUE_OFFICIEL' && post.authorType === 'CONSEIL_FAMILLE') {
    // Si c'est interne ou officiel Conseil, les visiteurs et postulants ne peuvent pas voir
    if (user.role === 'VISITEUR' && user.affiliationStatus !== 'APPROUVEE') {
      return false;
    }
  }

  // 4. Contrôle de la portée (Scope)
  switch (post.scope) {
    case 'PUBLIC':
      return true;

    case 'NZALA_INTERNE': {
      if (isSuperAdmin || isAdminFamilial || isValidateur) return true;
      // Membres directs Nzala avec statut approuvé
      return user.familyType === 'NZALA_DIRECT' && user.affiliationStatus === 'APPROUVEE';
    }

    case 'BRANCHE': {
      if (isSuperAdmin || isAdminFamilial || isValidateur || isAuthor) return true;
      if (!post.targetBranchId) return true;
      // Si l'utilisateur appartient à la branche ciblée (par convention de son profil / membre)
      // Les membres Nzala directs approuvés de la branche ou membres avec affinité
      return user.familyType === 'NZALA_DIRECT' && user.affiliationStatus === 'APPROUVEE';
    }

    case 'FAMILLE_ALLIEE': {
      if (isSuperAdmin || isAdminFamilial || isValidateur || isAuthor) return true;
      // Visible pour les membres de cette famille alliée spécifique
      if (post.targetFamilyId && user.familyId === post.targetFamilyId) return true;
      if (post.targetAlliedFamilyId && user.familyId === post.targetAlliedFamilyId) return true;
      return false;
    }

    case 'INTER_FAMILLES': {
      if (isSuperAdmin || isAdminFamilial || isValidateur || isAuthor) return true;
      // Visible par la Famille Nzala directe approuvée ET par la famille alliée cible spécifique
      const isNzalaDirect = user.familyType === 'NZALA_DIRECT' && user.affiliationStatus === 'APPROUVEE';
      const isTargetAlliedMember = Boolean(
        (post.targetAlliedFamilyId && user.familyId === post.targetAlliedFamilyId) ||
        (post.targetFamilyId && user.familyId === post.targetFamilyId)
      );
      return isNzalaDirect || isTargetAlliedMember;
    }

    case 'PRIVE': {
      return Boolean(isAuthor || isSuperAdmin || isAdminFamilial);
    }

    default:
      return false;
  }
}

/**
 * Vérifie si l'utilisateur peut modifier la publication.
 */
export function canUserEditPost(post: FamilyPost, user: CurrentUser): boolean {
  if (!post || !user) return false;
  if (user.role === 'SUPER_ADMIN' || user.role === 'ADMIN_FAMILIAL') return true;
  const isAuthor =
    (user.id && post.authorId === user.id) ||
    (user.memberId && post.authorId === user.memberId);
  return Boolean(isAuthor && post.status !== 'ARCHIVE');
}

/**
 * Vérifie si l'utilisateur peut supprimer / archiver la publication.
 */
export function canUserDeletePost(post: FamilyPost, user: CurrentUser): boolean {
  if (!post || !user) return false;
  if (user.role === 'SUPER_ADMIN' || user.role === 'ADMIN_FAMILIAL') return true;
  const isAuthor =
    (user.id && post.authorId === user.id) ||
    (user.memberId && post.authorId === user.memberId);
  return Boolean(isAuthor);
}

/**
 * Vérifie si l'utilisateur a le rôle de modérateur pour les publications.
 */
export function canUserModeratePost(user: CurrentUser): boolean {
  if (!user) return false;
  return (
    user.role === 'SUPER_ADMIN' ||
    user.role === 'ADMIN_FAMILIAL' ||
    user.role === 'VALIDATEUR'
  );
}

/**
 * Vérifie si l'utilisateur a le droit de rédiger une publication officielle.
 */
export function canUserCreateOfficialPost(user: CurrentUser): boolean {
  if (!user) return false;
  return user.role === 'SUPER_ADMIN' || user.role === 'ADMIN_FAMILIAL';
}

/**
 * Vérifie si l'utilisateur peut commenter sur la publication.
 */
export function canUserComment(post: FamilyPost, user: CurrentUser): boolean {
  if (!post || !user) return false;
  if (user.role === 'VISITEUR' && user.affiliationStatus !== 'APPROUVEE') return false;
  return canUserViewPost(post, user);
}

/**
 * Vérifie si l'utilisateur peut réagir à la publication.
 */
export function canUserReact(post: FamilyPost, user: CurrentUser): boolean {
  if (!post || !user) return false;
  if (user.role === 'VISITEUR' && user.affiliationStatus !== 'APPROUVEE') return false;
  return canUserViewPost(post, user);
}

/**
 * Informations visuelles et libellés par Type de Publication.
 */
export function getPostTypeBadgeInfo(type: PostType): {
  label: string;
  bgClass: string;
  textClass: string;
  borderClass: string;
  iconName: string;
} {
  switch (type) {
    case 'COMMUNIQUE_OFFICIEL':
      return {
        label: 'Communiqué Officiel',
        bgClass: 'bg-amber-950 text-amber-200 border-amber-800',
        textClass: 'text-amber-200',
        borderClass: 'border-amber-700',
        iconName: 'ShieldCheck',
      };
    case 'ANNONCE':
      return {
        label: 'Annonce Générale',
        bgClass: 'bg-stone-100 text-stone-800 border-stone-300',
        textClass: 'text-stone-800',
        borderClass: 'border-stone-300',
        iconName: 'Bell',
      };
    case 'ACTUALITE_FAMILIALE':
      return {
        label: 'Actualité Familiale',
        bgClass: 'bg-sky-50 text-sky-900 border-sky-300',
        textClass: 'text-sky-900',
        borderClass: 'border-sky-300',
        iconName: 'Sparkles',
      };
    case 'MARIAGE':
      return {
        label: 'Mariage & Alliance',
        bgClass: 'bg-rose-50 text-rose-900 border-rose-300',
        textClass: 'text-rose-900',
        borderClass: 'border-rose-300',
        iconName: 'HeartHandshake',
      };
    case 'NAISSANCE':
      return {
        label: 'Naissance & Bénédiction',
        bgClass: 'bg-emerald-50 text-emerald-900 border-emerald-300',
        textClass: 'text-emerald-900',
        borderClass: 'border-emerald-300',
        iconName: 'Baby',
      };
    case 'ANNIVERSAIRE':
      return {
        label: 'Anniversaire',
        bgClass: 'bg-amber-50 text-amber-900 border-amber-300',
        textClass: 'text-amber-900',
        borderClass: 'border-amber-300',
        iconName: 'Cake',
      };
    case 'FELICITATION':
      return {
        label: 'Félicitations & Réussite',
        bgClass: 'bg-amber-50 text-amber-900 border-amber-300',
        textClass: 'text-amber-900',
        borderClass: 'border-amber-300',
        iconName: 'Award',
      };
    case 'EVENEMENT':
      return {
        label: 'Événement & Rencontre',
        bgClass: 'bg-indigo-50 text-indigo-900 border-indigo-300',
        textClass: 'text-indigo-900',
        borderClass: 'border-indigo-300',
        iconName: 'Calendar',
      };
    case 'MEMOIRE_FAMILIALE':
      return {
        label: 'Mémoire & Tradition',
        bgClass: 'bg-stone-100 text-stone-900 border-stone-400',
        textClass: 'text-stone-900',
        borderClass: 'border-stone-400',
        iconName: 'Landmark',
      };
    case 'DECES_COMMUNIQUE':
      return {
        label: 'Hommage & Condoléances',
        bgClass: 'bg-stone-900 text-stone-200 border-stone-700',
        textClass: 'text-stone-200',
        borderClass: 'border-stone-700',
        iconName: 'Feather',
      };
    default:
      return {
        label: 'Publication',
        bgClass: 'bg-stone-100 text-stone-800 border-stone-300',
        textClass: 'text-stone-800',
        borderClass: 'border-stone-300',
        iconName: 'FileText',
      };
  }
}

/**
 * Informations visuelles et libellés par Portée de Publication.
 */
export function getPostScopeBadgeInfo(scope: PostScope): {
  label: string;
  description: string;
  bgClass: string;
  iconName: string;
} {
  switch (scope) {
    case 'PUBLIC':
      return {
        label: 'Public',
        description: 'Visible par tous les membres et visiteurs',
        bgClass: 'bg-emerald-50 text-emerald-800 border-emerald-200',
        iconName: 'Globe',
      };
    case 'NZALA_INTERNE':
      return {
        label: 'Interne Nzala',
        description: 'Réservé exclusivement aux membres de la famille souche Nzala',
        bgClass: 'bg-amber-50 text-amber-900 border-amber-300',
        iconName: 'Shield',
      };
    case 'BRANCHE':
      return {
        label: 'Branche Spécifique',
        description: 'Destiné principalement à une branche familiale',
        bgClass: 'bg-sky-50 text-sky-900 border-sky-300',
        iconName: 'GitBranch',
      };
    case 'FAMILLE_ALLIEE':
      return {
        label: 'Famille Alliée',
        description: 'Visible au sein de la famille alliée concernée',
        bgClass: 'bg-rose-50 text-rose-900 border-rose-300',
        iconName: 'HeartHandshake',
      };
    case 'INTER_FAMILLES':
      return {
        label: 'Inter-Familles',
        description: 'Partagé entre la Famille Nzala et la famille alliée partenaire',
        bgClass: 'bg-indigo-50 text-indigo-900 border-indigo-300',
        iconName: 'Users',
      };
    case 'PRIVE':
      return {
        label: 'Cercle Privé',
        description: 'Restreint aux destinataires et organisateurs',
        bgClass: 'bg-stone-100 text-stone-800 border-stone-300',
        iconName: 'Lock',
      };
    default:
      return {
        label: 'Standard',
        description: 'Périmètre standard',
        bgClass: 'bg-stone-100 text-stone-800 border-stone-200',
        iconName: 'Eye',
      };
  }
}

/**
 * Détails des 6 types de réactions officielles et chaleureuses.
 */
export function getReactionConfig(type: ReactionType): {
  type: ReactionType;
  label: string;
  emoji: string;
  activeClass: string;
  bgClass: string;
} {
  switch (type) {
    case 'LIKE':
      return {
        type: 'LIKE',
        label: "J'aime",
        emoji: '❤️',
        activeClass: 'text-rose-600 font-bold bg-rose-50 border-rose-200',
        bgClass: 'hover:bg-rose-50 text-stone-600',
      };
    case 'SUPPORT':
      return {
        type: 'SUPPORT',
        label: 'Soutien',
        emoji: '🙏',
        activeClass: 'text-amber-700 font-bold bg-amber-50 border-amber-200',
        bgClass: 'hover:bg-amber-50 text-stone-600',
      };
    case 'CONGRATS':
      return {
        type: 'CONGRATS',
        label: 'Félicitations',
        emoji: '🎉',
        activeClass: 'text-emerald-700 font-bold bg-emerald-50 border-emerald-200',
        bgClass: 'hover:bg-emerald-50 text-stone-600',
      };
    case 'HOMAGE':
      return {
        type: 'HOMAGE',
        label: 'Hommage',
        emoji: '🕊️',
        activeClass: 'text-sky-800 font-bold bg-sky-50 border-sky-200',
        bgClass: 'hover:bg-sky-50 text-stone-600',
      };
    case 'BRAVO':
      return {
        type: 'BRAVO',
        label: 'Bravo',
        emoji: '👏',
        activeClass: 'text-blue-700 font-bold bg-blue-50 border-blue-200',
        bgClass: 'hover:bg-blue-50 text-stone-600',
      };
    case 'JOY':
      return {
        type: 'JOY',
        label: 'Joie',
        emoji: '😂',
        activeClass: 'text-yellow-600 font-bold bg-yellow-50 border-yellow-200',
        bgClass: 'hover:bg-yellow-50 text-stone-600',
      };
  }
}

/**
 * Validation des données d'un post avant enregistrement.
 * Accepte les publications textuelles, multimédias ou partages de liens.
 */
export function validatePostData(data: Partial<FamilyPost>): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  const hasMedia = Boolean((data.media && data.media.length > 0) || data.imageUrl);
  const hasLink = Boolean(data.linkPreview && data.linkPreview.url);
  const hasContent = Boolean(data.content && data.content.trim().length > 0);
  const hasSharedPost = Boolean(data.sharedPostId);

  if (!hasContent && !hasMedia && !hasLink && !hasSharedPost) {
    errors.push('Veuillez saisir du texte ou ajouter un média / lien à votre publication.');
  }

  if (!data.postType) {
    errors.push('Veuillez sélectionner un type de publication.');
  }

  if (!data.scope) {
    errors.push('Veuillez définir la portée / visibilité de la publication.');
  }

  if (data.scope === 'BRANCHE' && !data.targetBranchId) {
    errors.push('Veuillez sélectionner la branche familiale ciblée.');
  }

  if (data.scope === 'FAMILLE_ALLIEE' && !data.targetAlliedFamilyId && !data.targetFamilyId) {
    errors.push('Veuillez sélectionner la famille alliée concernée.');
  }

  if (data.scope === 'INTER_FAMILLES' && !data.targetAlliedFamilyId) {
    errors.push('Pour une publication Inter-Familles, veuillez indiquer la famille alliée partenaire.');
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
}

/**
 * Création d'une notification préparatoire
 */
export function createNotification(
  recipientUserId: string,
  type: NotificationType,
  title: string,
  message: string,
  link?: string,
  targetPostId?: string
): FamilyNotification {
  return {
    id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    userId: recipientUserId,
    recipientUserId,
    category: 'SOCIAL',
    type,
    title,
    body: message,
    message,
    link,
    targetPostId,
    targetId: targetPostId,
    targetType: 'POST',
    read: false,
    isRead: false,
    createdAt: new Date().toISOString(),
  };
}
