/**
 * NzalaFamilly - Service de Gestion de la Présence (EN LIGNE, ABSENT, HORS LIGNE)
 */

import { UserPresence, PresenceStatus } from '../../types/messaging';
import { CurrentUser, UserAccount } from '../../types';
import { PrivacyService } from '../privacy/PrivacyService';

type AnyUser = CurrentUser | UserAccount;

export class PresenceService {
  /**
   * Retourne le libellé de statut formaté respectant la confidentialité
   */
  public static getFormattedPresence(
    viewer: AnyUser,
    target: AnyUser,
    presences: UserPresence[]
  ): { label: string; status: PresenceStatus; isOnline: boolean } {
    const canSee = PrivacyService.canSeeOnlineStatus(viewer, target);
    if (!canSee) {
      return { label: 'Statut masqué', status: 'HORS_LIGNE', isOnline: false };
    }

    const presence = presences.find((p) => p.userId === target.id);
    if (!presence) {
      return { label: 'Hors ligne', status: 'HORS_LIGNE', isOnline: false };
    }

    if (presence.status === 'EN_LIGNE') {
      return { label: 'En ligne', status: 'EN_LIGNE', isOnline: true };
    }

    if (presence.status === 'ABSENT') {
      return { label: 'Absent', status: 'ABSENT', isOnline: false };
    }

    if (presence.lastSeen) {
      const diffMinutes = Math.floor((Date.now() - new Date(presence.lastSeen).getTime()) / 60000);
      if (diffMinutes < 60) {
        return {
          label: `Vu il y a ${Math.max(1, diffMinutes)} min`,
          status: 'HORS_LIGNE',
          isOnline: false,
        };
      }
      const lastSeenDate = new Date(presence.lastSeen);
      const isToday = new Date().toDateString() === lastSeenDate.toDateString();
      if (isToday) {
        const timeStr = lastSeenDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        return { label: `Vu aujourd'hui à ${timeStr}`, status: 'HORS_LIGNE', isOnline: false };
      }
      return {
        label: `Vu le ${lastSeenDate.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}`,
        status: 'HORS_LIGNE',
        isOnline: false,
      };
    }

    return { label: 'Hors ligne', status: 'HORS_LIGNE', isOnline: false };
  }

  /**
   * Détermine la couleur de badge pour l'UI
   */
  public static getPresenceColor(status: PresenceStatus): string {
    switch (status) {
      case 'EN_LIGNE':
        return 'bg-emerald-500 text-emerald-100 border-emerald-400';
      case 'ABSENT':
        return 'bg-amber-500 text-amber-100 border-amber-400';
      case 'OCCUPE':
        return 'bg-rose-500 text-rose-100 border-rose-400';
      case 'HORS_LIGNE':
      default:
        return 'bg-stone-500 text-stone-300 border-stone-600';
    }
  }
}
