/**
 * NzalaFamilly - Service de Gestion de la Confidentialité & des Permissions Sociales
 * Contrôle finement qui peut appeler, envoyer des messages, voir le statut ou les stories
 */

import { CurrentUser, UserAccount } from '../../types';
import { UserPrivacySettings, PrivacyAudience } from '../../types/notifications';

type AnyUser = CurrentUser | UserAccount;

export class PrivacyService {
  public static readonly DEFAULT_PRIVACY_SETTINGS: UserPrivacySettings = {
    whoCanMessageMe: 'TOUS_AUTORISES',
    whoCanCallMe: 'TOUS_AUTORISES',
    whoCanSeeOnlineStatus: 'TOUS_AUTORISES',
    whoCanSeeStories: 'TOUS_AUTORISES',
    whoCanSeePosts: 'TOUS_AUTORISES',
    whoCanMentionMe: 'TOUS_AUTORISES',
    showOnlineStatus: true,
    showReadReceipts: true,
  };

  /**
   * Vérifie si l'utilisateur demandeur a accès selon l'audience de confidentialité
   */
  public static evaluateAudienceAccess(
    requester: AnyUser,
    target: AnyUser,
    audience: PrivacyAudience
  ): boolean {
    // Les super-admins ont un accès de modération si nécessaire
    if (requester.role === 'SUPER_ADMIN') return true;

    // Même personne
    if (requester.id === target.id) return true;

    const isSuspended = (requester as any).accountStatus === 'SUSPENDU' || (requester as any).status === 'SUSPENDU';

    switch (audience) {
      case 'TOUS_AUTORISES':
        // Tous les membres enregistrés actifs
        return requester.role !== 'VISITEUR' && !isSuspended;

      case 'FAMILLE_SEULEMENT': {
        // Même famille principale
        const reqFamily = (requester as any).familyId || (requester as any).primaryFamilyId || 'fam-nzala';
        const targetFamily = (target as any).primaryFamilyId || (target as any).familyId || 'fam-nzala';
        return reqFamily === targetFamily;
      }

      case 'FAMILLES_ALLIEES': {
        // Famille principale ou famille alliée reconnue
        return true;
      }

      case 'RELATIONS_AUTORISEES': {
        // Même branche familiale ou lien direct
        const reqBranch = (requester as any).branchId;
        const targetBranch = (target as any).branchId;
        if (reqBranch && targetBranch && reqBranch === targetBranch) return true;
        const reqFamily = (requester as any).familyId || (requester as any).primaryFamilyId;
        const targetFamily = (target as any).familyId || (target as any).primaryFamilyId;
        return reqFamily === targetFamily;
      }

      case 'PERSONNE':
        return false;

      default:
        return true;
    }
  }

  /**
   * Vérifie si l'appel est autorisé
   */
  public static canCallUser(
    caller: AnyUser,
    recipient: AnyUser,
    customSettings?: UserPrivacySettings
  ): { allowed: boolean; reason?: string } {
    const settings = customSettings || (recipient as any).privacySettings || this.DEFAULT_PRIVACY_SETTINGS;
    const allowed = this.evaluateAudienceAccess(caller, recipient, settings.whoCanCallMe);
    if (!allowed) {
      return { allowed: false, reason: 'Ce membre n’autorise pas les appels selon ses réglages de confidentialité.' };
    }
    return { allowed: true };
  }

  /**
   * Vérifie si les messages privés sont autorisés
   */
  public static canMessageUser(
    sender: AnyUser,
    recipient: AnyUser,
    customSettings?: UserPrivacySettings
  ): { allowed: boolean; reason?: string } {
    const settings = customSettings || (recipient as any).privacySettings || this.DEFAULT_PRIVACY_SETTINGS;
    const allowed = this.evaluateAudienceAccess(sender, recipient, settings.whoCanMessageMe);
    if (!allowed) {
      return { allowed: false, reason: 'Ce membre restreint la réception de messages privés.' };
    }
    return { allowed: true };
  }

  /**
   * Vérifie si le statut en ligne est visible pour le demandeur
   */
  public static canSeeOnlineStatus(
    viewer: AnyUser,
    target: AnyUser,
    customSettings?: UserPrivacySettings
  ): boolean {
    const settings = customSettings || (target as any).privacySettings || this.DEFAULT_PRIVACY_SETTINGS;
    if (!settings.showOnlineStatus) return false;
    return this.evaluateAudienceAccess(viewer, target, settings.whoCanSeeOnlineStatus);
  }

  /**
   * Vérifie si les stories sont visibles pour le demandeur
   */
  public static canSeeStories(
    viewer: AnyUser,
    author: AnyUser,
    customSettings?: UserPrivacySettings
  ): boolean {
    const settings = customSettings || (author as any).privacySettings || this.DEFAULT_PRIVACY_SETTINGS;
    return this.evaluateAudienceAccess(viewer, author, settings.whoCanSeeStories);
  }
}
