/**
 * NzalaFamilly - Relational Database Architecture Specification (PostgreSQL 15+ / Cloud SQL)
 * Definitive Schema Definition for Enterprise Multi-User Production Deployment.
 * 
 * Contains all 24 Core Domain Entities with Referential Integrity, Indexes, and Constraints.
 */

export const POSTGRESQL_DDL_SCHEMA = `
-- ==============================================================================
-- NZALAFAMILLY PRODUCTION RELATIONAL DATABASE SCHEMA (PostgreSQL 15+)
-- ==============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "citext";

-- --- 1. USER ACCOUNTS (Identity & Authentication) ---
CREATE TYPE user_role_enum AS ENUM (
  'SUPER_ADMIN',
  'ADMIN_FAMILIAL',
  'VALIDATEUR',
  'MEMBRE_NZALA',
  'MEMBRE_ALLIE',
  'VISITEUR'
);

CREATE TYPE account_status_enum AS ENUM (
  'COMPTE_CREE',
  'ACTIF',
  'SUSPENDU',
  'ARCHIVE',
  'EN_REVUE'
);

CREATE TYPE affiliation_status_enum AS ENUM (
  'NON_DEPOSEE',
  'EN_ATTENTE',
  'APPROUVEE',
  'REJETEE',
  'COMPLEMENT_REQUIS'
);

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email CITEXT UNIQUE NOT NULL,
  phone VARCHAR(32),
  password_hash VARCHAR(255) NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  avatar_url TEXT,
  role user_role_enum NOT NULL DEFAULT 'VISITEUR',
  account_status account_status_enum NOT NULL DEFAULT 'COMPTE_CREE',
  affiliation_status affiliation_status_enum NOT NULL DEFAULT 'NON_DEPOSEE',
  is_email_verified BOOLEAN NOT NULL DEFAULT FALSE,
  is_phone_verified BOOLEAN NOT NULL DEFAULT FALSE,
  two_factor_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  two_factor_secret VARCHAR(128),
  primary_family_id UUID,
  primary_family_name VARCHAR(150),
  family_type VARCHAR(32) DEFAULT 'NZALA_DIRECT',
  branch_id UUID,
  branch_name VARCHAR(150),
  member_id UUID UNIQUE, -- Strict 1-to-1 controlled pointer to genealogy Member
  last_login_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_status ON users(account_status);
CREATE INDEX idx_users_member_id ON users(member_id);

-- --- 2. FAMILIES ---
CREATE TYPE family_type_enum AS ENUM ('PRINCIPALE', 'ALLIEE');
CREATE TYPE family_status_enum AS ENUM ('ACTIVE', 'ARCHIVEE', 'EN_COURS_RATIFICATION');

CREATE TABLE families (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(150) NOT NULL,
  code VARCHAR(50) UNIQUE NOT NULL,
  type family_type_enum NOT NULL DEFAULT 'ALLIEE',
  status family_status_enum NOT NULL DEFAULT 'ACTIVE',
  origin_location VARCHAR(200),
  territory VARCHAR(200),
  description TEXT,
  founding_year INT,
  patriarch_name VARCHAR(150),
  badge_color VARCHAR(32),
  historical_info TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_families_code ON families(code);
CREATE INDEX idx_families_type ON families(type);

-- --- 3. FAMILY BRANCHES ---
CREATE TABLE family_branches (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  family_id UUID NOT NULL REFERENCES families(id) ON DELETE CASCADE,
  name VARCHAR(150) NOT NULL,
  code VARCHAR(50) NOT NULL,
  description TEXT,
  founding_elder_name VARCHAR(150),
  founding_elder_id UUID,
  generation_start INT NOT NULL DEFAULT 1,
  territory VARCHAR(200),
  status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (family_id, code)
);

CREATE INDEX idx_branches_family_id ON family_branches(family_id);

-- --- 4. MEMBERS (Genealogical Person Record) ---
CREATE TYPE gender_enum AS ENUM ('M', 'F', 'AUTRE');
CREATE TYPE living_status_enum AS ENUM ('VIVANT', 'DECEDE', 'INCONNU');
CREATE TYPE member_belonging_enum AS ENUM (
  'APPARTENANCE_DIRECTE',
  'ALLIANCE_MARIAGE',
  'ALLIANCE_DESCENDANCE',
  'ALLIANCE_AUTRE'
);

CREATE TYPE membership_status_enum AS ENUM (
  'ACTIF',
  'EN_ATTENTE_VERIFICATION',
  'SUSPENDU',
  'ARCHIVE'
);

CREATE TABLE members (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID UNIQUE REFERENCES users(id) ON DELETE SET NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  middle_name VARCHAR(100),
  post_name VARCHAR(100),
  maiden_name VARCHAR(100),
  gender gender_enum NOT NULL,
  birth_date DATE,
  birth_city VARCHAR(100),
  birth_territory VARCHAR(100),
  birth_country VARCHAR(100),
  living_status living_status_enum NOT NULL DEFAULT 'VIVANT',
  death_date DATE,
  burial_place VARCHAR(200),
  primary_family_id UUID NOT NULL REFERENCES families(id) ON DELETE RESTRICT,
  branch_id UUID REFERENCES family_branches(id) ON DELETE SET NULL,
  family_type VARCHAR(32) NOT NULL DEFAULT 'NZALA_DIRECT',
  origin_family_name VARCHAR(150),
  belonging_type member_belonging_enum NOT NULL DEFAULT 'APPARTENANCE_DIRECTE',
  membership_status membership_status_enum NOT NULL DEFAULT 'ACTIF',
  generation_level INT NOT NULL DEFAULT 1,
  generation_status VARCHAR(32) NOT NULL DEFAULT 'VALIDEE',
  visibility_level VARCHAR(32) NOT NULL DEFAULT 'FAMILY',
  email VARCHAR(150),
  phone VARCHAR(32),
  avatar_url TEXT,
  profession VARCHAR(150),
  location VARCHAR(200),
  bio TEXT,
  spouse_name VARCHAR(150),
  spouse_family_name VARCHAR(150),
  is_historical_figure BOOLEAN NOT NULL DEFAULT FALSE,
  honorific_title VARCHAR(100),
  historical_era VARCHAR(100),
  anecdotes JSONB DEFAULT '[]'::jsonb,
  historical_sources JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_members_family ON members(primary_family_id);
CREATE INDEX idx_members_branch ON members(branch_id);
CREATE INDEX idx_members_gen ON members(generation_level);
CREATE INDEX idx_members_status ON members(membership_status);
CREATE INDEX idx_members_user ON members(user_id);

-- Add foreign key back to users table
ALTER TABLE users ADD CONSTRAINT fk_users_primary_family 
  FOREIGN KEY (primary_family_id) REFERENCES families(id) ON DELETE SET NULL;
ALTER TABLE users ADD CONSTRAINT fk_users_branch 
  FOREIGN KEY (branch_id) REFERENCES family_branches(id) ON DELETE SET NULL;
ALTER TABLE users ADD CONSTRAINT fk_users_member 
  FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE SET NULL;

-- --- 5. RELATIONSHIPS (Lineage & Kinship Graph) ---
CREATE TYPE relationship_type_enum AS ENUM (
  'PARENT_ENFANT',
  'CONJOINT',
  'FRATRIE',
  'TUTEUR_LEGAL',
  'AUTRE'
);

CREATE TYPE relationship_status_enum AS ENUM (
  'PROPOSEE',
  'EN_ATTENTE_VALIDATION',
  'VALIDEE',
  'REFUSEE',
  'CONTESTEE',
  'SUSPENDUE'
);

CREATE TABLE relationships (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  member_a_id UUID NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  member_b_id UUID NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  relationship_type relationship_type_enum NOT NULL,
  status relationship_status_enum NOT NULL DEFAULT 'PROPOSEE',
  source VARCHAR(32) NOT NULL DEFAULT 'CONSEIL_SAGES',
  start_date DATE,
  end_date DATE,
  notes TEXT,
  confidence_score INT DEFAULT 100,
  validator_id UUID REFERENCES users(id) ON DELETE SET NULL,
  validated_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_different_members CHECK (member_a_id <> member_b_id),
  UNIQUE (member_a_id, member_b_id, relationship_type)
);

CREATE INDEX idx_rel_member_a ON relationships(member_a_id);
CREATE INDEX idx_rel_member_b ON relationships(member_b_id);
CREATE INDEX idx_rel_type ON relationships(relationship_type);
CREATE INDEX idx_rel_status ON relationships(status);

-- --- 6. ALLIANCES (Inter-Family Treaties & Marriages) ---
CREATE TYPE alliance_type_enum AS ENUM (
  'MARIAGE_COUTUMIER',
  'MARIAGE_CIVIL',
  'MARIAGE_RELIGIEUX',
  'PACTE_HISTORIQUE',
  'PATRONAGE_TRADITIONNEL'
);

CREATE TYPE alliance_status_enum AS ENUM (
  'PROPOSEE',
  'RATIFIEE',
  'HISTORIQUE',
  'SUSPENDUE',
  'DISSOLTE'
);

CREATE TABLE alliances (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  family_a_id UUID NOT NULL REFERENCES families(id) ON DELETE RESTRICT,
  family_b_id UUID NOT NULL REFERENCES families(id) ON DELETE RESTRICT,
  type alliance_type_enum NOT NULL,
  status alliance_status_enum NOT NULL DEFAULT 'PROPOSEE',
  title VARCHAR(200) NOT NULL,
  description TEXT,
  ratification_date DATE,
  place VARCHAR(200),
  spouses_involved JSONB DEFAULT '[]'::jsonb,
  customary_dowry_details TEXT,
  witnesses_council JSONB DEFAULT '[]'::jsonb,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_alliances_family_a ON alliances(family_a_id);
CREATE INDEX idx_alliances_family_b ON alliances(family_b_id);

-- --- 7. VERIFICATION REQUESTS (Formal 5-Stage Affiliation Pipeline) ---
CREATE TYPE verification_status_enum AS ENUM (
  'NON_DEPOSEE',
  'EN_ATTENTE_PREUVE',
  'EN_REVUE_VALIDATEUR',
  'CONSEIL_DES_SAGES',
  'APPROUVEE',
  'REJETEE',
  'COMPLEMENT_REQUIS'
);

CREATE TABLE verification_requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  applicant_name VARCHAR(150) NOT NULL,
  applicant_email VARCHAR(150) NOT NULL,
  applicant_phone VARCHAR(32) NOT NULL,
  origin_family_name VARCHAR(150) NOT NULL,
  claimed_family_type VARCHAR(32) NOT NULL,
  affiliation_option VARCHAR(64),
  target_nzala_member_id UUID REFERENCES members(id) ON DELETE SET NULL,
  target_nzala_member_name VARCHAR(150),
  relationship_nature VARCHAR(100) NOT NULL,
  branch_or_town VARCHAR(150),
  explanation TEXT NOT NULL,
  references_text TEXT,
  status verification_status_enum NOT NULL DEFAULT 'EN_REVUE_VALIDATEUR',
  current_step INT NOT NULL DEFAULT 1,
  reviewer_id UUID REFERENCES users(id) ON DELETE SET NULL,
  reviewer_name VARCHAR(150),
  reviewer_notes TEXT,
  public_feedback TEXT,
  council_session_id VARCHAR(64),
  council_decision_date TIMESTAMPTZ,
  attached_evidence JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_verif_user ON verification_requests(user_id);
CREATE INDEX idx_verif_status ON verification_requests(status);

-- --- 8. POSTS (Family Feed & Official Announcements) ---
CREATE TYPE post_type_enum AS ENUM (
  'TEXT',
  'IMAGE',
  'VIDEO',
  'AUDIO',
  'COMMUNIQUE_OFFICIEL',
  'HOMMAGE',
  'ANNONCE_MARIAGE',
  'ANNIVERSAIRE',
  'ARCHIVE_HISTORIQUE'
);

CREATE TYPE post_scope_enum AS ENUM (
  'NZALA_INTERNE',
  'FAMILLE_ALLIEE',
  'INTER_FAMILLES',
  'PRIVE',
  'CONSEIL_DES_SAGES'
);

CREATE TYPE post_status_enum AS ENUM ('PUBLIE', 'MODERE', 'ARCHIVE', 'BROUILLON');
CREATE TYPE post_moderation_status_enum AS ENUM ('EN_REVUE', 'APPROUVE', 'REJETE', 'SIGNALE');

CREATE TABLE posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  author_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  author_name VARCHAR(150) NOT NULL,
  author_avatar TEXT,
  author_role user_role_enum NOT NULL,
  author_family_id UUID REFERENCES families(id) ON DELETE SET NULL,
  author_family_name VARCHAR(150),
  author_branch_name VARCHAR(150),
  post_type post_type_enum NOT NULL DEFAULT 'TEXT',
  scope post_scope_enum NOT NULL DEFAULT 'INTER_FAMILLES',
  title VARCHAR(250),
  content TEXT NOT NULL,
  media JSONB DEFAULT '[]'::jsonb,
  link_preview JSONB,
  is_official BOOLEAN NOT NULL DEFAULT FALSE,
  is_pinned BOOLEAN NOT NULL DEFAULT FALSE,
  is_sensitive BOOLEAN NOT NULL DEFAULT FALSE,
  status post_status_enum NOT NULL DEFAULT 'PUBLIE',
  moderation_status post_moderation_status_enum NOT NULL DEFAULT 'APPROUVE',
  related_member_id UUID REFERENCES members(id) ON DELETE SET NULL,
  related_member_name VARCHAR(150),
  likes_count INT NOT NULL DEFAULT 0,
  comments_count INT NOT NULL DEFAULT 0,
  shares_count INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_posts_author ON posts(author_id);
CREATE INDEX idx_posts_scope ON posts(scope);
CREATE INDEX idx_posts_created ON posts(created_at DESC);

-- --- 9. COMMENTS ---
CREATE TABLE comments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  post_id UUID NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  author_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  author_name VARCHAR(150) NOT NULL,
  author_avatar TEXT,
  author_role user_role_enum NOT NULL,
  content TEXT NOT NULL,
  parent_comment_id UUID REFERENCES comments(id) ON DELETE CASCADE,
  status VARCHAR(32) NOT NULL DEFAULT 'PUBLIE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_comments_post ON comments(post_id);

-- --- 10. POST REACTIONS ---
CREATE TYPE reaction_type_enum AS ENUM ('LIKE', 'LOVE', 'RESPECT', 'SUPPORT', 'CELEBRATE', 'BLESSING');

CREATE TABLE post_reactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  post_id UUID NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_name VARCHAR(150) NOT NULL,
  reaction_type reaction_type_enum NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (post_id, user_id)
);

CREATE INDEX idx_reactions_post ON post_reactions(post_id);

-- --- 11. STORIES (24-Hour Ephemeral Media) ---
CREATE TABLE stories (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  author_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  author_name VARCHAR(150) NOT NULL,
  author_avatar TEXT,
  author_family_name VARCHAR(150),
  media_type VARCHAR(32) NOT NULL DEFAULT 'IMAGE',
  media_url TEXT NOT NULL,
  caption TEXT,
  background_gradient VARCHAR(100),
  scope post_scope_enum NOT NULL DEFAULT 'INTER_FAMILLES',
  views_count INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '24 hours')
);

CREATE INDEX idx_stories_active ON stories(expires_at DESC);
CREATE INDEX idx_stories_author ON stories(author_id);

-- --- 12. STORY VIEWS ---
CREATE TABLE story_views (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  story_id UUID NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
  viewer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  viewer_name VARCHAR(150) NOT NULL,
  viewer_avatar TEXT,
  viewed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (story_id, viewer_id)
);

CREATE INDEX idx_story_views_story ON story_views(story_id);

-- --- 13. STORY REACTIONS ---
CREATE TABLE story_reactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  story_id UUID NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_name VARCHAR(150) NOT NULL,
  reaction_emoji VARCHAR(32) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- --- 14. EVENTS (Family Calendar, Ceremonies & Assemblies) ---
CREATE TYPE event_type_enum AS ENUM (
  'ASSEMBLEE_GENERALE',
  'CONSEIL_DES_SAGES',
  'CEREMONIE_COUTUMIERE',
  'MARIAGE',
  'DEUIL_ET_OBSEQUES',
  'RETROUVAILLE',
  'ANNIVERSAIRE_COMMUN',
  'CULTE_ACTION_GRACE',
  'AUTRE'
);

CREATE TYPE event_visibility_enum AS ENUM (
  'NZALA_INTERNE',
  'FAMILLE_ALLIEE',
  'INTER_FAMILLES',
  'PRIVE'
);

CREATE TYPE event_status_enum AS ENUM ('PLANIFIE', 'EN_COURS', 'TERMINE', 'ANNULE', 'REPORTE');

CREATE TABLE events (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organizer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  organizer_name VARCHAR(150) NOT NULL,
  title VARCHAR(200) NOT NULL,
  type event_type_enum NOT NULL,
  description TEXT NOT NULL,
  start_date TIMESTAMPTZ NOT NULL,
  end_date TIMESTAMPTZ,
  location_name VARCHAR(200) NOT NULL,
  address VARCHAR(250),
  city VARCHAR(100),
  country VARCHAR(100),
  visibility event_visibility_enum NOT NULL DEFAULT 'INTER_FAMILLES',
  target_family_id UUID REFERENCES families(id) ON DELETE SET NULL,
  target_branch_id UUID REFERENCES family_branches(id) ON DELETE SET NULL,
  is_confidential BOOLEAN NOT NULL DEFAULT FALSE,
  status event_status_enum NOT NULL DEFAULT 'PLANIFIE',
  cover_image_url TEXT,
  participants_count INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_events_start ON events(start_date ASC);
CREATE INDEX idx_events_visibility ON events(visibility);

-- --- 15. EVENT RSVP & INVITATIONS ---
CREATE TYPE invitation_status_enum AS ENUM ('EN_ATTENTE', 'ACCEPTEE', 'DECLINEE', 'PEUT_ETRE');

CREATE TABLE event_rsvps (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  event_id UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_name VARCHAR(150) NOT NULL,
  user_avatar TEXT,
  status invitation_status_enum NOT NULL DEFAULT 'EN_ATTENTE',
  guests_count INT NOT NULL DEFAULT 1,
  note TEXT,
  responded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (event_id, user_id)
);

CREATE INDEX idx_rsvp_event ON event_rsvps(event_id);

-- --- 16. CONVERSATIONS (Private & Family Group Chats) ---
CREATE TYPE conversation_type_enum AS ENUM ('DIRECT', 'GROUP_BRANCH', 'GROUP_FAMILY', 'COUNCIL_SAGES');

CREATE TABLE conversations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  type conversation_type_enum NOT NULL DEFAULT 'DIRECT',
  title VARCHAR(150),
  avatar_url TEXT,
  created_by UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  family_id UUID REFERENCES families(id) ON DELETE SET NULL,
  branch_id UUID REFERENCES family_branches(id) ON DELETE SET NULL,
  is_archived BOOLEAN NOT NULL DEFAULT FALSE,
  last_message_at TIMESTAMPTZ,
  last_message_preview TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_conv_updated ON conversations(updated_at DESC);

-- --- 17. CONVERSATION MEMBERS (Membership & Roles in Chat) ---
CREATE TABLE conversation_members (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role VARCHAR(32) NOT NULL DEFAULT 'MEMBER', -- 'ADMIN', 'MEMBER'
  joined_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_read_at TIMESTAMPTZ,
  unread_count INT NOT NULL DEFAULT 0,
  is_muted BOOLEAN NOT NULL DEFAULT FALSE,
  UNIQUE (conversation_id, user_id)
);

CREATE INDEX idx_conv_mem_user ON conversation_members(user_id);
CREATE INDEX idx_conv_mem_conv ON conversation_members(conversation_id);

-- --- 18. MESSAGES (Rich Text, Audio Voice Notes, Media, View-Once) ---
CREATE TYPE message_type_enum AS ENUM (
  'TEXT',
  'AUDIO_VOICE',
  'IMAGE',
  'VIDEO',
  'DOCUMENT',
  'VIEW_ONCE_IMAGE',
  'VIEW_ONCE_VIDEO',
  'SYSTEM'
);

CREATE TYPE message_status_enum AS ENUM ('ENVOYE', 'DISTRIBUE', 'LU', 'EXPIRE', 'SUPPRIME');

CREATE TABLE messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  sender_name VARCHAR(150) NOT NULL,
  sender_avatar TEXT,
  type message_type_enum NOT NULL DEFAULT 'TEXT',
  content TEXT,
  media_url TEXT,
  media_file_name VARCHAR(255),
  media_file_size BIGINT,
  media_mime_type VARCHAR(100),
  audio_duration_seconds INT,
  is_view_once BOOLEAN NOT NULL DEFAULT FALSE,
  view_once_viewed_at TIMESTAMPTZ,
  view_once_viewer_id UUID REFERENCES users(id) ON DELETE SET NULL,
  status message_status_enum NOT NULL DEFAULT 'ENVOYE',
  reply_to_message_id UUID REFERENCES messages(id) ON DELETE SET NULL,
  deleted_for_all BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_messages_conv ON messages(conversation_id, created_at ASC);
CREATE INDEX idx_messages_sender ON messages(sender_id);

-- --- 19. MESSAGE REACTIONS ---
CREATE TABLE message_reactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  message_id UUID NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  emoji VARCHAR(32) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (message_id, user_id, emoji)
);

-- --- 20. NOTIFICATIONS ---
CREATE TYPE notification_type_enum AS ENUM (
  'VERIFICATION_SUBMITTED',
  'VERIFICATION_DECIDED',
  'FAMILY_ALLIANCE_NEW',
  'POST_REACTION',
  'POST_COMMENT',
  'EVENT_INVITATION',
  'BIRTHDAY_ALERT',
  'MESSAGE_NEW',
  'CALL_MISSED',
  'COUNCIL_ANNOUNCEMENT',
  'SECURITY_ALERT'
);

CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  recipient_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  actor_id UUID REFERENCES users(id) ON DELETE SET NULL,
  actor_name VARCHAR(150),
  actor_avatar TEXT,
  type notification_type_enum NOT NULL,
  title VARCHAR(200) NOT NULL,
  body TEXT NOT NULL,
  target_entity_type VARCHAR(64), -- 'POST', 'EVENT', 'MEMBER', 'VERIFICATION', 'CALL'
  target_entity_id VARCHAR(64),
  action_url VARCHAR(255),
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notif_recipient ON notifications(recipient_id, is_read, created_at DESC);

-- --- 21. LIVE STREAMS (Nzala Live Broadcasts) ---
CREATE TYPE live_status_enum AS ENUM ('SCHEDULED', 'LIVE', 'ENDED', 'CANCELLED');

CREATE TABLE live_streams (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  host_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  host_name VARCHAR(150) NOT NULL,
  host_avatar TEXT,
  title VARCHAR(200) NOT NULL,
  description TEXT,
  scope post_scope_enum NOT NULL DEFAULT 'INTER_FAMILLES',
  target_family_id UUID REFERENCES families(id) ON DELETE SET NULL,
  target_branch_id UUID REFERENCES family_branches(id) ON DELETE SET NULL,
  status live_status_enum NOT NULL DEFAULT 'LIVE',
  allow_comments BOOLEAN NOT NULL DEFAULT TRUE,
  scheduled_for TIMESTAMPTZ,
  started_at TIMESTAMPTZ,
  ended_at TIMESTAMPTZ,
  stream_key VARCHAR(128) UNIQUE,
  playback_url TEXT,
  peak_viewers_count INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_live_status ON live_streams(status);

-- --- 22. LIVE VIEWERS ---
CREATE TABLE live_viewers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  live_id UUID NOT NULL REFERENCES live_streams(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_name VARCHAR(150) NOT NULL,
  user_avatar TEXT,
  joined_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  left_at TIMESTAMPTZ,
  is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE INDEX idx_live_viewers_live ON live_viewers(live_id, is_active);

-- --- 23. BLOCKED USERS (Safety & Harassment Prevention) ---
CREATE TABLE blocked_users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  blocker_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  blocked_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reason VARCHAR(255),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_not_self_block CHECK (blocker_id <> blocked_user_id),
  UNIQUE (blocker_id, blocked_user_id)
);

CREATE INDEX idx_blocked_blocker ON blocked_users(blocker_id);
CREATE INDEX idx_blocked_blocked ON blocked_users(blocked_user_id);

-- --- 24. ISSUE REPORTS & MODERATION (Signalements) ---
CREATE TYPE issue_category_enum AS ENUM (
  'BUGS_TECHNIQUES',
  'COMPTE_ET_ACCES',
  'GENEALOGIE_ET_DONNEES',
  'SECURITE_ET_ABUS',
  'SUGGESTIONS_AMELIORATION',
  'AUTRE'
);

CREATE TYPE issue_priority_enum AS ENUM ('BASSE', 'NORMALE', 'HAUTE', 'URGENTE');
CREATE TYPE issue_status_enum AS ENUM ('NOUVEAU', 'EN_COURS', 'RESOLU', 'REJETE');

CREATE TABLE issue_reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  reporter_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reporter_name VARCHAR(150) NOT NULL,
  reporter_email VARCHAR(150) NOT NULL,
  category issue_category_enum NOT NULL,
  priority issue_priority_enum NOT NULL DEFAULT 'NORMALE',
  title VARCHAR(200) NOT NULL,
  description TEXT NOT NULL,
  device_info VARCHAR(200),
  attachments JSONB DEFAULT '[]'::jsonb,
  status issue_status_enum NOT NULL DEFAULT 'NOUVEAU',
  admin_notes TEXT,
  resolved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_issues_status ON issue_reports(status);

-- --- 25. AUDIT LOGS (Immutable Grand Livre d'Audit Familial) ---
CREATE TYPE audit_action_enum AS ENUM (
  'MEMBRE_CREE',
  'MEMBRE_MODIFIE',
  'MEMBRE_ARCHIVE',
  'RELATION_AJOUTEE',
  'RELATION_VALIDEE',
  'RELATION_REFUSEE',
  'ALLIANCE_CREEE',
  'ALLIANCE_RATIFIEE',
  'AFFILIATION_SOUMISE',
  'AFFILIATION_VALIDEE',
  'AFFILIATION_REJETEE',
  'ROLE_MODIFIE',
  'CERTIFICATION_ACCORDEE',
  'CERTIFICATION_REVOQUEE',
  'UTILISATEUR_BLOQUE',
  'MODERATION_SIGNALEMENT_TRAITE',
  'CONFIDENTIALITE_MODIFIEE',
  'PURGE_HISTORIQUE'
);

CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  action audit_action_enum NOT NULL,
  actor_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  actor_name VARCHAR(150) NOT NULL,
  actor_role user_role_enum NOT NULL,
  target_id VARCHAR(64) NOT NULL,
  target_name VARCHAR(150) NOT NULL,
  target_type VARCHAR(64) NOT NULL,
  details TEXT NOT NULL,
  changes_summary JSONB,
  ip_address VARCHAR(45),
  user_agent VARCHAR(255),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_created ON audit_logs(created_at DESC);
CREATE INDEX idx_audit_actor ON audit_logs(actor_id);
CREATE INDEX idx_audit_target ON audit_logs(target_type, target_id);
`;
