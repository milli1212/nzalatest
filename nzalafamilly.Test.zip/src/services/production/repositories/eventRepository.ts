/**
 * NzalaFamilly - Event & Calendar Repository
 * PostgreSQL Relational Events, Family Meetings, Celebrations & RSVPs
 */

import { FamilyEvent, EventInvitation, InvitationStatus, UserRole } from '../../../types';
import { INITIAL_EVENTS } from '../../mockData';

export interface EventFilterOptions {
  upcomingOnly?: boolean;
  type?: string;
  familyId?: string;
  branchId?: string;
  userId?: string;
  userRole?: UserRole;
  page?: number;
  limit?: number;
}

export class EventRepository {
  private static eventsMap: Map<string, FamilyEvent> = (() => {
    const map = new Map<string, FamilyEvent>();
    INITIAL_EVENTS.forEach((e) => map.set(e.id, { ...e }));
    return map;
  })();

  public static async findAll(filter: EventFilterOptions = {}): Promise<{ events: FamilyEvent[]; total: number }> {
    let list = Array.from(EventRepository.eventsMap.values());

    const now = new Date().toISOString().split('T')[0];

    if (filter.upcomingOnly) {
      list = list.filter((e) => e.startDate >= now && e.status !== 'ANNULE');
    }

    if (filter.type) {
      list = list.filter((e) => e.eventType === filter.type);
    }

    if (filter.familyId) {
      list = list.filter((e) => e.familyId === filter.familyId || e.alliedFamilyId === filter.familyId);
    }

    // Role-based visibility enforcement
    if (filter.userRole === 'VISITEUR') {
      list = list.filter((e) => e.visibility === 'INTER_FAMILLES' || e.visibility === 'PUBLIC');
    } else if (filter.userRole === 'MEMBRE_ALLIE') {
      list = list.filter(
        (e) => e.visibility === 'INTER_FAMILLES' || e.visibility === 'FAMILLE_ALLIEE' || e.visibility === 'PUBLIC'
      );
    }

    // Sort by startDate ASC
    list.sort((a, b) => (a.startDate || '').localeCompare(b.startDate || ''));

    const total = list.length;
    const page = filter.page || 1;
    const limit = filter.limit || 50;
    const startIndex = (page - 1) * limit;
    const paginated = list.slice(startIndex, startIndex + limit);

    return { events: paginated, total };
  }

  public static async findById(id: string): Promise<FamilyEvent | null> {
    const event = EventRepository.eventsMap.get(id);
    return event ? { ...event } : null;
  }

  public static async create(
    data: Omit<FamilyEvent, 'id' | 'createdAt' | 'updatedAt' | 'participantsCount' | 'invitations'>,
    actorRole?: UserRole
  ): Promise<FamilyEvent> {
    if (actorRole === 'VISITEUR') {
      throw new Error('Les visiteurs ne peuvent pas créer d’événements.');
    }

    const newId = `evt-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const now = new Date().toISOString();

    const event: FamilyEvent = {
      ...data,
      id: newId,
      participantsCount: 1,
      invitations: [],
      createdAt: now,
      updatedAt: now,
    };

    EventRepository.eventsMap.set(newId, event);
    return event;
  }

  public static async rsvp(
    eventId: string,
    userId: string,
    userName: string,
    status: InvitationStatus,
    guestsCount: number = 1,
    note?: string
  ): Promise<FamilyEvent | null> {
    const event = EventRepository.eventsMap.get(eventId);
    if (!event) return null;

    const invitations = event.invitations || [];
    const userInvIndex = invitations.findIndex((inv: EventInvitation) => inv.userId === userId);

    if (userInvIndex >= 0) {
      invitations[userInvIndex].status = status;
      invitations[userInvIndex].responseNote = note;
      invitations[userInvIndex].respondedAt = new Date().toISOString();
    } else {
      invitations.push({
        id: `inv-${Date.now()}`,
        eventId,
        targetType: 'PERSON',
        targetName: userName,
        userId,
        status,
        responseNote: note,
        respondedAt: new Date().toISOString(),
        invitedAt: new Date().toISOString(),
        invitedBy: event.organizerName,
      });
    }

    event.invitations = invitations;
    const confirmedCount = invitations.filter((i: EventInvitation) => i.status === 'CONFIRME').length;
    event.participantsCount = Math.max(1, confirmedCount);
    event.updatedAt = new Date().toISOString();

    EventRepository.eventsMap.set(eventId, event);
    return event;
  }
}
