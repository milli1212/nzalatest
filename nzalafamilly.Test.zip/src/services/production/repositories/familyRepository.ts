/**
 * NzalaFamilly - Family & Branch Repositories
 * PostgreSQL Relational Data Access for Families & Branches
 */

import { Family, FamilyBranch } from '../../../types';
import { INITIAL_FAMILIES, INITIAL_BRANCHES } from '../../mockData';
import { db } from '../database';

export class FamilyRepository {
  private static familiesMap: Map<string, Family> = (() => {
    const map = new Map<string, Family>();
    INITIAL_FAMILIES.forEach((fam) => map.set(fam.id, { ...fam }));
    return map;
  })();

  public static async findAll(): Promise<Family[]> {
    const res = await db.query<Family>('SELECT * FROM families ORDER BY name ASC');
    if (res.rows.length > 0) return res.rows;
    return Array.from(FamilyRepository.familiesMap.values());
  }

  public static async findById(id: string): Promise<Family | null> {
    const res = await db.query<Family>('SELECT * FROM families WHERE id = $1', [id]);
    if (res.rows.length > 0) return res.rows[0];
    return FamilyRepository.familiesMap.get(id) || null;
  }

  public static async findByCode(code: string): Promise<Family | null> {
    const res = await db.query<Family>('SELECT * FROM families WHERE code = $1', [code]);
    if (res.rows.length > 0) return res.rows[0];
    for (const fam of FamilyRepository.familiesMap.values()) {
      if (fam.code.toLowerCase() === code.toLowerCase()) return { ...fam };
    }
    return null;
  }

  public static async create(family: Omit<Family, 'id'>): Promise<Family> {
    const newId = `fam-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const newFamily: Family = {
      ...family,
      id: newId,
    };
    await db.query(
      `INSERT INTO families (id, name, code, type, status, origin_location, territory, description, founding_year, patriarch_name, badge_color, historical_info)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`,
      [
        newId,
        newFamily.name,
        newFamily.code,
        newFamily.type,
        newFamily.status || 'ACTIVE',
        newFamily.originLocation,
        newFamily.territory,
        newFamily.description,
        newFamily.foundingYear,
        newFamily.patriarchName,
        newFamily.badgeColor,
        newFamily.historicalInfo,
      ]
    );
    FamilyRepository.familiesMap.set(newId, newFamily);
    return newFamily;
  }

  public static async update(id: string, updates: Partial<Family>): Promise<Family | null> {
    const existing = await FamilyRepository.findById(id);
    if (!existing) return null;
    const updated: Family = { ...existing, ...updates };
    FamilyRepository.familiesMap.set(id, updated);
    return updated;
  }
}

export class BranchRepository {
  private static branchesMap: Map<string, FamilyBranch> = (() => {
    const map = new Map<string, FamilyBranch>();
    INITIAL_BRANCHES.forEach((b) => map.set(b.id, { ...b }));
    return map;
  })();

  public static async findAll(): Promise<FamilyBranch[]> {
    const res = await db.query<FamilyBranch>('SELECT * FROM family_branches ORDER BY name ASC');
    if (res.rows.length > 0) return res.rows;
    return Array.from(BranchRepository.branchesMap.values());
  }

  public static async findByFamilyId(familyId: string): Promise<FamilyBranch[]> {
    const all = await BranchRepository.findAll();
    return all.filter((b) => b.familyId === familyId);
  }

  public static async findById(id: string): Promise<FamilyBranch | null> {
    const res = await db.query<FamilyBranch>('SELECT * FROM family_branches WHERE id = $1', [id]);
    if (res.rows.length > 0) return res.rows[0];
    return BranchRepository.branchesMap.get(id) || null;
  }

  public static async create(branch: Omit<FamilyBranch, 'id'>): Promise<FamilyBranch> {
    const newId = `br-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const newBranch: FamilyBranch = {
      ...branch,
      id: newId,
    };
    BranchRepository.branchesMap.set(newId, newBranch);
    return newBranch;
  }
}
