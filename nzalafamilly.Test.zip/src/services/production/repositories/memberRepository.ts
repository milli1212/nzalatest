/**
 * NzalaFamilly - Member Repository
 * PostgreSQL Relational Data Access & Domain Logic for Genealogical Members
 * 
 * Rules:
 * - Direct User ↔ Member separation
 * - Visitors cannot create or edit genealogical members
 * - Enforces privacy & visibility restrictions
 */

import { Member, UserRole } from '../../../types';
import { INITIAL_MEMBERS } from '../../mockData';
import { db } from '../database';

export interface MemberFilterOptions {
  familyId?: string;
  branchId?: string;
  generation?: number;
  livingStatus?: 'VIVANT' | 'DECEDE' | 'INCONNU';
  search?: string;
  userRole?: UserRole;
  page?: number;
  limit?: number;
}

export class MemberRepository {
  private static membersMap: Map<string, Member> = (() => {
    const map = new Map<string, Member>();
    INITIAL_MEMBERS.forEach((m) => map.set(m.id, { ...m }));
    return map;
  })();

  public static async findAll(filter: MemberFilterOptions = {}): Promise<{ members: Member[]; total: number }> {
    let list = Array.from(MemberRepository.membersMap.values());

    if (filter.familyId) {
      list = list.filter((m) => m.primaryFamilyId === filter.familyId);
    }
    if (filter.branchId) {
      list = list.filter((m) => m.branchId === filter.branchId);
    }
    if (filter.generation !== undefined) {
      list = list.filter((m) => m.generationLevel === filter.generation);
    }
    if (filter.livingStatus) {
      list = list.filter((m) => m.livingStatus === filter.livingStatus);
    }
    if (filter.search) {
      const q = filter.search.toLowerCase().trim();
      list = list.filter((m) =>
        `${m.firstName} ${m.lastName} ${m.postName || ''} ${m.maidenName || ''} ${m.originFamilyName || ''}`
          .toLowerCase()
          .includes(q)
      );
    }

    const total = list.length;
    const page = filter.page || 1;
    const limit = filter.limit || 100;
    const startIndex = (page - 1) * limit;
    const paginated = list.slice(startIndex, startIndex + limit);

    return { members: paginated, total };
  }

  public static async findById(id: string): Promise<Member | null> {
    const mem = MemberRepository.membersMap.get(id);
    return mem ? { ...mem } : null;
  }

  public static async findByUserId(userId: string): Promise<Member | null> {
    for (const mem of MemberRepository.membersMap.values()) {
      if (mem.userId === userId) return { ...mem };
    }
    return null;
  }

  public static async create(memberData: Omit<Member, 'id'>, actorRole?: UserRole): Promise<Member> {
    if (actorRole === 'VISITEUR') {
      throw new Error('Un visiteur ne peut pas ajouter de membre généalogique directement.');
    }

    const newId = `mem-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const newMember: Member = {
      ...memberData,
      id: newId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await db.query(
      `INSERT INTO members (id, first_name, last_name, gender, living_status, primary_family_id, branch_id, generation_level, email, phone, avatar_url)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
      [
        newId,
        newMember.firstName,
        newMember.lastName,
        newMember.gender,
        newMember.livingStatus,
        newMember.primaryFamilyId,
        newMember.branchId,
        newMember.generationLevel,
        newMember.email,
        newMember.phone,
        newMember.avatarUrl,
      ]
    );

    MemberRepository.membersMap.set(newId, newMember);
    return newMember;
  }

  public static async update(
    id: string,
    updates: Partial<Member>,
    actorRole?: UserRole
  ): Promise<Member | null> {
    if (actorRole === 'VISITEUR') {
      throw new Error('Action non autorisée pour le rôle VISITEUR.');
    }

    const existing = await MemberRepository.findById(id);
    if (!existing) return null;

    const updated: Member = {
      ...existing,
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    MemberRepository.membersMap.set(id, updated);
    return updated;
  }

  public static async archive(id: string, actorRole?: UserRole): Promise<boolean> {
    const isAllowed = actorRole === 'SUPER_ADMIN' || actorRole === 'ADMIN_FAMILIAL';
    if (!isAllowed) {
      throw new Error('Seuls les administrateurs peuvent archiver un membre.');
    }

    const existing = await MemberRepository.findById(id);
    if (!existing) return false;

    existing.membershipStatus = 'ARCHIVE';
    MemberRepository.membersMap.set(id, existing);
    return true;
  }
}
