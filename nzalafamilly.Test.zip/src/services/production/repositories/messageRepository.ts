/**
 * NzalaFamilly - Message & Conversation Repository
 * PostgreSQL / Redis Real-Time Store for Private Messages, Audio Notes & View-Once Ephemeral Media
 */

import { FamilyConversation, FamilyMessage, ConversationType, ConversationParticipant, UserRole } from '../../../types';
import { INITIAL_CONVERSATIONS, INITIAL_MESSAGES } from '../../messagingMockData';

export class ConversationRepository {
  private static conversationsMap: Map<string, FamilyConversation> = (() => {
    const map = new Map<string, FamilyConversation>();
    INITIAL_CONVERSATIONS.forEach((c: FamilyConversation) => map.set(c.id, { ...c }));
    return map;
  })();

  public static async findForUser(userId: string): Promise<FamilyConversation[]> {
    return Array.from(ConversationRepository.conversationsMap.values())
      .filter((c) => c.participants.some((p) => p.userId === userId))
      .sort((a, b) => {
        const timeA = a.lastMessage?.createdAt ? new Date(a.lastMessage.createdAt).getTime() : 0;
        const timeB = b.lastMessage?.createdAt ? new Date(b.lastMessage.createdAt).getTime() : 0;
        return timeB - timeA;
      });
  }

  public static async findById(id: string): Promise<FamilyConversation | null> {
    const conv = ConversationRepository.conversationsMap.get(id);
    return conv ? { ...conv } : null;
  }

  public static async create(data: {
    type: ConversationType;
    title?: string;
    avatarUrl?: string;
    participants: Array<{ userId: string; userName: string; userAvatar?: string; role?: 'ADMIN' | 'MEMBER'; joinedAt?: string; unreadCount?: number }>;
    createdBy: string;
  }): Promise<FamilyConversation> {
    const newId = `conv-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const now = new Date().toISOString();

    const formattedParticipants: ConversationParticipant[] = data.participants.map((p) => ({
      userId: p.userId,
      userName: p.userName,
      userAvatar: p.userAvatar,
      role: p.role || 'MEMBER',
      joinedAt: p.joinedAt || now,
      unreadCount: p.unreadCount || 0,
    }));

    const conversation: FamilyConversation = {
      id: newId,
      type: data.type,
      title: data.title,
      avatarUrl: data.avatarUrl,
      participants: formattedParticipants,
      participantIds: formattedParticipants.map((p) => p.userId),
      admins: [data.createdBy],
      createdBy: data.createdBy,
      createdAt: now,
      updatedAt: now,
    };

    ConversationRepository.conversationsMap.set(newId, conversation);
    return conversation;
  }
}

export class MessageRepository {
  private static messagesMap: Map<string, FamilyMessage[]> = (() => {
    const map = new Map<string, FamilyMessage[]>();
    INITIAL_MESSAGES.forEach((m: FamilyMessage) => {
      const list = map.get(m.conversationId) || [];
      list.push({ ...m });
      map.set(m.conversationId, list);
    });
    return map;
  })();

  public static async findByConversation(conversationId: string, limit: number = 50): Promise<FamilyMessage[]> {
    const list = MessageRepository.messagesMap.get(conversationId) || [];
    return list.slice(-limit);
  }

  public static async create(
    conversationId: string,
    messageData: Omit<FamilyMessage, 'id' | 'createdAt' | 'status' | 'readByUserIds' | 'reactions'>
  ): Promise<FamilyMessage> {
    const newId = `msg-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const now = new Date().toISOString();

    const msg: FamilyMessage = {
      ...messageData,
      id: newId,
      conversationId,
      createdAt: now,
      status: 'ENVOYE',
      readByUserIds: [messageData.senderId],
      reactions: [],
    };

    const list = MessageRepository.messagesMap.get(conversationId) || [];
    list.push(msg);
    MessageRepository.messagesMap.set(conversationId, list);

    // Update conversation lastMessage
    const conv = await ConversationRepository.findById(conversationId);
    if (conv) {
      conv.lastMessage = {
        id: msg.id,
        content: msg.content,
        senderId: msg.senderId,
        senderName: msg.senderName,
        createdAt: msg.createdAt,
        mediaType: msg.mediaType,
        status: msg.status,
      };
      conv.updatedAt = now;
    }

    return msg;
  }

  public static async markAllRead(conversationId: string, userId: string): Promise<void> {
    const list = MessageRepository.messagesMap.get(conversationId) || [];
    list.forEach((m) => {
      if (!m.readByUserIds.includes(userId)) {
        m.readByUserIds.push(userId);
      }
      if (m.senderId !== userId) {
        m.status = 'LU';
      }
    });

    const conv = await ConversationRepository.findById(conversationId);
    if (conv) {
      const p = conv.participants.find((part) => part.userId === userId);
      if (p) p.unreadCount = 0;
    }
  }

  public static async consumeViewOnce(messageId: string, userId: string): Promise<{ success: boolean; message?: string }> {
    for (const [, messages] of MessageRepository.messagesMap.entries()) {
      const msg = messages.find((m) => m.id === messageId);
      if (msg) {
        if (!msg.isViewOnce) {
          return { success: false, message: 'Ce message n’est pas en vue unique.' };
        }
        if (msg.viewOnceState === 'VIEWED' || msg.viewOnceState === 'EXPIRED') {
          return { success: false, message: 'Ce média à vue unique a déjà été consulté.' };
        }

        msg.viewOnceState = 'VIEWED';
        msg.viewOnceOpenedAt = new Date().toISOString();
        msg.viewOnceOpenedByUserId = userId;
        return { success: true };
      }
    }
    return { success: false, message: 'Message introuvable.' };
  }
}
