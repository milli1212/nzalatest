/**
 * NzalaFamilly - Notification, Audit & Privacy Repository
 * PostgreSQL tables for System Events, Moderation Audits & User Privacy Directives
 */

import { FamilyNotification, AuditLog, UserPrivacySettings, UserRole } from '../../../types';
import { INITIAL_AUDIT_LOGS } from '../../mockData';

export class NotificationRepository {
  private static notificationsMap: Map<string, FamilyNotification[]> = new Map();

  public static async findForUser(userId: string): Promise<FamilyNotification[]> {
    const direct = NotificationRepository.notificationsMap.get(userId) || [];
    const broadcast = NotificationRepository.notificationsMap.get('all') || [];
    const merged = [...direct, ...broadcast];
    merged.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return merged;
  }

  public static async create(notificationData: Omit<FamilyNotification, 'id' | 'createdAt' | 'read'>): Promise<FamilyNotification> {
    const newId = `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const notification: FamilyNotification = {
      ...notificationData,
      id: newId,
      read: false,
      isRead: false,
      createdAt: new Date().toISOString(),
    };

    const targetUser = notificationData.userId || 'all';
    const list = NotificationRepository.notificationsMap.get(targetUser) || [];
    list.push(notification);
    NotificationRepository.notificationsMap.set(targetUser, list);

    return notification;
  }

  public static async markAsRead(notificationId: string, userId: string): Promise<boolean> {
    const userList = NotificationRepository.notificationsMap.get(userId) || [];
    const broadcastList = NotificationRepository.notificationsMap.get('all') || [];

    let found = false;
    userList.forEach((n) => {
      if (n.id === notificationId) {
        n.read = true;
        n.isRead = true;
        n.readAt = new Date().toISOString();
        found = true;
      }
    });

    broadcastList.forEach((n) => {
      if (n.id === notificationId) {
        n.read = true;
        n.isRead = true;
        found = true;
      }
    });

    return found;
  }
}

export class AuditRepository {
  private static logsList: AuditLog[] = (() => {
    return INITIAL_AUDIT_LOGS.map((l: AuditLog) => ({ ...l }));
  })();

  public static async record(logData: {
    action: string;
    actorName: string;
    actorRole: UserRole;
    actionType?: import('../../../types').AuditActionType;
    targetType?: import('../../../types').AuditTargetType;
    targetId?: string;
    targetName?: string;
    actorId?: string;
    details: string;
  }): Promise<AuditLog> {
    const newId = `audit-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const log: AuditLog = {
      id: newId,
      actorName: logData.actorName,
      actorRole: logData.actorRole,
      action: logData.action,
      actionType: logData.actionType || 'SECURITY',
      targetType: logData.targetType || 'MEMBER',
      targetId: logData.targetId || '',
      targetName: logData.targetName || '',
      details: logData.details,
      timestamp: new Date().toISOString(),
    };

    AuditRepository.logsList.unshift(log);
    return log;
  }

  public static async findLogs(options: { action?: string; limit?: number; actorRole?: UserRole } = {}): Promise<AuditLog[]> {
    if (options.actorRole === 'VISITEUR') {
      throw new Error('Accès interdit aux journaux d’audit.');
    }

    let logs = [...AuditRepository.logsList];
    if (options.action) {
      logs = logs.filter((l) => l.action.includes(options.action!));
    }

    return logs.slice(0, options.limit || 100);
  }
}

export interface ProfileAccessRequest {
  id: string;
  requesterUserId: string;
  requesterName: string;
  requesterAvatar?: string;
  targetUserId: string;
  status: 'PENDING' | 'ACCEPTED' | 'REJECTED';
  createdAt: string;
  respondedAt?: string;
}

export class ProfilePrivacyRepository {
  private static privacySettingsMap: Map<string, UserPrivacySettings> = new Map();
  private static accessRequestsMap: Map<string, ProfileAccessRequest> = new Map();
  private static authorizedProfilesMap: Map<string, Set<string>> = new Map();

  public static async getSettings(userId: string): Promise<UserPrivacySettings> {
    const existing = ProfilePrivacyRepository.privacySettingsMap.get(userId);
    if (existing) return existing;

    const defaultSettings: UserPrivacySettings = {
      whoCanMessageMe: 'TOUS_AUTORISES',
      whoCanCallMe: 'TOUS_AUTORISES',
      whoCanSeeOnlineStatus: 'TOUS_AUTORISES',
      whoCanSeeStories: 'TOUS_AUTORISES',
      whoCanSeePosts: 'TOUS_AUTORISES',
      whoCanMentionMe: 'TOUS_AUTORISES',
      showOnlineStatus: true,
      showReadReceipts: true,
    };

    ProfilePrivacyRepository.privacySettingsMap.set(userId, defaultSettings);
    return defaultSettings;
  }

  public static async updateSettings(userId: string, updates: Partial<UserPrivacySettings>): Promise<UserPrivacySettings> {
    const current = await ProfilePrivacyRepository.getSettings(userId);
    const updated = { ...current, ...updates };
    ProfilePrivacyRepository.privacySettingsMap.set(userId, updated);
    return updated;
  }

  public static async requestProfileAccess(
    requesterUserId: string,
    requesterName: string,
    requesterAvatar: string | undefined,
    targetUserId: string
  ): Promise<ProfileAccessRequest> {
    const newId = `req-access-${Date.now()}`;
    const req: ProfileAccessRequest = {
      id: newId,
      requesterUserId,
      requesterName,
      requesterAvatar,
      targetUserId,
      status: 'PENDING',
      createdAt: new Date().toISOString(),
    };

    ProfilePrivacyRepository.accessRequestsMap.set(newId, req);

    await NotificationRepository.create({
      userId: targetUserId,
      category: 'SECURITY',
      type: 'DEMANDE_ACCES_PROFIL',
      title: 'Demande d’accès au profil',
      body: `${requesterName} demande à voir l’intégralité de votre profil privé.`,
      targetId: newId,
      targetType: 'PROFILE',
      senderId: requesterUserId,
      senderName: requesterName,
      senderAvatar: requesterAvatar,
    });

    return req;
  }

  public static async respondToAccessRequest(
    requestId: string,
    targetUserId: string,
    accept: boolean
  ): Promise<ProfileAccessRequest | null> {
    const req = ProfilePrivacyRepository.accessRequestsMap.get(requestId);
    if (!req || req.targetUserId !== targetUserId) return null;

    req.status = accept ? 'ACCEPTED' : 'REJECTED';
    req.respondedAt = new Date().toISOString();

    if (accept) {
      const authorizedSet = ProfilePrivacyRepository.authorizedProfilesMap.get(targetUserId) || new Set();
      authorizedSet.add(req.requesterUserId);
      ProfilePrivacyRepository.authorizedProfilesMap.set(targetUserId, authorizedSet);
    }

    await NotificationRepository.create({
      userId: req.requesterUserId,
      category: 'SECURITY',
      type: accept ? 'ACCES_PROFIL_ACCEPTE' : 'ACCES_PROFIL_REFUSE',
      title: accept ? 'Accès profil accordé' : 'Accès profil refusé',
      body: accept
        ? 'Votre demande d’accès au profil a été acceptée.'
        : 'Votre demande d’accès au profil a été déclinée.',
      targetId: req.targetUserId,
      targetType: 'PROFILE',
    });

    return req;
  }

  public static isUserAuthorized(targetUserId: string, viewerUserId: string): boolean {
    if (targetUserId === viewerUserId) return true;
    const authorizedSet = ProfilePrivacyRepository.authorizedProfilesMap.get(targetUserId);
    return authorizedSet ? authorizedSet.has(viewerUserId) : false;
  }
}
