/**
 * NzalaFamilly - Post Repository
 * PostgreSQL Relational Data Access for Family Feed, Posts, Reactions & Comments
 */

import { FamilyPost, PostComment, PostReaction, ReactionType, UserRole } from '../../../types';
import { INITIAL_POSTS } from '../../mockData';
import { db } from '../database';

export interface PostFilterOptions {
  scope?: string;
  familyId?: string;
  authorId?: string;
  userRole?: UserRole;
  page?: number;
  limit?: number;
}

export class PostRepository {
  private static postsMap: Map<string, FamilyPost> = (() => {
    const map = new Map<string, FamilyPost>();
    INITIAL_POSTS.forEach((p) => map.set(p.id, { ...p }));
    return map;
  })();

  public static async findFeed(filter: PostFilterOptions = {}): Promise<{ posts: FamilyPost[]; total: number }> {
    let list = Array.from(PostRepository.postsMap.values());

    // Filter by status (exclude archived/suspended by default)
    list = list.filter((p) => p.status === 'PUBLIE');

    // Role-based scope filtering (Server-Side RBAC)
    if (filter.userRole === 'VISITEUR') {
      list = list.filter((p) => p.scope === 'INTER_FAMILLES' || p.scope === 'PUBLIC');
    } else if (filter.userRole === 'MEMBRE_ALLIE') {
      list = list.filter((p) => p.scope === 'INTER_FAMILLES' || p.scope === 'FAMILLE_ALLIEE' || p.scope === 'PUBLIC');
    }

    if (filter.authorId) {
      list = list.filter((p) => p.authorId === filter.authorId);
    }
    if (filter.scope) {
      list = list.filter((p) => p.scope === filter.scope);
    }

    // Sort by createdAt DESC
    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const total = list.length;
    const page = filter.page || 1;
    const limit = filter.limit || 20;
    const startIndex = (page - 1) * limit;
    const paginated = list.slice(startIndex, startIndex + limit);

    return { posts: paginated, total };
  }

  public static async findById(id: string): Promise<FamilyPost | null> {
    const post = PostRepository.postsMap.get(id);
    return post ? { ...post } : null;
  }

  public static async create(postData: Omit<FamilyPost, 'id' | 'createdAt' | 'updatedAt' | 'reactions' | 'reactionsCount' | 'comments' | 'commentsCount'>, actorRole?: UserRole): Promise<FamilyPost> {
    if (actorRole === 'VISITEUR') {
      throw new Error('Les visiteurs ne peuvent pas publier dans le fil familial.');
    }

    const newId = `post-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const now = new Date().toISOString();

    const newPost: FamilyPost = {
      ...postData,
      id: newId,
      createdAt: now,
      updatedAt: now,
      reactionsCount: 0,
      commentsCount: 0,
      reactions: [],
      comments: [],
    };

    PostRepository.postsMap.set(newId, newPost);
    return newPost;
  }

  public static async react(
    postId: string,
    userId: string,
    userName: string,
    reactionType: ReactionType
  ): Promise<FamilyPost | null> {
    const post = await PostRepository.findById(postId);
    if (!post) return null;

    const existingReactions = post.reactions || [];
    const userReactionIndex = existingReactions.findIndex((r) => r.userId === userId);

    if (userReactionIndex >= 0) {
      if (existingReactions[userReactionIndex].reactionType === reactionType) {
        // Remove reaction
        existingReactions.splice(userReactionIndex, 1);
      } else {
        // Change reaction type
        existingReactions[userReactionIndex].reactionType = reactionType;
      }
    } else {
      existingReactions.push({
        id: `react-${Date.now()}`,
        postId,
        userId,
        userName,
        reactionType,
        createdAt: new Date().toISOString(),
      });
    }

    post.reactions = existingReactions;
    post.reactionsCount = existingReactions.length;
    PostRepository.postsMap.set(postId, post);
    return post;
  }

  public static async comment(
    postId: string,
    commentData: {
      authorId: string;
      authorName: string;
      authorRole: UserRole;
      authorAvatar?: string;
      content: string;
    }
  ): Promise<PostComment | null> {
    const post = await PostRepository.findById(postId);
    if (!post) return null;

    const newComment: PostComment = {
      id: `comm-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      postId,
      authorId: commentData.authorId,
      authorName: commentData.authorName,
      authorRole: commentData.authorRole,
      authorAvatar: commentData.authorAvatar,
      content: commentData.content,
      createdAt: new Date().toISOString(),
      status: 'ACTIF',
    };

    const existingComments = post.comments || [];
    existingComments.push(newComment);
    post.comments = existingComments;
    post.commentsCount = existingComments.length;

    PostRepository.postsMap.set(postId, post);
    return newComment;
  }

  public static async delete(postId: string, actorId: string, actorRole?: UserRole): Promise<boolean> {
    const post = await PostRepository.findById(postId);
    if (!post) return false;

    const isAuthor = post.authorId === actorId;
    const isAdmin = actorRole === 'SUPER_ADMIN' || actorRole === 'ADMIN_FAMILIAL';

    if (!isAuthor && !isAdmin) {
      throw new Error('Vous n’avez pas l’autorisation de supprimer cette publication.');
    }

    return PostRepository.postsMap.delete(postId);
  }
}
