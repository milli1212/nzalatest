/**
 * NzalaFamilly - Relationship & Alliance Repository
 * Relational Kinship, Lineage Links and Allied Family Alliances
 */

import { Relationship, Alliance, RelationshipType, RelationshipStatus, AllianceStatus, UserRole } from '../../../types';
import { INITIAL_RELATIONSHIPS, INITIAL_ALLIANCES } from '../../mockData';

export class RelationshipRepository {
  private static relationshipsMap: Map<string, Relationship> = (() => {
    const map = new Map<string, Relationship>();
    INITIAL_RELATIONSHIPS.forEach((r) => map.set(r.id, { ...r }));
    return map;
  })();

  public static async findAll(): Promise<Relationship[]> {
    return Array.from(RelationshipRepository.relationshipsMap.values());
  }

  public static async findByMemberId(memberId: string): Promise<Relationship[]> {
    return Array.from(RelationshipRepository.relationshipsMap.values()).filter(
      (r) => r.memberAId === memberId || r.memberBId === memberId
    );
  }

  public static async create(
    data: Omit<Relationship, 'id' | 'createdAt' | 'updatedAt' | 'status'> & { status?: RelationshipStatus },
    actorRole?: UserRole
  ): Promise<Relationship> {
    const newId = `rel-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const now = new Date().toISOString();

    const isDirectApproved = actorRole === 'SUPER_ADMIN' || actorRole === 'ADMIN_FAMILIAL' || actorRole === 'VALIDATEUR';

    const relationship: Relationship = {
      ...data,
      id: newId,
      status: data.status || (isDirectApproved ? 'VALIDEE' : 'PROPOSEE'),
      createdAt: now,
      updatedAt: now,
    };

    RelationshipRepository.relationshipsMap.set(newId, relationship);
    return relationship;
  }

  public static async validate(
    relationshipId: string,
    validatorId: string,
    actorRole?: UserRole
  ): Promise<Relationship | null> {
    if (actorRole === 'VISITEUR' || actorRole === 'MEMBRE_ALLIE') {
      throw new Error('Permissions insuffisantes pour valider une relation de parenté.');
    }

    const rel = RelationshipRepository.relationshipsMap.get(relationshipId);
    if (!rel) return null;

    rel.status = 'VALIDEE';
    rel.validatedBy = validatorId;
    rel.validatedAt = new Date().toISOString();
    rel.updatedAt = new Date().toISOString();

    RelationshipRepository.relationshipsMap.set(relationshipId, rel);
    return rel;
  }
}

export class AllianceRepository {
  private static alliancesMap: Map<string, Alliance> = (() => {
    const map = new Map<string, Alliance>();
    INITIAL_ALLIANCES.forEach((a) => map.set(a.id, { ...a }));
    return map;
  })();

  public static async findAll(): Promise<Alliance[]> {
    return Array.from(AllianceRepository.alliancesMap.values());
  }

  public static async findById(id: string): Promise<Alliance | null> {
    const a = AllianceRepository.alliancesMap.get(id);
    return a ? { ...a } : null;
  }

  public static async create(
    data: Omit<Alliance, 'id' | 'createdAt' | 'updatedAt'>,
    actorRole?: UserRole
  ): Promise<Alliance> {
    if (actorRole === 'VISITEUR') {
      throw new Error('Permissions insuffisantes pour enregistrer une alliance.');
    }

    const newId = `all-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const now = new Date().toISOString();

    const alliance: Alliance = {
      ...data,
      id: newId,
      createdAt: now,
      updatedAt: now,
    };

    AllianceRepository.alliancesMap.set(newId, alliance);
    return alliance;
  }

  public static async ratify(
    allianceId: string,
    actorRole?: UserRole
  ): Promise<Alliance | null> {
    if (actorRole !== 'SUPER_ADMIN' && actorRole !== 'ADMIN_FAMILIAL' && actorRole !== 'VALIDATEUR') {
      throw new Error('Seuls les Sages et Administrateurs peuvent ratifier une alliance.');
    }

    const alliance = AllianceRepository.alliancesMap.get(allianceId);
    if (!alliance) return null;

    alliance.status = 'APPROUVEE';
    alliance.updatedAt = new Date().toISOString();
    AllianceRepository.alliancesMap.set(allianceId, alliance);
    return alliance;
  }
}
