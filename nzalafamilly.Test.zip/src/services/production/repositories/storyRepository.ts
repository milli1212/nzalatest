/**
 * NzalaFamilly - Story & Status Repository
 * Ephemeral (24h) Family Stories, Statuses & Reactions
 */

import { FamilyStory, FamilyStatusItem, StoryViewer, StoryReaction, UserRole } from '../../../types';
import { INITIAL_STORIES, INITIAL_STATUSES } from '../../mockData';

export class StoryRepository {
  private static storiesMap: Map<string, FamilyStory> = (() => {
    const map = new Map<string, FamilyStory>();
    INITIAL_STORIES.forEach((s: FamilyStory) => map.set(s.id, { ...s }));
    return map;
  })();

  public static async findActive(userRole?: UserRole): Promise<FamilyStory[]> {
    const now = new Date();
    let stories = Array.from(StoryRepository.storiesMap.values());

    // Exclude expired stories (> 24 hours)
    stories = stories.filter((s) => {
      const expiresAt = new Date(s.expiresAt);
      return expiresAt.getTime() > now.getTime();
    });

    // Server-Side RBAC Filtering
    if (userRole === 'VISITEUR') {
      stories = stories.filter((s) => s.scope === 'INTER_FAMILLES' || s.scope === 'PUBLIC');
    }

    stories.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return stories;
  }

  public static async create(
    data: Omit<FamilyStory, 'id' | 'createdAt' | 'expiresAt' | 'viewedByUserIds' | 'views' | 'reactions'>,
    actorRole?: UserRole
  ): Promise<FamilyStory> {
    if (actorRole === 'VISITEUR') {
      throw new Error('Les visiteurs ne peuvent pas publier de stories.');
    }

    const newId = `story-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const now = new Date();
    const expiresAt = new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString();

    const story: FamilyStory = {
      ...data,
      id: newId,
      createdAt: now.toISOString(),
      expiresAt,
      viewedByUserIds: [],
      views: [],
      reactions: [],
    };

    StoryRepository.storiesMap.set(newId, story);
    return story;
  }

  public static async recordView(storyId: string, userId: string, userName: string, userAvatar?: string): Promise<FamilyStory | null> {
    const story = StoryRepository.storiesMap.get(storyId);
    if (!story) return null;

    if (!story.viewedByUserIds.includes(userId)) {
      story.viewedByUserIds.push(userId);
    }

    const views = story.views || [];
    if (!views.some((v: StoryViewer) => v.userId === userId)) {
      views.push({
        userId,
        userName,
        userAvatar,
        viewedAt: new Date().toISOString(),
      });
      story.views = views;
    }

    StoryRepository.storiesMap.set(storyId, story);
    return story;
  }

  public static async react(storyId: string, userId: string, userName: string, emoji: string): Promise<FamilyStory | null> {
    const story = StoryRepository.storiesMap.get(storyId);
    if (!story) return null;

    const reactions = story.reactions || [];
    const newReaction: StoryReaction = {
      id: `sreact-${Date.now()}`,
      userId,
      userName,
      reaction: emoji,
      createdAt: new Date().toISOString(),
    };

    reactions.push(newReaction);
    story.reactions = reactions;
    StoryRepository.storiesMap.set(storyId, story);
    return story;
  }
}

export class StatusRepository {
  private static statusesMap: Map<string, FamilyStatusItem> = (() => {
    const map = new Map<string, FamilyStatusItem>();
    INITIAL_STATUSES.forEach((st: FamilyStatusItem) => map.set(st.id, { ...st }));
    return map;
  })();

  public static async findAll(): Promise<FamilyStatusItem[]> {
    return Array.from(StatusRepository.statusesMap.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  public static async create(data: Omit<FamilyStatusItem, 'id' | 'createdAt'>): Promise<FamilyStatusItem> {
    const newId = `status-${Date.now()}`;
    const status: FamilyStatusItem = {
      ...data,
      id: newId,
      createdAt: new Date().toISOString(),
    };
    StatusRepository.statusesMap.set(newId, status);
    return status;
  }
}
