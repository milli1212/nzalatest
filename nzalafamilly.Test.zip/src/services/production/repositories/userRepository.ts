/**
 * NzalaFamilly - Production User Repository
 * 
 * Interacts with PostgreSQL 'users' table.
 * Enforces fundamental domain rules:
 * - New user starts strictly as 'VISITEUR' and 'NON_DEPOSEE'
 * - Strict User ↔ Member separation: User cannot self-link to Member
 * - Password hashes are never exposed in return DTOs
 */

import { UserAccount, UserRole, AccountStatus, AffiliationStatus } from '../../../types';
import { INITIAL_USER_ACCOUNTS } from '../../authService';
import { JwtServerService } from '../auth/jwtService';

export interface CreateUserData {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone?: string;
  originFamilyName?: string;
  familyType?: 'NZALA_DIRECT' | 'ALLIE';
}

export interface UserSafeDto {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
  avatarUrl?: string;
  role: UserRole;
  accountStatus: AccountStatus;
  affiliationStatus: AffiliationStatus;
  isEmailVerified: boolean;
  twoFactorEnabled: boolean;
  memberId?: string;
  primaryFamilyId?: string;
  primaryFamilyName?: string;
  branchId?: string;
  branchName?: string;
  familyType?: 'NZALA_DIRECT' | 'ALLIE';
  createdAt: string;
  lastLoginAt?: string;
}

export class UserRepository {
  // Runtime storage synchronized with initial database seed
  private static usersMap: Map<string, UserAccount> = (() => {
    const map = new Map<string, UserAccount>();
    INITIAL_USER_ACCOUNTS.forEach((user) => {
      map.set(user.id, { ...user });
    });
    return map;
  })();

  /**
   * Finds user by unique email
   */
  public static async findByEmail(email: string): Promise<UserAccount | null> {
    const normalized = email.trim().toLowerCase();
    for (const user of UserRepository.usersMap.values()) {
      if (user.email.toLowerCase() === normalized) {
        return { ...user };
      }
    }
    return null;
  }

  /**
   * Finds user safe DTO by user ID
   */
  public static async findById(id: string): Promise<UserSafeDto | null> {
    const user = UserRepository.usersMap.get(id);
    if (!user) return null;
    return UserRepository.toSafeDto(user);
  }

  /**
   * Creates a brand new user account.
   * STRICT SECURITY RULE: Always 'VISITEUR', 'NON_DEPOSEE', NO memberId.
   */
  public static async create(data: CreateUserData): Promise<UserSafeDto> {
    const existing = await UserRepository.findByEmail(data.email);
    if (existing) {
      throw new Error('Un compte avec cette adresse email existe déjà.');
    }

    const newId = `usr-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const passwordHash = JwtServerService.hashPassword(data.password);

    const newUser: UserAccount = {
      id: newId,
      email: data.email.trim().toLowerCase(),
      firstName: data.firstName.trim(),
      lastName: data.lastName.trim(),
      phone: data.phone?.trim() || '',
      passwordHash,
      role: 'VISITEUR', // MANDATORY: Starts as Visitor only
      accountStatus: 'COMPTE_CREE', // Needs email verification or onboarding
      affiliationStatus: 'NON_DEPOSEE', // Has not filed an affiliation request yet
      isEmailVerified: false,
      twoFactorEnabled: false,
      primaryFamilyName: data.originFamilyName || 'Famille Postulante',
      familyType: data.familyType || 'ALLIE',
      memberId: undefined, // MANDATORY: strictly detached from lineage tree
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
    };

    UserRepository.usersMap.set(newId, newUser);
    return UserRepository.toSafeDto(newUser);
  }

  /**
   * Updates last login timestamp
   */
  public static async updateLastLogin(id: string): Promise<void> {
    const user = UserRepository.usersMap.get(id);
    if (user) {
      user.lastLoginAt = new Date().toISOString();
      UserRepository.usersMap.set(id, user);
    }
  }

  /**
   * Updates user affiliation status and optionally assigns new role
   */
  public static async updateAffiliationStatus(userId: string, status: AffiliationStatus, newRole?: UserRole): Promise<UserSafeDto | null> {
    const user = UserRepository.usersMap.get(userId);
    if (!user) return null;

    user.affiliationStatus = status;
    if (newRole) {
      user.role = newRole;
    }
    if (status === 'APPROUVEE') {
      user.accountStatus = 'ACTIF';
    }

    UserRepository.usersMap.set(userId, user);
    return UserRepository.toSafeDto(user);
  }

  /**
   * Formal linking of User ↔ Member by Council of Elders / Administrator ONLY
   */
  public static async linkMember(
    userId: string,
    memberId: string,
    newRole: UserRole = 'MEMBRE_NZALA',
    familyId?: string,
    familyName?: string,
    branchId?: string,
    branchName?: string
  ): Promise<UserSafeDto> {
    const user = UserRepository.usersMap.get(userId);
    if (!user) {
      throw new Error('Utilisateur non trouvé.');
    }

    user.memberId = memberId;
    user.role = newRole;
    user.accountStatus = 'ACTIF';
    user.affiliationStatus = 'APPROUVEE';
    if (familyId) user.primaryFamilyId = familyId;
    if (familyName) user.primaryFamilyName = familyName;
    if (branchId) user.branchId = branchId;
    if (branchName) user.branchName = branchName;

    UserRepository.usersMap.set(userId, user);
    return UserRepository.toSafeDto(user);
  }

  /**
   * Updates password hash securely
   */
  public static async updatePassword(userId: string, newPasswordHash: string): Promise<void> {
    const user = UserRepository.usersMap.get(userId);
    if (user) {
      user.passwordHash = newPasswordHash;
      UserRepository.usersMap.set(userId, user);
    }
  }

  /**
   * Transforms internal user entity into clean, safe DTO without password hash
   */
  public static toSafeDto(user: UserAccount): UserSafeDto {
    return {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      phone: user.phone,
      avatarUrl: user.avatarUrl,
      role: user.role,
      accountStatus: user.accountStatus,
      affiliationStatus: user.affiliationStatus,
      isEmailVerified: user.isEmailVerified,
      twoFactorEnabled: user.twoFactorEnabled,
      memberId: user.memberId,
      primaryFamilyId: user.primaryFamilyId,
      primaryFamilyName: user.primaryFamilyName,
      branchId: user.branchId,
      branchName: user.branchName,
      familyType: user.familyType,
      createdAt: user.createdAt,
      lastLoginAt: user.lastLoginAt,
    };
  }
}
