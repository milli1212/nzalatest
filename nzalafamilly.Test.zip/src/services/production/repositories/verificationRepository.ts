/**
 * NzalaFamilly - Verification & Affiliation Repository
 * Multi-Stage Verification Pipeline for Family Membership Validation
 */

import { VerificationRequest, VerificationStatus, UserRole } from '../../../types';
import { INITIAL_VERIFICATION_REQUESTS } from '../../mockData';
import { UserRepository } from './userRepository';
import { MemberRepository } from './memberRepository';
import { AuditRepository } from './notificationRepository';

export class VerificationRepository {
  private static requestsMap: Map<string, VerificationRequest> = (() => {
    const map = new Map<string, VerificationRequest>();
    INITIAL_VERIFICATION_REQUESTS.forEach((r) => map.set(r.id, { ...r }));
    return map;
  })();

  public static async findAll(actorRole?: UserRole): Promise<VerificationRequest[]> {
    if (actorRole === 'VISITEUR' || actorRole === 'MEMBRE_ALLIE') {
      throw new Error('Accès interdit aux dossiers d’affiliation.');
    }

    return Array.from(VerificationRepository.requestsMap.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  public static async findById(id: string): Promise<VerificationRequest | null> {
    const req = VerificationRepository.requestsMap.get(id);
    return req ? { ...req } : null;
  }

  public static async submit(
    data: Omit<VerificationRequest, 'id' | 'createdAt' | 'updatedAt' | 'status'>
  ): Promise<VerificationRequest> {
    const newId = `req-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const now = new Date().toISOString();

    const request: VerificationRequest = {
      ...data,
      id: newId,
      status: 'EN_ATTENTE',
      createdAt: now,
      updatedAt: now,
    };

    VerificationRepository.requestsMap.set(newId, request);

    // Update user affiliation status if user is known
    if (data.userId) {
      await UserRepository.updateAffiliationStatus(data.userId, 'EN_ATTENTE');
    }

    await AuditRepository.record({
      action: 'DEMANDE_AFFILIATION_SOUMISE',
      actorName: data.applicantName,
      actorRole: 'VISITEUR',
      targetId: newId,
      targetName: data.applicantName,
      targetType: 'VERIFICATION_REQUEST',
      details: `Dépôt d’un nouveau dossier d’affiliation par ${data.applicantName} (${data.originFamilyName}).`,
    });

    return request;
  }

  public static async processDecision(
    id: string,
    decision: {
      status: VerificationStatus;
      reviewerId: string;
      reviewerName: string;
      reviewerNotes?: string;
      publicFeedback?: string;
      currentStep?: number;
    },
    actorRole?: UserRole
  ): Promise<VerificationRequest | null> {
    if (actorRole !== 'SUPER_ADMIN' && actorRole !== 'ADMIN_FAMILIAL' && actorRole !== 'VALIDATEUR') {
      throw new Error('Permissions insuffisantes pour traiter un dossier d’affiliation.');
    }

    const request = VerificationRepository.requestsMap.get(id);
    if (!request) return null;

    request.status = decision.status;
    request.reviewedBy = decision.reviewerId;
    request.reviewedByName = decision.reviewerName;
    request.reviewedAt = new Date().toISOString();
    request.reviewerNotes = decision.reviewerNotes;
    request.publicFeedback = decision.publicFeedback;
    request.updatedAt = new Date().toISOString();

    VerificationRepository.requestsMap.set(id, request);

    // If approved, update user account role & link to Member
    if (decision.status === 'APPROUVEE' && request.userId) {
      const isNzalaDirect = request.claimedFamilyType === 'NZALA_DIRECT';
      const assignedRole: UserRole = isNzalaDirect ? 'MEMBRE_NZALA' : 'MEMBRE_ALLIE';

      await UserRepository.updateAffiliationStatus(request.userId, 'APPROUVEE', assignedRole);

      if (request.targetNzalaMemberId) {
        await UserRepository.linkMember(request.userId, request.targetNzalaMemberId);
      }
    } else if (decision.status === 'REFUSEE' && request.userId) {
      await UserRepository.updateAffiliationStatus(request.userId, 'REFUSEE');
    }

    await AuditRepository.record({
      action: `DECISION_AFFILIATION_${decision.status}`,
      actorName: decision.reviewerName,
      actorRole: actorRole || 'VALIDATEUR',
      targetId: id,
      targetName: request.applicantName,
      targetType: 'VERIFICATION_REQUEST',
      details: `Dossier d’affiliation de ${request.applicantName} mis à jour : ${decision.status}. Note : ${decision.reviewerNotes || 'Aucune'}.`,
    });

    return request;
  }
}
