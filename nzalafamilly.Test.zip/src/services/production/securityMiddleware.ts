/**
 * NzalaFamilly - Server-Side Security & RBAC Enforcement Middleware
 * 
 * Rules:
 * 1. Permissions must never rely exclusively on frontend UI state.
 * 2. User account (User) and genealogical person (Member) are separate entities.
 * 3. Formal 5-stage verification must be validated on every step.
 */

import { UserRole } from '../../types';

export interface ServerAuthContext {
  userId: string;
  role: UserRole;
  memberId?: string;
  familyId?: string;
  accountStatus: 'COMPTE_CREE' | 'ACTIF' | 'SUSPENDU' | 'ARCHIVE' | 'EN_REVUE';
  ipAddress: string;
}

export type ServerPermission =
  | 'VIEW_GENEALOGY_TREE'
  | 'EDIT_MEMBER'
  | 'VALIDATE_MEMBER_AFFILIATION'
  | 'DECIDE_COUNCIL_AFFILIATION'
  | 'CREATE_ALLIANCE'
  | 'VALIDATE_ALLIANCE'
  | 'POST_FAMILY_FEED'
  | 'POST_OFFICIAL_COMMUNIQUE'
  | 'MODERATE_CONTENT'
  | 'VIEW_AUDIT_LOG'
  | 'SEND_PRIVATE_MESSAGE'
  | 'INITIATE_CALL'
  | 'BROADCAST_LIVE'
  | 'ACCESS_SACRED_ARCHIVES';

export const SERVER_ROLE_PERMISSIONS: Record<UserRole, Set<ServerPermission>> = {
  SUPER_ADMIN: new Set([
    'VIEW_GENEALOGY_TREE',
    'EDIT_MEMBER',
    'VALIDATE_MEMBER_AFFILIATION',
    'DECIDE_COUNCIL_AFFILIATION',
    'CREATE_ALLIANCE',
    'VALIDATE_ALLIANCE',
    'POST_FAMILY_FEED',
    'POST_OFFICIAL_COMMUNIQUE',
    'MODERATE_CONTENT',
    'VIEW_AUDIT_LOG',
    'SEND_PRIVATE_MESSAGE',
    'INITIATE_CALL',
    'BROADCAST_LIVE',
    'ACCESS_SACRED_ARCHIVES',
  ]),
  ADMIN_FAMILIAL: new Set([
    'VIEW_GENEALOGY_TREE',
    'EDIT_MEMBER',
    'VALIDATE_MEMBER_AFFILIATION',
    'DECIDE_COUNCIL_AFFILIATION',
    'CREATE_ALLIANCE',
    'VALIDATE_ALLIANCE',
    'POST_FAMILY_FEED',
    'POST_OFFICIAL_COMMUNIQUE',
    'MODERATE_CONTENT',
    'VIEW_AUDIT_LOG',
    'SEND_PRIVATE_MESSAGE',
    'INITIATE_CALL',
    'BROADCAST_LIVE',
    'ACCESS_SACRED_ARCHIVES',
  ]),
  VALIDATEUR: new Set([
    'VIEW_GENEALOGY_TREE',
    'VALIDATE_MEMBER_AFFILIATION',
    'DECIDE_COUNCIL_AFFILIATION',
    'CREATE_ALLIANCE',
    'VALIDATE_ALLIANCE',
    'POST_FAMILY_FEED',
    'POST_OFFICIAL_COMMUNIQUE',
    'MODERATE_CONTENT',
    'VIEW_AUDIT_LOG',
    'SEND_PRIVATE_MESSAGE',
    'INITIATE_CALL',
    'BROADCAST_LIVE',
    'ACCESS_SACRED_ARCHIVES',
  ]),
  MEMBRE_NZALA: new Set([
    'VIEW_GENEALOGY_TREE',
    'POST_FAMILY_FEED',
    'SEND_PRIVATE_MESSAGE',
    'INITIATE_CALL',
    'BROADCAST_LIVE',
    'ACCESS_SACRED_ARCHIVES',
  ]),
  MEMBRE_ALLIE: new Set([
    'VIEW_GENEALOGY_TREE',
    'POST_FAMILY_FEED',
    'SEND_PRIVATE_MESSAGE',
    'INITIATE_CALL',
  ]),
  VISITEUR: new Set([
    // Limited to basic public viewing and filing verification request
  ]),
};

export class ServerSecurityManager {
  /**
   * Asserts whether a user has permission to execute an action
   */
  public static verifyPermission(ctx: ServerAuthContext, permission: ServerPermission): boolean {
    if (ctx.accountStatus === 'SUSPENDU' || ctx.accountStatus === 'ARCHIVE') {
      return false;
    }
    const permissions = SERVER_ROLE_PERMISSIONS[ctx.role];
    return permissions ? permissions.has(permission) : false;
  }

  /**
   * Enforces strict User ↔ Member Separation.
   * A user CANNOT self-link their account to a Member or create a new Member in the lineage
   * without passing through the formal 5-step verification workflow.
   */
  public static validateMemberLinkOperation(
    actor: ServerAuthContext,
    targetUserId: string,
    targetMemberId: string,
    hasPassedCouncilApproval: boolean
  ): { allowed: boolean; error?: string } {
    const isCouncilOrAdmin =
      actor.role === 'SUPER_ADMIN' ||
      actor.role === 'ADMIN_FAMILIAL' ||
      actor.role === 'VALIDATEUR';

    if (!isCouncilOrAdmin) {
      return {
        allowed: false,
        error: 'Seul le Conseil des Sages ou un Administrateur peut lier un compte à une fiche généalogique.',
      };
    }

    if (!hasPassedCouncilApproval) {
      return {
        allowed: false,
        error: 'Impossible d’intégrer un membre sans décision formelle du Conseil des Sages (Étape 5/5 requise).',
      };
    }

    return { allowed: true };
  }
}
