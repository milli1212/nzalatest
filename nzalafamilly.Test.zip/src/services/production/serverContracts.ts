/**
 * NzalaFamilly - Server API Contracts & Endpoints Specification
 * Enterprise-grade REST & Real-Time Protocol Specification for Multi-User Sync.
 */

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    fieldErrors?: Record<string, string>;
  };
  meta?: {
    page?: number;
    limit?: number;
    total?: number;
    hasMore?: boolean;
    timestamp: string;
  };
}

export interface PaginationQuery {
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  search?: string;
}

export const API_ROUTES = {
  // Authentication & Session
  AUTH_REGISTER: '/api/v1/auth/register',
  AUTH_LOGIN: '/api/v1/auth/login',
  AUTH_LOGOUT: '/api/v1/auth/logout',
  AUTH_REFRESH: '/api/v1/auth/refresh',
  AUTH_ME: '/api/v1/auth/me',
  AUTH_PASSWORD_CHANGE: '/api/v1/auth/password/change',
  AUTH_PASSWORD_RESET_REQUEST: '/api/v1/auth/password/reset-request',
  AUTH_PASSWORD_RESET_CONFIRM: '/api/v1/auth/password/reset-confirm',
  AUTH_2FA_TOGGLE: '/api/v1/auth/2fa/toggle',

  // Genealogy & Members
  MEMBERS_LIST: '/api/v1/members',
  MEMBERS_DETAIL: (id: string) => `/api/v1/members/${id}`,
  MEMBERS_CREATE: '/api/v1/members',
  MEMBERS_UPDATE: (id: string) => `/api/v1/members/${id}`,
  MEMBERS_ARCHIVE: (id: string) => `/api/v1/members/${id}/archive`,
  
  // Lineage Graph & Relations
  RELATIONSHIPS_LIST: '/api/v1/relationships',
  RELATIONSHIPS_PROPOSE: '/api/v1/relationships/propose',
  RELATIONSHIPS_VALIDATE: (id: string) => `/api/v1/relationships/${id}/validate`,
  RELATIONSHIPS_DELETE: (id: string) => `/api/v1/relationships/${id}`,
  
  // Alliances
  ALLIANCES_LIST: '/api/v1/alliances',
  ALLIANCES_CREATE: '/api/v1/alliances',
  ALLIANCES_VALIDATE: (id: string) => `/api/v1/alliances/${id}/validate`,

  // Affiliations & Council Verification Pipeline
  VERIFICATIONS_SUBMIT: '/api/v1/verifications/submit',
  VERIFICATIONS_LIST: '/api/v1/verifications',
  VERIFICATIONS_PROCESS: (id: string) => `/api/v1/verifications/${id}/process`,

  // Feed, Posts & Media
  POSTS_FEED: '/api/v1/posts',
  POSTS_CREATE: '/api/v1/posts',
  POSTS_DETAIL: (id: string) => `/api/v1/posts/${id}`,
  POSTS_REACT: (id: string) => `/api/v1/posts/${id}/react`,
  POSTS_COMMENT: (id: string) => `/api/v1/posts/${id}/comments`,

  // Stories (24h Ephemeral)
  STORIES_ACTIVE: '/api/v1/stories/active',
  STORIES_CREATE: '/api/v1/stories',
  STORIES_VIEW: (id: string) => `/api/v1/stories/${id}/view`,
  STORIES_REACT: (id: string) => `/api/v1/stories/${id}/react`,

  // Messaging & Audio Notes
  CONVERSATIONS_LIST: '/api/v1/conversations',
  CONVERSATIONS_CREATE: '/api/v1/conversations',
  CONVERSATIONS_MESSAGES: (id: string) => `/api/v1/conversations/${id}/messages`,
  MESSAGES_SEND: (id: string) => `/api/v1/conversations/${id}/messages`,
  MESSAGES_READ: (id: string) => `/api/v1/conversations/${id}/read`,
  MESSAGES_VIEW_ONCE_CONSUME: (messageId: string) => `/api/v1/messages/${messageId}/view-once/consume`,

  // WebRTC Calls & Signaling
  CALLS_INITIATE: '/api/v1/calls/initiate',
  CALLS_RESPOND: (callId: string) => `/api/v1/calls/${callId}/respond`,
  CALLS_END: (callId: string) => `/api/v1/calls/${callId}/end`,
  CALLS_ICE_CANDIDATE: (callId: string) => `/api/v1/calls/${callId}/ice`,

  // Live Streams
  LIVE_LIST: '/api/v1/live',
  LIVE_START: '/api/v1/live/start',
  LIVE_JOIN: (id: string) => `/api/v1/live/${id}/join`,
  LIVE_LEAVE: (id: string) => `/api/v1/live/${id}/leave`,
  LIVE_END: (id: string) => `/api/v1/live/${id}/end`,
  LIVE_COMMENT: (id: string) => `/api/v1/live/${id}/comments`,

  // Media Storage & Signed URLs
  STORAGE_REQUEST_UPLOAD_URL: '/api/v1/storage/upload-signed-url',
  STORAGE_GET_SIGNED_MEDIA_URL: '/api/v1/storage/media-signed-url',

  // Notifications
  NOTIFICATIONS_LIST: '/api/v1/notifications',
  NOTIFICATIONS_MARK_READ: (id: string) => `/api/v1/notifications/${id}/read`,
  NOTIFICATIONS_MARK_ALL_READ: '/api/v1/notifications/read-all',

  // Moderation, Blocking & Audit
  MODERATION_REPORTS_SUBMIT: '/api/v1/moderation/reports',
  MODERATION_REPORTS_PROCESS: (id: string) => `/api/v1/moderation/reports/${id}/process`,
  SECURITY_BLOCK_USER: '/api/v1/security/block',
  SECURITY_UNBLOCK_USER: (userId: string) => `/api/v1/security/unblock/${userId}`,
  AUDIT_LOGS_LIST: '/api/v1/audit/logs',
} as const;
