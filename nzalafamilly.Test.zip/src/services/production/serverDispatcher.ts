/**
 * NzalaFamilly - Universal Server Request Dispatcher & Controller
 * 
 * Enforces server-side authentication, RBAC, parameter parsing,
 * and delegates to the PostgreSQL Repositories.
 */

import { ApiResponse } from './serverContracts';
import { AuthServerController } from './auth/authController';
import { JwtServerService } from './auth/jwtService';
import {
  UserRepository,
  FamilyRepository,
  BranchRepository,
  MemberRepository,
  RelationshipRepository,
  AllianceRepository,
  EventRepository,
  PostRepository,
  StoryRepository,
  StatusRepository,
  ConversationRepository,
  MessageRepository,
  VerificationRepository,
  NotificationRepository,
  AuditRepository,
  ProfilePrivacyRepository,
} from './repositories';
import { UserRole } from '../../types';

export class ServerDispatcher {
  private static extractAuthContext(authHeader?: string) {
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return null;
    }
    const token = authHeader.substring(7);
    const result = JwtServerService.verifyAccessToken(token);
    return result.valid && result.payload ? result.payload : null;
  }

  public static async dispatch<T = any>(
    endpoint: string,
    method: string,
    body: any = {},
    authHeader?: string
  ): Promise<ApiResponse<T>> {
    const authContext = ServerDispatcher.extractAuthContext(authHeader);
    const userRole: UserRole = (authContext?.role as UserRole) || 'VISITEUR';
    const userId = authContext?.userId || 'anonymous';
    const userName = authContext?.email ? authContext.email.split('@')[0] : 'Visiteur';

    // Parse URL and query params
    const [path, queryString] = endpoint.split('?');
    const queryParams = new URLSearchParams(queryString || '');

    try {
      // --- AUTHENTICATION ROUTES ---
      if (path === '/auth/register') {
        return (await AuthServerController.register(body)) as ApiResponse<T>;
      }
      if (path === '/auth/login') {
        return (await AuthServerController.login(body)) as ApiResponse<T>;
      }
      if (path === '/auth/refresh') {
        return (await AuthServerController.refresh(body.refreshToken)) as ApiResponse<T>;
      }
      if (path === '/auth/logout') {
        return (await AuthServerController.logout(authHeader)) as ApiResponse<T>;
      }
      if (path === '/auth/me') {
        return (await AuthServerController.getMe(authHeader)) as ApiResponse<T>;
      }
      if (path === '/auth/forgot-password') {
        return (await AuthServerController.forgotPassword(body.email)) as ApiResponse<T>;
      }
      if (path === '/auth/reset-password') {
        return (await AuthServerController.resetPassword(body.token, body.newPassword)) as ApiResponse<T>;
      }

      // --- FAMILIES & BRANCHES ---
      if (path === '/families') {
        if (method === 'GET') {
          const families = await FamilyRepository.findAll();
          return { success: true, data: families as any };
        }
        if (method === 'POST') {
          const fam = await FamilyRepository.create(body);
          return { success: true, data: fam as any };
        }
      }

      if (path === '/branches') {
        const familyId = queryParams.get('familyId');
        const branches = familyId
          ? await BranchRepository.findByFamilyId(familyId)
          : await BranchRepository.findAll();
        return { success: true, data: branches as any };
      }

      // --- MEMBERS ---
      if (path === '/members') {
        if (method === 'GET') {
          const result = await MemberRepository.findAll({
            familyId: queryParams.get('familyId') || undefined,
            branchId: queryParams.get('branchId') || undefined,
            search: queryParams.get('search') || undefined,
            generation: queryParams.get('generation') ? parseInt(queryParams.get('generation')!) : undefined,
            userRole,
            page: queryParams.get('page') ? parseInt(queryParams.get('page')!) : 1,
            limit: queryParams.get('limit') ? parseInt(queryParams.get('limit')!) : 100,
          });
          return { success: true, data: result as any };
        }
        if (method === 'POST') {
          const member = await MemberRepository.create(body, userRole);
          await AuditRepository.record({
            action: 'MEMBRE_CREE',
            actorName: userName,
            actorRole: userRole,
            targetId: member.id,
            targetName: `${member.firstName} ${member.lastName}`,
            targetType: 'MEMBER',
            details: `Création de la fiche généalogique pour ${member.firstName} ${member.lastName}.`,
          });
          return { success: true, data: member as any };
        }
      }

      const memberDetailMatch = path.match(/^\/members\/([^/]+)$/);
      if (memberDetailMatch) {
        const memberId = memberDetailMatch[1];
        if (method === 'GET') {
          const member = await MemberRepository.findById(memberId);
          if (!member) return { success: false, error: { code: 'NOT_FOUND', message: 'Membre non trouvé.' } };
          return { success: true, data: member as any };
        }
        if (method === 'PATCH') {
          const member = await MemberRepository.update(memberId, body, userRole);
          if (!member) return { success: false, error: { code: 'NOT_FOUND', message: 'Membre non trouvé.' } };
          return { success: true, data: member as any };
        }
      }

      const memberArchiveMatch = path.match(/^\/members\/([^/]+)\/archive$/);
      if (memberArchiveMatch && method === 'POST') {
        const memberId = memberArchiveMatch[1];
        await MemberRepository.archive(memberId, userRole);
        return { success: true, data: { message: 'Membre archivé avec succès.' } as any };
      }

      // --- RELATIONSHIPS ---
      if (path === '/relationships') {
        if (method === 'GET') {
          const rels = await RelationshipRepository.findAll();
          return { success: true, data: rels as any };
        }
      }
      if (path === '/relationships/propose' && method === 'POST') {
        const rel = await RelationshipRepository.create(body, userRole);
        return { success: true, data: rel as any };
      }
      const relValMatch = path.match(/^\/relationships\/([^/]+)\/validate$/);
      if (relValMatch && method === 'POST') {
        const relId = relValMatch[1];
        const rel = await RelationshipRepository.validate(relId, userId, userRole);
        return { success: true, data: rel as any };
      }

      // --- ALLIANCES ---
      if (path === '/alliances') {
        if (method === 'GET') {
          const alliances = await AllianceRepository.findAll();
          return { success: true, data: alliances as any };
        }
        if (method === 'POST') {
          const alliance = await AllianceRepository.create(body, userRole);
          return { success: true, data: alliance as any };
        }
      }
      const allianceValMatch = path.match(/^\/alliances\/([^/]+)\/validate$/);
      if (allianceValMatch && method === 'POST') {
        const allianceId = allianceValMatch[1];
        const alliance = await AllianceRepository.ratify(allianceId, userRole);
        return { success: true, data: alliance as any };
      }

      // --- POSTS ---
      if (path === '/posts') {
        if (method === 'GET') {
          const feed = await PostRepository.findFeed({
            userRole,
            scope: queryParams.get('scope') || undefined,
            page: queryParams.get('page') ? parseInt(queryParams.get('page')!) : 1,
            limit: queryParams.get('limit') ? parseInt(queryParams.get('limit')!) : 20,
          });
          return { success: true, data: feed as any };
        }
        if (method === 'POST') {
          const post = await PostRepository.create(
            {
              ...body,
              authorId: userId,
              authorName: userName,
              authorRole: userRole,
            },
            userRole
          );
          return { success: true, data: post as any };
        }
      }

      const postReactMatch = path.match(/^\/posts\/([^/]+)\/react$/);
      if (postReactMatch && method === 'POST') {
        const postId = postReactMatch[1];
        const updatedPost = await PostRepository.react(postId, userId, userName, body.reactionType);
        return { success: true, data: updatedPost as any };
      }

      const postCommentMatch = path.match(/^\/posts\/([^/]+)\/comments$/);
      if (postCommentMatch && method === 'POST') {
        const postId = postCommentMatch[1];
        const comment = await PostRepository.comment(postId, {
          authorId: userId,
          authorName: userName,
          authorRole: userRole,
          authorAvatar: body.authorAvatar,
          content: body.content,
        });
        return { success: true, data: comment as any };
      }

      const postDeleteMatch = path.match(/^\/posts\/([^/]+)$/);
      if (postDeleteMatch && method === 'DELETE') {
        const postId = postDeleteMatch[1];
        await PostRepository.delete(postId, userId, userRole);
        return { success: true, data: { message: 'Publication supprimée.' } as any };
      }

      // --- STORIES ---
      if (path === '/stories/active') {
        const stories = await StoryRepository.findActive(userRole);
        return { success: true, data: stories as any };
      }
      if (path === '/stories' && method === 'POST') {
        const story = await StoryRepository.create(
          {
            ...body,
            authorId: userId,
            authorName: userName,
          },
          userRole
        );
        return { success: true, data: story as any };
      }
      const storyViewMatch = path.match(/^\/stories\/([^/]+)\/view$/);
      if (storyViewMatch && method === 'POST') {
        const storyId = storyViewMatch[1];
        const story = await StoryRepository.recordView(storyId, userId, userName, body.userAvatar);
        return { success: true, data: story as any };
      }
      const storyReactMatch = path.match(/^\/stories\/([^/]+)\/react$/);
      if (storyReactMatch && method === 'POST') {
        const storyId = storyReactMatch[1];
        const story = await StoryRepository.react(storyId, userId, userName, body.emoji);
        return { success: true, data: story as any };
      }

      // --- STATUSES ---
      if (path === '/statuses') {
        if (method === 'GET') {
          const statuses = await StatusRepository.findAll();
          return { success: true, data: statuses as any };
        }
        if (method === 'POST') {
          const status = await StatusRepository.create({
            ...body,
            userId,
            userName,
          });
          return { success: true, data: status as any };
        }
      }

      // --- CONVERSATIONS & MESSAGES ---
      if (path === '/conversations') {
        if (method === 'GET') {
          const convs = await ConversationRepository.findForUser(userId);
          return { success: true, data: convs as any };
        }
        if (method === 'POST') {
          const conv = await ConversationRepository.create({
            ...body,
            createdBy: userId,
          });
          return { success: true, data: conv as any };
        }
      }

      const convMessagesMatch = path.match(/^\/conversations\/([^/]+)\/messages$/);
      if (convMessagesMatch) {
        const convId = convMessagesMatch[1];
        if (method === 'GET') {
          const limit = queryParams.get('limit') ? parseInt(queryParams.get('limit')!) : 50;
          const msgs = await MessageRepository.findByConversation(convId, limit);
          return { success: true, data: msgs as any };
        }
        if (method === 'POST') {
          const msg = await MessageRepository.create(convId, {
            ...body,
            senderId: userId,
            senderName: userName,
          });
          return { success: true, data: msg as any };
        }
      }

      const convReadMatch = path.match(/^\/conversations\/([^/]+)\/read$/);
      if (convReadMatch && method === 'POST') {
        const convId = convReadMatch[1];
        await MessageRepository.markAllRead(convId, userId);
        return { success: true, data: { success: true } as any };
      }

      const viewOnceMatch = path.match(/^\/messages\/([^/]+)\/view-once\/consume$/);
      if (viewOnceMatch && method === 'POST') {
        const messageId = viewOnceMatch[1];
        const res = await MessageRepository.consumeViewOnce(messageId, userId);
        return { success: res.success, data: res as any, error: res.success ? undefined : { code: 'VIEW_ONCE_ERROR', message: res.message || '' } };
      }

      // --- EVENTS ---
      if (path === '/events') {
        if (method === 'GET') {
          const res = await EventRepository.findAll({
            upcomingOnly: queryParams.get('upcomingOnly') === 'true',
            type: queryParams.get('type') || undefined,
            userRole,
            userId,
          });
          return { success: true, data: res as any };
        }
        if (method === 'POST') {
          const event = await EventRepository.create(
            {
              ...body,
              organizerId: userId,
              organizerName: userName,
            },
            userRole
          );
          return { success: true, data: event as any };
        }
      }

      const eventRsvpMatch = path.match(/^\/events\/([^/]+)\/rsvp$/);
      if (eventRsvpMatch && method === 'POST') {
        const eventId = eventRsvpMatch[1];
        const event = await EventRepository.rsvp(
          eventId,
          userId,
          userName,
          body.status,
          body.guestsCount || 1,
          body.note
        );
        return { success: true, data: event as any };
      }

      // --- VERIFICATIONS ---
      if (path === '/verifications') {
        const requests = await VerificationRepository.findAll(userRole);
        return { success: true, data: requests as any };
      }
      if (path === '/verifications/submit' && method === 'POST') {
        const req = await VerificationRepository.submit({
          ...body,
          userId,
          applicantName: userName,
        });
        return { success: true, data: req as any };
      }
      const verifProcessMatch = path.match(/^\/verifications\/([^/]+)\/process$/);
      if (verifProcessMatch && method === 'POST') {
        const reqId = verifProcessMatch[1];
        const req = await VerificationRepository.processDecision(
          reqId,
          {
            status: body.status,
            reviewerId: userId,
            reviewerName: userName,
            reviewerNotes: body.reviewerNotes,
            publicFeedback: body.publicFeedback,
            currentStep: body.currentStep || 5,
          },
          userRole
        );
        return { success: true, data: req as any };
      }

      // --- PRIVACY & ACCESS REQUESTS ---
      const privacySettingsMatch = path.match(/^\/privacy\/settings\/([^/]+)$/);
      if (privacySettingsMatch && method === 'GET') {
        const targetId = privacySettingsMatch[1];
        const settings = await ProfilePrivacyRepository.getSettings(targetId);
        return { success: true, data: settings as any };
      }
      if (path === '/privacy/settings' && method === 'PUT') {
        const settings = await ProfilePrivacyRepository.updateSettings(userId, body);
        return { success: true, data: settings as any };
      }
      if (path === '/privacy/access-requests' && method === 'POST') {
        const req = await ProfilePrivacyRepository.requestProfileAccess(
          userId,
          userName,
          body.requesterAvatar,
          body.targetUserId
        );
        return { success: true, data: req as any };
      }
      const privacyRespondMatch = path.match(/^\/privacy\/access-requests\/([^/]+)\/respond$/);
      if (privacyRespondMatch && method === 'POST') {
        const reqId = privacyRespondMatch[1];
        const req = await ProfilePrivacyRepository.respondToAccessRequest(reqId, userId, body.accept);
        return { success: true, data: req as any };
      }

      // --- GLOBAL SEARCH ---
      if (path === '/search' && method === 'GET') {
        const q = queryParams.get('q') || '';
        const membersRes = await MemberRepository.findAll({ search: q, userRole, limit: 10 });
        const postsRes = await PostRepository.findFeed({ userRole, limit: 10 });
        const eventsRes = await EventRepository.findAll({ userRole, limit: 10 });

        const filteredPosts = postsRes.posts.filter((p) =>
          p.content.toLowerCase().includes(q.toLowerCase()) || (p.title && p.title.toLowerCase().includes(q.toLowerCase()))
        );
        const filteredEvents = eventsRes.events.filter((e) =>
          e.title.toLowerCase().includes(q.toLowerCase()) || e.description.toLowerCase().includes(q.toLowerCase())
        );

        return {
          success: true,
          data: {
            members: membersRes.members,
            posts: filteredPosts,
            events: filteredEvents,
          } as any,
        };
      }

      // --- AUDIT LOGS ---
      if (path === '/audit/logs' && method === 'GET') {
        const logs = await AuditRepository.findLogs({
          action: queryParams.get('action') || undefined,
          limit: queryParams.get('limit') ? parseInt(queryParams.get('limit')!) : 100,
          actorRole: userRole,
        });
        return { success: true, data: logs as any };
      }

      return {
        success: false,
        error: { code: 'NOT_FOUND', message: `Route ${endpoint} introuvable.` },
      };
    } catch (err: any) {
      return {
        success: false,
        error: { code: 'INTERNAL_ERROR', message: err.message || 'Erreur serveur interne.' },
      };
    }
  }
}
