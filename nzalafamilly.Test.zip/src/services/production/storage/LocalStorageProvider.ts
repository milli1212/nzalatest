/**
 * NzalaFamilly - Local / IndexedDB / Memory Storage Provider
 * Assure la compatibilité en environnement de développement et démo hors-ligne
 */

import { IStorageProvider, MediaMetadata, StorageUploadOptions, SignedUrlOptions, SignedUploadOptions, SignedUploadResult, ThumbnailOptions } from './StorageProvider';
import { MediaType } from '../../../types';

function toBase64Url(str: string): string {
  if (typeof btoa !== 'undefined') {
    return btoa(unescape(encodeURIComponent(str)))
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');
  }
  return str;
}

export class LocalStorageProvider implements IStorageProvider {
  public readonly name = 'LOCAL';
  private storageMap = new Map<string, { blob: Blob; metadata: MediaMetadata }>();

  async uploadFile(file: File | Blob, options: StorageUploadOptions): Promise<MediaMetadata> {
    const fileId = `media-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
    const originalName = options.customFileName || (file instanceof File ? file.name : `file-${fileId}`);
    const mimeType = file.type || 'application/octet-stream';
    const fileSize = file.size;

    let mediaType: MediaType = 'DOCUMENT';
    if (mimeType.startsWith('image/')) mediaType = 'IMAGE';
    else if (mimeType.startsWith('video/')) mediaType = 'VIDEO';
    else if (mimeType.startsWith('audio/')) mediaType = 'AUDIO';

    const storageKey = `nzala/${options.category.toLowerCase()}/${fileId}-${originalName.replace(/[^a-zA-Z0-9.-]/g, '_')}`;

    if (options.onProgress) options.onProgress(30);

    // Convert to Data URL / Object URL
    const dataUrl = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (options.onProgress) options.onProgress(85);
        resolve(reader.result as string);
      };
      reader.onerror = () => reject(new Error('Erreur de lecture du fichier.'));
      reader.readAsDataURL(file);
    });

    if (options.onProgress) options.onProgress(100);

    const now = new Date().toISOString();
    let expiresAt: string | undefined;
    if (options.category === 'STORY_IMAGE' || options.category === 'STORY_VIDEO') {
      expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
    } else if (options.isViewOnce) {
      expiresAt = new Date(Date.now() + 2 * 60 * 1000).toISOString();
    }

    const metadata: MediaMetadata = {
      id: fileId,
      ownerId: options.ownerId,
      ownerName: options.ownerName,
      storageKey,
      storageProvider: 'LOCAL',
      originalFileName: originalName,
      mimeType,
      fileSize,
      mediaType,
      category: options.category,
      width: options.width,
      height: options.height,
      duration: options.duration,
      publicUrl: dataUrl,
      visibilityScope: options.visibilityScope || 'NZALA_INTERNE',
      targetFamilyId: options.targetFamilyId,
      isViewOnce: options.isViewOnce,
      viewOnceConsumed: false,
      status: 'READY',
      createdAt: now,
      expiresAt,
    };

    this.storageMap.set(storageKey, { blob: file, metadata });

    return metadata;
  }

  async getSignedDownloadUrl(storageKey: string, options?: SignedUrlOptions): Promise<string> {
    const item = this.storageMap.get(storageKey);
    if (item && item.metadata.publicUrl) {
      if (options?.isViewOnce) {
        const token = toBase64Url(JSON.stringify({ key: storageKey, exp: Date.now() + 120000, viewOnce: true }));
        return `${item.metadata.publicUrl}#token=${token}`;
      }
      return item.metadata.publicUrl;
    }
    return '';
  }

  async getSignedUploadUrl(
    fileName: string,
    mimeType: string,
    options: SignedUploadOptions
  ): Promise<SignedUploadResult> {
    const storageKey = `nzala/${options.category.toLowerCase()}/${Date.now()}-${fileName}`;
    return {
      uploadUrl: `/api/v1/storage/upload/${encodeURIComponent(storageKey)}`,
      storageKey,
      expiresAt: new Date(Date.now() + 3600 * 1000).toISOString(),
    };
  }

  async deleteFile(storageKey: string, ownerId: string): Promise<boolean> {
    const item = this.storageMap.get(storageKey);
    if (!item) return false;
    if (item.metadata.ownerId !== ownerId && ownerId !== 'admin') {
      throw new Error('Non autorisé à supprimer ce média.');
    }
    this.storageMap.delete(storageKey);
    return true;
  }

  async fileExists(storageKey: string): Promise<boolean> {
    return this.storageMap.has(storageKey);
  }

  async generateThumbnail(
    file: File | Blob,
    options?: ThumbnailOptions
  ): Promise<{ thumbnailBlob: Blob; dataUrl: string } | undefined> {
    if (typeof window === 'undefined' || typeof document === 'undefined') return undefined;

    const maxWidth = options?.maxWidth || 400;
    const maxHeight = options?.maxHeight || 400;
    const quality = options?.quality || 0.85;

    // Image thumbnail
    if (file.type.startsWith('image/')) {
      return new Promise((resolve) => {
        const img = new Image();
        const objectUrl = URL.createObjectURL(file);
        img.onload = () => {
          URL.revokeObjectURL(objectUrl);
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > maxWidth) {
              height = Math.round((height * maxWidth) / width);
              width = maxWidth;
            }
          } else {
            if (height > maxHeight) {
              width = Math.round((width * maxHeight) / height);
              height = maxHeight;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) return resolve(undefined);
          ctx.drawImage(img, 0, 0, width, height);

          const dataUrl = canvas.toDataURL('image/jpeg', quality);
          canvas.toBlob(
            (blob) => {
              if (blob) {
                resolve({ thumbnailBlob: blob, dataUrl });
              } else {
                resolve(undefined);
              }
            },
            'image/jpeg',
            quality
          );
        };
        img.onerror = () => {
          URL.revokeObjectURL(objectUrl);
          resolve(undefined);
        };
        img.src = objectUrl;
      });
    }

    // Video thumbnail
    if (file.type.startsWith('video/')) {
      return new Promise((resolve) => {
        const video = document.createElement('video');
        const objectUrl = URL.createObjectURL(file);
        video.muted = true;
        video.playsInline = true;
        video.preload = 'metadata';

        video.onloadeddata = () => {
          video.currentTime = options?.timeOffsetSeconds || 0.5;
        };

        video.onseeked = () => {
          URL.revokeObjectURL(objectUrl);
          const canvas = document.createElement('canvas');
          let width = video.videoWidth || 640;
          let height = video.videoHeight || 360;

          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) return resolve(undefined);
          ctx.drawImage(video, 0, 0, width, height);

          const dataUrl = canvas.toDataURL('image/jpeg', quality);
          canvas.toBlob(
            (blob) => {
              if (blob) {
                resolve({ thumbnailBlob: blob, dataUrl });
              } else {
                resolve(undefined);
              }
            },
            'image/jpeg',
            quality
          );
        };

        video.onerror = () => {
          URL.revokeObjectURL(objectUrl);
          resolve(undefined);
        };

        video.src = objectUrl;
      });
    }

    return undefined;
  }
}
