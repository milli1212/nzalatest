/**
 * NzalaFamilly - Storage Provider Contract & Metadata Schema
 * Étape 9 / Partie 2 : Stockage Multimédia Réel (Cloud Storage / S3 / GCS / Local)
 */

import { MediaType, PostScope } from '../../../types';

export type MediaStorageCategory =
  | 'PROFILE_PHOTO'
  | 'PROFILE_VIDEO'
  | 'COVER_PHOTO'
  | 'POST_IMAGE'
  | 'POST_VIDEO'
  | 'STORY_IMAGE'
  | 'STORY_VIDEO'
  | 'VOICE_NOTE'
  | 'VIEW_ONCE'
  | 'SACRED_ARCHIVE'
  | 'DOCUMENT'
  | 'ATTACHMENT';

export type MediaStatus = 'PENDING' | 'READY' | 'QUARANTINED' | 'DELETED';

export interface MediaMetadata {
  id: string;
  ownerId: string;
  ownerName?: string;
  storageKey: string;
  storageProvider: 'GCS' | 'S3' | 'LOCAL';
  originalFileName: string;
  mimeType: string;
  fileSize: number;
  mediaType: MediaType;
  category: MediaStorageCategory;
  width?: number;
  height?: number;
  duration?: number; // Durée réelle en secondes (pour audio & vidéo)
  thumbnailKey?: string;
  thumbnailUrl?: string;
  publicUrl?: string;
  visibilityScope: PostScope | 'NZALA_FAMILY' | 'ALLIED_FAMILY' | 'PUBLIC' | 'PRIVATE';
  targetFamilyId?: string;
  isViewOnce?: boolean;
  viewOnceConsumed?: boolean;
  checksumSha256?: string;
  status: MediaStatus;
  createdAt: string;
  expiresAt?: string;
}

export interface StorageUploadOptions {
  category: MediaStorageCategory;
  ownerId: string;
  ownerName?: string;
  visibilityScope?: PostScope;
  targetFamilyId?: string;
  isViewOnce?: boolean;
  customFileName?: string;
  duration?: number;
  width?: number;
  height?: number;
  thumbnailBlob?: Blob;
  onProgress?: (percent: number) => void;
}

export interface SignedUrlOptions {
  durationSeconds?: number;
  isViewOnce?: boolean;
  userId?: string;
  downloadFilename?: string;
}

export interface SignedUploadOptions {
  category: MediaStorageCategory;
  ownerId: string;
  fileSize: number;
  mimeType: string;
  durationSeconds?: number;
}

export interface SignedUploadResult {
  uploadUrl: string;
  storageKey: string;
  fields?: Record<string, string>;
  expiresAt: string;
}

export interface ThumbnailOptions {
  maxWidth?: number;
  maxHeight?: number;
  quality?: number;
  timeOffsetSeconds?: number;
}

/**
 * Contrat d'interface universel pour tout fournisseur de stockage (GCS, AWS S3, Local)
 */
export interface IStorageProvider {
  name: 'GCS' | 'S3' | 'LOCAL';

  /**
   * Téléverse un fichier (binaire, Blob ou File)
   */
  uploadFile(
    file: File | Blob,
    options: StorageUploadOptions
  ): Promise<MediaMetadata>;

  /**
   * Génère une URL de téléchargement ou d'accès signée sécurisée
   */
  getSignedDownloadUrl(
    storageKey: string,
    options?: SignedUrlOptions
  ): Promise<string>;

  /**
   * Génère une URL de téléversement direct signée (Direct to Bucket)
   */
  getSignedUploadUrl(
    fileName: string,
    mimeType: string,
    options: SignedUploadOptions
  ): Promise<SignedUploadResult>;

  /**
   * Supprime définitivement un fichier du stockage
   */
  deleteFile(storageKey: string, ownerId: string): Promise<boolean>;

  /**
   * Vérifie la présence d'un objet
   */
  fileExists(storageKey: string): Promise<boolean>;

  /**
   * Génère une miniature pour une image ou une vidéo
   */
  generateThumbnail?(
    file: File | Blob,
    options?: ThumbnailOptions
  ): Promise<{ thumbnailBlob: Blob; dataUrl: string } | undefined>;
}
