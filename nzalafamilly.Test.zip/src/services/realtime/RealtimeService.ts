/**
 * NzalaFamilly - Service d'Événements Temps Réel (NZALA REALTIME)
 * Abstraction pour la présence, les messages, les notifications et la signalisation
 */

export type RealtimeEventType =
  | 'MESSAGE_NEW'
  | 'MESSAGE_READ'
  | 'PRESENCE_CHANGE'
  | 'CALL_INCOMING'
  | 'NOTIFICATION_NEW'
  | 'TYPING_START'
  | 'TYPING_STOP';

export interface RealtimeEvent<T = any> {
  type: RealtimeEventType;
  payload: T;
  timestamp: string;
}

export type RealtimeEventHandler<T = any> = (event: RealtimeEvent<T>) => void;

export class RealtimeService {
  private static instance: RealtimeService;
  private handlers: Map<RealtimeEventType, Set<RealtimeEventHandler>> = new Map();
  private isConnected: boolean = false;

  private constructor() {}

  public static getInstance(): RealtimeService {
    if (!RealtimeService.instance) {
      RealtimeService.instance = new RealtimeService();
    }
    return RealtimeService.instance;
  }

  public subscribe<T = any>(type: RealtimeEventType, handler: RealtimeEventHandler<T>): () => void {
    if (!this.handlers.has(type)) {
      this.handlers.set(type, new Set());
    }
    this.handlers.get(type)!.add(handler);

    return () => {
      this.handlers.get(type)?.delete(handler);
    };
  }

  public emit<T = any>(type: RealtimeEventType, payload: T): void {
    const event: RealtimeEvent<T> = {
      type,
      payload,
      timestamp: new Date().toISOString(),
    };

    const listeners = this.handlers.get(type);
    if (listeners) {
      listeners.forEach((listener) => {
        try {
          listener(event);
        } catch (err) {
          console.error(`Error in realtime handler for ${type}:`, err);
        }
      });
    }
  }

  public isRealBackendConnected(): boolean {
    return this.isConnected;
  }

  public setRealBackendConnected(connected: boolean): void {
    this.isConnected = connected;
  }
}
