import {
  Member,
  Relationship,
  RelationshipType,
  Alliance,
  AllianceType,
  UserAccount,
  UserRole,
  VisibilityLevel
} from '../types';

export interface ValidationResult {
  isValid: boolean;
  error?: string;
  warning?: string;
}

/**
 * Check whether a relationship is symmetric (e.g. spouse, sibling, cousin)
 */
export const isSymmetricRelationship = (type: RelationshipType): boolean => {
  return type === 'CONJOINT' || type === 'FRERE_SOEUR' || type === 'COUSIN';
};

/**
 * Generate human-readable French relationship label based on type, gender and direction
 */
export const getRelationshipLabel = (
  type: RelationshipType,
  memberA: { gender?: 'M' | 'F' | 'AUTRE'; firstName: string; lastName: string },
  memberB: { gender?: 'M' | 'F' | 'AUTRE'; firstName: string; lastName: string }
): { labelAtoB: string; labelBtoA: string } => {
  const isMaleA = memberA.gender === 'M';
  const isFemaleA = memberA.gender === 'F';
  const isMaleB = memberB.gender === 'M';
  const isFemaleB = memberB.gender === 'F';

  switch (type) {
    case 'PARENT_ENFANT':
      return {
        labelAtoB: isFemaleA ? `Mère de ${memberB.firstName}` : `Père de ${memberB.firstName}`,
        labelBtoA: isFemaleB ? `Fille de ${memberA.firstName}` : `Fils de ${memberA.firstName}`,
      };

    case 'CONJOINT':
      return {
        labelAtoB: isFemaleA ? `Épouse de ${memberB.firstName}` : `Époux de ${memberB.firstName}`,
        labelBtoA: isFemaleB ? `Épouse de ${memberA.firstName}` : `Époux de ${memberA.firstName}`,
      };

    case 'FRERE_SOEUR':
      return {
        labelAtoB: isFemaleA ? `Sœur de ${memberB.firstName}` : `Frère de ${memberB.firstName}`,
        labelBtoA: isFemaleB ? `Sœur de ${memberA.firstName}` : `Frère de ${memberA.firstName}`,
      };

    case 'GRAND_PARENT_PETIT_ENFANT':
      return {
        labelAtoB: isFemaleA ? `Grand-mère de ${memberB.firstName}` : `Grand-père de ${memberB.firstName}`,
        labelBtoA: isFemaleB ? `Petite-fille de ${memberA.firstName}` : `Petit-fils de ${memberA.firstName}`,
      };

    case 'ONCLE_TANTE_NEVEU_NIECE':
      return {
        labelAtoB: isFemaleA ? `Tante de ${memberB.firstName}` : `Oncle de ${memberB.firstName}`,
        labelBtoA: isFemaleB ? `Nièce de ${memberA.firstName}` : `Neveu de ${memberA.firstName}`,
      };

    case 'COUSIN':
      return {
        labelAtoB: isFemaleA ? `Cousine de ${memberB.firstName}` : `Cousin de ${memberB.firstName}`,
        labelBtoA: isFemaleB ? `Cousine de ${memberA.firstName}` : `Cousin de ${memberA.firstName}`,
      };

    case 'BEAU_PARENT_BEAU_FILS_FILLE':
      return {
        labelAtoB: isFemaleA ? `Belle-mère de ${memberB.firstName}` : `Beau-père de ${memberB.firstName}`,
        labelBtoA: isFemaleB ? `Belle-fille de ${memberA.firstName}` : `Beau-fils / Gendre de ${memberA.firstName}`,
      };

    case 'PARRAIN_MARRAINE':
      return {
        labelAtoB: isFemaleA ? `Marraine de ${memberB.firstName}` : `Parrain de ${memberB.firstName}`,
        labelBtoA: isFemaleB ? `Filleule de ${memberA.firstName}` : `Filleul de ${memberA.firstName}`,
      };

    case 'AUTRE':
    default:
      return {
        labelAtoB: `En relation avec ${memberB.firstName}`,
        labelBtoA: `En relation avec ${memberA.firstName}`,
      };
  }
};

/**
 * Validate proposed relationship to prevent self-links, duplicates and logical inconsistencies
 */
export const validateRelationship = (
  memberAId: string,
  memberBId: string,
  relationshipType: RelationshipType,
  existingRelationships: Relationship[],
  members: Member[]
): ValidationResult => {
  // 1. Check self-relationship
  if (!memberAId || !memberBId) {
    return { isValid: false, error: 'Les deux membres doivent être sélectionnés.' };
  }

  if (memberAId === memberBId) {
    return {
      isValid: false,
      error: 'Une personne ne peut pas être liée à elle-même dans une relation familiale.',
    };
  }

  const memberA = members.find((m) => m.id === memberAId);
  const memberB = members.find((m) => m.id === memberBId);

  if (!memberA || !memberB) {
    return { isValid: false, error: 'L\'un des membres spécifiés est introuvable.' };
  }

  // 2. Check duplicate relationship
  const isDuplicate = existingRelationships.some((rel) => {
    if (rel.status === 'REFUSEE') return false; // Allowed to re-propose after a refusal

    const directMatch =
      rel.memberAId === memberAId &&
      rel.memberBId === memberBId &&
      rel.relationshipType === relationshipType;

    const reverseMatch =
      rel.memberAId === memberBId &&
      rel.memberBId === memberAId &&
      (isSymmetricRelationship(relationshipType)
        ? rel.relationshipType === relationshipType
        : false);

    return directMatch || reverseMatch;
  });

  if (isDuplicate) {
    return {
      isValid: false,
      error: `Une relation de type "${relationshipType}" existe déjà entre ${memberA.firstName} ${memberA.lastName} et ${memberB.firstName} ${memberB.lastName}.`,
    };
  }

  // 3. Generation logic check
  let warning: string | undefined;
  if (relationshipType === 'PARENT_ENFANT') {
    if (memberA.generationLevel && memberB.generationLevel) {
      if (memberA.generationLevel >= memberB.generationLevel) {
        warning = `Attention : La génération de ${memberA.firstName} (G${memberA.generationLevel}) n'est pas antérieure à celle de ${memberB.firstName} (G${memberB.generationLevel}). Vérifiez la hiérarchie parent/enfant.`;
      }
    }
    // Check birth dates if both present
    if (memberA.birthDate && memberB.birthDate) {
      const birthA = new Date(memberA.birthDate).getFullYear();
      const birthB = new Date(memberB.birthDate).getFullYear();
      if (!isNaN(birthA) && !isNaN(birthB) && birthA >= birthB) {
        return {
          isValid: false,
          error: `Incohérence de dates : ${memberA.firstName} (${birthA}) est né(e) la même année ou après son enfant déclaré ${memberB.firstName} (${birthB}).`,
        };
      }
    }
  }

  return { isValid: true, warning };
};

/**
 * Validate proposed alliance between two families
 */
export const validateAlliance = (
  sourceFamilyId: string,
  alliedFamilyId: string,
  allianceType: AllianceType,
  existingAlliances: Alliance[]
): ValidationResult => {
  if (!sourceFamilyId || !alliedFamilyId) {
    return { isValid: false, error: 'Les deux familles doivent être sélectionnées.' };
  }

  if (sourceFamilyId === alliedFamilyId) {
    return {
      isValid: false,
      error: 'Une famille ne peut pas sceller une alliance avec elle-même.',
    };
  }

  // Check duplicate active alliance of same type
  const isDuplicate = existingAlliances.some(
    (ali) =>
      ali.status !== 'REFUSEE' &&
      ali.status !== 'ARCHIVEE' &&
      ((ali.sourceFamilyId === sourceFamilyId && ali.alliedFamilyId === alliedFamilyId) ||
        (ali.sourceFamilyId === alliedFamilyId && ali.alliedFamilyId === sourceFamilyId)) &&
      ali.allianceType === allianceType
  );

  if (isDuplicate) {
    return {
      isValid: false,
      error: 'Une alliance active du même type existe déjà entre ces deux familles.',
    };
  }

  return { isValid: true };
};

/**
 * Validate linking a User Account to a Member record
 */
export const validateUserMemberLink = (
  userId: string,
  memberId: string,
  userAccounts: UserAccount[],
  members: Member[]
): ValidationResult => {
  const account = userAccounts.find((u) => u.id === userId);
  const member = members.find((m) => m.id === memberId);

  if (!account) {
    return { isValid: false, error: 'Compte utilisateur introuvable.' };
  }

  if (!member) {
    return { isValid: false, error: 'Fiche membre introuvable.' };
  }

  // Check if member is already linked to another account
  if (member.userId && member.userId !== userId) {
    const existingUser = userAccounts.find((u) => u.id === member.userId);
    return {
      isValid: false,
      error: `Cette fiche membre est déjà associée au compte de ${existingUser?.firstName || 'un autre utilisateur'} (${existingUser?.email || member.userId}).`,
    };
  }

  // Check if user account is already linked to another member
  if (account.memberId && account.memberId !== memberId) {
    const existingMember = members.find((m) => m.id === account.memberId);
    return {
      isValid: false,
      error: `Ce compte utilisateur est déjà rattaché à la fiche membre de ${existingMember?.firstName} ${existingMember?.lastName}.`,
    };
  }

  return { isValid: true };
};

/**
 * Retrieve full structured family network for a given member
 */
export interface MemberRelatives {
  member: Member;
  parents: { member: Member; relationship: Relationship }[];
  children: { member: Member; relationship: Relationship }[];
  spouses: { member: Member; relationship: Relationship }[];
  siblings: { member: Member; relationship: Relationship }[];
  grandparents: { member: Member; relationship: Relationship }[];
  grandchildren: { member: Member; relationship: Relationship }[];
  allies: { member: Member; relationship: Relationship; allianceTitle?: string }[];
  allRelationships: (Relationship & { relatedMember: Member; roleLabel: string })[];
  pendingProposals: (Relationship & { relatedMember: Member; roleLabel: string })[];
}

export const getMemberRelatives = (
  memberId: string,
  members: Member[],
  relationships: Relationship[],
  alliances: Alliance[] = []
): MemberRelatives | null => {
  const member = members.find((m) => m.id === memberId);
  if (!member) return null;

  const parents: { member: Member; relationship: Relationship }[] = [];
  const children: { member: Member; relationship: Relationship }[] = [];
  const spouses: { member: Member; relationship: Relationship }[] = [];
  const siblings: { member: Member; relationship: Relationship }[] = [];
  const grandparents: { member: Member; relationship: Relationship }[] = [];
  const grandchildren: { member: Member; relationship: Relationship }[] = [];
  const allies: { member: Member; relationship: Relationship; allianceTitle?: string }[] = [];
  const allRelationships: (Relationship & { relatedMember: Member; roleLabel: string })[] = [];
  const pendingProposals: (Relationship & { relatedMember: Member; roleLabel: string })[] = [];

  relationships.forEach((rel) => {
    if (rel.memberAId !== memberId && rel.memberBId !== memberId) return;

    const isMemberA = rel.memberAId === memberId;
    const relatedMemberId = isMemberA ? rel.memberBId : rel.memberAId;
    const relatedMember = members.find((m) => m.id === relatedMemberId);

    if (!relatedMember) return;

    const labels = getRelationshipLabel(
      rel.relationshipType,
      isMemberA ? member : relatedMember,
      isMemberA ? relatedMember : member
    );
    const roleLabel = isMemberA ? labels.labelAtoB : labels.labelBtoA;

    if (rel.status === 'PROPOSEE') {
      pendingProposals.push({
        ...rel,
        relatedMember,
        roleLabel,
      });
      return;
    }

    if (rel.status !== 'VALIDEE') return;

    allRelationships.push({
      ...rel,
      relatedMember,
      roleLabel,
    });

    switch (rel.relationshipType) {
      case 'PARENT_ENFANT':
        if (isMemberA) {
          // A is parent of B
          children.push({ member: relatedMember, relationship: rel });
        } else {
          // B is child of A -> A is parent of B
          parents.push({ member: relatedMember, relationship: rel });
        }
        break;

      case 'CONJOINT':
        spouses.push({ member: relatedMember, relationship: rel });
        if (relatedMember.familyType === 'ALLIE' || member.familyType === 'ALLIE') {
          const matchingAlliance = alliances.find(
            (a) =>
              (a.primaryMemberSourceId === memberId && a.primaryMemberAlliedId === relatedMemberId) ||
              (a.primaryMemberSourceId === relatedMemberId && a.primaryMemberAlliedId === memberId) ||
              (a.sourceFamilyId === member.primaryFamilyId && a.alliedFamilyId === relatedMember.primaryFamilyId) ||
              (a.sourceFamilyId === relatedMember.primaryFamilyId && a.alliedFamilyId === member.primaryFamilyId)
          );
          allies.push({
            member: relatedMember,
            relationship: rel,
            allianceTitle: matchingAlliance?.title,
          });
        }
        break;

      case 'FRERE_SOEUR':
        siblings.push({ member: relatedMember, relationship: rel });
        break;

      case 'GRAND_PARENT_PETIT_ENFANT':
        if (isMemberA) {
          grandchildren.push({ member: relatedMember, relationship: rel });
        } else {
          grandparents.push({ member: relatedMember, relationship: rel });
        }
        break;

      default:
        break;
    }
  });

  return {
    member,
    parents,
    children,
    spouses,
    siblings,
    grandparents,
    grandchildren,
    allies,
    allRelationships,
    pendingProposals,
  };
};

/**
 * Filter Member data based on audience visibility rules
 */
export const filterMemberVisibility = (
  member: Member,
  viewerRole: UserRole,
  isOwnProfile: boolean = false
): Member => {
  // Super Admin & Family Admin have unrestricted access
  if (viewerRole === 'SUPER_ADMIN' || viewerRole === 'ADMIN_FAMILIAL' || isOwnProfile) {
    return member;
  }

  // Member of Nzala / Allied Family
  if (viewerRole === 'MEMBRE_NZALA' || viewerRole === 'MEMBRE_ALLIE' || viewerRole === 'VALIDATEUR') {
    if (member.visibilityLevel === 'PRIVATE') {
      return {
        ...member,
        email: undefined,
        phone: undefined,
        bio: 'Informations biographiques réservées aux administrateurs familiaux.',
      };
    }
    return member;
  }

  // Public / Visitor Access
  if (member.visibilityLevel === 'PRIVATE') {
    return {
      id: member.id,
      firstName: member.firstName,
      lastName: member.lastName,
      gender: member.gender,
      livingStatus: member.livingStatus,
      primaryFamilyId: member.primaryFamilyId,
      primaryFamilyName: member.primaryFamilyName,
      familyType: member.familyType,
      belongingType: member.belongingType,
      membershipStatus: member.membershipStatus,
      generationLevel: member.generationLevel,
      generationStatus: member.generationStatus,
      visibilityLevel: member.visibilityLevel,
      createdAt: member.createdAt,
      updatedAt: member.updatedAt,
      bio: 'Profil protégé par la gouvernance familiale.',
    };
  }

  if (member.visibilityLevel === 'FAMILY') {
    return {
      ...member,
      email: undefined,
      phone: undefined,
      birthDate: member.birthDate ? `${new Date(member.birthDate).getFullYear()}` : undefined, // only show year
      deathDate: member.deathDate ? `${new Date(member.deathDate).getFullYear()}` : undefined,
    };
  }

  return member;
};
