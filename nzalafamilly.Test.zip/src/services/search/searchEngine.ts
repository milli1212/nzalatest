/**
 * NzalaFamilly - Moteur de Recherche Globale, Découverte & Filtrage Sécurisé
 * Implémente la recherche multilingue, la normalisation diacritique,
 * le respect strict de la confidentialité et l'exploration contextuelle.
 */

import {
  Member,
  Family,
  FamilyBranch,
  FamilyPost,
  FamilyEvent,
  FamilyStory,
  UpcomingBirthday,
  CurrentUser,
  MemoryAlbum,
  HistoricalPublication,
  PostScope,
} from '../../types';
import { LiveStream } from '../../types/socialFeatures';
import {
  SearchResult,
  SearchCategory,
  SearchCategoryGroup,
  SearchFilters,
  SearchHistoryItem,
  SmartSuggestion,
  SearchVisibilitySettings,
  DEFAULT_SEARCH_VISIBILITY_SETTINGS,
} from '../../types/search';
import { canUserViewPost } from '../postService';

// --- 1. NORMALISATION MULTILINGUE & DIACRITIQUE ---
export function normalizeSearchText(text: string | null | undefined): string {
  if (!text) return '';
  return text
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
}

/**
 * Calcule un score de pertinence entre une chaîne cible et les termes de recherche
 */
export function calculateMatchScore(
  targetText: string | null | undefined,
  queryTerms: string[],
  normalizedQuery: string,
  weight: number = 1
): number {
  if (!targetText) return 0;
  const normalizedTarget = normalizeSearchText(targetText);
  if (!normalizedTarget) return 0;

  let score = 0;

  // Correspondance exacte
  if (normalizedTarget === normalizedQuery) {
    score += 100 * weight;
  }
  // Débute par la requête
  else if (normalizedTarget.startsWith(normalizedQuery)) {
    score += 60 * weight;
  }
  // Contient la phrase complète
  else if (normalizedTarget.includes(normalizedQuery)) {
    score += 35 * weight;
  }

  // Correspondance par mot
  for (const term of queryTerms) {
    if (term.length > 1) {
      if (normalizedTarget === term) {
        score += 25 * weight;
      } else if (normalizedTarget.startsWith(term)) {
        score += 15 * weight;
      } else if (normalizedTarget.includes(term)) {
        score += 8 * weight;
      }
    }
  }

  return score;
}

// --- 2. VÉRIFICATEURS DE SÉCURITÉ & DE CONFIDENTIALITÉ ---

/**
 * Vérifie si l'utilisateur courant a le droit de voir ce membre et ses attributs
 */
export function canUserViewMember(
  member: Member,
  currentUser: CurrentUser,
  privacySettings?: SearchVisibilitySettings
): { canView: boolean; sanitizedMember: Member } {
  const isSuperAdmin = currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL';
  const isSelf = currentUser.memberId === member.id || currentUser.id === member.userId;
  const isVisitor = currentUser.role === 'VISITEUR';

  // Paramètres de visibilité dans la recherche
  const visibility = privacySettings || DEFAULT_SEARCH_VISIBILITY_SETTINGS;

  // Si le membre a désactivé son apparition dans la recherche (sauf pour admins et lui-même)
  if (!isSuperAdmin && !isSelf && visibility.showInSearch === false) {
    return { canView: false, sanitizedMember: member };
  }

  // Profil privé
  if (member.visibilityLevel === 'PRIVATE' && !isSuperAdmin && !isSelf) {
    // Si c'est un visiteur non authentifié, aucun accès
    if (isVisitor) {
      return { canView: false, sanitizedMember: member };
    }
  }

  // Copie assainie respectant la confidentialité
  const sanitized: Member = {
    ...member,
    firstName: visibility.showNameInSearch ? member.firstName : 'Membre',
    lastName: visibility.showNameInSearch ? member.lastName : 'Nzala',
    avatarUrl: visibility.showPhotoInSearch ? member.avatarUrl : undefined,
    primaryFamilyName: visibility.showFamilyInSearch ? member.primaryFamilyName : 'Famille restreinte',
    branchName: visibility.showBranchInSearch ? member.branchName : undefined,
    generationLevel: visibility.showGenerationInSearch ? member.generationLevel : 0,
    bio: visibility.showBioInSearch || isSuperAdmin || isSelf ? member.bio : undefined,
    birthDate: visibility.showBirthdayInSearch || isSuperAdmin || isSelf ? member.birthDate : undefined,
    location: visibility.showLocationInSearch || isSuperAdmin || isSelf ? member.location : undefined,
    phone: visibility.showContactInSearch || isSuperAdmin || isSelf ? member.phone : undefined,
    email: visibility.showContactInSearch || isSuperAdmin || isSelf ? member.email : undefined,
  };

  return { canView: true, sanitizedMember: sanitized };
}

/**
 * Vérifie l'accès à un événement selon son niveau de visibilité et confidentialité
 */
export function canUserViewEvent(event: FamilyEvent, currentUser: CurrentUser): boolean {
  const isCouncilOrAdmin =
    currentUser.role === 'SUPER_ADMIN' ||
    currentUser.role === 'ADMIN_FAMILIAL' ||
    currentUser.role === 'VALIDATEUR';

  // Événements confidentiels du Conseil
  if (event.isConfidential && !isCouncilOrAdmin) {
    return false;
  }

  // Visibilité publique ou visiteur
  if (currentUser.role === 'VISITEUR') {
    return event.visibility === 'PUBLIC' || event.visibility === 'INTER_FAMILLES';
  }

  // Événements privés
  if (event.visibility === 'PRIVE') {
    const isOrganizer = event.organizerId === currentUser.id;
    const isInvited = event.invitations?.some(
      (inv) => inv.userId === currentUser.id || inv.memberId === currentUser.memberId
    );
    return isOrganizer || isInvited || isCouncilOrAdmin;
  }

  // Événements Nzala interne
  if (event.visibility === 'NZALA_INTERNE') {
    return currentUser.familyId === 'fam-nzala' || !currentUser.familyId;
  }

  // Familles alliées ou inter-familles ou public
  return true;
}

/**
 * Vérifie l'accès à une Story
 */
export function canUserViewStory(story: FamilyStory, currentUser: CurrentUser): boolean {
  // Vérifier l'expiration (les stories de plus de 24h ne doivent jamais apparaître)
  const isExpired = new Date(story.expiresAt).getTime() <= Date.now();
  if (isExpired) return false;

  if (currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL') return true;
  if (story.authorId === currentUser.id) return true;

  if (currentUser.role === 'VISITEUR') {
    return story.scope === 'PUBLIC';
  }

  if (story.scope === 'PUBLIC' || story.scope === 'INTER_FAMILLES') return true;
  if (story.scope === 'NZALA_INTERNE') {
    return currentUser.familyId === 'fam-nzala' || !currentUser.familyId;
  }
  if (story.scope === 'BRANCHE' && story.targetBranchId) {
    return currentUser.branchId === story.targetBranchId;
  }

  return true;
}

/**
 * Vérifie l'accès à un Live Stream
 */
export function canUserViewLive(live: LiveStream, currentUser: CurrentUser): boolean {
  if (live.status === 'ENDED' || live.status === 'CANCELLED') {
    return false;
  }

  if (currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'ADMIN_FAMILIAL') return true;
  if (live.hostUserId === currentUser.id) return true;

  if (currentUser.role === 'VISITEUR') {
    return live.scope === 'PUBLIC';
  }

  if (live.scope === 'PUBLIC' || live.scope === 'INTER_FAMILLES') return true;
  if (live.scope === 'NZALA_INTERNE') {
    return currentUser.familyId === 'fam-nzala' || !currentUser.familyId;
  }

  return true;
}

// --- 3. MOTEUR DE RECHERCHE PRINCIPAL ---

export interface SearchDataSources {
  members: Member[];
  families: Family[];
  branches: FamilyBranch[];
  posts: FamilyPost[];
  events: FamilyEvent[];
  stories: FamilyStory[];
  liveStreams: LiveStream[];
  memoryAlbums?: MemoryAlbum[];
  historicalPublications?: HistoricalPublication[];
  currentUser: CurrentUser;
}

/**
 * Exécute la recherche globale avec filtrage préalable des permissions
 */
export function executeGlobalSearch(
  query: string,
  sources: SearchDataSources,
  category: SearchCategory = 'ALL',
  filters?: SearchFilters
): SearchResult[] {
  const normalizedQuery = normalizeSearchText(query);
  const terms = normalizedQuery.split(/\s+/).filter((t) => t.length > 0);

  if (!normalizedQuery && !filters) {
    return [];
  }

  const results: SearchResult[] = [];
  const {
    members,
    families,
    branches,
    posts,
    events,
    stories,
    liveStreams,
    memoryAlbums = [],
    historicalPublications = [],
    currentUser,
  } = sources;

  const searchAll = category === 'ALL';

  // 1. RECHERCHE MEMBRES
  if (searchAll || category === 'MEMBERS' || category === 'GENEALOGY') {
    members.forEach((m) => {
      // Filtrage sécurité amont
      const { canView, sanitizedMember } = canUserViewMember(m, currentUser);
      if (!canView) return;

      // Filtres avancés
      if (filters?.familyId && filters.familyId !== 'ALL' && m.primaryFamilyId !== filters.familyId) return;
      if (filters?.branchId && filters.branchId !== 'ALL' && m.branchId !== filters.branchId) return;
      if (filters?.generationLevel && filters.generationLevel !== 'ALL' && m.generationLevel !== Number(filters.generationLevel)) return;
      if (filters?.livingStatus && filters.livingStatus !== 'ALL' && m.livingStatus !== filters.livingStatus) return;
      if (filters?.belongingType && filters.belongingType !== 'ALL' && m.belongingType !== filters.belongingType) return;

      const fullName = `${sanitizedMember.firstName} ${sanitizedMember.postName || ''} ${sanitizedMember.lastName}`.trim();
      const nameReversed = `${sanitizedMember.lastName} ${sanitizedMember.firstName}`.trim();

      let score = 0;
      if (normalizedQuery) {
        score += calculateMatchScore(fullName, terms, normalizedQuery, 2.5);
        score += calculateMatchScore(nameReversed, terms, normalizedQuery, 2.0);
        score += calculateMatchScore(sanitizedMember.firstName, terms, normalizedQuery, 1.8);
        score += calculateMatchScore(sanitizedMember.lastName, terms, normalizedQuery, 1.8);
        score += calculateMatchScore(sanitizedMember.postName, terms, normalizedQuery, 1.5);
        score += calculateMatchScore(sanitizedMember.primaryFamilyName, terms, normalizedQuery, 1.0);
        score += calculateMatchScore(sanitizedMember.branchName, terms, normalizedQuery, 1.0);
        score += calculateMatchScore(sanitizedMember.profession, terms, normalizedQuery, 0.8);
        score += calculateMatchScore(sanitizedMember.location, terms, normalizedQuery, 0.7);

        // Correspondance génération (ex: "G1", "Génération 2", "Gen 3")
        if (
          normalizedQuery.includes(`g${sanitizedMember.generationLevel}`) ||
          normalizedQuery.includes(`generation ${sanitizedMember.generationLevel}`)
        ) {
          score += 20;
        }

        if (score <= 0) return;
      } else {
        score = 10; // score par défaut pour filtre sans texte
      }

      const isDirect = sanitizedMember.belongingType === 'APPARTENANCE_DIRECTE';
      const isDeceased = sanitizedMember.livingStatus === 'DECEDE';

      results.push({
        id: `member-${sanitizedMember.id}`,
        type: 'MEMBER',
        category: 'MEMBERS',
        title: fullName,
        subtitle: `${sanitizedMember.primaryFamilyName} ${sanitizedMember.branchName ? `• ${sanitizedMember.branchName}` : ''} • Gén. ${sanitizedMember.generationLevel}`,
        description: sanitizedMember.profession || sanitizedMember.bio || (isDeceased ? '🕊️ Hommage mémoriel' : undefined),
        avatarUrl: sanitizedMember.avatarUrl,
        badge: isDeceased ? 'Mémoire' : isDirect ? 'Lignée directe' : 'Membre allié',
        badgeColor: isDeceased ? 'slate' : isDirect ? 'blue' : 'emerald',
        linkTab: 'members',
        targetId: sanitizedMember.id,
        relevanceScore: score,
        isVerified: sanitizedMember.membershipStatus === 'ACTIF',
        metadata: {
          familyId: sanitizedMember.primaryFamilyId,
          familyName: sanitizedMember.primaryFamilyName,
          branchId: sanitizedMember.branchId,
          branchName: sanitizedMember.branchName,
          generationLevel: sanitizedMember.generationLevel,
          livingStatus: sanitizedMember.livingStatus,
          belongingType: sanitizedMember.belongingType,
        },
      });

      // Si recherche généalogie, ajouter aussi l'accès à l'arbre
      if (category === 'GENEALOGY' || (searchAll && score > 25)) {
        results.push({
          id: `genealogy-node-${sanitizedMember.id}`,
          type: 'GENEALOGY_NODE',
          category: 'GENEALOGY',
          title: `Arbre : ${fullName}`,
          subtitle: `Recentrer l'arbre généalogique sur ${sanitizedMember.firstName} (Génération ${sanitizedMember.generationLevel})`,
          description: `Branche ${sanitizedMember.branchName || 'Générale'} • Filiation & Alliances`,
          avatarUrl: sanitizedMember.avatarUrl,
          badge: `Gén. ${sanitizedMember.generationLevel}`,
          badgeColor: 'amber',
          linkTab: 'genealogy',
          targetId: sanitizedMember.id,
          relevanceScore: score * 0.95,
          metadata: {
            branchId: sanitizedMember.branchId,
            generationLevel: sanitizedMember.generationLevel,
          },
        });
      }
    });
  }

  // 2. RECHERCHE FAMILLES & BRANCHES
  if (searchAll || category === 'FAMILIES' || category === 'GENEALOGY') {
    // Familles
    families.forEach((f) => {
      let score = 0;
      if (normalizedQuery) {
        score += calculateMatchScore(f.name, terms, normalizedQuery, 2.5);
        score += calculateMatchScore(f.patriarchName, terms, normalizedQuery, 1.5);
        score += calculateMatchScore(f.originLocation, terms, normalizedQuery, 1.2);
        score += calculateMatchScore(f.territory, terms, normalizedQuery, 1.2);
        score += calculateMatchScore(f.description, terms, normalizedQuery, 0.8);

        if (score <= 0) return;
      } else {
        score = 15;
      }

      const isNzala = f.type === 'PRINCIPALE';

      results.push({
        id: `family-${f.id}`,
        type: 'FAMILY',
        category: 'FAMILIES',
        title: f.name,
        subtitle: isNzala ? 'Famille Souche Fondatrice' : `Famille Alliée Reconnue • ${f.membersCount || 0} membres`,
        description: f.description || f.originLocation,
        badge: isNzala ? 'Famille Souche' : 'Famille Alliée',
        badgeColor: isNzala ? 'blue' : 'emerald',
        linkTab: 'alliances',
        targetId: f.id,
        relevanceScore: score + (isNzala ? 20 : 10),
        metadata: {
          familyId: f.id,
          familyName: f.name,
          location: f.originLocation || f.territory,
        },
      });
    });

    // Branches généalogiques
    branches.forEach((b) => {
      let score = 0;
      if (normalizedQuery) {
        score += calculateMatchScore(b.name, terms, normalizedQuery, 2.5);
        score += calculateMatchScore(b.familyName, terms, normalizedQuery, 1.5);
        score += calculateMatchScore(b.foundingElderName, terms, normalizedQuery, 1.5);
        score += calculateMatchScore(b.description, terms, normalizedQuery, 0.8);

        if (score <= 0) return;
      } else {
        score = 12;
      }

      results.push({
        id: `branch-${b.id}`,
        type: 'BRANCH',
        category: 'GENEALOGY',
        title: `Branche ${b.name}`,
        subtitle: `${b.familyName} • Fondateur : ${b.foundingElderName || 'Non renseigné'}`,
        description: b.description || `Branche dynastique débutant à la Génération ${b.generationStart}`,
        badge: 'Branche',
        badgeColor: 'amber',
        linkTab: 'genealogy',
        targetId: b.id,
        relevanceScore: score + 10,
        metadata: {
          branchId: b.id,
          branchName: b.name,
          familyId: b.familyId,
        },
      });
    });
  }

  // 3. RECHERCHE PUBLICATIONS
  if (searchAll || category === 'POSTS') {
    posts.forEach((p) => {
      // Vérification permissions amont
      if (!canUserViewPost(p, currentUser)) return;

      // Filtres avancés
      if (filters?.authorId && filters.authorId !== 'ALL' && p.authorId !== filters.authorId) return;
      if (filters?.postType && filters.postType !== 'ALL' && p.postType !== filters.postType) return;
      if (filters?.postScope && filters.postScope !== 'ALL' && p.scope !== filters.postScope) return;

      // Filtre période
      if (filters?.period && filters.period !== 'ALL') {
        const postTime = new Date(p.createdAt).getTime();
        const now = Date.now();
        const oneDay = 24 * 60 * 60 * 1000;
        if (filters.period === 'TODAY' && now - postTime > oneDay) return;
        if (filters.period === 'WEEK' && now - postTime > 7 * oneDay) return;
        if (filters.period === 'MONTH' && now - postTime > 30 * oneDay) return;
        if (filters.period === 'YEAR' && now - postTime > 365 * oneDay) return;
      }

      let score = 0;
      if (normalizedQuery) {
        score += calculateMatchScore(p.title, terms, normalizedQuery, 2.5);
        score += calculateMatchScore(p.content, terms, normalizedQuery, 1.5);
        score += calculateMatchScore(p.authorName, terms, normalizedQuery, 1.8);
        score += calculateMatchScore(p.authorFamilyName, terms, normalizedQuery, 1.0);
        score += calculateMatchScore(p.authorBranchName, terms, normalizedQuery, 1.0);
        score += calculateMatchScore(p.relatedMemberName, terms, normalizedQuery, 1.5);

        if (score <= 0) return;
      } else {
        score = 10;
      }

      const isOfficial = p.isOfficial;

      results.push({
        id: `post-${p.id}`,
        type: 'POST',
        category: 'POSTS',
        title: p.title || `Publication de ${p.authorName}`,
        subtitle: `Par ${p.authorName} (${p.authorFamilyName || 'Famille'}) • ${new Date(p.createdAt).toLocaleDateString('fr-FR')}`,
        description: p.content ? (p.content.length > 140 ? `${p.content.substring(0, 140)}...` : p.content) : undefined,
        thumbnailUrl: p.imageUrl || p.media?.[0]?.url,
        badge: isOfficial ? 'Officiel Nzala' : p.postType || 'Publication',
        badgeColor: isOfficial ? 'amber' : 'blue',
        linkTab: 'announcements',
        targetId: p.id,
        relevanceScore: score + (isOfficial ? 15 : 0),
        isOfficial,
        date: p.createdAt,
        metadata: {
          postType: p.postType,
          familyId: p.targetFamilyId,
        },
      });
    });
  }

  // 4. RECHERCHE ÉVÉNEMENTS
  if (searchAll || category === 'EVENTS') {
    events.forEach((e) => {
      if (!canUserViewEvent(e, currentUser)) return;

      // Filtres avancés
      if (filters?.eventType && filters.eventType !== 'ALL' && e.eventType !== filters.eventType) return;
      if (filters?.familyId && filters.familyId !== 'ALL' && e.familyId !== filters.familyId) return;

      // Filtre période événement
      if (filters?.eventPeriod && filters.eventPeriod !== 'ALL') {
        const eventDate = new Date(e.startDate).getTime();
        const now = Date.now();
        const oneDay = 24 * 60 * 60 * 1000;
        if (filters.eventPeriod === 'UPCOMING' && eventDate < now - oneDay) return;
        if (filters.eventPeriod === 'PAST' && eventDate >= now) return;
        if (filters.eventPeriod === 'THIS_WEEK' && (eventDate < now - oneDay || eventDate > now + 7 * oneDay)) return;
        if (filters.eventPeriod === 'THIS_MONTH' && (eventDate < now - oneDay || eventDate > now + 30 * oneDay)) return;
      }

      let score = 0;
      if (normalizedQuery) {
        score += calculateMatchScore(e.title, terms, normalizedQuery, 2.5);
        score += calculateMatchScore(e.description, terms, normalizedQuery, 1.2);
        score += calculateMatchScore(e.location, terms, normalizedQuery, 1.5);
        score += calculateMatchScore(e.organizerName, terms, normalizedQuery, 1.3);
        score += calculateMatchScore(e.organizerFamily, terms, normalizedQuery, 1.0);
        score += calculateMatchScore(e.eventType, terms, normalizedQuery, 1.0);

        if (score <= 0) return;
      } else {
        score = 10;
      }

      results.push({
        id: `event-${e.id}`,
        type: 'EVENT',
        category: 'EVENTS',
        title: e.title,
        subtitle: `📅 ${new Date(e.startDate).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' })} • 📍 ${e.location}`,
        description: e.description || `Organisé par ${e.organizerName}`,
        badge: e.eventType,
        badgeColor: 'rose',
        linkTab: 'events',
        targetId: e.id,
        relevanceScore: score + 12,
        date: e.startDate,
        metadata: {
          eventType: e.eventType,
          eventStatus: e.status,
          location: e.location,
          participantsCount: e.participantsCount,
        },
      });
    });
  }

  // 5. RECHERCHE LIVES (DIFFUSIONS EN DIRECT & PROGRAMMÉES)
  if (searchAll || category === 'LIVES') {
    liveStreams.forEach((l) => {
      if (!canUserViewLive(l, currentUser)) return;

      let score = 0;
      if (normalizedQuery) {
        score += calculateMatchScore(l.title, terms, normalizedQuery, 2.5);
        score += calculateMatchScore(l.description, terms, normalizedQuery, 1.2);
        score += calculateMatchScore(l.hostName, terms, normalizedQuery, 1.8);
        score += calculateMatchScore(l.hostFamilyName, terms, normalizedQuery, 1.0);

        if (score <= 0) return;
      } else {
        score = 15;
      }

      const isLiveNow = l.status === 'LIVE';

      results.push({
        id: `live-${l.id}`,
        type: 'LIVE',
        category: 'LIVES',
        title: l.title,
        subtitle: isLiveNow
          ? `🔴 En Direct • Animé par ${l.hostName} (${l.viewersCount || 0} spectateurs)`
          : `📅 Live Programmé • Par ${l.hostName}`,
        description: l.description,
        thumbnailUrl: l.thumbnailUrl,
        avatarUrl: l.hostAvatar,
        badge: isLiveNow ? '🔴 EN DIRECT' : 'Programmé',
        badgeColor: isLiveNow ? 'rose' : 'purple',
        linkTab: 'announcements',
        targetId: l.id,
        relevanceScore: score + (isLiveNow ? 40 : 15),
        isLive: isLiveNow,
        metadata: {
          hostName: l.hostName,
          viewersCount: l.viewersCount,
        },
      });
    });
  }

  // 6. RECHERCHE STORIES (ACTIVES SEULEMENT)
  if (searchAll || category === 'STORIES') {
    stories.forEach((s) => {
      if (!canUserViewStory(s, currentUser)) return;

      let score = 0;
      if (normalizedQuery) {
        score += calculateMatchScore(s.authorName, terms, normalizedQuery, 2.0);
        score += calculateMatchScore(s.authorFamilyName, terms, normalizedQuery, 1.2);
        score += calculateMatchScore(s.authorBranchName, terms, normalizedQuery, 1.2);

        // Vérifier texte des slides
        s.slides.forEach((slide) => {
          score += calculateMatchScore(slide.text || slide.textContent || slide.caption, terms, normalizedQuery, 1.0);
        });

        if (score <= 0) return;
      } else {
        score = 8;
      }

      results.push({
        id: `story-${s.id}`,
        type: 'STORY',
        category: 'STORIES',
        title: `Story de ${s.authorName}`,
        subtitle: `${s.authorFamilyName || 'Famille'} • ${s.slides.length} diapositive(s)`,
        avatarUrl: s.authorAvatar,
        thumbnailUrl: s.slides[0]?.mediaUrl || s.slides[0]?.contentUrl,
        badge: 'Story 24h',
        badgeColor: 'purple',
        linkTab: 'announcements',
        targetId: s.id,
        relevanceScore: score,
        metadata: {
          familyName: s.authorFamilyName,
          branchName: s.authorBranchName,
        },
      });
    });
  }

  // 7. RECHERCHE MÉMOIRE & ARCHIVES HISTORIQUES
  if (searchAll || category === 'MEMORY') {
    memoryAlbums.forEach((album) => {
      let score = 0;
      if (normalizedQuery) {
        score += calculateMatchScore(album.title, terms, normalizedQuery, 2.2);
        score += calculateMatchScore(album.description, terms, normalizedQuery, 1.2);
        score += calculateMatchScore(album.historicalEra, terms, normalizedQuery, 1.5);
        score += calculateMatchScore(album.curatorName, terms, normalizedQuery, 1.0);

        if (score <= 0) return;
      } else {
        score = 10;
      }

      results.push({
        id: `album-${album.id}`,
        type: 'MEMORY_ALBUM',
        category: 'MEMORY',
        title: album.title,
        subtitle: `Archives Historiques • ${album.historicalEra || 'Époque Fondatrice'} • ${album.photoCount || 0} photos`,
        description: album.description,
        thumbnailUrl: album.coverUrl,
        badge: 'Mémoire Nzala',
        badgeColor: 'amber',
        linkTab: 'memoire',
        targetId: album.id,
        relevanceScore: score + 10,
        isOfficial: album.isOfficial,
      });
    });

    historicalPublications.forEach((pub) => {
      let score = 0;
      if (normalizedQuery) {
        score += calculateMatchScore(pub.title, terms, normalizedQuery, 2.2);
        score += calculateMatchScore(pub.summary, terms, normalizedQuery, 1.4);
        score += calculateMatchScore(pub.historicalPeriod, terms, normalizedQuery, 1.3);

        if (score <= 0) return;
      } else {
        score = 10;
      }

      results.push({
        id: `hist-pub-${pub.id}`,
        type: 'HISTORICAL_FIGURE',
        category: 'MEMORY',
        title: pub.title,
        subtitle: `Récit Historique • ${pub.historicalPeriod}`,
        description: pub.summary,
        badge: 'Patrimoine',
        badgeColor: 'amber',
        linkTab: 'memoire',
        targetId: pub.id,
        relevanceScore: score + 10,
        isOfficial: pub.verifiedByCouncil,
      });
    });
  }

  // Tri par pertinence décroissante
  results.sort((a, b) => b.relevanceScore - a.relevanceScore);

  return results;
}

/**
 * Organise les résultats par groupes de catégories avec comptage
 */
export function groupSearchResults(results: SearchResult[]): SearchCategoryGroup[] {
  const categoryConfigs: { category: SearchCategory; label: string; iconName: string }[] = [
    { category: 'MEMBERS', label: 'Membres', iconName: 'Users' },
    { category: 'FAMILIES', label: 'Familles', iconName: 'HeartHandshake' },
    { category: 'GENEALOGY', label: 'Généalogie & Branches', iconName: 'GitFork' },
    { category: 'POSTS', label: 'Publications & Fil', iconName: 'Newspaper' },
    { category: 'EVENTS', label: 'Événements & Célébrations', iconName: 'Calendar' },
    { category: 'LIVES', label: 'Nzala Live', iconName: 'Radio' },
    { category: 'STORIES', label: 'Stories Actives', iconName: 'Sparkles' },
    { category: 'MEMORY', label: 'Mémoire & Patrimoine', iconName: 'Crown' },
  ];

  return categoryConfigs
    .map((config) => {
      const catResults = results.filter((r) => r.category === config.category);
      return {
        category: config.category,
        label: config.label,
        iconName: config.iconName,
        count: catResults.length,
        results: catResults,
      };
    })
    .filter((group) => group.count > 0);
}

// --- 4. GESTION DE L'HISTORIQUE DE RECHERCHE LOCAL ---

const SEARCH_HISTORY_STORAGE_KEY = 'nzalafamilly_search_history_v1';
const MAX_HISTORY_ITEMS = 8;

export function loadSearchHistory(): SearchHistoryItem[] {
  try {
    const raw = localStorage.getItem(SEARCH_HISTORY_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed.slice(0, MAX_HISTORY_ITEMS);
    }
  } catch (err) {
    console.warn('Erreur lecture historique recherche:', err);
  }
  return [];
}

export function saveSearchHistoryItem(query: string, category: SearchCategory = 'ALL', count?: number): SearchHistoryItem[] {
  const cleanQuery = query.trim();
  if (!cleanQuery || cleanQuery.length < 2) return loadSearchHistory();

  try {
    const current = loadSearchHistory();
    // Éviter doublon
    const filtered = current.filter(
      (item) => normalizeSearchText(item.query) !== normalizeSearchText(cleanQuery)
    );

    const newItem: SearchHistoryItem = {
      id: `hist-${Date.now()}`,
      query: cleanQuery,
      category,
      timestamp: new Date().toISOString(),
      resultsCount: count,
    };

    const updated = [newItem, ...filtered].slice(0, MAX_HISTORY_ITEMS);
    localStorage.setItem(SEARCH_HISTORY_STORAGE_KEY, JSON.stringify(updated));
    return updated;
  } catch (err) {
    console.warn('Erreur sauvegarde historique recherche:', err);
    return [];
  }
}

export function deleteSearchHistoryItem(id: string): SearchHistoryItem[] {
  try {
    const current = loadSearchHistory();
    const updated = current.filter((item) => item.id !== id);
    localStorage.setItem(SEARCH_HISTORY_STORAGE_KEY, JSON.stringify(updated));
    return updated;
  } catch (err) {
    return [];
  }
}

export function clearAllSearchHistory(): void {
  try {
    localStorage.removeItem(SEARCH_HISTORY_STORAGE_KEY);
  } catch (err) {
    console.warn('Erreur purge historique:', err);
  }
}

// --- 5. GÉNÉRATEUR DE SUGGESTIONS INTELLIGENTES CONTEXTUELLES ---

export function getSmartSuggestions(currentUser: CurrentUser, liveStreams: LiveStream[] = []): SmartSuggestion[] {
  const isVisitor = currentUser.role === 'VISITEUR';
  const hasLiveActive = liveStreams.some((l) => l.status === 'LIVE');

  const suggestions: SmartSuggestion[] = [];

  if (hasLiveActive) {
    suggestions.push({
      id: 'sug-live',
      title: '🔴 Nzala Live en cours',
      subtitle: 'Rejoignez la diffusion vidéo en direct',
      icon: 'Radio',
      category: 'LIVES',
      actionType: 'NAVIGATE',
      targetTab: 'announcements',
    });
  }

  if (!isVisitor && currentUser.branchName) {
    suggestions.push({
      id: 'sug-branch',
      title: `👥 Membres de ma branche (${currentUser.branchName})`,
      subtitle: 'Retrouver les descendants directs de votre lignée',
      icon: 'Users',
      category: 'MEMBERS',
      actionType: 'SEARCH_PRESET',
      presetQuery: currentUser.branchName,
    });
  }

  suggestions.push({
    id: 'sug-tree',
    title: '🌳 Registre & Arbre Généalogique',
    subtitle: 'Naviguer dans la lignée et les filiations',
    icon: 'GitFork',
    category: 'GENEALOGY',
    actionType: 'NAVIGATE',
    targetTab: 'genealogy',
  });

  suggestions.push({
    id: 'sug-alliances',
    title: '👨‍👩‍👧 Familles Alliées Reconnues',
    subtitle: 'Mavungu, Kanza, Lukoki, Ndombe...',
    icon: 'HeartHandshake',
    category: 'FAMILIES',
    actionType: 'NAVIGATE',
    targetTab: 'alliances',
  });

  suggestions.push({
    id: 'sug-events',
    title: '📅 Prochains événements & cérémonies',
    subtitle: 'Consulter le calendrier familial',
    icon: 'Calendar',
    category: 'EVENTS',
    actionType: 'NAVIGATE',
    targetTab: 'events',
  });

  suggestions.push({
    id: 'sug-birthdays',
    title: '🎂 Anniversaires & Célébrations proches',
    subtitle: 'Souhaiter les anniversaires du mois',
    icon: 'Cake',
    category: 'EVENTS',
    actionType: 'SEARCH_PRESET',
    presetQuery: 'Anniversaire',
  });

  suggestions.push({
    id: 'sug-memory',
    title: '👑 Mémoire & Archives Fondatrices',
    subtitle: 'Récits des aînés, photos d’époque & hommages',
    icon: 'Crown',
    category: 'MEMORY',
    actionType: 'NAVIGATE',
    targetTab: 'memoire',
  });

  return suggestions;
}
