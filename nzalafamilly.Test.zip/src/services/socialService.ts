import {
  FamilyStory,
  FamilyStatusItem,
  CurrentUser,
  Member,
  MemberMention,
  PostScope,
} from '../types';

/**
 * Durée de vie par défaut d'une story : 24 heures en millisecondes.
 */
export const STORY_LIFETIME_MS = 24 * 60 * 60 * 1000;

/**
 * Vérifie si une story a expiré.
 */
export function isStoryExpired(story: FamilyStory): boolean {
  if (!story || !story.expiresAt) return false;
  return new Date(story.expiresAt).getTime() <= Date.now();
}

/**
 * Calcule le nombre d'heures restantes avant expiration de la story.
 */
export function getStoryHoursRemaining(story: FamilyStory): number {
  if (!story || !story.expiresAt) return 0;
  const diffMs = new Date(story.expiresAt).getTime() - Date.now();
  if (diffMs <= 0) return 0;
  return Math.ceil(diffMs / (1000 * 60 * 60));
}

/**
 * Formate le temps restant précis avant expiration d'une story.
 */
export function formatStoryTimeRemaining(story: FamilyStory): string {
  if (!story || !story.expiresAt) return 'Expirée';
  const diffMs = new Date(story.expiresAt).getTime() - Date.now();
  if (diffMs <= 0) return 'Expirée';
  
  const totalMinutes = Math.floor(diffMs / (1000 * 60));
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;

  if (hours > 1) {
    return `Il reste ${hours} h`;
  }
  if (hours === 1) {
    return minutes > 0 ? `Il reste 1 h ${minutes} min` : `Il reste 1 h`;
  }
  if (minutes > 0) {
    return `Il reste ${minutes} min`;
  }
  return 'Moins d\'une minute';
}

/**
 * Détermine si un utilisateur a le droit de voir une story.
 */
export function canUserViewStory(story: FamilyStory, user: CurrentUser): boolean {
  if (!story || !user) return false;

  const isSuperAdmin = user.role === 'SUPER_ADMIN';
  const isAdminFamilial = user.role === 'ADMIN_FAMILIAL';
  const isAuthor = story.authorId === user.id || (user.memberId && story.memberId === user.memberId);

  if (isAuthor || isSuperAdmin || isAdminFamilial) return true;

  // Contrôle de la portée (Scope)
  switch (story.scope) {
    case 'PUBLIC':
      return true;

    case 'NZALA_INTERNE':
      return user.familyType === 'NZALA_DIRECT' && user.affiliationStatus === 'APPROUVEE';

    case 'BRANCHE':
      if (!story.targetBranchId) return true;
      return user.familyType === 'NZALA_DIRECT' && user.affiliationStatus === 'APPROUVEE';

    case 'FAMILLE_ALLIEE':
      if (story.targetFamilyId && user.familyId === story.targetFamilyId) return true;
      return false;

    case 'INTER_FAMILLES': {
      const isNzalaDirect = user.familyType === 'NZALA_DIRECT' && user.affiliationStatus === 'APPROUVEE';
      const isTargetAllied = Boolean(story.targetFamilyId && user.familyId === story.targetFamilyId);
      return isNzalaDirect || isTargetAllied;
    }

    case 'PRIVE':
      return Boolean(isAuthor || isSuperAdmin || isAdminFamilial);

    default:
      return false;
  }
}

/**
 * Détermine si un utilisateur a le droit de voir un statut.
 */
export function canUserViewStatus(statusItem: FamilyStatusItem, user: CurrentUser): boolean {
  if (!statusItem || !user) return false;

  const isSuperAdmin = user.role === 'SUPER_ADMIN';
  const isAdminFamilial = user.role === 'ADMIN_FAMILIAL';
  const isAuthor = statusItem.authorId === user.id || (user.memberId && statusItem.memberId === user.memberId);

  if (isAuthor || isSuperAdmin || isAdminFamilial) return true;

  switch (statusItem.scope) {
    case 'PUBLIC':
      return true;

    case 'NZALA_INTERNE':
      return user.familyType === 'NZALA_DIRECT' && user.affiliationStatus === 'APPROUVEE';

    case 'BRANCHE':
      return user.familyType === 'NZALA_DIRECT' && user.affiliationStatus === 'APPROUVEE';

    case 'FAMILLE_ALLIEE':
      if (statusItem.targetFamilyId && user.familyId === statusItem.targetFamilyId) return true;
      return false;

    case 'INTER_FAMILLES': {
      const isNzalaDirect = user.familyType === 'NZALA_DIRECT' && user.affiliationStatus === 'APPROUVEE';
      const isTargetAllied = Boolean(statusItem.targetFamilyId && user.familyId === statusItem.targetFamilyId);
      return isNzalaDirect || isTargetAllied;
    }

    case 'PRIVE':
      return Boolean(isAuthor || isSuperAdmin || isAdminFamilial);

    default:
      return false;
  }
}

/**
 * Filtre les stories actives et visibles pour un utilisateur donné,
 * groupées par auteur avec calcul du statut vu/non vu.
 */
export function filterVisibleActiveStories(stories: FamilyStory[], user: CurrentUser): FamilyStory[] {
  return stories.filter((s) => {
    if (isStoryExpired(s) && s.authorId !== user.id) return false;
    return canUserViewStory(s, user);
  });
}

/**
 * Extrait les mentions d'un texte et associe les membres correspondants.
 */
export function parseMentionsFromText(text: string, members: Member[]): MemberMention[] {
  if (!text || !members) return [];
  const mentions: MemberMention[] = [];

  // Match @Nom ou @Prénom_Nom ou @"Prénom Nom"
  const regex = /@([a-zA-ZÀ-ÿ0-9_-]+)/g;
  let match: RegExpExecArray | null;

  while ((match = regex.exec(text)) !== null) {
    const handle = match[1].toLowerCase().replace(/_/g, ' ');
    const member = members.find((m) => {
      const full = `${m.firstName} ${m.lastName}`.toLowerCase();
      const first = m.firstName.toLowerCase();
      const last = m.lastName.toLowerCase();
      return full === handle || first === handle || last === handle;
    });

    if (member) {
      mentions.push({
        memberId: member.id,
        memberName: `${member.firstName} ${member.lastName}`,
        memberAvatar: member.avatarUrl,
        startIndex: match.index,
        endIndex: match.index + match[0].length,
      });
    }
  }

  return mentions;
}

/**
 * Humeurs / statuts prédéfinis pour "Mon Statut"
 */
export const STATUS_MOOD_PRESETS = [
  { emoji: '👋', label: 'Passe un bonjour' },
  { emoji: '🙏', label: 'En prière & reconnaissance' },
  { emoji: '🎉', label: 'En fête / Célébration' },
  { emoji: '✈️', label: 'En déplacement / Voyage' },
  { emoji: '🏡', label: 'Au village / Au pays' },
  { emoji: '🎓', label: 'Études & Projets' },
  { emoji: '💼', label: 'Au travail' },
  { emoji: '🕊️', label: 'En pensée avec la famille' },
  { emoji: '🍲', label: 'En cuisine familiale' },
];
