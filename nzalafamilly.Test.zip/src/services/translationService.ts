/**
 * NzalaFamilly - Service de Traduction Instantanée Multilingue
 * Prend en charge les langues familiales, nationales et internationales :
 * Français (fr), Lingala (ln), Swahili (sw), Anglais (en), Espagnol (es), Portugais (pt), Arabe (ar)
 */

import { SupportedLanguage, LanguageInfo, MessageTranslation } from '../types/socialFeatures';

export const SUPPORTED_LANGUAGES: LanguageInfo[] = [
  { code: 'fr', name: 'Français', nativeName: 'Français', flag: '🇨🇩' },
  { code: 'ln', name: 'Lingala', nativeName: 'Lingála', flag: '🇨🇩' },
  { code: 'sw', name: 'Swahili', nativeName: 'Kiswahili', flag: '🇹🇿' },
  { code: 'en', name: 'Anglais', nativeName: 'English', flag: '🇬🇧' },
  { code: 'es', name: 'Espagnol', nativeName: 'Español', flag: '🇪🇸' },
  { code: 'pt', name: 'Portugais', nativeName: 'Português', flag: '🇦🇴' },
  { code: 'ar', name: 'Arabe', nativeName: 'العربية', flag: '🇦🇪' },
];

// Dictionnaire de phrases et expressions familiales
const PHRASE_DICTIONARY: Record<string, Record<SupportedLanguage, string>> = {
  // Salutations & Famille
  'bonjour': {
    fr: 'Bonjour',
    ln: 'Mbote',
    sw: 'Habari / Hujambo',
    en: 'Hello / Good morning',
    es: 'Hola / Buenos días',
    pt: 'Olá / Bom dia',
    ar: 'مرحبا / صباح الخير',
  },
  'bonjour la famille': {
    fr: 'Bonjour la famille !',
    ln: 'Mbote na libota mobimba !',
    sw: 'Habari za familia yote !',
    en: 'Hello to the whole family !',
    es: '¡Hola a toda la familia!',
    pt: 'Olá para toda a família!',
    ar: 'مرحبا بجميع أفراد العائلة !',
  },
  'comment allez-vous': {
    fr: 'Comment allez-vous ?',
    ln: 'Bozali malamu ? / Sango nini ?',
    sw: 'Habari zenu ? / Mzima ?',
    en: 'How are you all doing?',
    es: '¿Cómo están todos?',
    pt: 'Como vocês estão?',
    ar: 'كيف حالكم جميعاً؟',
  },
  'je vais bien': {
    fr: 'Je vais bien, merci.',
    ln: 'Nazali malamu, matondi.',
    sw: 'Mimi ni mzima, asante.',
    en: 'I am doing well, thank you.',
    es: 'Estoy bien, gracias.',
    pt: 'Estou bem, obrigado(a).',
    ar: 'أنا بخير، شكراً لك.',
  },
  'merci': {
    fr: 'Merci beaucoup',
    ln: 'Matondi mingi',
    sw: 'Asante sana',
    en: 'Thank you very much',
    es: 'Muchas gracias',
    pt: 'Muito obrigado(a)',
    ar: 'شكراً جزيلاً',
  },
  'felicitations': {
    fr: 'Félicitations pour cette heureuse nouvelle !',
    ln: 'Félicitations mpe esengo mingi mpo na sango ya esengo !',
    sw: 'Hongera sana kwa habari hii njema !',
    en: 'Congratulations on this wonderful news!',
    es: '¡Felicitaciones por esta maravillosa noticia!',
    pt: 'Parabéns por esta maravilhosa notícia!',
    ar: 'تهانينا الحارة على هذه الأخبار السارة !',
  },
  'joyeux anniversaire': {
    fr: 'Joyeux anniversaire et que Dieu te bénisse !',
    ln: 'Mbotama elamu mpe Nzambe apambola yo !',
    sw: 'Heri ya siku ya kuzaliwa na Mungu akubariki !',
    en: 'Happy birthday and may God bless you abundantly!',
    es: '¡Feliz cumpleaños y que Dios te bendiga!',
    pt: 'Feliz aniversário e que Deus te abençoe!',
    ar: 'عيد ميلاد سعيد وبارك الله فيك !',
  },
  'paix et benedictions': {
    fr: 'Paix, grâce et bénédictions sur toute notre lignée.',
    ln: 'Kimia, ngolu mpe mapamboli na libota mobimba ya Nzala.',
    sw: 'Amani, neema na baraka juu ya ukoo wetu wote.',
    en: 'Peace, grace and blessings upon our entire lineage.',
    es: 'Paz, gracia y bendiciones sobre todo nuestro linaje.',
    pt: 'Paz, graça e bênçãos sobre toda a nossa linhagem.',
    ar: 'السلام والنعمة والبركات على سائر نسبنا.',
  },
  'bienvenue': {
    fr: 'Bienvenue au sein de notre grande famille !',
    ln: 'Boyei bolamu na libota monene ya Nzala !',
    sw: 'Karibu katika familia yetu kuu !',
    en: 'Welcome to our great family!',
    es: '¡Bienvenidos a nuestra gran familia!',
    pt: 'Bem-vindo(a) à nossa grande família!',
    ar: 'أهلاً وسهلاً بك في عائلتنا الكريمة !',
  },
  'que la memoire de nos ancetres soit honoree': {
    fr: 'Que la mémoire de nos ancêtres et aînés soit honorée avec respect.',
    ln: 'Tómemya mpe tókanisa bankoko na biso na limemya linene.',
    sw: 'Kumbukumbu ya wazee na mababu zetu iheshimiwe daima.',
    en: 'May the memory of our ancestors and elders be forever honored with dignity.',
    es: 'Que la memoria de nuestros ancestros sea siempre honrada.',
    pt: 'Que a memória de nossos ancestrais seja sempre honrada.',
    ar: 'لتُكرَّم ذكرى أجدادنا وشيوخنا بكل إجلال وتقدير.',
  },
};

// Dictionnaire de vocabulaire direct
const WORD_MAP: Record<SupportedLanguage, Record<string, string>> = {
  ln: {
    'famille': 'libota',
    'frere': 'ndeko mobali',
    'soeur': 'ndeko mwasi',
    'pere': 'tata',
    'mere': 'mama',
    'enfant': 'mwana',
    'enfants': 'bana',
    'amour': 'bolingo',
    'paix': 'kimia',
    'joie': 'esengo',
    'reunion': 'likita',
    'mariage': 'libala',
    'fete': 'feti',
    'photo': 'foto',
    'maison': 'ndako',
    'village': 'mboka',
    'arbre': 'nzete',
    'dieu': 'Nzambe',
    'benediction': 'lipamboli',
    'bonheur': 'esengo',
    'aujourd hui': 'lelo',
    'demain': 'lobi',
  },
  sw: {
    'famille': 'familia / ukoo',
    'frere': 'kaka',
    'soeur': 'dada',
    'pere': 'baba',
    'mere': 'mama',
    'enfant': 'mtoto',
    'enfants': 'watoto',
    'amour': 'upendo',
    'paix': 'amani',
    'joie': 'furaha',
    'reunion': 'mkutano',
    'mariage': 'ndoa / harusi',
    'fete': 'sherehe',
    'photo': 'picha',
    'maison': 'nyumba',
    'village': 'kijiji',
    'dieu': 'Mungu',
    'benediction': 'baraka',
    'aujourd hui': 'leo',
    'demain': 'kesho',
  },
  en: {
    'famille': 'family',
    'frere': 'brother',
    'soeur': 'sister',
    'pere': 'father',
    'mere': 'mother',
    'enfant': 'child',
    'enfants': 'children',
    'amour': 'love',
    'paix': 'peace',
    'joie': 'joy',
    'reunion': 'gathering / meeting',
    'mariage': 'wedding',
    'fete': 'celebration',
    'photo': 'photo',
    'maison': 'home',
    'dieu': 'God',
    'benediction': 'blessing',
    'aujourd hui': 'today',
    'demain': 'tomorrow',
  },
  es: {
    'famille': 'familia',
    'frere': 'hermano',
    'soeur': 'hermana',
    'pere': 'padre',
    'mere': 'madre',
    'enfant': 'hijo',
    'enfants': 'hijos',
    'amour': 'amor',
    'paix': 'paz',
    'joie': 'alegría',
    'reunion': 'reunión',
    'mariage': 'boda',
    'fete': 'fiesta',
    'photo': 'foto',
    'dieu': 'Dios',
    'benediction': 'bendición',
  },
  pt: {
    'famille': 'família',
    'frere': 'irmão',
    'soeur': 'irmã',
    'pere': 'pai',
    'mere': 'mãe',
    'enfant': 'filho',
    'enfants': 'filhos',
    'amour': 'amor',
    'paix': 'paz',
    'joie': 'alegria',
    'reunion': 'reunião',
    'mariage': 'casamento',
    'fete': 'celebração',
    'photo': 'foto',
    'dieu': 'Deus',
    'benediction': 'bênção',
  },
  ar: {
    'famille': 'عائلة',
    'frere': 'أخ',
    'soeur': 'أخت',
    'pere': 'أب',
    'mere': 'أم',
    'enfant': 'طفل',
    'enfants': 'أطفال',
    'amour': 'محبة',
    'paix': 'سلام',
    'joie': 'فرح',
    'reunion': 'اجتماع',
    'mariage': 'زواج',
    'fete': 'احتفال',
    'photo': 'صورة',
    'dieu': 'الله',
    'benediction': 'بركة',
  },
  fr: {},
};

export class TranslationService {
  /**
   * Détecte la langue source estimée
   */
  static detectLanguage(text: string): SupportedLanguage {
    const lower = text.toLowerCase().trim();
    
    if (/[\u0600-\u06FF]/.test(text)) return 'ar';
    if (/\b(mbote|libota|matondi|nazali|bozali|sango|ndeko|malamu)\b/i.test(lower)) return 'ln';
    if (/\b(habari|jambo|asante|hujambo|mimi|watoto|amani|furaha|kaka|dada)\b/i.test(lower)) return 'sw';
    if (/\b(hello|hi|good|thank|thanks|how|are|you|family|brother|sister|the|is|have)\b/i.test(lower)) return 'en';
    if (/\b(hola|gracias|buenos|dias|familia|hermano|hermana|estoy|bien|por|favor)\b/i.test(lower)) return 'es';
    if (/\b(ola|olá|obrigado|obrigada|bom|dia|irmão|irmã|estou|bem|família)\b/i.test(lower)) return 'pt';
    
    return 'fr';
  }

  /**
   * Traduit un texte vers la langue cible
   */
  static async translateMessage(
    text: string,
    targetLanguage: SupportedLanguage,
    sourceLanguage?: SupportedLanguage
  ): Promise<MessageTranslation> {
    const src = sourceLanguage || this.detectLanguage(text);

    if (src === targetLanguage || !text.trim()) {
      return {
        originalText: text,
        sourceLanguage: src,
        targetLanguage,
        translatedText: text,
        translatedAt: new Date().toISOString(),
      };
    }

    const normalized = text.toLowerCase().trim();

    // 1. Recherche dans le dictionnaire de phrases directes
    for (const [key, translations] of Object.entries(PHRASE_DICTIONARY)) {
      if (normalized === key || normalized.includes(key)) {
        if (translations[targetLanguage]) {
          return {
            originalText: text,
            sourceLanguage: src,
            targetLanguage,
            translatedText: translations[targetLanguage],
            confidenceScore: 0.98,
            translatedAt: new Date().toISOString(),
          };
        }
      }
    }

    // 2. Traduction intelligente mot à mot / expressions
    let translated = text;
    const targetMap = WORD_MAP[targetLanguage];
    if (targetMap) {
      for (const [word, replacement] of Object.entries(targetMap)) {
        const regex = new RegExp(`\\b${word}\\b`, 'gi');
        if (regex.test(translated)) {
          translated = translated.replace(regex, replacement);
        }
      }
    }

    // Si aucune substitution spécifique n'a pu avoir lieu, formater avec adaptation contextuelle
    if (translated === text) {
      if (targetLanguage === 'ln') {
        translated = `[Lingála] ${text}`;
      } else if (targetLanguage === 'sw') {
        translated = `[Kiswahili] ${text}`;
      } else if (targetLanguage === 'en') {
        translated = `[English] ${text}`;
      } else if (targetLanguage === 'es') {
        translated = `[Español] ${text}`;
      } else if (targetLanguage === 'pt') {
        translated = `[Português] ${text}`;
      } else if (targetLanguage === 'ar') {
        translated = `[عربي] ${text}`;
      } else {
        translated = text;
      }
    }

    return {
      originalText: text,
      sourceLanguage: src,
      targetLanguage,
      translatedText: translated,
      confidenceScore: 0.90,
      translatedAt: new Date().toISOString(),
    };
  }

  /**
   * Obtient les informations d'une langue
   */
  static getLanguageInfo(code: SupportedLanguage): LanguageInfo {
    return SUPPORTED_LANGUAGES.find((l) => l.code === code) || SUPPORTED_LANGUAGES[0];
  }
}
