/**
 * NzalaFamilly - Modèles TypeScript pour le module d'Appels (NZALA CALLS & WebRTC)
 */

export type CallType = 'AUDIO' | 'VIDEO';
export type CallStatus =
  | 'IDLE'
  | 'RINGING'
  | 'CONNECTING'
  | 'CONNECTED'
  | 'ENDED'
  | 'MISSED'
  | 'REJECTED'
  | 'BUSY'
  | 'ERROR';

export type CallDirection = 'INCOMING' | 'OUTGOING';

export interface CallParticipant {
  userId: string;
  name: string;
  avatarUrl?: string;
  role?: string;
  familyName?: string;
  isMuted?: boolean;
  isVideoEnabled?: boolean;
  isSpeaking?: boolean;
  connectionQuality?: 'EXCELLENT' | 'GOOD' | 'POOR';
}

export interface CallSession {
  id: string;
  type: CallType;
  status: CallStatus;
  direction: CallDirection;
  initiatorId: string;
  initiatorName: string;
  initiatorAvatar?: string;
  recipientId: string;
  recipientName: string;
  recipientAvatar?: string;
  conversationId?: string;
  startedAt: string;
  connectedAt?: string;
  endedAt?: string;
  durationSeconds: number;
  isMuted: boolean;
  isVideoEnabled: boolean;
  isFrontCamera: boolean;
  isSpeakerOn: boolean;
  isSimulated: boolean;
  isGroup?: boolean;
  groupTitle?: string;
  error?: string;
}

export interface CallHistoryItem {
  id: string;
  type: CallType;
  direction: CallDirection;
  status: 'COMPLETED' | 'MISSED' | 'REJECTED' | 'CANCELLED';
  callerId: string;
  callerName: string;
  callerAvatar?: string;
  receiverId: string;
  receiverName: string;
  receiverAvatar?: string;
  conversationId?: string;
  timestamp: string;
  durationSeconds: number;
  recordedNote?: string;
  isSimulated?: boolean;
}

export type WebRTCPeerState = 'new' | 'connecting' | 'connected' | 'disconnected' | 'failed' | 'closed';

export interface SignalingMessage {
  type: 'CALL_REQUEST' | 'CALL_ACCEPT' | 'CALL_REJECT' | 'CALL_END' | 'OFFER' | 'ANSWER' | 'ICE_CANDIDATE' | 'PING' | 'PONG';
  callId: string;
  senderId: string;
  targetId: string;
  callType?: CallType;
  payload?: any;
  timestamp: string;
}
