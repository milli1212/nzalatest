/**
 * NzalaFamilly - Core Domain Types (Étape 3: Modélisation Familiale Fondamentale)
 * Defines Families, Branches, Members, Relationships, Alliances, Verification Requests, Roles & Permissions.
 */

// --- 1. FAMILY MODEL ---
export type FamilyType = 'PRINCIPALE' | 'ALLIEE';
export type FamilyStatus = 'ACTIVE' | 'ARCHIVEE' | 'EN_COURS_RATIFICATION';

export interface Family {
  id: string;
  name: string;
  code: string;
  type: FamilyType;
  status: FamilyStatus;
  originLocation?: string;
  territory?: string; // Territoire / province / chefferie d'origine
  description: string;
  foundingYear?: number;
  patriarchName?: string;
  membersCount: number;
  alliancesCount: number;
  badgeColor?: string;
  historicalInfo?: string; // Données historiques et traditions orales
  createdAt: string;
  updatedAt: string;
}

// --- 2. FAMILY BRANCH MODEL ---
export interface FamilyBranch {
  id: string;
  familyId: string;
  familyName: string;
  name: string;
  code: string;
  description: string;
  foundingElderName?: string;
  foundingElderId?: string;
  generationStart: number;
  territory?: string;
  status: 'ACTIVE' | 'ARCHIVEE';
  membersCount: number;
  createdAt: string;
  updatedAt: string;
}

// --- 3. MEMBER & FAMILY PERSON MODEL ---
export type Gender = 'M' | 'F' | 'AUTRE';
export type LivingStatus = 'VIVANT' | 'DECEDE' | 'INCONNU';

export interface BirthInformation {
  birthDate?: string;
  city?: string;
  territory?: string;
  country?: string;
  formattedPlace?: string;
  privacyLevel?: 'PUBLIC' | 'FAMILY_ONLY' | 'PRIVATE';
  hideAge?: boolean;
}

export type MemberBelonging = 
  | 'APPARTENANCE_DIRECTE' // Lignée directe Nzala (souche consanguine)
  | 'ALLIANCE_MARIAGE'     // Conjoint(e) par mariage
  | 'ALLIANCE_DESCENDANCE' // Enfant / descendant issu d'une alliance
  | 'ALLIANCE_AUTRE';      // Autre lien reconnu par le Conseil

export type MembershipStatus = 
  | 'ACTIF' 
  | 'EN_ATTENTE_VERIFICATION' 
  | 'SUSPENDU'
  | 'ARCHIVE';

export type GenerationStatus = 'CONNUE' | 'ESTIMEE' | 'VALIDEE';
export type VisibilityLevel = 'PUBLIC' | 'FAMILY' | 'PRIVATE';

export interface Member {
  id: string;
  userId?: string; // Lien optionnel vers un compte User (si la personne utilise la plateforme)
  firstName: string;
  lastName: string;
  middleName?: string;
  postName?: string; // Postnom traditionnel
  maidenName?: string; // Nom de jeune fille si applicable
  gender: Gender;
  birthDate?: string;
  birthPlace?: string;
  birthCity?: string;
  birthTerritory?: string;
  birthCountry?: string;
  livingStatus: LivingStatus;
  deathDate?: string; // Si décédé(e)
  burialPlace?: string; // Lieu de repos / sépulture si décédé(e)
  primaryFamilyId: string; // ID de la famille de rattachement
  primaryFamilyName: string;
  familyType: 'NZALA_DIRECT' | 'ALLIE';
  originFamilyName?: string; // Famille d'origine si différente (ex: famille de naissance pour un conjoint)
  belongingType: MemberBelonging;
  membershipStatus: MembershipStatus;
  generationLevel: number; // 1: Patriarches fondateurs, 2: Aînés/Branches, 3: Descendants, 4: Jeunesse...
  generationStatus: GenerationStatus;
  branchId?: string;
  branchName?: string;
  visibilityLevel: VisibilityLevel; // PUBLIC, FAMILY, PRIVATE
  email?: string;
  phone?: string;
  avatarUrl?: string;
  profession?: string;
  location?: string;
  bio?: string;
  spouseName?: string;
  spouseFamilyName?: string;
  // Données historiques & Mémoire
  isHistoricalFigure?: boolean;
  honorificTitle?: string;
  historicalEra?: string; // e.g. "1920-1980", "Époque Fondatrice"
  anecdotes?: string[];
  historicalSources?: string[];
  historicalPhotos?: MediaItem[];
  createdAt: string;
  updatedAt: string;
}

// Distinction explicite: FamilyPerson représente toute personne de la généalogie/histoire (avec ou sans compte)
export type FamilyPerson = Member;

// --- 4. RELATIONSHIP MODEL ---
export type RelationshipType =
  | 'PARENT_ENFANT'
  | 'CONJOINT'
  | 'FRERE_SOEUR'
  | 'GRAND_PARENT_PETIT_ENFANT'
  | 'ONCLE_TANTE_NEVEU_NIECE'
  | 'COUSIN'
  | 'BEAU_PARENT_BEAU_FILS_FILLE'
  | 'PARRAIN_MARRAINE'
  | 'AUTRE';

export type RelationshipStatus = 
  | 'PROPOSEE' 
  | 'VALIDEE' 
  | 'REFUSEE' 
  | 'SUSPENDUE';

export type RelationshipSource = 
  | 'ADMINISTRATEUR' 
  | 'MEMBRE_PROPOSITION' 
  | 'IMPORT_HISTORIQUE' 
  | 'VALIDATEUR';

export interface Relationship {
  id: string;
  memberAId: string;
  memberAName: string;
  memberBId: string;
  memberBName: string;
  relationshipType: RelationshipType;
  relationLabel: string; // e.g. "Père de", "Époux de", "Conjoint(e) de", "Fils de", "Mère de"
  status: RelationshipStatus;
  source: RelationshipSource;
  proposedBy?: string;
  proposedByName?: string;
  validatedBy?: string;
  validatedByName?: string;
  validatedAt?: string;
  startDate?: string; // e.g. date de mariage
  endDate?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

// --- 5. ALLIANCE MODEL ---
export type AllianceType = 
  | 'MARIAGE' 
  | 'DESCENDANCE' 
  | 'ALLIANCE_FAMILIALE'
  | 'PACT_FAMILIAL' 
  | 'AUTRE';

export type AllianceStatus = 
  | 'PROPOSEE'
  | 'EN_VERIFICATION'
  | 'APPROUVEE'
  | 'VALIDEE'
  | 'REFUSEE'
  | 'ARCHIVEE'
  | 'SUSPENDUE';

export interface Alliance {
  id: string;
  sourceFamilyId: string; // Ex: fam-nzala
  sourceFamilyName: string;
  alliedFamilyId: string; // Ex: fam-mavungu
  alliedFamilyName: string;
  allianceType: AllianceType;
  title: string;
  description: string;
  status: AllianceStatus;
  startDate?: string;
  endDate?: string;
  primaryMemberSourceId?: string; // Personne clé côté Famille Source (ex: Jean-Pierre Nzala)
  primaryMemberSourceName?: string;
  primaryMemberAlliedId?: string; // Personne clé côté Famille Alliée (ex: Claudine Mavungu)
  primaryMemberAlliedName?: string;
  validatedBy?: string;
  validatedByName?: string;
  validatedAt?: string;
  historicalContext?: string;
  descendantsCount?: number;
  notes?: string;
  createdAt: string;
  updatedAt?: string;
}

// --- 6. VERIFICATION REQUEST & AFFILIATION ---
export type VerificationStatus =
  | 'EN_ATTENTE'
  | 'EN_VERIFICATION'
  | 'COMPLEMENT_REQUIS'
  | 'APPROUVEE'
  | 'REFUSEE'
  | 'SUSPENDUE';

export type AffiliationOption =
  | 'NZALA_DIRECT'       // 1. Membre direct de la famille Nzala (descendance directe, lignée sanguine)
  | 'NZALA_CONJOINT'     // 2. Conjoint(e) d'un membre de la famille Nzala
  | 'ALLIANCE_DESCENDANT'// 3. Descendant issu d'une alliance avec la famille Nzala
  | 'FAMILLE_ALLIEE'     // 4. Représentant ou membre d'une famille alliée
  | 'AUTRE_LIEN';        // 5. Autre lien familial ou historique

export type VerificationRelationNature =
  | 'MEMBRE_DIRECT'
  | 'ENFANT'
  | 'PARENT'
  | 'FRERE_SOEUR'
  | 'CONJOINT'
  | 'DESCENDANT_ALLIANCE'
  | 'FAMILLE_ALLIEE'
  | 'AUTRE';

export interface VerificationRequest {
  id: string;
  userId?: string;
  applicantName: string;
  applicantFirstName?: string;
  applicantLastName?: string;
  applicantEmail: string;
  applicantPhone: string;
  originFamilyName: string;
  claimedFamilyType: 'NZALA_DIRECT' | 'FAMILLE_ALLIEE';
  affiliationOption?: AffiliationOption;
  targetNzalaMemberId?: string;
  targetNzalaMemberName?: string;
  relationshipNature: VerificationRelationNature;
  branchOrTown?: string;
  explanation: string;
  references?: string;
  status: VerificationStatus;
  reviewerNotes?: string;      // Notes internes du validateur (non publiques)
  publicFeedback?: string;     // Message adressé au demandeur (ex: demande de complément)
  reviewedBy?: string;
  reviewedByName?: string;
  reviewedAt?: string;
  assignedTo?: string;
  assignedToName?: string;
  createdAt: string;
  updatedAt: string;
}

// --- 7. USER ACCOUNT & AUTHENTICATION ---
export type UserRole =
  | 'SUPER_ADMIN'
  | 'ADMIN_FAMILIAL'
  | 'VALIDATEUR'
  | 'MEMBRE_NZALA'
  | 'MEMBRE_ALLIE'
  | 'VISITEUR';

export type AccountStatus = 'COMPTE_CREE' | 'ACTIF' | 'SUSPENDU';
export type AffiliationStatus =
  | 'NON_DEPOSEE'
  | 'EN_ATTENTE'
  | 'EN_VERIFICATION'
  | 'COMPLEMENT_REQUIS'
  | 'APPROUVEE'
  | 'REFUSEE';

export interface UserAccount {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
  passwordHash?: string;
  role: UserRole;
  accountStatus: AccountStatus;
  affiliationStatus: AffiliationStatus;
  isEmailVerified: boolean;
  twoFactorEnabled: boolean;
  isVerified?: boolean;
  verifiedBadge?: string;
  avatarUrl?: string;
  avatarVideoUrl?: string;
  bio?: string;
  memberId?: string; // Lien direct vers la fiche Member correspondante
  primaryFamilyId?: string;
  primaryFamilyName?: string;
  branchId?: string;
  branchName?: string;
  familyType?: 'NZALA_DIRECT' | 'ALLIE';
  createdAt: string;
  lastLoginAt?: string;
}

export type User = UserAccount;

export interface CurrentUser {
  id: string;
  name: string;
  firstName?: string;
  lastName?: string;
  email: string;
  phone?: string;
  role: UserRole;
  accountStatus?: AccountStatus;
  affiliationStatus?: AffiliationStatus;
  isEmailVerified?: boolean;
  twoFactorEnabled?: boolean;
  isVerified?: boolean;
  verifiedBadge?: string;
  avatarUrl?: string;
  avatar?: string;
  avatarVideoUrl?: string;
  bio?: string;
  memberId?: string;
  familyId?: string;
  familyName?: string;
  branchId?: string;
  branchName?: string;
  familyType?: 'NZALA_DIRECT' | 'ALLIE';
  verificationStatus?: VerificationStatus;
}

// --- 8. AUDIT LOG MODEL ---
export type AuditActionType = 
  | 'VALIDATION' 
  | 'MEMBER' 
  | 'RELATIONSHIP' 
  | 'ALLIANCE' 
  | 'FAMILY' 
  | 'BRANCH' 
  | 'SECURITY' 
  | 'ROLE_CHANGE'
  | 'EVENT'
  | 'INVITATION'
  | 'POST'
  | 'COMMENT'
  | 'MODERATION';

export type AuditTargetType = 
  | 'VERIFICATION_REQUEST' 
  | 'MEMBER' 
  | 'RELATIONSHIP' 
  | 'ALLIANCE' 
  | 'FAMILY' 
  | 'BRANCH' 
  | 'USER'
  | 'EVENT'
  | 'INVITATION'
  | 'POST'
  | 'COMMENT';

export interface AuditLog {
  id: string;
  actorName: string;
  actorRole: UserRole;
  action: string;
  actionType: AuditActionType;
  targetType: AuditTargetType;
  targetId: string;
  targetName: string;
  details: string;
  timestamp: string;
}

// --- 9. FAMILY FEED & PUBLICATIONS MODEL (FIL FAMILIAL) ---
export type PostType =
  | 'ANNONCE'
  | 'COMMUNIQUE_OFFICIEL'
  | 'ACTUALITE_FAMILIALE'
  | 'FELICITATION'
  | 'NAISSANCE'
  | 'MARIAGE'
  | 'DECES_COMMUNIQUE'
  | 'ANNIVERSAIRE'
  | 'EVENEMENT'
  | 'MEMOIRE_FAMILIALE'
  | 'AUTRE';

export type PostScope =
  | 'NZALA_INTERNE'
  | 'BRANCHE'
  | 'FAMILLE_ALLIEE'
  | 'INTER_FAMILLES'
  | 'PUBLIC'
  | 'PRIVE';

export type PostStatus =
  | 'BROUILLON'
  | 'PUBLIE'
  | 'ARCHIVE'
  | 'SUSPENDU';

export type PostModerationStatus =
  | 'EN_ATTENTE_MODERATION'
  | 'APPROUVE'
  | 'REFUSE';

export type AuthorType =
  | 'MEMBRE'
  | 'ADMIN'
  | 'CONSEIL_FAMILLE'
  | 'OFFICIEL_NZALA';

export type ReactionType =
  | 'LIKE'     // ❤️ J'aime
  | 'SUPPORT'  // 🙏 Soutien
  | 'CONGRATS' // 🎉 Félicitations
  | 'HOMAGE'   // 🕊️ Hommage
  | 'BRAVO'    // 👏 Bravo
  | 'JOY';     // 😂 Joie

export type MediaType = 'IMAGE' | 'VIDEO' | 'AUDIO' | 'DOCUMENT';

export interface MediaItem {
  id: string;
  type: MediaType;
  url: string;
  thumbnailUrl?: string;
  caption?: string;
  fileName?: string;
  fileSize?: number;
  mimeType?: string;
  width?: number;
  height?: number;
  duration?: number; // secondes pour audio / vidéo
  createdAt?: string;
}

export interface LinkPreview {
  url: string;
  domain: string;
  title: string;
  description?: string;
  imageUrl?: string;
}

export interface MemberMention {
  memberId: string;
  memberName: string;
  memberAvatar?: string;
  startIndex?: number;
  endIndex?: number;
}

export interface PostReaction {
  id: string;
  postId: string;
  userId: string;
  memberId?: string;
  userName: string;
  userFamilyName?: string;
  reactionType: ReactionType;
  createdAt: string;
}

export interface PostComment {
  id: string;
  postId: string;
  authorId: string;
  authorMemberId?: string;
  authorName: string;
  authorRole: UserRole;
  authorAvatar?: string;
  authorFamilyName?: string;
  content: string;
  parentCommentId?: string; // Support des réponses imbriquées (threads)
  status: 'ACTIF' | 'MASQUE' | 'SUPPRIME';
  isReported?: boolean;
  reportCount?: number;
  reportReason?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface FamilyPost {
  id: string;
  title?: string;
  content: string;
  summary?: string;
  postType: PostType;
  scope: PostScope;
  status: PostStatus;
  moderationStatus: PostModerationStatus;
  
  // Auteur
  authorId: string;
  authorName: string;
  authorRole: UserRole;
  authorAvatar?: string;
  authorType: AuthorType;
  authorFamilyId?: string;
  authorFamilyName?: string;
  authorBranchId?: string;
  authorBranchName?: string;

  // Périmètre & Cibles (famille, branche, alliance)
  targetFamilyId?: string;
  targetFamilyName?: string;
  targetBranchId?: string;
  targetBranchName?: string;
  targetAlliedFamilyId?: string;
  targetAlliedFamilyName?: string;
  targetAllianceId?: string;

  // Liaisons avec Événements ou Membres
  relatedEventId?: string;
  relatedEventTitle?: string;
  relatedMemberId?: string;
  relatedMemberName?: string;

  // Média & Multi-médias
  imageUrl?: string; // compatibilité descendante
  mediaCaption?: string;
  media?: MediaItem[]; // multi-photos, vidéos, clips
  audioTrack?: import('./socialFeatures').FamilyAudioTrack; // Musique / Bande-son attachée
  linkPreview?: LinkPreview; // aperçu de lien web
  mentions?: MemberMention[]; // membres identifiés / mentionnés

  // Partages internes
  sharedPostId?: string;
  sharedPost?: FamilyPost;
  quoteComment?: string;
  sharesCount?: number;

  // Drapeaux & Propriétés
  isOfficial: boolean; // Sceau / Publication officielle du Conseil ou Admin
  isPinned: boolean;   // Épinglée en haut du fil familial
  isImportant?: boolean;

  // Modération & Traçabilité
  moderatedBy?: string;
  moderatedByName?: string;
  moderatedAt?: string;
  moderationDecision?: string; // Motif de refus ou consigne de révision

  // Interactions & Données sociales
  reactions: PostReaction[];
  reactionsCount: number;
  comments: PostComment[];
  commentsCount: number;

  isDemoData?: boolean;
  publishedAt?: string;
  createdAt: string;
  updatedAt: string;
}

// --- 9c. STORIES FAMILIALES (Stories 24h) ---
export type StorySlideType = 'IMAGE' | 'VIDEO' | 'TEXT';

export interface StorySlide {
  id: string;
  type?: StorySlideType;
  mediaType?: 'IMAGE' | 'VIDEO' | 'TEXT' | 'TEXT_ONLY';
  contentUrl?: string;
  mediaUrl?: string;
  textContent?: string;
  text?: string;
  backgroundColor?: string;
  textColor?: string;
  caption?: string;
  durationSeconds?: number;
  durationSec?: number;
  linkUrl?: string;
  linkText?: string;
  createdAt?: string;
}

export interface StoryViewer {
  userId: string;
  userName: string;
  userAvatar?: string;
  viewedAt: string;
}

export interface StoryReaction {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  reaction: '❤️' | '😂' | '😮' | '😢' | '👏' | '🎉' | string;
  createdAt: string;
}

export interface FamilyStory {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar?: string;
  authorRole: UserRole;
  authorFamilyName?: string;
  authorBranchName?: string;
  memberId?: string;
  slides: StorySlide[];
  scope: PostScope;
  targetFamilyId?: string;
  targetBranchId?: string;
  createdAt: string;
  expiresAt: string; // ISO timestamp (24h après création)
  viewedByUserIds: string[];
  views?: StoryViewer[];
  reactions?: StoryReaction[];
  isAuthorVerified?: boolean;
  authorVerifiedBadge?: string;
  isDemoData?: boolean;
}

// --- 9d. MON STATUT FAMILIAL (Statuts éphémères & humeurs) ---
export interface FamilyStatusItem {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar?: string;
  authorRole: UserRole;
  authorFamilyName?: string;
  authorBranchName?: string;
  memberId?: string;
  text?: string;
  moodEmoji?: string;
  moodLabel?: string;
  media?: MediaItem;
  scope: PostScope;
  targetFamilyId?: string;
  targetBranchId?: string;
  createdAt: string;
  expiresAt?: string;
  reactions?: PostReaction[];
  isDemoData?: boolean;
}

// Profil Tab Type
export type ProfileActiveTab = 'APERCU' | 'PUBLICATIONS' | 'PHOTOS' | 'VIDEOS' | 'EVENEMENTS' | 'FAMILLE';

// --- 9b. ANNOUNCEMENTS (Rétrocompatibilité) ---
export interface FamilyAnnouncement {
  id: string;
  title: string;
  content: string;
  authorName: string;
  authorFamily: string;
  authorAvatar?: string;
  category: 'COMMUNIQUE_OFFICIEL' | 'MARIAGE' | 'NAISSANCE' | 'NECROLOGIE' | 'REUNION' | 'CELEBRATION';
  visibility: 'NZALA_SEULEMENT' | 'TOUTES_FAMILLES';
  isImportant?: boolean;
  publishedAt: string;
  commentsCount: number;
  reactionsCount: number;
}

// --- 10. ADVANCED FAMILY EVENT & CALENDAR SYSTEM ---
export type EventType =
  | 'ANNIVERSAIRE'
  | 'REUNION_FAMILIALE'
  | 'CONSEIL_FAMILLE'
  | 'MARIAGE'
  | 'NAISSANCE'
  | 'CEREMONIE'
  | 'COMMEMORATION'
  | 'RENCONTRE_ALLIANCE'
  | 'AUTRE';

export type EventVisibility =
  | 'NZALA_INTERNE'
  | 'FAMILLE_ALLIEE'
  | 'INTER_FAMILLES'
  | 'PUBLIC'
  | 'PRIVE';

export type EventStatus =
  | 'PLANIFIE'
  | 'EN_COURS'
  | 'TERMINE'
  | 'ANNULE'
  | 'REPORTE';

export type InvitationStatus =
  | 'INVITE'
  | 'CONFIRME'
  | 'DECLINE'
  | 'PEUT_ETRE';

export type InvitationTargetType =
  | 'PERSON'
  | 'BRANCH'
  | 'FAMILY'
  | 'ALLIED_FAMILY'
  | 'COUNCIL_MEMBERS';

export interface EventInvitation {
  id: string;
  eventId: string;
  targetType: InvitationTargetType;
  targetId?: string;
  targetName: string;
  userId?: string;
  memberId?: string;
  userEmail?: string;
  status: InvitationStatus;
  responseNote?: string;
  respondedAt?: string;
  invitedAt: string;
  invitedBy: string;
}

export interface EventReminderConfig {
  daysBefore: number;
  label: string;
  isActive: boolean;
}

export interface AgendaItem {
  id: string;
  time?: string;
  title: string;
  description?: string;
  presenter?: string;
}

export interface FamilyEvent {
  id: string;
  title: string;
  description: string;
  eventType: EventType;
  visibility: EventVisibility;
  startDate: string; // YYYY-MM-DD
  endDate?: string;   // YYYY-MM-DD
  startTime?: string; // HH:mm
  endTime?: string;   // HH:mm
  location: string;
  addressDetails?: string;
  isVirtual?: boolean;
  virtualLink?: string;
  organizerId: string;
  organizerName: string;
  organizerFamily: string;
  organizerAvatar?: string;
  familyId?: string;       // e.g. 'fam-nzala'
  alliedFamilyId?: string; // e.g. 'fam-mavungu'
  alliedFamilyName?: string;
  allianceId?: string;
  branchId?: string;
  branchName?: string;
  status: EventStatus;
  agenda?: AgendaItem[];
  isConfidential?: boolean; // Spécial CONSEIL_FAMILLE
  maxParticipants?: number;
  participantsCount: number;
  reminders?: EventReminderConfig[];
  invitations?: EventInvitation[];
  isDemoData?: boolean;
  relatedMemberId?: string; // Si lié à un anniversaire ou hommage
  relatedMemberName?: string;
  createdAt: string;
  updatedAt: string;
  // Compatibilité ascendante
  date?: string;
  category?: string;
}

export type BirthdayPrivacy = 'PUBLIC' | 'FAMILY_ONLY' | 'MONTH_DAY_ONLY' | 'PRIVATE';

export interface UpcomingBirthday {
  memberId: string;
  firstName: string;
  lastName: string;
  fullName: string;
  avatarUrl?: string;
  birthDate: string; // YYYY-MM-DD
  birthMonth: number; // 0-11
  birthDay: number;   // 1-31
  daysUntil: number;
  formattedDate: string;
  ageNext?: number;
  showAge: boolean;
  primaryFamilyName: string;
  primaryFamilyId: string;
  familyType: 'NZALA_DIRECT' | 'ALLIE';
  branchName?: string;
  branchId?: string;
  livingStatus: LivingStatus;
  privacyLevel: BirthdayPrivacy;
}

// --- 11. HISTORICAL MEMORY & ARCHIVES (MÉMOIRE NZALA) ---
export type MemoryAlbumCategory =
  | 'FONDATEURS'
  | 'ANCIENNES_GENERATIONS'
  | 'MARIAGES_ANCIENS'
  | 'CEREMONIES'
  | 'REUNIONS_HISTORIQUES'
  | 'DIASPORA'
  | 'ARCHIVES_DOCUMENTAIRES'
  | 'HOMMAGES';

export interface MemoryAlbum {
  id: string;
  title: string;
  description: string;
  category: MemoryAlbumCategory;
  coverUrl?: string;
  photoCount: number;
  photos: MediaItem[];
  historicalEra?: string; // e.g. "1940 - 1975"
  curatorName?: string;
  curatorRole?: string;
  isOfficial: boolean;
  relatedPersonIds?: string[];
  createdAt: string;
}

export interface HistoricalPublication {
  id: string;
  title: string;
  historicalPeriod: string;
  location?: string;
  summary: string;
  fullNarrative: string;
  relatedPersonNames: string[];
  relatedPersonIds?: string[];
  photos: MediaItem[];
  sources: string[];
  verifiedByCouncil: boolean;
  publishedAt: string;
  authorName: string;
  authorRole: string;
  likesCount: number;
  commentsCount: number;
}

export interface BirthdayCelebrationDraft {
  personId: string;
  personName: string;
  avatarUrl?: string;
  branchName?: string;
  familyType: 'NZALA_DIRECT' | 'ALLIE';
  birthDate: string;
  age?: number;
  suggestedMessage: string;
  isDeceasedHonor?: boolean;
}

export * from './messaging';
export * from './calls';
export * from './notifications';
export * from './moderation';
export * from './socialFeatures';
export * from './search';

