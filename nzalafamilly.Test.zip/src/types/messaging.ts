/**
 * NzalaFamilly - Modèles TypeScript pour le module de Messagerie Privée (NZALA MESSAGES)
 */

export type ConversationType = 'DIRECT' | 'GROUP';
export type ConversationStatus = 'ACTIVE' | 'ARCHIVED' | 'BLOCKED';
export type MessageDeliveryStatus = 'ENVOI' | 'ENVOYE' | 'LIVRE' | 'LU' | 'ERREUR';
export type MessageMediaType = 'NONE' | 'IMAGE' | 'VIDEO' | 'AUDIO' | 'FILE' | 'SHARED_POST' | 'SHARED_EVENT';
export type PresenceStatus = 'EN_LIGNE' | 'ABSENT' | 'HORS_LIGNE' | 'OCCUPE';

export interface MessageReaction {
  id: string;
  messageId: string;
  userId: string;
  userName: string;
  emoji: string; // '❤️' | '😂' | '🙏' | '👏' | '🎉' | '🕊️' | '👍' etc.
  createdAt: string;
}

export interface MessageAttachment {
  id: string;
  type: 'IMAGE' | 'VIDEO' | 'AUDIO' | 'FILE';
  url: string;
  fileName?: string;
  fileSize?: number; // En octets
  mimeType?: string;
  durationSec?: number; // Pour audio / vidéo
  caption?: string;
  thumbnailUrl?: string;
  isViewOnce?: boolean;
  viewOnceState?: 'UNOPENED' | 'VIEWED' | 'EXPIRED';
  viewOnceOpenedAt?: string;
  viewOnceOpenedByUserId?: string;
}

export interface QuotedMessage {
  id: string;
  senderId: string;
  senderName: string;
  content: string;
  mediaType?: MessageMediaType;
  mediaCaption?: string;
  thumbnailUrl?: string;
}

export interface SharedPostSummary {
  postId: string;
  title?: string;
  content: string;
  authorName: string;
  authorFamilyName?: string;
  publishedAt: string;
  firstImageUrl?: string;
  postType: string;
  scope: string;
}

export interface SharedEventSummary {
  eventId: string;
  title: string;
  startDate: string;
  location: string;
  eventType: string;
  organizerName: string;
}

export interface FamilyMessage {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  senderRole?: string;
  senderFamilyName?: string;
  isSenderVerified?: boolean;
  senderVerifiedBadge?: string;
  content: string;
  translatedContent?: string;
  translatedLanguage?: string;
  mediaType: MessageMediaType;
  attachments?: MessageAttachment[];
  isViewOnce?: boolean;
  viewOnceState?: 'UNOPENED' | 'VIEWED' | 'EXPIRED';
  viewOnceOpenedAt?: string;
  viewOnceOpenedByUserId?: string;
  viewOnceOpenedByUserName?: string;
  quotedMessage?: QuotedMessage;
  sharedPost?: SharedPostSummary;
  sharedEvent?: SharedEventSummary;
  reactions: MessageReaction[];
  mentions?: string[]; // IDs des utilisateurs ou @noms
  status: MessageDeliveryStatus;
  readByUserIds: string[];
  isEdited?: boolean;
  editedAt?: string;
  isDeleted?: boolean;
  deletedForUserIds?: string[];
  createdAt: string;
  updatedAt?: string;
}

export interface ConversationParticipant {
  userId: string;
  userName: string;
  userAvatar?: string;
  role: 'ADMIN' | 'MEMBER';
  joinedAt: string;
  lastReadMessageId?: string;
  unreadCount: number;
  familyName?: string;
  branchName?: string;
  isMuted?: boolean;
  isBlocked?: boolean;
}

export interface FamilyConversation {
  id: string;
  type: ConversationType;
  title?: string; // Nom du groupe ou null si direct
  avatarUrl?: string;
  description?: string;
  participants: ConversationParticipant[];
  participantIds: string[];
  admins: string[]; // User IDs des admins du groupe
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  lastMessage?: {
    id: string;
    content: string;
    senderId: string;
    senderName: string;
    createdAt: string;
    mediaType?: MessageMediaType;
    status?: MessageDeliveryStatus;
  };
  isPinned?: boolean;
  isArchived?: boolean;
  isCouncilGroup?: boolean; // Spécial Conseil de Famille (réservé SUPER_ADMIN, ADMIN_FAMILIAL, sages)
  relatedFamilyId?: string;
  relatedFamilyName?: string;
  relatedBranchId?: string;
  relatedBranchName?: string;
  relatedAlliedFamilyId?: string;
  relatedAlliedFamilyName?: string;
  relatedAllianceId?: string;
  relatedAllianceName?: string;
  relatedEventId?: string;
  relatedEventTitle?: string;
}

export interface UserPresence {
  userId: string;
  userName: string;
  status: PresenceStatus;
  lastSeen: string;
  showOnlineStatus: boolean;
  customStatusText?: string;
}

export type MessageReportReason = 'HARCELEMENT' | 'CONTENU_INAPPROPRIE' | 'SPAM' | 'USURPATION' | 'AUTRE';

export interface MessageReport {
  id: string;
  conversationId: string;
  messageId?: string;
  reportedUserId: string;
  reportedUserName: string;
  reporterUserId: string;
  reporterUserName: string;
  reason: MessageReportReason;
  details?: string;
  createdAt: string;
  status: 'EN_ATTENTE' | 'TRAITE' | 'REJETE';
}

export interface BlockedContact {
  id: string;
  userId: string;
  blockedUserId: string;
  blockedUserName: string;
  blockedAt: string;
  reason?: string;
}
