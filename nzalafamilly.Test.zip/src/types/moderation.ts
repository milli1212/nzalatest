/**
 * NzalaFamilly - Modèles TypeScript pour la Modération Unifiée, Signalements & Blocage
 */

export type ReportCategory =
  | 'SPAM'
  | 'COMPORTEMENT_ABUSIF'
  | 'CONTENU_INAPPROPRIE'
  | 'USURPATION'
  | 'AUTRE';

export type ReportTargetType =
  | 'MEMBRE'
  | 'PUBLICATION'
  | 'COMMENTAIRE'
  | 'STORY'
  | 'MESSAGE'
  | 'GROUPE';

export interface SocialReport {
  id: string;
  reporterId: string;
  reporterName: string;
  targetType: ReportTargetType;
  targetId: string;
  targetTitle?: string;
  reportedUserId?: string;
  reportedUserName?: string;
  category: ReportCategory;
  description: string;
  status: 'EN_ATTENTE' | 'TRAITE' | 'REJETE';
  createdAt: string;
  resolutionNotes?: string;
  resolvedBy?: string;
  resolvedAt?: string;
}
