/**
 * NzalaFamilly - Modèles TypeScript pour le Centre de Notifications Centralisé & Intelligent
 */

export type NotificationCategory =
  | 'ALL'
  | 'UNREAD'
  | 'SOCIAL'
  | 'MESSAGES'
  | 'STORIES'
  | 'EVENTS'
  | 'FAMILY'
  | 'LIVE'
  | 'SECURITY'
  | 'ADMIN'
  | 'SYSTEM';

export type NotificationType =
  // --- SOCIAL (Publications, Réactions, Commentaires, Mentions, Partages) ---
  | 'REACTION'
  | 'COMMENTAIRE'
  | 'REPONSE_COMMENTAIRE'
  | 'MENTION'
  | 'PARTAGE'
  | 'NOUVELLE_PUBLICATION'
  | 'NEW_COMMENT'
  | 'NEW_REACTION'
  | 'PUBLICATION'
  | 'POST_PUBLISHED'

  // --- STORIES ---
  | 'STORY_REACTION'
  | 'STORY_REPLY'
  | 'STORY_MENTION'
  | 'STORY'

  // --- MESSAGERIE & APPELS ---
  | 'MESSAGE'
  | 'MESSAGE_AUDIO'
  | 'MESSAGE_MEDIA'
  | 'MESSAGE_VUE_UNIQUE'
  | 'INVITATION_GROUPE'
  | 'APPEL_ENTRANT'
  | 'APPEL_MANQUE'

  // --- PROFILS PRIVÉS & DEMANDES D'ACCÈS ---
  | 'DEMANDE_ACCES_PROFIL'
  | 'ACCES_PROFIL_ACCEPTE'
  | 'ACCES_PROFIL_REFUSE'
  | 'ACCES_PROFIL_RETIRE'

  // --- AFFILIATION FAMILIALE & ARBRE ---
  | 'AFFILIATION_DOSSIER_RECU'
  | 'AFFILIATION_EN_EXAMEN'
  | 'AFFILIATION_COMPLEMENT'
  | 'AFFILIATION_APPROUVEE'
  | 'AFFILIATION_REFUSEE'
  | 'AFFILIATION_SUSPENDUE'
  | 'AFFILIATION'
  | 'ARBRE_MODIFIE'

  // --- ÉVÉNEMENTS & ANNIVERSAIRES ---
  | 'EVENEMENT_INVITATION'
  | 'EVENEMENT_RAPPEL'
  | 'EVENEMENT_MODIFIE'
  | 'EVENEMENT_ANNULE'
  | 'EVENEMENT_RSVP'
  | 'EVENEMENT'
  | 'ANNIVERSAIRE_JOUR'
  | 'ANNIVERSAIRE_AVENIR'
  | 'ANNIVERSAIRE'

  // --- NZALA LIVE ---
  | 'LIVE_PROGRAMME'
  | 'LIVE_BIENTOT'
  | 'LIVE_EN_COURS'
  | 'LIVE_INVITATION'

  // --- GOUVERNANCE & ADMINISTRATION ---
  | 'ADMIN_NOUVELLE_AFFILIATION'
  | 'ADMIN_DOSSIER_EXAMEN'
  | 'ADMIN_MODERATION_POST'
  | 'ADMIN_SIGNALEMENT'
  | 'ADMIN_TICKET_TECHNIQUE'
  | 'ADMIN_CERTIFICATION'
  | 'GOUVERNANCE'
  | 'MODERATION_UPDATE'
  | 'COUNCIL_ANNOUNCEMENT'

  // --- SÉCURITÉ DU COMPTE ---
  | 'SECURITE_CONNEXION'
  | 'SECURITE_MOT_DE_PASSE'
  | 'SECURITE_PARAMETRES'
  | 'SECURITE_2FA'
  | 'SECURITE_ALERTE'

  // --- NOTIFICATIONS SYSTÈME ---
  | 'SYSTEME_COMMUNIQUE'
  | 'SYSTEME_MAINTENANCE'
  | 'SYSTEME_MISE_A_JOUR'
  | 'OFFICIAL_COMMUNIQUE';

export type NotificationTargetType =
  | 'POST'
  | 'EVENT'
  | 'CONVERSATION'
  | 'CALL'
  | 'PROFILE'
  | 'VERIFICATION'
  | 'STORY'
  | 'LIVE'
  | 'ADMIN'
  | 'ISSUE_REPORT'
  | 'SETTINGS';

export interface NotificationMetadata {
  reactionType?: 'LIKE' | 'SUPPORT' | 'CELEBRATION' | 'HOMAGE' | 'LOVE';
  reactionEmoji?: string;
  count?: number; // Pour les notifications regroupées (ex: 4 nouveaux messages, 5 réactions)
  actorIds?: string[];
  actorNames?: string[];
  postScope?: string;
  liveScope?: string;
  requestId?: string;
  reportId?: string;
  eventDate?: string;
  birthdayDate?: string;
  birthdayMemberName?: string;
  viewOnce?: boolean;
  securityDevice?: string;
  securityIpMasked?: string;
  securityLocation?: string;
  quickActionState?: 'PENDING' | 'ACCEPTED' | 'REJECTED';
  isOfficialAnnouncement?: boolean;
  priority?: 'NORMALE' | 'HAUTE' | 'URGENTE';
}

export interface FamilyNotification {
  id: string;
  userId: string; // 'all' ou identifiant utilisateur destinataire
  category: NotificationCategory;
  type: NotificationType;
  title: string;
  body: string;
  targetId?: string;
  targetType?: NotificationTargetType;
  senderId?: string;
  senderName?: string;
  senderAvatar?: string;
  senderVerifiedBadge?: string;
  senderRole?: string;
  read: boolean;
  isRead?: boolean;
  createdAt: string;
  readAt?: string;
  linkTab?: string;
  actionUrl?: string;
  thumbnailUrl?: string;
  metadata?: NotificationMetadata;

  // Compatibilité ascendante
  link?: string;
  targetPostId?: string;
  recipientUserId?: string;
  message?: string;
}

import { SearchVisibilitySettings } from './search';

export type PrivacyAudience =
  | 'TOUS_AUTORISES'
  | 'FAMILLE_SEULEMENT'
  | 'FAMILLES_ALLIEES'
  | 'RELATIONS_AUTORISEES'
  | 'PERSONNE';

export interface UserPrivacySettings {
  whoCanMessageMe: PrivacyAudience;
  whoCanCallMe: PrivacyAudience;
  whoCanSeeOnlineStatus: PrivacyAudience;
  whoCanSeeStories: PrivacyAudience;
  whoCanSeePosts: PrivacyAudience;
  whoCanMentionMe: PrivacyAudience;
  showOnlineStatus: boolean;
  showReadReceipts: boolean;
  searchVisibility?: SearchVisibilitySettings;
}

export interface NotificationPreferences {
  messages: boolean;
  stories: boolean;
  publications: boolean;
  events: boolean;
  birthdays: boolean;
  calls: boolean;
  governance: boolean;
  security: boolean;
  system: boolean;
  soundEnabled: boolean;
  pushEnabled: boolean; // Préparé pour Web Push / FCM
}

