/**
 * NzalaFamilly - Types pour le Système de Recherche Globale, Découverte & Confidentialité
 */

import {
  Member,
  Family,
  FamilyBranch,
  FamilyPost,
  FamilyEvent,
  FamilyStory,
  FamilyAnnouncement,
  UpcomingBirthday,
  UserRole,
  VisibilityLevel,
  PostScope,
} from './index';
import { LiveStream } from './socialFeatures';

export type SearchCategory =
  | 'ALL'
  | 'MEMBERS'
  | 'FAMILIES'
  | 'GENEALOGY'
  | 'POSTS'
  | 'EVENTS'
  | 'LIVES'
  | 'STORIES'
  | 'MEMORY';

export type SearchResultType =
  | 'MEMBER'
  | 'FAMILY'
  | 'BRANCH'
  | 'GENEALOGY_NODE'
  | 'POST'
  | 'EVENT'
  | 'LIVE'
  | 'STORY'
  | 'MEMORY_ALBUM'
  | 'HISTORICAL_FIGURE';

export interface SearchResult {
  id: string;
  type: SearchResultType;
  category: SearchCategory;
  title: string;
  subtitle?: string;
  description?: string;
  avatarUrl?: string;
  thumbnailUrl?: string;
  badge?: string;
  badgeColor?: 'blue' | 'amber' | 'emerald' | 'purple' | 'rose' | 'slate';
  linkTab: string;
  targetId: string;
  relevanceScore: number;
  highlightText?: string;
  isVerified?: boolean;
  isOfficial?: boolean;
  isLive?: boolean;
  date?: string;
  metadata?: {
    familyId?: string;
    familyName?: string;
    branchId?: string;
    branchName?: string;
    generationLevel?: number;
    livingStatus?: string;
    belongingType?: string;
    postType?: string;
    eventType?: string;
    eventStatus?: string;
    hostName?: string;
    viewersCount?: number;
    participantsCount?: number;
    location?: string;
    tags?: string[];
  };
}

export interface SearchCategoryGroup {
  category: SearchCategory;
  label: string;
  iconName: string;
  count: number;
  results: SearchResult[];
}

export interface SearchFilters {
  category?: SearchCategory;
  // Membres & Généalogie
  familyId?: string;
  branchId?: string;
  generationLevel?: number | 'ALL';
  livingStatus?: 'ALL' | 'VIVANT' | 'DECEDE';
  belongingType?: string;
  memberStatus?: string;
  // Publications
  authorId?: string;
  postType?: string;
  postScope?: PostScope | 'ALL';
  period?: 'ALL' | 'TODAY' | 'WEEK' | 'MONTH' | 'YEAR';
  // Événements
  eventType?: string;
  eventPeriod?: 'ALL' | 'UPCOMING' | 'THIS_WEEK' | 'THIS_MONTH' | 'PAST';
  eventVisibility?: string;
}

export interface SearchHistoryItem {
  id: string;
  query: string;
  category: SearchCategory;
  timestamp: string;
  resultsCount?: number;
}

export interface SmartSuggestion {
  id: string;
  title: string;
  subtitle: string;
  icon: string;
  category: SearchCategory;
  actionType: 'NAVIGATE' | 'SEARCH_PRESET' | 'FILTER';
  targetTab?: string;
  targetId?: string;
  presetQuery?: string;
  presetFilter?: Partial<SearchFilters>;
}

export interface SearchVisibilitySettings {
  showInSearch: boolean;
  showNameInSearch: boolean;
  showPhotoInSearch: boolean;
  showFamilyInSearch: boolean;
  showBranchInSearch: boolean;
  showGenerationInSearch: boolean;
  showBioInSearch: boolean;
  showBirthdayInSearch: boolean;
  showLocationInSearch: boolean;
  showContactInSearch: boolean;
}

export const DEFAULT_SEARCH_VISIBILITY_SETTINGS: SearchVisibilitySettings = {
  showInSearch: true,
  showNameInSearch: true,
  showPhotoInSearch: true,
  showFamilyInSearch: true,
  showBranchInSearch: true,
  showGenerationInSearch: true,
  showBioInSearch: false,
  showBirthdayInSearch: false,
  showLocationInSearch: false,
  showContactInSearch: false,
};
