/**
 * NzalaFamilly - Modèles étendus pour les nouvelles fonctionnalités sociales, de sécurité et d'administration
 */

import { UserRole, PostScope, MediaItem } from './index';

// --- 1. MESSAGES À VUE UNIQUE ---
export type ViewOnceState = 'UNOPENED' | 'VIEWED' | 'EXPIRED';

export interface ViewOnceMetadata {
  isViewOnce: boolean;
  viewOnceState: ViewOnceState;
  openedAt?: string;
  openedByUserId?: string;
  openedByUserName?: string;
  expiresAfterSeconds?: number;
  screenshotAttemptDetected?: boolean;
}

// --- 2. TRADUCTION DES MESSAGES ---
export type SupportedLanguage = 'fr' | 'ln' | 'sw' | 'en' | 'es' | 'pt' | 'ar';

export interface LanguageInfo {
  code: SupportedLanguage;
  name: string;
  nativeName: string;
  flag: string;
}

export interface MessageTranslation {
  originalText: string;
  sourceLanguage: SupportedLanguage | string;
  targetLanguage: SupportedLanguage;
  translatedText: string;
  confidenceScore?: number;
  translatedAt: string;
}

// --- 3. FONCTIONNALITÉ LIVE (DIFFUSIONS EN DIRECT) ---
export type LiveStatus = 'SCHEDULED' | 'LIVE' | 'ENDED' | 'CANCELLED';

export interface LiveComment {
  id: string;
  liveId: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  userRole: UserRole;
  isVerified?: boolean;
  verifiedBadge?: string;
  content: string;
  isHost?: boolean;
  isPinned?: boolean;
  isDeleted?: boolean;
  createdAt: string;
}

export interface LiveReaction {
  id: string;
  emoji: string;
  userId: string;
  userName: string;
  timestamp: number;
}

export interface LiveStream {
  id: string;
  title: string;
  description?: string;
  hostUserId: string;
  hostName: string;
  hostAvatar?: string;
  hostRole: UserRole;
  hostFamilyName?: string;
  isHostVerified?: boolean;
  hostVerifiedBadge?: string;
  status: LiveStatus;
  scope: PostScope;
  targetFamilyId?: string;
  targetFamilyName?: string;
  targetBranchId?: string;
  targetBranchName?: string;
  scheduledFor?: string; // Date ISO si programmé
  startedAt?: string;
  endedAt?: string;
  viewersCount: number;
  maxViewersReached?: number;
  thumbnailUrl?: string;
  streamVideoUrl?: string;
  isMicOn: boolean;
  isCameraOn: boolean;
  allowComments: boolean;
  comments: LiveComment[];
  reactionsCount: Record<string, number>;
  recordedPlaybackUrl?: string;
  kickedUserIds?: string[];
  createdAt: string;
  updatedAt: string;
}

// --- 4. CERTIFICATION DES COMPTES ADMINISTRATIFS & OFFICIELS ---
export type CertificationType =
  | 'SUPER_ADMIN'
  | 'ADMIN_FAMILIAL'
  | 'MODERATEUR'
  | 'RESPONSABLE_OFFICIEL'
  | 'SAGE_CONSEIL';

export interface AccountCertification {
  id: string;
  userId: string;
  userName: string;
  userEmail?: string;
  userRole: UserRole;
  familyName?: string;
  branchName?: string;
  certificationType: CertificationType;
  badgeLabel: string; // e.g. "Conseil des Sages Nzala", "Administrateur Familial Certifié"
  icon: string; // e.g. "👑", "🛡️", "📜"
  badgeColor?: string; // e.g. "#EC4899" (Pink for Super Admin), "#2563EB" (Nzala Blue), "#D97706" (Gold), etc.
  reason: string;
  certifiedByUserId: string;
  certifiedByUserName: string;
  certifiedAt: string;
  isActive: boolean;
  revokedAt?: string;
  revokedReason?: string;
}

export interface CertificationColorRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail?: string;
  userRole: UserRole;
  currentCertificationId?: string;
  requestedColor: string;
  requestedLabel?: string;
  reason: string;
  status: 'EN_ATTENTE' | 'APPROUVEE' | 'REFUSEE';
  adminDecisionNotes?: string;
  reviewedByUserId?: string;
  reviewedByUserName?: string;
  reviewedAt?: string;
  createdAt: string;
}

// --- 5. SIGNALEMENT DE PROBLÈMES TECHNIQUES & ASSISTANCE ---
export type IssueCategory =
  | 'BUG_TECHNIQUE'
  | 'COMPTE'
  | 'MESSAGERIE'
  | 'PUBLICATION'
  | 'LIVE_VIDEO'
  | 'SECURITE'
  | 'AUTRE';

export type IssueStatus = 'NOUVEAU' | 'EN_COURS' | 'RESOLU' | 'REJETE';
export type IssuePriority = 'BASSE' | 'NORMALE' | 'HAUTE' | 'URGENTE';

export interface IssueReport {
  id: string;
  reporterUserId: string;
  reporterName: string;
  reporterEmail?: string;
  reporterAvatar?: string;
  category: IssueCategory;
  priority: IssuePriority;
  title: string;
  description: string;
  attachments?: MediaItem[];
  deviceInfo?: string;
  status: IssueStatus;
  adminNotes?: string;
  handledByUserId?: string;
  handledByUserName?: string;
  resolvedAt?: string;
  createdAt: string;
  updatedAt: string;
}

// --- 6. AUDIO & BANDES SONORES POUR PUBLICATIONS ---
export interface FamilyAudioTrack {
  id: string;
  title: string;
  artistOrTradition: string;
  category: 'TRADITIONNEL' | 'CELEBRATION' | 'MEMOIRE' | 'AMBIANCE' | 'PERSONNEL';
  url: string;
  durationSec: number;
  coverUrl?: string;
}
